<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                           <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>                            
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                    
                </div>
                
               <div class="row">
                    <div class="col-lg-12">
                        <?php if ($this->session->flashdata('msg')): ?>
                            <div class="alert alert-success alert-dismissible fade-in">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success ! </strong> <?php echo $this->session->flashdata('msg'); ?>
                            </div>
                        <?php endif; ?> 
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                               <form id="form-filter" class="form-horizontal">
                                   <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Business Unit</label>
                                            <select id="businessunit_name" class="form-control"> 
                                                <option value="">All Business Unit</option>
                                                <?php foreach ($form_businessunit as $unit) { ?>
                                                    <option value="<?= $unit->id; ?>"><?= $unit->unitname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Company Name</label>
                                            <select id="company_name" class="form-control custom-select"> 
                                                <option value="">-Select Company-</option>
                                                <?php foreach ($companyname as $company) { ?>
                                                    <option value="<?= $company->id; ?>"><?= $company->company_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>  

                                    <div class="col-lg-3 col-md-4 col-sm-6">  
                                        <div class="form-group">
                                            <label for="control-label">Employee Name</label>
                                            <input type="text" id="userfullname" class="form-control" />
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6">  
                                        <div class="form-group">
                                            <label for="control-label">Employee ID</label>
                                            <input type="text" id="employeeId" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Designation</label>
                                            <select id="designation_name" class="form-control custom-select"> 
                                                <option value="">-Select Designation-</option>
                                                <?php foreach ($position as $designation) { ?>
                                                    <option value="<?= $designation->id; ?>"><?= $designation->positionname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Department</label>
                                            <select id="department_name" class="form-control custom-select"> 
                                                <option value="" class="w-100">-Select Department-</option>
                                                <?php foreach ($departmentname as $dept) { ?>
                                                    <option value="<?= $dept->id; ?>"><?= $dept->deptname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Location/Project Name</label>
                                            <?php $proj = get_all_active_project(); ?>
                                            <select id="project_name" class="form-control custom-select"> 
                                                <option value="">-Select Project-</option>
                                                <?php foreach ($proj as $rrrow) { ?>
                                                    <option value="<?= $rrrow->id; ?>"><?= $rrrow->project_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>     

                                    <div class="col-lg-3 col-md-4 col-sm-6"> 
                                        <div class="form-group">
                                            <label for="control-label">Emp Status</label>
                                            <select id="status_type" name="status_type" class="form-control">
                                                <option value="">-Select Emp Status-</option>
                                                <?php foreach ($emp_sta as $rrrow) { ?>
                                                    <option value="<?= $rrrow->id; ?>"><?= $rrrow->employemnt_status; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="col-lg-3 col-md-4 col-sm-6">
										<div class="mt-md-3 mt-lg-0 pt-md-2 pt-lg-0">
                                        <button type="button" id="btn-filter" class="btn btn-one"> Search </button>   
                                  
                                        <button type="button" id="btn-reset" class="btn btn-success"> Reset </button>   
                                    </div>     
                                    </div>     

                                </div>
                               </form>
                                <br>
                                <br>
                                
                                <div class="row clearfix">
                                    <div class="col-lg-12">
                                        <ul class="nav nav-tabs-new mb-2">
                                            <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#all_report">All</a></li>
                                            <li class="nav-item ml-2"><a class="nav-link " data-toggle="tab" href="#active_report">Active</a></li>
                                            <li class="nav-item ml-2"><a class="nav-link " data-toggle="tab" href="#inactive_report">InActive</a></li>
                                            <li class="nav-item ml-2"><a class="nav-link " data-toggle="tab" href="#notice_report">Notice</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="tab-content">
                                    <div class="tab-pane active show" id="all_report"> 
                                        <div class="table-responsive">
                                            <table id="table_all" class="table table-bordered table-striped table-hover w-100">
                                                <thead>
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                                    <div class="tab-pane" id="active_report">
                                        <div class="table-responsive">
                                             
                                             <table id="table_active" class="table table-bordered table-striped table-hover w-100">
                                                <thead>
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="inactive_report">
                                        <div class="table-responsive">
                                            <table id="table_inactive" class="table table-bordered table-striped table-hover w-100">
                                                <thead>
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Notice Period</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="notice_report">
                                        <div class="table-responsive">
                                            <table id="table_notice" class="table table-bordered table-striped table-hover w-100">
                                                <thead>
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Exit Type</th>
                                                        <th>Notice Period</th>
<!--                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>-->
                                                        <th>last Working Date</th>
<!--                                                        <th>Action</th>-->
                                                    </tr>
                                                </thead>
                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Exit Type</th>
                                                        <th>Notice Period</th>
                                                        <th>last Working Date</th>
<!--                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Employee Status</th>-->
<!--                                                        <th>Action</th>-->
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>     
                            </div> 
                        </div> 
                    </div> 
                </div>
            </div>
        </div>    
        
    </div>


    <div id="add_seperation" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Seperation</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-2">
                            <a href="#"><img class="avatar rounded-circle" src="" alt=""></a>
                        </div>
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">UserName :</label>
                                        <input type="text" disabled="disabled" class="form-control user-name">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Position Name:</label>
                                        <input type="text" disabled="disabled" class="form-control text-muted">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Employee ID :</label>
                                        <input type="text" disabled="disabled" class="form-control emp_id">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Phone:</label>
                                        <input type="text" disabled="disabled" class="form-control phone">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Email :</label>
                                        <input type="text" disabled="disabled" class="form-control email">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">DOJ :</label>
                                        <input type="text" disabled="disabled" class="form-control birthday">
                                    </div> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Io :</label>
                                        <input type="text" disabled="disabled" class="form-control ro">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="label-control">Department :</label>
                                        <input type="text" disabled="disabled" class="form-control dept">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?= form_open(base_url('seperation_add'), array('id' => 'form_seperation', 'method' => 'post', 'novalidate' => 'novalidate')) ?>
                    <div class="row">

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Type of Seperation<span class="text-danger">*</span></label>
                                <select id="type_seperation" name="type_seperation" autocomplete="off" class="form-control">
                                    <option value="">-Select Seperation-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 0) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4" id="resignation">
                            <div class="form-group">
                                <label class="control-label">Resignation<span class="text-danger">*</span></label>
                                <select id="resignation-first" name="resignation" autocomplete="off" class="form-control">
                                    <option value="">-Select Reason-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 1) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4" id="other_resignation_first" style="display:none;">  
                            <div class="form-group">
                                <label class="control-label">For Other resignation <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="other_resignation" id="other_resignation" class="form-control"/>
                            </div>
                        </div>    

                        <div class="col-sm-4" id="resignation-left">
                            <div class="form-group">
                                <label class="control-label">Resignation and Left<span class="text-danger">*</span></label>
                                <select name="resignation-left" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason Left-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 2) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>     

                        <div id="demobilization" class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Demobilization<span class="text-danger">*</span></label>
                                <select name="demobilization" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason demobilization-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 4) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div> 

                        <div class="col-sm-4" id="severance">
                            <div class="form-group">
                                <label class="control-label">Severance<span class="text-danger">*</span></label>
                                <select id="severance-first" name="severance" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason severance-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 3) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>     

                        <div class="col-sm-4" id="other_severance_first"  style="display:none;">  
                            <div class="form-group">
                                <label class="control-label">For Other severance <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="other_severance" id="other_severance" class="form-control"/>
                            </div>
                        </div>    

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Desired for Early Relieving  <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input  type="date" name="early_relieving" id="early_relieving" class="form-control"/></div>
                            </div>
                        </div>

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Desired for Late Relieving  <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="date" name="late_relieving" id="late_relieving" class="form-control"/></div>
                            </div>
                        </div>

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Notice Period <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="notice_period" id="notice_period" value="" class="form-control" readonly/>
                            </div>
                        </div>


                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Last Working date as per notice period <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="date" name="last_working_day" id="last_working_day" value="" class="form-control" readonly/></div>
                            </div>
                        </div>


                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Actual Last Working Date <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="date" name="actual_working_day" id="actual_working_day" value="" class="form-control"/></div>
                            </div>
                        </div>
                        <div class="col-sm-12 text-center">
                            <input type="hidden" value="" name="emp_id" id="ids">
                            <input type="hidden" value="" name="relieving_date" id="relieving_date">
                            <input type="submit" required class="btn btn-one" value="submit">
                        </div>

                    </div>
                    <?= form_close(); ?>  
                </div>  
            </div>
        </div>


    </div>
</div>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
<script type="text/javascript">
    var table_active;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_active = $('#table_active').DataTable({
                    "processing": true, //Feature control the processing indicator.
                    "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('ajax_seperation_active_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.businessunit_name = $('#businessunit_name').val();
                            data.company_name = $('#company_name').val();
                            data.userfullname = $('#userfullname').val();
                            data.employeeId = $('#employeeId').val();
                            data.designation_name = $('#designation_name').val();
                            data.department_name = $('#department_name').val();
                            data.project_name = $('#project_name').val();
                            data.status_type = $('#status_type').val();
                            data.is_active = 1;
    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';

                        },
                             

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('#btn-filter').click(function () { //button filter event click
                    table_active.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_active.ajax.reload();  //just reload table
                });
    });
</script> 
<script type="text/javascript">
    var table_inactive;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_inactive = $('#table_inactive').DataTable({
                    "processing": true, //Feature control the processing indicator.
                    "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('ajax_seperation_inactive_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.businessunit_name = $('#businessunit_name').val();
                            data.company_name = $('#company_name').val();
                            data.userfullname = $('#userfullname').val();
                            data.employeeId = $('#employeeId').val();
                            data.designation_name = $('#designation_name').val();
                            data.department_name = $('#department_name').val();
                            data.project_name = $('#project_name').val();
                            data.status_type = $('#status_type').val();
                            data.isactive = 2;
                            data.isactive1 = 0;
                           // data.isactive = 2;
    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';

                        },
                                

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('#btn-filter').click(function () { //button filter event click
                    table_inactive.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_inactive.ajax.reload();  //just reload table
                });
    });
</script>  
<script type="text/javascript">
    var table_notice;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_notice = $('#table_notice').DataTable({
                    "processing": true, //Feature control the processing indicator.
                    "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('ajax_seperation_notice_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.businessunit_name = $('#businessunit_name').val();
                            data.company_name = $('#company_name').val();
                            data.userfullname = $('#userfullname').val();
                            data.employeeId = $('#employeeId').val();
                            data.designation_name = $('#designation_name').val();
                            data.department_name = $('#department_name').val();
                            data.project_name = $('#project_name').val();
                            data.status_type = $('#status_type').val();
                            //data.is_active = 2;
    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';

                        },
                             

                                
                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('#btn-filter').click(function () { //button filter event click
                    table_notice.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_notice.ajax.reload();  //just reload table
                });
    });
</script>
<script>
    var table_all;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_all = $('#table_all').DataTable({
                    "processing": true, //Feature control the processing indicator.
                    "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('ajax_seperation_all_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.businessunit_name = $('#businessunit_name').val();
                            data.company_name = $('#company_name').val();
                            data.userfullname = $('#userfullname').val();
                            data.employeeId = $('#employeeId').val();
                            data.designation_name = $('#designation_name').val();
                            data.department_name = $('#department_name').val();
                            data.project_name = $('#project_name').val();
                            data.status_type = $('#status_type').val();
    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';


                        },
                               

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //var colvis = new $.fn.dataTable.ColVis(table_all); //initial colvis
                //$('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('#btn-filter').click(function () { //button filter event click
                    table_all.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_all.ajax.reload();  //just reload table
                });
    });
</script>


<script>
    $('#resignation').hide();
    $('#resignation-left').hide();
    $('#severance').hide();
    $('#demobilization').hide();
    $('#type_seperation').on('change', function () {
        var val = $(this).val();
        if (val == '') {
            $('#resignation').hide();
            $('#resignation-left').hide();
            $('#severance').hide();
            $('#demobilization').hide();
            $('#other_resignation_first').hide();
            $('#other_severance_first').hide();
        } else if (val == '1') {
            $('#resignation').show();
            $('#resignation-left').hide();
            $('#severance').hide();
            $('#demobilization').hide();
            $('#other_severance_first').hide();
        } else if (val == '2') {
            $('#resignation-left').show();
            $('#resignation').hide();
            $('#severance').hide();
            $('#demobilization').hide();
            $('#other_resignation_first').hide();
            $('#other_severance_first').hide();
        } else if (val == '3') {
            $('#severance').show();
            $('#resignation').hide();
            $('#resignation-left').hide();
            $('#demobilization').hide();
            $('#other_resignation_first').hide();
        } else if (val == '4') {
            $('#demobilization').show();
            $('#resignation').hide();
            $('#resignation-left').hide();
            $('#severance').hide();
            $('#other_resignation_first').hide();
            $('#other_severance_first').hide();
        }
    });
</script>

<script>
    $('#resignation-first').on('change', function () {
        var resign = $(this).val();
        // alert(resign);
        if (resign == '14')
        {
            $('#other_resignation_first').show();
            $('#other_severance_first').hide();
        } else {
            $('#other_resignation_first').hide();
        }
    });
</script>

<script>
    $('#severance-first').on('change', function () {
        var severance = $(this).val();
        if (severance == '20')
        {
            $('#other_severance_first').show();
            $('#other_resignation_first').hide();
        } else {
            $('#other_severance_first').hide();
        }
    });
</script>

<script>
    function myFunction(id) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('seperation/Seperation_Controller/getDataByid/'); ?>',
            data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'id': id},
            success: function (res) {
                var result = JSON.parse(res);
                $('#ids').val(result.user_id);
                $('#ids').val(result.user_id);
                if (result.profileimg) {
                    $('.avatar').attr('src', '<?= EMPLPROFILENEW; ?>/public/uploads/profile/' + result.profileimg);
                } else {
                    $('.avatar').attr('src', '<?= EMPLPROFILENEW; ?>/public/uploads/profile/user.jpg');
                }
                $('.user-name').val(result.userfullname);
                $('.text-muted').val(result.position_name);
                $('.emp_id').val(result.employeeId);
                $('.phone').val(result.contactnumber);
                $('.email').val(result.emailaddress);
                $('.birthday').val(result.date_of_joining);
                $('.ro').val(result.reporting_manager_name);
                $('.dept').val(result.department_name);
                $('#type_seperation').val(result.type_of_seperation);
                $('#notice_period').val(result.noticeperiod);
                $('#relieving_date').val(result.relieving_date);
    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';

            },
              
        });

    }
</script>
<script>
    /********************calculate last working day according to notice period and default date***/
    $(document).ready(function () {
        $('#type_seperation').on('change', function () {
            var ntpdate = $('#notice_period').val();
            var relievedate = $('#relieving_date').val();
            $.ajax({
                url: '<?php echo base_url('seperation/Seperation_Controller/getactualdate?rperday='); ?>' + relievedate + '&nperday=' + ntpdate,
                type: "GET",
                success: function (resdata) {
                    $('#actual_working_day').val(resdata);
                    $('#last_working_day').val(resdata);
                }
                data:{[csrfName]: csrfHash}, 
            });
        });
    });
</script>
<script type="text/javascript">
    $(function () {
        $("#project_name,#company_name,#designation_name, #department_name").customselect();
    });
</script>
<script>
    $('#early_relieving').datepicker({format: 'mm/dd/yyyy'});
    $('#late_relieving').datepicker({format: 'mm/dd/yyyy'});
    $('#last_working_day').datepicker({format: 'mm/dd/yyyy'});
    $('#actual_working_day').datepicker({format: 'mm/dd/yyyy'});
</script>
<style>
    .custom-select{width:100%!important; padding: 0!important;} 
    .custom-select input{width:100%!important;}
</style>
</body>
<style>
    /* Extra small devices (phones, 600px and down) */
    @media only screen and (max-width: 600px) {
        .modal-dialog {
            max-width: 900px!important;
        }
    }

    /* Small devices (portrait tablets and large phones, 600px and up) */
    @media only screen and (min-width: 600px) {
        .modal-dialog {
            max-width: 1003px!important;
        }
    }

    /* Medium devices (landscape tablets, 768px and up) */
    @media only screen and (min-width: 768px) {
        .modal-dialog {
            max-width: 1003px!important;
        }
    }

    /* Large devices (laptops/desktops, 992px and up) */
    @media only screen and (min-width: 992px) {
        .modal-dialog {
            max-width: 1003px!important;
        }
    }

    /* Extra large devices (large laptops and desktops, 1200px and up) */
    @media only screen and (min-width: 1200px) {
        .modal-dialog {
            max-width: 1003px!important;
        }
    } 
</style>
<style>
    #table_length,  #table1_length,  #table2_length,  #table3_length {
        position: absolute;
        margin-left: 100px !important;
    }

    .table tbody tr td,
    .table tbody th td {
        vertical-align: middle;
        white-space: normal !important;
    }
        .table1 tbody tr td,
    .table1 tbody th td {
        vertical-align: middle;
        white-space: normal !important;
    }
  div.ColVis {
    position: absolute;
    margin-top: -30px;
    margin-left: 26%;
}
ul.nav.nav-tabs-new {
    float: right !important;
    margin: auto;
}
</style>
<style>
    #table_length{margin-left:20px;}
    #table_filter{margin-right:2%;}
    #chatbox {padding: 15px;overflow: scroll;height: 300px;}
    #table1_wrapper {
        width: 94em;
        /*overflow-x: auto;*/
        white-space: nowrap;
    }
    .tablespace {
                padding: 7px 7px !important;
                text-align: left;
            }

            .tab {
                overflow: hidden;
                border: 1px solid #ccc;
                background-color: #f1f1f1;
            }
            /* Style the buttons inside the tab */
            .tab button {
                background-color: inherit;
                float: left;
                border: none;
                outline: none;
                cursor: pointer;
                padding: 14px 16px;
                transition: 0.3s;
                font-size: 17px;
            }
            /* Change background color of buttons on hover */
            .tab button:hover {
                background-color: #ddd;
            }
            /* Create an active/current tablink class */
            .tab button.active {
                background-color: #ccc;
            }
            /* Style the tab content */
            .tabcontent {
                display: none;
                padding: 6px 12px;
                border: 1px solid #ccc;
                border-top: none;
            }
            /* Style the close button */
            .topright {
                float: right;
                cursor: pointer;
                font-size: 28px;
            }
            .topright:hover {color: red;}
            /*        .dt-buttons, .dataTables_filter {
            display: none;
            }*/
            .panel-title a[aria-expanded="true"] {
                background: #1c4e7f!important;
                padding: 10px 30px 10px 10px!important;
                border-radius: 5px!important;
                margin: -15px!important;
            }
            .panel-title a[aria-expanded="true"]:active {
                background: #1c4e7f!important;
                padding: 10px 30px 10px 10px!important;
                border-radius: 5px!important;
                margin: -15px!important;
            }
            .panel-title a[data-toggle="collapse"] {
                padding: 10px 30px 10px 10px!important;
                margin: -15px!important;
            }

            .chosen-container{width:100%!important;}
</style>
<?php $this->load->view('admin/includes/footer'); ?>
</html>