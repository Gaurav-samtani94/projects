<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
#company_data_length{
	float: right !important;
	margin-left: 10px;
}
 
.btn{
	margin: 0 2px 0 2px !important;
}

</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
		<div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
							 
                            <h2 >Employee List  <button type="button" class="btn mb-1 btn-simple btn-sm  pull-right btn-default btn-filter" data-target="10" id="all" onclick="drawTable(this.id)">All</button>
							<button type="button" class="btn mb-1 btn-simple btn-sm btn-success  pull-right btn-filter" data-target="1" id="active" onclick="drawTable(this.id)">Active</button>
							<button type="button" class="btn mb-1 btn-simple btn-sm btn-warning  pull-right btn-filter" data-target="0" id="inactive" onclick="drawTable(this.id)">In Active</button>
							<button type="button" class="btn mb-1 btn-simple btn-sm btn-info  pull-right btn-filter" data-target="3" id="left" onclick="drawTable(this.id)">Left</button>
							<button type="button" class="btn mb-1 btn-simple btn-sm btn-info  pull-right btn-filter" data-target="2" id="resigned" onclick="drawTable(this.id)">Resigned</button>
							 <button type="button" class="btn mb-1 btn-simple btn-sm btn-info  pull-right btn-filter" data-target="4" id="suspended" onclick="drawTable(this.id)">Suspended</button>
							 
							 </h2> 
							 
							 
							 
													
                        </div>
                        <div class="body">
							
							<div class="table-responsive">
							
                                <table id="employeeTable" class="table table-bordered table-hover ">
                                    <thead>
                                        <tr>
										<th></th>
                                            <th>Name</th>
                                            <th>Emp. Code</th>
                                            <th>Department</th>
                                            <th>IO</th>
                                            <th>Action</th>
                                             
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
										<th></th>
                                            <th>Name</th>
                                            <th>Emp. Code</th>
                                            <th>Department</th>
                                            <th>IO</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
									
									
									
									<?php
									
									if (isset($empList)) {
									foreach ($empList as $key => $emp) {
									?>
                                        <tr data-status="<?php $employeeStatus = $emp->employeeStatus ? $emp->employeeStatus : '0'; echo $employeeStatus?>">
											 
											<td><div class="media-object"><img src="../assets/images/xs/<?php echo $emp->profilePic;?>" alt="" width="35px" class="rounded-circle"></div></td>

                                            <td>
											<span style="display: none"><?php if($employeeStatus == "0"){ echo "inactive"; }elseif($employeeStatus == "1"){ echo "active"; }elseif($employeeStatus == "2"){ echo "resigned"; }elseif($employeeStatus == "3"){ echo "left"; }elseif($employeeStatus == "4"){ echo "suspended"; }else{ echo "all"; }?></span><p class="c_name"><?php echo $emp->firstName." ".$emp->lastName;?> <span class="badge badge-default m-l-10 hidden-sm-down"><?php if($employeeStatus == "0"){ echo "inactive"; }elseif($employeeStatus == "1"){ echo "active"; }elseif($employeeStatus == "2"){ echo "resigned"; }elseif($employeeStatus == "3"){ echo "left"; }elseif($employeeStatus == "4"){ echo "suspended"; }?></span></p> </td>
                                            <td><?php echo $emp->employeeCode;?></td>
                                            <td><?php echo $emp->departmentName;?></td>
                                            <td><?php echo $emp->immediateOfficer;?></td>
                                            <td><button class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit" data-toggle="tooltip" data-original-title="Edit"><i class="icon-pencil" aria-hidden="true"></i>
                                            </button></td>
                                             
                                        </tr>
										
									<?php
										}
									}
									?>
                                        
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
		 
						
                    </div>
                </div>
            </div>
        </div>
		
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
    </div>
</body>

  
<script>
    $(document).ready(function () {
      var table = $('#employeeTable').DataTable();
	  $("#active").trigger('click');
     });
	
	function drawTable(val){
		var table = $('#employeeTable').DataTable();
		console.log(val);
		if(val === "all"){
			var filterVar = "";
		}else{
			var filterVar = val;
		}
		
		table.search(filterVar).draw(function(){
			
			
			
		});
	}
	
</script>
<?php $this->load->view('admin/includes/footer'); ?>
 
