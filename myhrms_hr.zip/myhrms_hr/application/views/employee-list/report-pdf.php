<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Offer Letter - CEG</title>
</head>
<body>
 
<div id="container">
<h1 style="text-align: center">Offer Letter - CEG</h1>
<div id="body">
</div>
 
</div>
</body>
</html>