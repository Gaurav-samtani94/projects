<?php
$departments = get_sub_department_names(intval($_GET['edit_id']));
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    .table tbody tr td,
    .table tbody th td {
        white-space: pre-wrap !important;
    }
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="">
                            <?php if ($this->session->flashdata('success_msg')) : ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error_msg')) : ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (validation_errors()) : ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Error ! </strong> <?= validation_errors(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card">
                        <div class="body">
                            <form action="<?= base_url("update_department");?>" method="POST">
                                <input type="hidden" name="edit_id" value="<?=$department_detail->id;?>">
                                <div class="row">
                                    <div class="col-12  mb-3">
                                        <label for="">Sub Departments :</label><br>
                                        <?php 
                                            foreach ($departments as $value)
                                            {
                                                // echo $value->id;
                                                $Active = subDeptEmployeeCountActive($value->id);
                                                $NotActive = subDeptEmployeeCountNotActive($value->id);
                                                
                                        ?>
                                                <input type="checkbox" value="<?= $value->id; ?>" name="subDepartments[]" checked> &nbsp<?= $value->subdepartment;?> ( <span class="text-success">Active :- <?= $Active ?></span> &nbsp <span class="text-danger">Not Active :- <?= $NotActive ?> </span> ) </input><br>
                                        <?php
                                            }
                                        ?>
                                    </div>
                                    <br>
                                    <div class="col-sm-4">
                                        <span id="reqd" class="error_deptname"><?= form_error('deptname'); ?></span>
                                        <label for="">Department Name :</label>
                                        <input type="text" value="<?= set_value('deptname') !=''?set_value('deptname'):$department_detail->deptname;?>" name="deptname" class="form-control">
                                    </div>
                                    <div class="col-sm-4">
                                        <span id="reqd" class="error_deptcode"><?= form_error('deptcode'); ?></span>
                                        <label for="">Department Code :</label>
                                        <input type="text" value="<?= set_value('deptcode') !=''?set_value('deptcode'):$department_detail->deptcode; ?>" name="deptcode" class="form-control">
                                    </div>
                                    <div class="col-sm-4">
                                        <span id="reqd" class="error_startdate"><?= form_error('startdate'); ?></span>
                                    
                                        <label for="">Start Date :</label>
                                        <input type="date" name="startdate"value="<?= set_value('startdate')!=''?set_value('startdate'):$department_detail->startdate?>"  class="form-control">
                                    </div>
                                    <div class="col-sm-12 mt-3">
                                        <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                    
                                        <label for="">Description :</label>
                                       <textarea name="description" id="" cols="5" rows="5" class="form-control"><?= set_value('description')!=''?set_value('description'):$department_detail->description; ?></textarea>
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                        <span id="reqd" class="error_country"><?= form_error('country'); ?></span>
                                   
                                        <label for="">country :</label>
                                      <select name="country" id="country" class="form-control select2" onchange="get_state()">
                                        <option value="">-- Select country --</option>
                                        <?php foreach($countries as $key=>$val)
                                        {
                                            ?>
                                                <option value="<?=$val->id;?>" <?=set_select("country",$val->id);?><?=  $department_detail->country ==$val->id?'selected':''; ?>><?= $val->country_name;?></option>
                                            <?php 
                                        }?>
                                        
                                        </select>
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                        <span id="reqd" class="error_state"><?= form_error('state'); ?></span>
                                   
                                        <label for="">state :</label>
                                        <select name="state" id="state" class="form-control select2" onchange="get_city()">
                                        <option>-- Select State --</option>
                                        <?php if($department_detail->country)
                                        {
                                            $state = getState_country($department_detail->country);
                                            foreach($state as $key=>$val)
                                            {
                                            ?>
                                            <option value="<?= $val->id?>" <?= $department_detail->state==$val->id?'Selected':''?> <?=set_select('state',$val->id);?>><?= $val->state_name?></option>
                                            <?php
                                        }
                                    }?>
                                        <?php if(set_value('country'))
                                        {
                                            $state = getState_country(set_value('country'));
                                            foreach($state as $key=>$val)
                                            {
                                            ?>
                                            <option value="<?= $val->id?>" <?=set_select('state',$val->id);?>><?= $val->state_name?></option>
                                            <?php
                                        }
                                    }?>
                                        </select>
                                      
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_city"><?= form_error('city'); ?></span>
                                        <label for="">city :</label>
                                        <select name="city" id="city" class="form-control">
                                            <option value="">-- select city --</option>
                                            <?php
                                       
                                       if($department_detail->city)
                                       {
                                           $city = getcity_State($department_detail->state);
                                            foreach($city as $key=>$vall)
                                            {
                                               ?>
                                               <option value="<?= $vall->id?>"<?= $department_detail->city==$vall->id?'Selected':''; ?><?= set_select('city',$vall->id)?>><?= $vall->city_name; ?></option>
                                               <?php
                                            }
                                            }?>
                                            <?php
                                       
                                            if(set_value('state'))
                                            {
                                                $city =  getcity_State(set_value('state'));
                                                 foreach($city as $key=>$vall)
                                                 {
                                                    ?>
                                                    <option value="<?= $vall->id?>"<?= set_select('city',$vall->id)?>><?= $vall->city_name; ?></option>
                                                    <?php
                                                 }
                                                 }?>
                                        </select>
                                        <!-- <input type="date" name="city" class="form-control"> -->
                                    </div>

                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_address1"><?= form_error('address1'); ?></span>
                                        <label for="">address1 :</label>
                                      <textarea name="address1" id="" cols="30" rows="10" class="form-control"><?= $department_detail->address1?$department_detail->address1:''?><?= set_value('address1')?></textarea>
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_address2"><?= form_error('address2'); ?></span>
                                        <label for="">address2 :</label>
                                      <textarea name="address2" id="address2" cols="30" rows="10" class="form-control"><?= $department_detail->address2?$department_detail->address2:''?><?= set_value('address2')?></textarea>
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_address3"><?= form_error('address3'); ?></span>
                                      
                                        <label for="">address3 :</label>
                                      <textarea name="address3" id="" cols="30" rows="10" class="form-control"><?= $department_detail->address3?$department_detail->address3:''?><?= set_value('address3')?></textarea>
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_unitid"><?= form_error('unitid'); ?></span>
                                
                                        <label for="">Bussiness Unit :</label>
                                        <select name="unitid" id="unitid" class="form-control select2" onchange="get_employes()">
                                            <option value="">-- Select Bussiness Unit --</option>
                                            <?php foreach($business_unit as $key=>$val)
                                            {
                                                ?>
                                                <option value="<?= $val->id;?>"<?= $department_detail->unitid ==$val->id?'selected':'' ?><?= set_select('unitid',$val->id) ?>><?= $val->unitname; ?></option>
                                                <?php
                                            }?>
                                        </select>
                                        <!-- <input type="text" name="unitid" class="form-control"> -->
                                    </div>
                                    <div class="col-sm-4 mt-3">
                                    <span id="reqd"
                                                        class="error_depthead"><?= form_error('depthead'); ?></span>
                                
                                        <label for="">Department head :</label>
                                        <select name="depthead" id="depthead" class="form-control select2">
                                            <option value="">-- Select HOD --</option>
                                            <?php if($department_detail->depthead)
                                            {
                                                // if(set_value('unitid'))
                                                // {
                                                   $employe  = Get_employess($department_detail->unitid);
                                                    foreach($employe as $key=>$val)
                                                    {
                                                        ?>
                                                        <option <?= $department_detail->depthead==$val->user_id?'Selected':''?><?= set_select('depthead',$val->user_id)?> value="<?=$val->user_id?>"><?= $val->userfullname?></option>
                                                        <?php

                                                    // }
                                                }
                                            }?>
                                            
                                            <?php if(set_value('depthead'))
                                            {
                                                // if(set_value('unitid'))
                                                // {
                                                   $employe  = Get_employess(set_value('unitid'));
                                                    foreach($employe as $key=>$val)
                                                    {
                                                        ?>
                                                        <option <?= set_select('depthead',$val->user_id)?> value="<?=$val->user_id?>"><?= $val->userfullname?></option>
                                                        <?php

                                                    // }
                                                }
                                            }?>
                                            
                                        </select>
                                        <!-- <input type="text" name="depthead" class="form-control"> -->
                                    </div>
                                  
                                    <div class="col-sm-4 mt-4">
                                      <input type="submit" class="btn btn-sm btn-primary" value="Edit Department">
                                    </div>

                                  

                                </div>
                            </form>
                            </div>

                        </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>


   



    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        function get_state()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var country_id = $("#country").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_state') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'country_id': country_id,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#state').html(" ");
                    $('#state').append("<option>-- Select State --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#state').append('<option value="' + val.id +
                                    '">' + val.state_name +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        
        function get_city()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var state_id = $("#state").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_city') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'state_id': state_id,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#city').html(" ");
                    $('#city').append("<option>-- Select City --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#city').append('<option value="' + val.id +
                                    '">' + val.city_name +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        function get_employes()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var unitid = $("#unitid").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_employes') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'unitid': unitid,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#depthead').html(" ");
                    $('#depthead').append("<option>-- Select HOD --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#depthead').append('<option value="' + val.user_id +
                                    '">' + val.userfullname +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        $('#adddesignation').on("click", function(e) {
            e.preventDefault();
            // function adddesignation() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var position_name = $('#positon_name').val();
            var jobtitle = $('#jobtitle').val();
            var description = $('#description').val();
            // alert(position_name);
            // $('#resultSection');
            $.ajax({
                type: 'POST',
                url: '<?= base_url('designation/Designation_Controller/addDesignation') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'position_name': position_name,
                    'jobtitle': jobtitle,
                    'description': description
                },
                success: function(response) {
                    var staus = JSON.parse(response);
                    var error = JSON.parse(response);
                    //    alert();
                    if (staus.Status) {
                        $('#resultSection').show();
                        $('#resultSection').html(staus.Status);

                        $('#errorSection').hide();
                        $('#table_designations').dataTable().fnReloadAjax();
                    } else {
                        $('#resultSection').hide();
                        $('#errorSection').show();
                        $('#errorSection').html(staus.error);
                    }
                },

            });
        });

       
      

     
       
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
    </div>
</body>
<script>

</script>