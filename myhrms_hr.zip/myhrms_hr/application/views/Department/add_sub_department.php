<?php
// epd($departments);
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    .table tbody tr td,
    .table tbody th td {
        white-space: pre-wrap !important;
    }
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="">
                            <?php if ($this->session->flashdata('success_msg')) : ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error_msg')) : ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        <div class="card">
                            <div class="body">
                                <form action="" method="POST">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label for="">Select Department:</label>
                                            <select name="department_name" class="form-control">
                                                <option value="" selected disabled hidden> Select Department </option>
                                                <?php
                                                    foreach ($departments as $value)
                                                    {
                                                ?>
                                                        <option value="<?= $value->id; ?>"> <?= $value->deptname; ?> ( <?= $value->deptcode; ?> ) </option>
                                                <?php
                                                    }
                                                ?>
                                            </select>
                                            <span id="reqd" class="error_deptname"><?= form_error('department_name'); ?></span>
                                        </div>
                                        <div class="col-sm-4">
                                            <label for="">Assign HOD:</label>
                                            <select name="reporting_manager" class="form-control">
                                                <option value="" selected disabled hidden> Select Department </option>
                                                <?php
                                                    foreach ($get_hod as $value)
                                                    {
                                                ?>
                                                        <option value="<?= $value->reporting_manager; ?>"> <?= $value->reporting_manager_name; ?> </option>
                                                <?php
                                                    }
                                                ?>
                                            </select>
                                            <span id="reqd" class="error_deptname"><?= form_error('department_name'); ?></span>
                                        </div>
                                        <div class="col-sm-4">
                                            <label for="">Sub Department Name:</label>
                                            <input type="text" value="<?= set_value('sub_department_name')?>" name="sub_department_name" class="form-control" placeholder="Enter Sub-department name.">
                                            <span id="reqd" class="error_deptname"><?= form_error('sub_department_name'); ?></span>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="submit" value="Submit" name="deptname" class="btn btn-primary mt-4">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="body">
                            <div class="">
                                <table id="table_designations" class="table table-bordered table-striped table-hover  w-100">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Deptartment Name</th>
                                            <th>Department code</th>
                                            <th>Sub Department Name</th>
                                            <th>Description</th>

                                            <th width="110px">Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>S.No.</th>
                                            <th>Deptartment Name</th>
                                            <th>Department code</th>
                                            <th>Sub Department Name</th>
                                            <th>Description</th>

                                            <th width="110px">Action</th>
                                        </tr>
                                    </tfoot>


                                </table>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog modal-lg" style="margin-top:100px;">

                <div class="modal-content">
                    <div class="modal-header">
                        <h5> Add Designation</h5>
                        <button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
                    </div>
                    <div class="modal-body">
                        <div id="resultSection" class="alert alert-success">

                        </div>
                        <div id="errorSection" class="alert alert-danger">

                        </div>


                        <h6></h6>
                        <!-- resultSection     -->
                        <form method="post" action="" name="frmmNews" id="frmmNews" enctype="multipart/form-data">

                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label class="email">Position Name: </label>
                                    <input type="text" name="positon_name" id="positon_name" placeholder="Enter Position Name" class="form-control">
                                   
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="email">Job Title: </label>
                                    <select class="form-control" name="jobtitle" id="jobtitle" required>
                                        <option value=""> -- Select -- </option>
                                        <?php
                                        $get_jobtitle = Getjobtitle();
                                        // print_R($get_jobtitle);

                                        if ($get_jobtitle) {
                                            foreach ($get_jobtitle as $recD) {
                                        ?>
                                                <option value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?></option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label class="email">Description: </label>
                                    <textarea cols="10" rows="10" name="description" id="description" required class="form-control"></textarea>
                                </div>
                            </div>
                            <!-- <div class="row">
                                <div class="form-group col-md-6">
                                    <label class="email">Expiry Date: </label>
                                    <input type="date" class="form-control" name="expiry_date" id="expiry_date" required>
                                </div>
                                <div class="form-group  col-md-6">
                                    <label class="email">Attachment: </label>
                                    <input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="doc_file" id="doc_file">
                                </div>
                            </div> -->
                            <!-- <div class="row">
                                <div class="form-group  col-md-6">
                                    <label class="email"> </label>
                                    <b>Show in Headline : </b> &nbsp;
                                    <input type="checkbox" id="show_in_headline" name="show_in_headline" style="zoom:1.3;">
                                </div>
                                <div class="form-group  col-md-6">
                                    <label class="email"> </label>
                                    <b>Mark Important : </b> &nbsp;
                                    <input type="checkbox" id="mark_important" name="mark_important" style="zoom:1.3;">
                                </div>
                            </div> -->
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <center><input id="adddesignation" type="submit" class="btn btn-primary" value="Submit"></center>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>



    <div class="container">
        <div class="modal fade" id="myModal2" role="dialog">
            <div class="modal-dialog modal-lg" style="margin-top:100px;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5>Edit Position</h5>
                        <button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
                    </div>
                    <div class="modal-body">
                        <div id="editresultSection" class="alert alert-success">

                        </div>
                        <div id="editerrorSection" class="alert alert-danger">

                        </div>
                        <form method="post" action="<?= base_url('news_update'); ?>" name="frmmNewsupdate" id="frmmNewsupdate" enctype="multipart/form-data">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <input type="hidden" name="position_id" id="position_id">
                            <div class="row">
                                <?php $get_news_category = get_news_category();
                                //print_r($get_news_category); 
                                ?>
                                <div class="form-group col-md-6">
                                    <label class="email">Position Name: </label>
                                    <input class="form-control" type="text" name="Designation_name" id="edit_desi_nation">

                                </div>
                                <div class="form-group col-md-6">
                                    <label class="email">Job Title: </label>
                                    <select class="form-control" name="jobtitle_id" id="edit_jobtitle" required>
                                        <option value=""> -- Select -- </option>
                                        <?php
                                        $get_jobtitle = Getjobtitle();
                                        // print_R($get_jobtitle);

                                        if ($get_jobtitle) {
                                            foreach ($get_jobtitle as $recD) {
                                        ?>
                                                <option value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?></option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label class="email">Description: </label>
                                    <textarea cols="10" rows="10" name="edit_description" id="edit_description" required class="form-control"></textarea>
                                </div>
                            </div>



                            <div class="row">
                                <div class="form-group col-md-12">
                                    <input type="hidden" id="upnews_id" name="news_id">
                                    <center><input type="submit" id="update_designation" class="btn btn-primary" value="Update"></center>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        function get_state()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var country_id = $("#country").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_state') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'country_id': country_id,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#state').html(" ");
                    $('#state').append("<option>-- Select State --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#state').append('<option value="' + val.id +
                                    '">' + val.state_name +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        
        function get_city()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var state_id = $("#state").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_city') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'state_id': state_id,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#city').html(" ");
                    $('#city').append("<option>-- Select City --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#city').append('<option value="' + val.id +
                                    '">' + val.city_name +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        function get_employes()
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var unitid = $("#unitid").val();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('department/Department_controller/get_employes') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'unitid': unitid,
                  
                },
                success: function(response) {
                    // var staus = JSON.parse(response);
                    // var error = JSON.parse(response);
                    var data = jQuery.parseJSON(response);
                    $('#depthead').html(" ");
                    $('#depthead').append("<option>-- Select HOD --</option>");

                        // if (data) {
                            $.each(data, function(index, val) {
                                $('#depthead').append('<option value="' + val.user_id +
                                    '">' + val.userfullname +' </option>');
                            });
                        // }
                    //    alert();
                    // if (staus.Status) {
                    //     $('#resultSection').show();
                    //     $('#resultSection').html(staus.Status);

                    //     $('#errorSection').hide();
                    //     $('#table_designations').dataTable().fnReloadAjax();
                    // } else {
                    //     $('#resultSection').hide();
                    //     $('#errorSection').show();
                    //     $('#errorSection').html(staus.error);
                    // }
                },

            });
        }
        $('#adddesignation').on("click", function(e) {
            e.preventDefault();
            // function adddesignation() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var position_name = $('#positon_name').val();
            var jobtitle = $('#jobtitle').val();
            var description = $('#description').val();
            // alert(position_name);
            // $('#resultSection');
            $.ajax({
                type: 'POST',
                url: '<?= base_url('designation/Designation_Controller/addDesignation') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'position_name': position_name,
                    'jobtitle': jobtitle,
                    'description': description
                },
                success: function(response) {
                    var staus = JSON.parse(response);
                    var error = JSON.parse(response);
                    //    alert();
                    if (staus.Status) {
                        $('#resultSection').show();
                        $('#resultSection').html(staus.Status);

                        $('#errorSection').hide();
                        $('#table_designations').dataTable().fnReloadAjax();
                    } else {
                        $('#resultSection').hide();
                        $('#errorSection').show();
                        $('#errorSection').html(staus.error);
                    }
                },

            });
        });

        function seteditupdatedata(position_id) {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var postion_name = $('#position_nam');
            $.ajax({
                url: '<?= base_url("designation/Designation_Controller/edit_Designation"); ?>',
                data: ({
                    [csrfName]: csrfHash,
                    position_id: position_id
                }),
                type: 'post',
                success: function(data) {
                    var status = JSON.parse(data);
                    $('#position_id').val(status.id);
                    $('#edit_desi_nation').val(status.positionname);
                    $('#edit_jobtitle').val(status.jobtitleid);
                    $('#edit_description').val(status.description);
                }
                //data:{[csrfName]: csrfHash},
            });
        }

        $('#update_designation').on("click", function(e) {
            e.preventDefault();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var position_Name = $('#edit_desi_nation').val();
            var jobtitle_id = $('#edit_jobtitle').val();
            var description = $('#edit_description').val();
            var position_id = $('#position_id').val();
            $.ajax({
                url: '<?= base_url("designation/Designation_Controller/edit_Designation_update"); ?>',
                data: ({
                    [csrfName]: csrfHash,
                    position_id: position_id,
                    position_Name: position_Name,
                    jobtitle_id: jobtitle_id,
                    description: description,


                }),
                type: 'post',
                success: function(data) {
                    var staus = JSON.parse(data);
                    if (staus.status) {
                        $('#editresultSection').show();
                        $('#editresultSection').html(staus.status);

                        $('#editerrorSection').hide();
                        $('#table_designations').dataTable().fnReloadAjax();
                    } else {
                        $('#editresultSection').hide();
                        $('#editerrorSection').show();
                        $('#editerrorSection').html(staus.error);
                    }
                    $('#table_designations').dataTable().fnReloadAjax();
                }
                //data:{[csrfName]: csrfHash},
            });
        });

        //    abhi
    </script>
    <!-- <script type="text/javascript">
        var timeout = 1000; // in miliseconds (3*1000)
        $('.alert').delay(timeout).fadeOut(3000);

        function NewsDelete(news_id) {
            //alert(news_id);
            if (confirm("Are You sure Delete this ? ")) {
                window.location = "<?php // base_url('news_delete/'); 
                                    ?>" + news_id;
            }
        }
    -->

    </script>
    <script>
        var table;
        $(document).ready(function() {
            $('#resultSection').hide();
            $('#errorSection').hide();
            $('#editresultSection').hide();
            $('#editerrorSection').hide();
            $('').hide();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            //datatables
            table = $('#table_designations').DataTable({
                "processing": true,
                "serverSide": true,
                // "pageLength": -1,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('department/Department_controller/Department') ?>",
                    "type": "POST",
                    "data": function(data) {
                        // data.dept_name = $('#dept_name').val();
                        // data.businessunit_name = $('#businessunit_name').val();
                        data.csrfName = csrfHash;
                    },
                    // data: {[csrfName]: csrfHash}, 
                },

                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                }],

                "columnDefs": [{
                    "searchable": true,
                    "targets": [0],
                    "orderable": false
                }],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            $('#btn-filter').click(function() {
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
    </div>
</body>
<script>

</script>