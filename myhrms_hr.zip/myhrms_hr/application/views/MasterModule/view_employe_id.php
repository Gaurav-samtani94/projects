<!-- $this->db->query("show tables");    
$tables = $this->db->get();    
return $tables->result_array(); -->
<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>



                    </div>
                </div>
				<div><h4><?=$name;?> <a href="<?=base_url('mastertable');?>"> Back</a></h4></div>
                <div>
			<table id="table" class="table">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Table Record Name</th>
                               
								
                            </tr>
                        </thead>
                        <tbody>
<?php

$i=1;
if($record)
{
 foreach($record as $key=>$tab)
{
	?>
	<tr>
	<th><?=$i++;?></th>
	<th><?=$tab->candidate_id?></th>
	</tr><?php
}}?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>S.No</th>
                                <th>Table Record Name</th>
                               
								
                            </tr>
                        </tfoot>
                    </table>





                </div>





            </div>
        </div>

        <?php $this->load->view('admin/includes/footer'); ?>





    </div>
</body>
<script>
  $(document).ready(function () {
    $('#example').DataTable();
});
</script>