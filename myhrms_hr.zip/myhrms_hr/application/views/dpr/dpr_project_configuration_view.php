<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>DPR Project Expenditure Bill Configuration </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>



                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div class="row clearfix">
                                        <div class="col-lg-3">
                                            <b> DPR Project : </b>
                                            <div class="input-group mb-3">
                                                <?= $ProjectDetailsByID->project_name; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <b> Client : </b>
                                            <div class="input-group mb-3">
                                                <?= $ProjectDetailsByID->client_name; ?>
                                            </div>
                                        </div>                                   
                                        <div class="col-lg-3">
                                            </br>
                                            <div class="input-group mb-3">
                                                <a href="<?= base_url("dpr_project_config"); ?>">
                                                    <button class="btn btn-info btn-sm"> << Back </button> 
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>  


                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">                            
                                <form method="post" action="<?= base_url('assign_departmentsaveupdate'); ?>" id="visitingcard_form">  
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-lg-4 col-md-6">
                                            <label class="email" > Assign Department : </label>
                                            <div class="input-group mb-6">
                                                <select class="form-control select2" name="master_tbl_id" required="required">
                                                    <option value=""> -- All -- </option>
                                                    <?php
                                                    if ($AllDepartment_DPR) {
                                                        foreach ($AllDepartment_DPR as $key => $roWs) {
                                                            ?>
                                                            <option value="<?= $roWs->fld_id; ?>"><?= $roWs->dpr_department_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-md-6">
                                            <label class="email" > Sr. No. : </label>
                                            <div class="input-group mb-6">     
                                                <input min="1" type="number" class="form-control" required="required" name="sr_no">      
                                            </div>
                                        </div>                                 

                                        <div class="col-lg-2">
                                            <div class="mb-2">
                                                <b></b>
                                                <input type="hidden" name="type" value="1">
                                                <input type="hidden" name="proj_id" value="<?= $ProjectDetailsByID->id ?>">
                                                <button style="margin-top: 27px;" type="submit" class="btn btn-success btn-block"> Assign </button>
                                            </div>
                                        </div>

                                    </div>
                                </form>   
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">                            
                                <form method="post" action="<?= base_url('assign_departmentsaveupdate'); ?>" id="visitingcard_form">   
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-lg-4 col-md-6">
                                            <label class="email" > Assign Activity : </label>
                                            <div class="input-group mb-6">
                                                <select class="form-control select2" name="master_tbl_id" required="required" >
                                                    <option value=""> -- All -- </option>
                                                    <?php
                                                    if ($AllActivity_DPR) {
                                                        foreach ($AllActivity_DPR as $key => $roWs) {
                                                            ?>
                                                            <option value="<?= $roWs->fld_id; ?>"><?= $roWs->activity_title; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-md-6">
                                            <label class="email" > Sr. No. : </label>
                                            <div class="input-group mb-6">     
                                                <input min="1" type="number" class="form-control" required="required" name="sr_no">      
                                            </div>
                                        </div>

                                        <div class="col-lg-2 col-md-6">
                                            <div class="mb-2">
                                                <b></b>
                                                <input type="hidden" name="type" value="2">
                                                <input type="hidden" name="proj_id" value="<?= $ProjectDetailsByID->id ?>">
                                                <button style="margin-top: 27px;" type="submit" class="btn btn-success btn-block"> Assign </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>   
                            </div>
                        </div>
                    </div>



                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Department Name</th>                                               
                                                <th>Number</th>                                               
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <?php
                                        if ($AssignedDepartments) {
                                            foreach ($AssignedDepartments as $kEy => $rOws) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= $rOws->dpr_department_name; ?></td>                                               
                                                    <td><?= $rOws->sr_no; ?></td>                                               
                                                    <td><a href="<?= base_url("delete_attr/".$rOws->fld_id); ?>" class="fa fa-trash"></a></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>

                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Department Name</th>
                                                <th>Number</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table2" class="table table-striped display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Activity Name</th>
                                                <th>Number</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                         <?php
                                        if ($AssignedActivity) {
                                            foreach ($AssignedActivity as $kEy => $rOws) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= $rOws->activity_title; ?></td>                                               
                                                    <td><?= $rOws->sr_no; ?></td>                                               
                                                    <td><a href="<?= base_url("delete_attr/".$rOws->fld_id); ?>" class="fa fa-trash"></a></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Activity Name</th>
                                                <th>Number</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>


    <script type="text/javascript">
        var table;
        $(document).ready(function () {
            table = $('#table').DataTable();
        });

        var table2;
        $(document).ready(function () {
            table2 = $('#table2').DataTable();
        });

    </script>
<?php $this->load->view('admin/includes/footer'); ?>
</body>