<html>

<body>
<div>
    <?php foreach($employee_detail as $key=>$v)
    {
        foreach($v as $k=>$val)
        {
            print_r($val);
            die();
        }
        // print_r($v);
        // die();
    }
    ?>
    

        
    </div>
</body>
</html>