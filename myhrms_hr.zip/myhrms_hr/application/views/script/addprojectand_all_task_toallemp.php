<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//$statusArr = array("0"=>"A","1"=>"","2"=>"","3"=>"","4"=>);
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Add All Employee Project Task</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">

                        <div class="">

                            <form action="<?= base_url('script_add_project_task') ?>" method="POST" class="form-control card">

                                <div class="row">
                                    <div class="col-md-4">
                                        <label for=""> Project Name :</label>
                                        <Select class="form-control" name="project_id" required>
                                            <option value="">-------Select Project --------</option>
                                            <?php foreach ($project as $k => $v) {
                                            ?> <option value="<?= $v->id; ?>"><?= $v->project_name; ?></option>
                                            <?php
                                            } ?>
                                        </Select>
                                    </div>
                                    <div> <label for=""> Employe :</label>
                                        <Select class="form-control selectpicker" name="employe_id" data-live-search="true">
                                            <option value="">-------Select Employe --------</option>
                                            <?php foreach ($employelist as $k => $v) {
                                            ?> <option value="<?= $v->id; ?>"><?= $v->employeeId . " " . $v->userfullname; ?></option>
                                            <?php
                                            } ?>
                                        </Select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for=""> </label>
                                        <br>
                                        <input type="submit" value="Assign Project Task" class="btn btn-primary">
                                    </div>
                                    <div class="col-md-4"></div>
                                </div>
                            </form>

                        </div>


                    </div>
                </div>

            </div>
        </div>

        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<script>
    $(document).ready(function() {
        $('select').selectpicker();
    });
</script>