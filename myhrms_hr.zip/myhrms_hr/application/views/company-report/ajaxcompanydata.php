     
								<?php
								 

								$rowCount = 1;
								 
								if (isset($companyGrade)) {
								
								foreach ($companyGrade as $kEy => $data) {
									if(isset($data[0]->cityName)){
								?>
									<tr style="">
										<td class="<?php echo 'row_'.$rowCount;?>">
										<?php
										 
										$city = $data[0]->cityName;
										 
										 echo "CEG ".$city; ?></td>
										<?php 
										if ($data) {
											
										echo '<td class="row_'.$rowCount.'  aclass">';
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'A'){ 
												echo $dt->countGrade;
											}
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.'  bclass">';	
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'B'){ 
												echo $dt->countGrade;
											}
																		 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.'  cclass">';
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'C'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.'  dclass">';
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'D'){ 
											 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.'  eclass">';
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'E'){ 
												echo $dt->countGrade;
											}
											 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' fclass">';
										foreach ($data as $key => $dt) {
											if($dt->cityName == $city && $dt->Grade == 'F'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										}
										?>
										
										<td class="<?php echo 'row_'.$rowCount.' row_sum'.$rowCount;?>"></td>
									</tr>
								   <?php
									}
								   $rowCount++;
								  }
								  
								}
								if (isset($cegTh)) {
									$rowCount = $rowCount + 1;
								?>
								 <tr style="">
										<td>
										<?php 
										echo "CEGTH"; ?>
										</td>
										<?php 
										echo '<td class="row_'.$rowCount.' aclass">';
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'A'){ 
												echo $dt->countGrade;
											}
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' bclass">';	
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'B'){ 
												echo $dt->countGrade;
											}
																		 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' cclass">';
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'C'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' dclass">';
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'D'){ 
											 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' eclass">';
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'E'){ 
												echo $dt->countGrade;
											}
											 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' fclass">';
										foreach ($cegTh as $key => $dt) {
											if($dt->Grade == 'F'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
								?>
								<td class="<?php echo 'row_'.$rowCount.' row_sum'.$rowCount;?>"></td>
								</tr>
								<?php
								}
								if (isset($cegProject)) {
									$rowCount = $rowCount + 1;
								?>
								 <tr style="">
									<td>
										<?php 
										echo "CEG Project"; ?>
										</td>
										
										<?php 
										echo '<td class="row_'.$rowCount.' aclass">';
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'A'){ 
												echo $dt->countGrade;
											}
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' bclass">';	
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'B'){ 
												echo $dt->countGrade;
											}
																		 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' cclass">';
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'C'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' dclass">';
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'D'){ 
											 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' eclass">';
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'E'){ 
												echo $dt->countGrade;
											}
											 
										}
										echo "</td>";
										echo '<td class="row_'.$rowCount.' fclass">';
										foreach ($cegProject as $key => $dt) {
											if($dt->Grade == 'F'){ 
												echo $dt->countGrade;
											}
																					 
										}
										echo "</td>";
										?>
											<td class="<?php echo 'row_'.$rowCount.' row_sum'.$rowCount;?>"></td>								
									  </tr>
								<?php
								}
								 if (!isset($cegTh) && !isset($cegProject) && !isset($companyGrade)) {  ?>
								<tr>
									<td style="color:red;text-align:center;" colspan="8"> Record Not Found. </td>
								</tr>
								<?php } ?>
								
								
								
								
	
								
								
								
								
<script type="text/javascript">

 
 $(document).ready(function(){
	 
		var rowNumber = [1, 2, 3, 4, 5, 6, 7];
		rowNumber.forEach(sumRowFunction);

		function sumRowFunction(value) {
			sumRow(value);
		}
		
		function sumRow(value){
		var sum = 0;
		$(".row_"+value).each(function() {
		var value = $(this).text();
		if(!isNaN(value) && value.length != 0) {
		sum += parseFloat(value);
		}
		});
		$(".row_sum"+value).text(sum);
		}
		
		
		
		var colNumber = ['a', 'b', 'c', 'd', 'e', 'f'];
		colNumber.forEach(sumColumnFunction);

		function sumColumnFunction(value) {
			sumColumn(value);
			
		}
		
		function sumColumn(value){
			var sum = 0;
			$("."+value+"class").each(function() {
			var value = $(this).text();
			if(!isNaN(value) && value.length != 0) {
			sum += parseFloat(value);
			}
			});
			$(".row_sum_"+value).text(sum);
		}
	 
			
			rowSumTotal();
			function rowSumTotal(){
			var sum = 0;
			$(".row_sum_th").each(function() {
			var value = $(this).text();
			if(!isNaN(value) && value.length != 0) {
			sum += parseFloat(value);
			}
			});
			$(".row_sum_total").text(sum);
			}
});



 


function filterData(){
  var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
	var business_id =	$("#business_id").val();
	var company_id =	$("#company_id").val();
	
	 
	
	$.ajax({
		url: '<?php echo base_url('mastercontrol/ajaxCompanyData'); ?>',
		type: 'POST',
		data: {business_id: business_id, company_id: company_id},
		dataType: 'json',
		success: function(data1) {
			console.log("Test Data :"+data1);
			$("#ajaxCompanyData").html(data1);
			
 		
		}
                data:{[csrfName]: csrfHash}, 
	});
	
}



</script>