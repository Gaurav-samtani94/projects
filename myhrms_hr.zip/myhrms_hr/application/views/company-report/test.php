
<!doctype html>
<html lang="en">
    <head>
        <title>CEG HRMS</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
        <meta name="author" content="CEG india HRMS">
        <link rel="icon" href="favicon.ico" type="image/x-icon">
        
        
<!-- Start New Section For All Form  -->
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap-colorpicker/css/bootstrap-colorpicker.css" />
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/multi-select/css/multi-select.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/nouislider/nouislider.min.css" />
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/select2/select2.css" />
        <link rel="stylesheet" href="http://localhost/myhrms/assets/css/main.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/css/color_skins.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/font-awesome/css/font-awesome.min.css">
        <!-- Close Section For All Form . -->

        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/vendor/sweetalert/sweetalert.css"/>
        <link rel="stylesheet" href="http://localhost/myhrms/assets/css/main.css">
        <link rel="stylesheet" href="http://localhost/myhrms/assets/css/color_skins.css">
        
        
    </head>
<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-btn">
            <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
        </div>
        <div class="navbar-brand">
            <a href="http://localhost/myhrms/index.php/">
                <img src="http://www.cegindia.com/images/logo.png" style="width:200px!important;" alt="CEG" class="img-responsive logo">
            </a>                
        </div>
        <div class="navbar-right">
            <form id="navbar-search" class="navbar-form search-form">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                <input value="" class="form-control" placeholder="Search here" type="text">
                <button type="button" class="btn btn-default"><i class="icon-magnifier"></i></button>
            </form>                
            <div id="navbar-menu">
               
                &nbsp;
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#" class="icon-menu d-none d-sm-block d-md-none d-lg-block"><i class="fa fa-folder-open-o"></i></a>
                    </li>
                    <li>
                        <a href="http://localhost/myhrms/index.php/logout" class="icon-menu 123" title="Logout"><i class="icon-logout"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav><body class="theme-cyan">
    <div id="wrapper">
        






<!-- Menu 2 Lvl !-->

<div id="left-sidebar" class="sidebar">
    <div class="sidebar-scroll">
        <div class="user-account">
              
            <div class="dropdown">
                <span>Welcome,</span>
                <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>Gaurav Samtani</strong></a>
                <ul class="dropdown-menu dropdown-menu-right account">
                    <li><a href="http://localhost/myhrms/index.php/myprofile"><i class="icon-user"></i>My Profile</a></li>
                    <li><a href="#"><i class="icon-envelope-open"></i>Messages</a></li>
                    <li><a href="javascript:void(0);"><i class="icon-settings"></i>Settings</a></li>
                    <li class="divider"></li>
                    <li><a href="http://localhost/myhrms/index.php/logout"><i class="icon-power"></i>Logout</a></li>
                </ul>
            </div>
        </div>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#menu">Employee</a></li>   
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#master_menu">HR</a></li> 
        </ul>
        <!-- Tab panes -->
        <div class="tab-content p-l-0 p-r-0">   
            <div class="tab-pane active" id="menu">
                <nav id="left-sidebar-nav" class="sidebar-nav">
                    <ul id="main-menu" class="metismenu">
                                                        <li class="">
                                    <a style="cursor: pointer" class="has-arrow"><i class="icon-home"></i><span>Self Services</span></a>
                                                                                <ul>
                                                <li id="mymenu_2" class="">
                                                    <a href="http://localhost/myhrms/index.php/myprofile">My Profile</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_9" class="">
                                                    <a href="http://localhost/myhrms/index.php/myleave">Leave</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_11" class="">
                                                    <a href="http://localhost/myhrms/index.php/myholidays">My Holiday</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_12" class="">
                                                    <a href="http://localhost/myhrms/index.php/myteam">My Team</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_13" class="">
                                                    <a href="http://localhost/myhrms/index.php/#">Other</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_14" class="">
                                                    <a href="http://localhost/myhrms/index.php/#">Other 2</a>
                                                </li>
                                            </ul>
                                                                            </li>
                                                            <li class="">
                                    <a style="cursor: pointer" class="has-arrow"><i class="icon-home"></i><span>Account</span></a>
                                                                                <ul>
                                                <li id="mymenu_22" class="">
                                                    <a href="http://localhost/myhrms/index.php/mypayslip">Pay Slips</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_23" class="">
                                                    <a href="http://localhost/myhrms/index.php/mysalarydetails">Salary</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_24" class="">
                                                    <a href="http://localhost/myhrms/index.php/myformitr">Form 16</a>
                                                </li>
                                            </ul>
                                                                                        <ul>
                                                <li id="mymenu_25" class="">
                                                    <a href="http://localhost/myhrms/index.php/#">Attendance</a>
                                                </li>
                                            </ul>
                                                                            </li>
                                                </ul>
                </nav>
            </div>

            <div class="tab-pane" id="master_menu"> 
                <nav id="left-sidebar-nav" class="sidebar-nav">
                    <ul id="main-menu" class="metismenu">
                                                        <li class="active">
                                    <a href="#" class="has-arrow"><i class="icon-home"></i> <span>HR Section</span></a>
                                                                                <ul>
                                                <li class="mymenu_26">
                                                    <a href="http://localhost/myhrms/index.php/#">HR Reports</a>
                                                </li>
                                            </ul>
                                                                            </li>
                                                    </ul>
                </nav>
            </div>
        </div>          
    </div>
</div>        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="http://localhost/myhrms/index.php/"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active">My Leave Details</li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <div class="card-header" id="headingOne">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    Apply Leave
                                                </button>
                                            </h5>
                                        </div>                                
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="header">
                                                <ul class="header-dropdown">
                                                    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="zmdi zmdi-more"></i> </a>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="javascript:void(0);">View Holidays</a></li>
                                                            <li><a href="javascript:void(0);">Apply Tour</a></li>
                                                            <li><a href="javascript:void(0);">Employee Leave</a></li>
                                                            <li><a href="javascript:void(0);">Employee Tour</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="remove">
                                                        <a role="button" class="boxs-close"><i class="zmdi zmdi-close"></i></a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="body">
                                                <div class="row clearfix">
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Available Leaves</b>
                                                            <input type="text" class="form-control" name="avl_leave" value="05.5" disabled="disabled">    
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Reporting Manager</b>
                                                            <input disabled="disabled" type="text" value="Mr. Kapil Arora" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Leave Type</b>
                                                            <select class="form-control" data-placeholder="Select">
                                                                <option value=""> -- Select -- </option>
                                                                <option value="1"> PL </option>
                                                                <option value="2"> RH </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Reason</b>
                                                            <textarea class="form-control" name="reason"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>From Date</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="text" class="form-control date" placeholder="Ex: 30/07/2016">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>To Date</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" class="form-control date" placeholder="Ex: 30/07/2016">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Leave For</b>
                                                            <select class="form-control" data-placeholder="Select">
                                                                <option value="1"> Full Day </option>
                                                                <option value="2"> Half Day </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Days</b>
                                                            <input readonly="readonly" type="number" step="any" value="" id="" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-2 col-md-6">
                                                        <div class="mb-2">
                                                            <b>&nbsp;</b>
                                                            <input type="submit" id="" class="btn btn-round btn-primary">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Leave Type </th>
                                                <th>Reason</th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Days</th>
                                                <th>Applied On</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                                                                            <tr>
                                                    <td style="color:red" colspan="9"> Record Not Found. </td>
                                                </tr>
                                                                                    </tbody>
                                        
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Leave Type </th>
                                                <th>Reason</th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Days</th>
                                                <th>Applied On</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
<!--Start Section Form All Element Included  --> 
<script src="http://localhost/myhrms/assets/bundles/libscripts.bundle.js"></script> 
<script src="http://localhost/myhrms/assets/bundles/vendorscripts.bundle.js"></script>
<script src="http://localhost/myhrms/assets/vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-inputmask/jquery.inputmask.bundle.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery.maskedinput/jquery.maskedinput.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/multi-select/js/jquery.multi-select.js"></script>
<script src="http://localhost/myhrms/assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="http://localhost/myhrms/assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
<script src="http://localhost/myhrms/assets/vendor/nouislider/nouislider.js"></script> 
<script src="http://localhost/myhrms/assets/vendor/select2/select2.min.js"></script>
<script src="http://localhost/myhrms/assets/bundles/mainscripts.bundle.js"></script>
<script src="http://localhost/myhrms/assets/js/pages/forms/advanced-form-elements.js"></script>
<!-- Close Section For Data Table  -->

<!-- Start Javascript -->
<script src="http://localhost/myhrms/assets/bundles/datatablescripts.bundle.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-datatable/buttons/buttons.html5.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/jquery-datatable/buttons/buttons.print.min.js"></script>
<script src="http://localhost/myhrms/assets/vendor/sweetalert/sweetalert.min.js"></script>
<script src="http://localhost/myhrms/assets/js/pages/tables/jquery-datatable.js"></script>
<!-- Close Javascript -->


<style>
    #reqd{color:red}
</style>

</body>
</html>    </div>
</body>