<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
	#company_data_length {
		float: right !important;
		margin-left: 10px;
	}
</style>

<body class="theme-cyan">
	<div id="wrapper">
		<?php
		$this->load->view('admin/includes/sidebar');
		?>
		<div id="main-content">
			<div class="container-fluid">
				<div class="block-header">
					<div class="row">
						<div class="col-lg-5 col-md-8 col-sm-12">
							<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2>
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
								<li class="breadcrumb-item">Home</li>
								<li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
							</ul>
						</div>
					</div>
				</div>

				<div class="row clearfix">
					<div class="col-lg-12">
						<div class="card">
							<div class="body">





								<div class="accordion" id="accordion">
									<div>
										<form method="post" action="<?= base_url('applyvisitingcard'); ?>" id="dataCompany">
                                                                                 <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

											<div class="card-header" id="headingOne">
												<h5 class="mb-0">
													<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
														Company Detail
													</button>
												</h5>
											</div>
											<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">

												<div class="body">
													<div class="row clearfix">



														<div class="col-lg-4 col-md-4">
															<div class="mb-3">
																<b>Business Unit</b>
																<select name="business_id" class="form-control" data-placeholder="Select" id="business_id">
																	<option value="100"> -- All Business Unit -- </option>
																	<?php
																	if ($getBusinessUnit) {
																		foreach ($getBusinessUnit as $kEy => $data) { ?>
																			<option value="<?php echo $data->id; ?>"> <?php echo $data->unitname; ?></option>
																	<?php }
																	}
																	?>

																</select>
															</div>
														</div>

														<div class="col-lg-4 col-md-4">
															<div class="mb-4">
																<b>Company</b>
																<select class="form-control" data-placeholder="Select" name="company_id" id="company_id">
																	<option value="100"> -- All Company -- </option>
																	<?php
																	if ($getCompanyName) {
																		foreach ($getCompanyName as $kEy => $data) { ?>
																			<option value="<?php echo $data->id; ?>"> <?php echo $data->company_name; ?></option>
																	<?php }
																	}
																	?>

																</select>
															</div>
														</div>


														<div class="col-lg-4 col-md-4">

															<a class="btn btn-round btn-primary pull-right" id="btn-filter" style="margin-top: 22px; width: 50%; color: #FFFFFF">Filter</a>

														</div>


													</div>
										</form>


										<div class="row clearfix">



											<div class="col-md-7">
												<div class="card">
													<div class="body">
														<div class="table-responsive">
															<table id="company_data" class="table table-bordered table-striped table-hover" style="width: 100% !important">
																<thead>
																	<tr>
																		<th>Company</th>
																		<th class="sum">A</th>
																		<th class="sum">B</th>
																		<th class="sum">C</th>
																		<th class="sum">D</th>
																		<th class="sum">E</th>
																		<th class="sum">F</th>
																		<th class="sum">Total</th>

																	</tr>
																</thead>
																<tbody>

																</tbody>
																<tfoot>
																	<tr>
																		<th>Total</th>
																		<th id="aSum"></th>
																		<th id="bSum"></th>
																		<th id="cSum"></th>
																		<th id="dSum"></th>
																		<th id="eSum"></th>
																		<th id="fSum"></th>
																		<th id="gSum"></th>

																	</tr>
																</tfoot>


															</table>
														</div>
													</div>
												</div>
											</div>

											<div class="col-lg-5 col-md-5">
												<div id="companyChart"></div>
											</div>
										</div>
									</div>

								</div>
							</div>

						</div>
					</div>
				</div>
			</div>


		</div>
	</div>
	</div>
	</div>
	<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
	
	</div>
</body>



<script type="text/javascript" src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1','packages':['corechart']}]}"></script>
<script src="https://cdn.datatables.net/plug-ins/1.10.20/api/sum().js"></script>
<script type="text/javascript">
	var table;
	$(document).ready(function() {
      var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';


		var business_id = $("#business_id").val();
		var company_id = $("#company_id").val();

		var dataVal = {
			"business_id": (business_id == '') ? business_id : business_id,
			"company_id": (company_id == '') ? company_id : company_id
		}


		table = $('#company_data').DataTable({
			"processing": true,
			"serverSide": false,
			"ajax": {
				"url": "<?php echo base_url('Company_Controller/newAjaxCompanyData'); ?>",
				"type": "POST",
				"data": function(d) {
					console.log(d);
					return $('#dataCompany').serialize();
				},
                           data:{[csrfName]: csrfHash}, 
			},
			"dom": 'lBfrtip',
			"buttons": [{
				extend: 'collection',
				text: 'Export',
				buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
			}],


			"columns": [{
					"data": "company"
				},
				{
					"data": "a"
				},
				{
					"data": "b"
				},
				{
					"data": "c"
				},
				{
					"data": "d"
				},
				{
					"data": "e"
				},
				{
					"data": "f"
				},
				{
					"data": "g"
				}
			],
			"columnDefs": [{
				"searchable": true,
				"targets": ["company", "a", "b", "c", "d", "e", "f"]
			}],

			"footerCallback": function(row, data, start, end, display) {
				var api = this.api();

				api.columns('.sum', {
					page: 'current'
				}).every(function() {
					var sum = this
						.data()
						.reduce(function(a, b) {
							var x = parseFloat(a) || 0;
							var y = parseFloat(b) || 0;
							return x + y;
						}, 0);

					$(this.footer()).html(sum);

					var aSum = $("#aSum").text();
					var bSum = $("#bSum").text();
					var cSum = $("#cSum").text();
					var dSum = $("#dSum").text();
					var eSum = $("#eSum").text();
					var fSum = $("#fSum").text();

					var totalSum = parseInt(aSum) + parseInt(bSum) + parseInt(cSum) + parseInt(dSum) + parseInt(eSum) + parseInt(fSum);
					$("#gSum").html(totalSum);

				});
			},
			"drawCallback": function(settings) {
				drawChart();
			},
			"rowCallback": function(row, data, index) {

				if (data['company'] <= 0) {
					$(row).hide();
				}

				if (data[0] !== null) {
					var total = parseInt(data.a) + parseInt(data.b) + parseInt(data.c) + parseInt(data.d) + parseInt(data.e) + parseInt(data.f);
					$('td:eq(7)', row).html(total);
				}

			}
		});




		$('#btn-filter').click(function() {

			table.ajax.reload(function() {

				drawChart();

			});

		});


		function drawChart() {
			var aSum = $("#aSum").text();
			var bSum = $("#bSum").text();
			var cSum = $("#cSum").text();
			var dSum = $("#dSum").text();
			var eSum = $("#eSum").text();
			var fSum = $("#fSum").text();

			var totalSum = parseInt(aSum) + parseInt(bSum) + parseInt(cSum) + parseInt(dSum) + parseInt(eSum) + parseInt(fSum);
			$("#gSum").html(totalSum);
			drawAjaxChart(aSum, bSum, cSum, dSum, eSum, fSum);
		}



		var filteredData = table
			.rows()
			.indexes()
			.filter(function(value, index) {
				return table.row(value).data()[0] == 0;
			});
		table.rows(filteredData)
			.remove()
			.draw();

	});

	google.load("visualization", "1.0", {
		packages: ["bar"]
	});

	function drawAjaxChart(aSum, bSum, cSum, dSum, eSum, fSum) {
		var data = new google.visualization.DataTable({
			"cols": [{
					"id": "",
					"label": "Company Grade",
					"type": "string"
				},
				{
					"id": "",
					"label": "No.of Employees",
					"type": "number"
				}
			],
			"rows": [{
					"c": [{
						"v": "A"
					}, {
						"v": aSum
					}]
				},
				{
					"c": [{
						"v": " B"
					}, {
						"v": bSum
					}]
				},
				{
					"c": [{
						"v": " C"
					}, {
						"v": cSum
					}]
				},
				{
					"c": [{
						"v": " D"
					}, {
						"v": dSum
					}]
				},
				{
					"c": [{
						"v": " E"
					}, {
						"v": eSum
					}]
				},

				{
					"c": [{
						"v": " F"
					}, {
						"v": fSum
					}]
				}
			]
		});

		var options = {
			"title": "CEG Grade Based Employee Report",
			"vAxis": {
				"title": "No.of Employees",
				"minValue": 0
			},
			"hAxis": {
				"title": "Company Grade",
				"maxValue": 10
			},
			"legend": "none",
			"is3D": true,
			"width": 400,
			"height": 500,
			"colors": ["2089a0"]
		};
		var chart = new google.visualization.ColumnChart(document.getElementById('companyChart'));
		chart.draw(data, options);
	}
</script>
<?php $this->load->view('admin/includes/footer'); ?>