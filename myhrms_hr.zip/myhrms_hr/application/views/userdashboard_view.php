<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<!-- <script>
  floardata(5, 11);
</script> -->

<body class="theme-cyan">
  <div id="wrapper">
    <?php
    $this->load->view('admin/includes/sidebar');
    ?>

    <div id="main-content">
      <div class="container-fluid">
        <div class="block-header stepper">
          <div class="row">
            <div class="col-lg-5 col-md-8 col-sm-12">
              <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2> -->
              <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                <li class="breadcrumb-item active"><a href="<?= base_url(); ?>">Home</a> / <?= ($title) ? $title : ""; ?></li>
              </ul>
            </div>



          </div>
        </div>

        <div class="row clearfix">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="box-userdashboard">
              <div class="links"><a href="<?php echo base_url('companyreport') ?>" class="mr-2" style="margin:0 0 0 20px"><i class="icon-pin"></i></a><a href="<?php echo base_url('companyProjectReport') ?>" class=""><i class="icon-plus"></i></a></div>
              <div class="body">
                <div class="row">
                  <div class="col-3 align-self-center">
                    <span class="userdashboard-icon">
                      <img src="../assets/images/employee.png" class="w-100">
                    </span>
                  </div>
                  <div class="col-9">
                    <p class="mb-0"><b>Active Employee</b></p>
                    <?php
                    $totalActiveEmp = 0;
                    $cegActiveEmp = 0;
                    $cegthActiveEmp = 0;
                    $cegprojectActiveEmp = 0;
                    foreach ($ActiveEmployeedata as $ActiveEmpData) {
                      if ($ActiveEmpData->businessunit_id == 1) {
                        $cegActiveEmp++;
                      } elseif ($ActiveEmpData->businessunit_id == 2) {
                        $cegthActiveEmp++;
                      } else {
                        $cegprojectActiveEmp++;
                      }
                      $totalActiveEmp++;
                    } ?>
                    <h2 class="tc-logo mb-0"><b><?= $totalActiveEmp; ?></b></h2>
                    <p class="mb-0">this day</p>
                  </div>
                </div>
              </div>
              <div class="userdashboard-footer">
                <div class="row">
                  <div class="col-3">
                    <div class="dropdown">
                      <a class="dropdown-toggle" class="tc-logo" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="../assets/images/menu.png" style="width:25px">
                      </a>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#Active-EmployeeOne" class="d-block">CEG <span class="text-muted float-right" id="empCeg"><?= $cegActiveEmp; ?></span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#Active-EmployeeCEGTH" class="d-block">CEGTH <span class="text-muted float-right" id="empCegTh"><?= $cegthActiveEmp; ?></span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#Active-EmployeeCEGProject" class="d-block">CEG Project <span class="text-muted float-right" id="empCegProject"><?= $cegprojectActiveEmp; ?></span></a>
                      </div>
                    </div>
                  </div>

                  <div class="col-9 text-right">
                    <img src="../assets/images/Active-Employee.png" class="w-75">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="box-userdashboard">
              <div class="links"><a href="<?php echo base_url('emp_on_leave'); ?>" class="pull-right"><i class="icon-plus"></i></a></div>
              <div class="body">
                <div class="row">
                  <div class="col-3 align-self-center">
                    <span class="userdashboard-icon">
                      <img src="../assets/images/employee-infographic.png" class="w-100">
                    </span>
                  </div>
                  <div class="col-9">
                    <p class="mb-0"><b>Employees on Leave</b></p>
                    <?php $today = date("Y-m-d");
                    $today_date = strtotime($today);
                    $i = 0;
                    $cegth = 0;
                    $ceg = 0;
                    foreach ($employeeLeaveData as $leavedata) {
                       $fromdate = strtotime($leavedata->f_date);
                      $todate = strtotime($leavedata->t_date);
                      if (($fromdate == $today_date && $todate == $today_date) || ($fromdate <= $today_date && $todate >= $today_date)) {
                        if ($leavedata->business_id == 1) {
                          $ceg++;
                        }
                        if ($leavedata->business_id == 2) {
                          $cegth++;
                        }
                        $i++;
                      }
                    } ?>
                    <h2 class="tc-active mb-0"><b><?= $i; ?></b></h2>
                    <p class="mb-0">this day</p>
                  </div>
                </div>
              </div>
              <div class="userdashboard-footer bg5-active">
                <div class="row">
                  <div class="col-3">
                    <div class="dropdown">
                      <a class="dropdown-toggle" class="tc-logo" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="../assets/images/menu.png" style="width:25px">
                      </a>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#EmployeeLeave-ceg" class="d-block">CEG <span class="text-muted float-right" id="empCeg"><?= $ceg ? $ceg  : ''; ?></span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#EmployeeLeave-cegTh" class="d-block">CEGTH <span class="text-muted float-right" id="empCegTh"><?= $cegth ? $cegth : ''; ?></span></a>

                      </div>
                    </div>
                  </div>

                  <div class="col-9 text-right">
                    <img src="../assets/images/Employees-Leave-icon.png" class="w-75">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="box-userdashboard">
              <div class="body">
                <div class="row">
                  <div class="col-3 align-self-center">
                    <span class="userdashboard-icon">
                      <img src="../assets/images/tourism.png" class="w-100">
                    </span>
                  </div>
                  <div class="col-9">
                    <p class="mb-0"><b>Employees On Tour</b></p>
                    <?php $tod = date("Y-m-d");
                    $currentdate = strtotime($tod);
                 //   $currentdate = strtotime($today_dateM);
                    $totaltour_emp = 0;
                    $cegth_emp_tour = 0;
                    $ceg_emp_on_tour = 0;
                    foreach ($empontourtoday as $emp) {
                      $fromtourdate =  strtotime($emp->stdate);
                      $totourdate =  strtotime($emp->endate);
                      if (($fromtourdate == $currentdate && $totourdate == $currentdate) || ($fromtourdate <= $currentdate && $totourdate >= $currentdate)) {
                        if ($emp->busid == 1) {
                          $ceg_emp_on_tour++;
                        }
                        if ($emp->busid == 2) {
                          $cegth_emp_tour++;
                        }
                        //  elseif ($emp->busid == 3) {
                        //   $cegth_emp_tour++;
                        // }
                        $totaltour_emp++;
                      }
                    } ?>
                    <h2 class="tc-darkhospital mb-0"><b><?= $totaltour_emp; ?></b></h2>
                    <p class="mb-0">this day</p>
                  </div>
                </div>
              </div>
              <div class="userdashboard-footer bg5-darkhospital">
                <div class="row">
                  <div class="col-3">
                    <div class="dropdown">
                      <a class="dropdown-toggle" class="tc-logo" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="../assets/images/menu.png" style="width:25px">
                      </a>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#EmployeeTour-CEG" class="d-block">CEG <span class="text-muted float-right" id="empCeg"><?= $ceg_emp_on_tour ?></span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#EmployeeTour-CEGTh" class="d-block">CEGTH <span class="text-muted float-right" id="empCegTh"><?= $cegth_emp_tour ?></span></a>

                      </div>
                    </div>
                  </div>

                  <div class="col-9 text-right">
                    <img src="../assets/images/Employees-Tour-icon.png" class="w-75">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="box-userdashboard">
              <div class="body">
                <div class="row">
                  <div class="col-3 align-self-center">
                    <span class="userdashboard-icon">
                      <img src="../assets/images/work-from-home-icon.png" class="w-100">
                    </span>
                  </div>
                  <div class="col-9">
                    <p class="mb-0"><b>Work From Home</b></p>
                    <h2 class="tc-draknailon mb-0"><b>000</b></h2>
                    <p class="mb-0">this day</p>
                  </div>
                </div>
              </div>
              <div class="userdashboard-footer bg5-draknailon">
                <div class="row">
                  <div class="col-3">
                    <div class="dropdown">
                      <a class="dropdown-toggle" class="tc-logo" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="../assets/images/menu.png" style="width:25px">
                      </a>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal" class="d-block">CEG <span class="text-muted float-right" id="empCeg">000</span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal" class="d-block">CEGTH <span class="text-muted float-right" id="empCegTh">000</span></a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal" class="d-block">CEG Project <span class="text-muted float-right" id="empCegProject">000</span></a>
                      </div>
                    </div>
                  </div>

                  <div class="col-9 text-right">
                    <img src="../assets/images/Work-From-Home.png" class="w-75">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row clearfix">
          <div class="col-md-9">
            <div class="card planned_task box-dashboard o-hidden">
              <div class="header">
                <h2>Floor Wise Attendance</h2>

              </div>
              <div class="body">
                <figure class="highcharts-figure">
                  <div id="container"></div>
                </figure>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card planned_task box-dashboard o-hidden">
              <div class="header">
                <h2>Events</h2>
              </div>
              <div class="body ">

              </div>
            </div>
          </div>
        </div>
        <!-- <div class="row clearfix">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="card overflowhidden number-chart">
                            <div class="body">
                                <div class="number">
                                    <h6>ACTIVE EMPLOYEE <a href="<?php echo base_url('companyreport') ?>" class="" style="margin:0 0 0 20px"><i class="icon-pin"></i></a><a href="<?php echo base_url('companyProjectReport') ?>" class="pull-right"><i class="icon-plus"></i></a></h6>
                                    <span>CEG </span> <small class="text-muted" id="empCeg"></small><div class="clearfix"></div>
                                    <span>CEGTH </span> <small class="text-muted" id="empCegTh"></small><div class="clearfix"></div>
                                    <span>CEG Project </span> <small class="text-muted" id="empCegProject"></small><div class="clearfix"></div>
                                </div>
                                <small class="text-muted">Total <b><span id="activeEmployeeTotal"></span></b> Active Employee</small>
                            </div>
                            <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"  data-line-Width="1" data-line-Color="#f79647" data-fill-Color="#fac091">1,4,1,3,7,1</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="card overflowhidden number-chart">
                            <div class="body">
                                <div class="number">
                                    <h6>Employees on Leave<a href="<?php echo base_url('emp_on_leave'); ?>" class="pull-right"><i class="icon-plus"></i></a></h6>
                                    <span>CEG(<?= $countEmpleaveceg; ?>)</span><br>
                                    <span>CEGTH(<?= $countEmpleavecegth; ?>)</span><br>
                                    <span>CEG Project(0)</span>
                                </div>
                                <small class="text-muted">19% compared to last week</small>
                            </div>
                            <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                                 data-line-Width="1" data-line-Color="#604a7b" data-fill-Color="#a092b0">1,4,2,3,6,2</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="card overflowhidden number-chart">
                            <div class="body">
                                <div class="number">
                                    <h6>Tasks<a href="<?php echo "#"; ?>" class="pull-right"><i class="icon-plus"></i></a></h6>
                                    <span>CEG(4)</span><br>
                                    <span>CEGTH(2)</span><br>
                                    <span>CEG Project(9)</span>
                                </div>
                                <small class="text-muted">19% compared to last week</small>
                            </div>
                            <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                                 data-line-Width="1" data-line-Color="#4aacc5" data-fill-Color="#92cddc">1,4,2,3,1,5</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="card overflowhidden number-chart">
                            <div class="body">
                                <div class="number">
                                    <h6>Projects</h6>
                                    <span>-</span>
                                </div>
                                <small class="text-muted">-</small>
                            </div>
                            <div class="sparkline" data-type="line" data-spot-Radius="0" data-offset="90" data-width="100%" data-height="50px"
                                 data-line-Width="1" data-line-Color="#4f81bc" data-fill-Color="#95b3d7">1,3,5,1,4,2</div>
                        </div>
                    </div>
                </div> -->


      </div>
    </div>


  </div>


  <!-- Active-Employee CEG -->
  <div class="modal fade" id="Active-EmployeeOne" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Active Employee CEG</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $d = 1;
                foreach ($ActiveEmployeedata as $ActiveEmpData) {
                  if ($ActiveEmpData->businessunit_id == 1) {
                ?>
                    <tr>
                      <th scope="row"><?= $d++; ?></th>
                      <td><?= $ActiveEmpData->employeeId; ?></td>
                      <td><?= $ActiveEmpData->userfullname; ?></td>
                      <td><?= $ActiveEmpData->jobtitle_name; ?></td>
                    </tr>

                <?php
                  }
                } ?>
                <!-- <tr>
                  <th scope="row">1</th>
                  <td>EMP00315</td>
                  <td>Narayan Singh</td>
                  <td>F</td>
                </tr> -->

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Active-Employee CEGTH -->
  <div class="modal fade" id="Active-EmployeeCEGTH" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Active Employee CEGTH</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $d = 1;
                foreach ($ActiveEmployeedata as $ActiveEmpData) {
                  if ($ActiveEmpData->businessunit_id == 2) {
                ?>
                    <tr>
                      <th scope="row"><?= $d++; ?></th>
                      <td><?= $ActiveEmpData->employeeId; ?></td>
                      <td><?= $ActiveEmpData->userfullname; ?></td>
                      <td><?= $ActiveEmpData->jobtitle_name; ?></td>
                    </tr>

                <?php
                  }
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Active-Employee CEG Projrect -->
  <div class="modal fade" id="Active-EmployeeCEGProject" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Active Employee CEG Project</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $d = 1;
                foreach ($ActiveEmployeedata as $ActiveEmpData) {
                  if ($ActiveEmpData->businessunit_id == 3) {
                ?>
                    <tr>
                      <th scope="row"><?= $d++; ?></th>
                      <td><?= $ActiveEmpData->employeeId; ?></td>
                      <td><?= $ActiveEmpData->userfullname; ?></td>
                      <td><?= $ActiveEmpData->jobtitle_name; ?></td>
                    </tr>

                <?php
                  }
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Employee Leave CEG -->
  <div class="modal fade" id="EmployeeLeave-ceg" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Employee Leave Status CEG</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                  <th scope="col">No of Days</th>
                  <th scope="col">Bus. Unit</th>
                  <th scope="col">Leave Status</th>
                </tr>
              </thead>
              <tbody>


                <?php
                $c = 1;
                foreach ($employeeLeaveData as $leavedata) {
                  $fromdate =  strtotime($leavedata->f_date);
                  $todate =  strtotime($leavedata->t_date);
                  if (($fromdate == $today_date && $todate == $today_date) || ($fromdate <= $today_date && $todate >= $today_date)) {
                    if ($leavedata->business_id == 1) { ?>
                      <tr>
                        <th scope="row"><?= $c++; ?></th>
                        <td><?= $leavedata->emp_id; ?></td>
                        <td><?= $leavedata->username; ?></td>
                        <td><?= $leavedata->title_name; ?></td>
                        <td><?= $leavedata->nofday; ?></td>
                        <td><?= $leavedata->busname; ?></td>
                        <td><?= $leavedata->lstatus; ?></td>
                      </tr>
                <?php  }
                  }
                } ?>




              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Employee Leave CEGTH -->
  <div class="modal fade" id="EmployeeLeave-cegTh" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Employee Leave Status CEGTH</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                  <th scope="col">No of Days</th>
                  <th scope="col">Bus. Unit</th>
                  <th scope="col">Leave Status</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $c = 1;
                foreach ($employeeLeaveData as $leavedata) {
                  $fromdate =  strtotime($leavedata->f_date);
                  $todate =  strtotime($leavedata->t_date);
                  if (($fromdate == $today_date && $todate == $today_date) || ($fromdate <= $today_date && $todate >= $today_date)) {
                    if ($leavedata->business_id == 2) { ?>
                      <tr>
                        <th scope="row"><?= $c++; ?></th>
                        <td><?= $leavedata->emp_id; ?></td>
                        <td><?= $leavedata->username; ?></td>
                        <td><?= $leavedata->title_name; ?></td>
                        <td><?= $leavedata->nofday; ?></td>
                        <td><?= $leavedata->busname; ?></td>
                        <td><?= $leavedata->lstatus; ?></td>
                      </tr>
                <?php  }
                  }
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>



  <!-- Employees On Tour ceg -->
  <div class="modal fade" id="EmployeeTour-CEG" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Employees On Tour CEG</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                  <th scope="col">Bus. Unit</th>
                  <th scope="col">Leave Status</th>
                </tr>
              </thead>
              <tbody>
                <?php
                // foreach ($empontourtoday as $emplo) {
                // } 
                ?>
                <?php
                $c = 1;
                foreach ($empontourtoday as $emplo) {
                  $fromtourdate =  strtotime($emplo->stdate);
                  $totourdate =  strtotime($emplo->endate);
                  if (($fromtourdate == $currentdate && $totourdate == $currentdate) || ($fromtourdate <= $currentdate && $totourdate >= $currentdate)) {
                    if ($emplo->busid == 1) { ?>
                      <tr>
                        <th scope="row"><?= $c++; ?></th>
                           <td><?= $emplo->empuserid; ?></td>
                        <td><?= $emplo->username; ?></td>
                        <td><?= $emplo->titlename; ?></td>
                        <td><?= $emplo->busname; ?></td>
                        <td><?php ?></td>
                      </tr>
                <?php  }
                  }
                } ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Employees On Tour cegTh -->
  <div class="modal fade" id="EmployeeTour-CEGTh" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered w-max-90" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Employees On Tour CEGTH</h5>
          <button type="button" class="btn btn-secondary" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">Close</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="table-responsive bootstrapTable ">
            <table class="table table-striped table-bordered table-hover">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Sr.No.</th>
                  <th scope="col">Emp. ID</th>
                  <th scope="col">Emp. Name</th>
                  <th scope="col">Job Grade</th>
                  <th scope="col">Bus. Unit</th>
                  <th scope="col">Leave Status</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $c = 1;
                foreach ($empontourtoday as $emplo) {
                  $fromtourdate =  strtotime($emplo->stdate);
                  $totourdate =  strtotime($emplo->endate);
                  if (($fromtourdate == $currentdate && $totourdate == $currentdate) || ($fromtourdate <= $currentdate && $totourdate >= $currentdate)) {
                    if ($emplo->busid == 2) { ?>
                      <tr>
                        <th scope="row"><?= $c++; ?></th>
                        <td><?= $emplo->empid; ?></td>
                        <td><?= $emplo->username; ?></td>
                        <td><?= $emplo->titlename; ?></td>
                        <td><?= $emplo->busname; ?></td>
                        <td><?php ?></td>
                      </tr>
                <?php  }
                  }
                } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
        <script type="text/javascript">
            $.ajax({
                url: '<?php echo base_url('mastercontrol/activeEmployee'); ?>',
                type: 'POST',
                dataType: 'json',
                success: function (data) {
                    console.log("Test Data :" + data);
                    $("#empCeg").html('(' + data.activeEmployeeCeg + ')');
                    $("#empCegTh").html('(' + data.activeEmployeeCegTh + ')');
                    $("#empCegProject").html('(' + data.activeEmployeeCegProject + ')');
                    $("#activeEmployeeTotal").html(data.activeEmployeeTotal);
                }
                data:{[csrfName]: csrfHash}, 
            });
</script>
   <script>
            Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    exporting:false,
    credits:false,
    title: {
        text: ''
    },
    xAxis: {
        categories: ['Floor  -1','Floor 0', 'Floor 1', 'Floor  2', 'Floor 3', 'Floor  4', 'Floor  5','Floor  6', 'Floor  7']
    },
    yAxis: {
        min: 0,
        title: {
            text: null
        },

    },
    tooltip: {
        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
        shared: true
    },
    plotOptions: {
        column: {
            stacking: 'percent'
        }
    },
    series: [{
        name: 'A',
        data: [5, 3, 4, 7, 2,5,8,9,7]
    }, {
        name: 'B',
        data: [5, 3, 10, 7, 2,5,8,9,7]
    }, {
        name: 'C',
        data: [5, 56, 4, 7, 2,5,8,9,7]
    }, {
        name: 'D',
        data: [5, 3, 4, 7, 2,5,8,9,7]
    }, {
        name: 'E',
        data: [5, 3, 4, 45, 2,5,8,9,7]
    }, {
        name: 'F',
        data: [5, 3, 4, 7, 2,55,8,9,7]
    }]
});
        </script>
        
        
        <?php $this->load->view('admin/includes/footer'); ?>

    </div>
</body>

