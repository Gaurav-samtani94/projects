<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$YearArr = array('2010' => '2010', '2011' => '2011', '2012' => '2012', '2013' => '2013', '2014' => '2014', '2015' => '2015', '2016' => '2016', '2017' => '2017', '2018' => '2018', '2019' => '2019', '2020' => '2020', '2021' => '2021', '2022' => '2022');
$MonthArr = array('1' => 'Jan', '2' => 'Feb', '3' => 'March', '4' => 'April', '5' => 'May', '6' => 'June', '7' => 'July', '8' => 'August', '9' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'December');

?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
										<form id="form-filter">
										<div class="row">
											<div class="col-lg-3 col-md-6">
												<label for="year_name">Year :</label>
												<div class="input-group mb-3">
													<select name="year_name" id="year_name" class="form-control" data-placeholder="Select">
														<option value="" selected="selected"> Select Year </option>
														<?php
														if ($YearArr):
															foreach ($YearArr as $key_year => $YearRow) {
																?>
																<option <?= (date('Y') == $key_year) ? "Selected" : "" ?> value="<?= $key_year; ?>"><?= $YearRow; ?></option>
																<?php
															}
														endif;
														?>
													</select>
												</div>
											</div>

											<div class="col-lg-3 col-md-6">
												<label for="month_name">Month :</label>
												<div class="input-group mb-3">
													<select name="month_name" id="month_name" class="form-control" data-placeholder="Select">
														<option value="" selected="selected"> Select Month </option>
														<?php
														if ($MonthArr):
															foreach ($MonthArr as $key_month => $MonthRow) {
																?>
																<option <?= (date('m') == $key_month) ? "Selected" : "" ?> value="<?= $key_month; ?>"><?= $MonthRow; ?></option>
																<?php
															}
														endif;
														?>
													</select>
												</div>
											</div>
											<div class="col-sm-3 col-xs-4"> 
												<div class="mt-sm-3">
												<button type="button" id="btn-filter" class="btn btn-one"> Filter </button>
											
												<button type="button" id="btn-reset" class="btn btn-success"> Reset </button>
											</div>
											</div>
										</div>
									</form>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="card">
                            <div class="body">
                               <ul class="nav nav-tabs-new mb-2">
                                    <li class="nav-item mr-1"><a class="nav-link active show" data-toggle="tab" href="#cegprojectTab">CEG Project</a></li>
                                    <li class="nav-item mr-1"><a class="nav-link" data-toggle="tab" href="#cegTab">CEG</a></li>
                                    <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#cegthTab">CEGTH</a></li>
                        
                                </ul> 
								<div class="tab-content">
                                    <div class="tab-pane show active" id="cegprojectTab">
								<div class="table-responsive">
                                    <table id="table" class="table table-striped display" cellspacing="0" width="100%">
                <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Project Name</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Project Name</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
												<th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                            </tr>
                                        </tfoot>
                <tbody>
                </tbody>
            </table>
                                </div>
                                </div>
								<div class="tab-pane" id="cegTab"  style="overflow: auto;" >
									<table id="table1" class="table table-striped display" cellspacing="0" width="100%">
										<thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Location</th>
                                                <th>Department</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                                  <th>31</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Location</th>
                                                <th>Department</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
												<th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                                  <th>31</th>
                                            </tr>
                                        </tfoot>
										<tbody>
										</tbody>
									</table>
								</div>
								<!-- Attendance Report of CEGTH -->
								<div class="tab-pane" id="cegthTab"  style="overflow: auto;" >
									<table id="table2" class="table table-striped display" cellspacing="0" width="100%">
										<thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Location</th>
                                                <th>Department</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                                  <th>31</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EmpCode</th>
                                                <th>EmpName</th>
                                                <th>Location</th>
                                                <th>Department</th>
                                                <th>JobTitle</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
												<th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                 <th>24</th>
                                                  <th>25</th>
                                                  <th>26</th>
                                                  <th>27</th>
                                                  <th>28</th>
                                                  <th>29</th>
                                                  <th>30</th>
                                                  <th>31</th>
                                            </tr>
                                        </tfoot>
										<tbody>
										</tbody>
									</table>
								</div>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
    </div>

<script type="text/javascript">
    var table;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        // var compid = $('#companynames').val();
        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
			"scrollY":'65vh',
             "scrollX": true,
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url('AttendanceReport_Controller/ajax_listattendance_cegProject') ?>",
                "type": "POST",
                "data": function (data) {
                            data.year_name = $('#year_name').val();
                            data.month_name = $('#month_name').val();
                },
                        data:{[csrfName]: csrfHash}, 

            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
	
	var table1;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        // var compid = $('#companynames').val();
        table1 = $('#table1').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
			"scrollY":'65vh',
             "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('AttendanceReport_Controller/ajax_list_monthly_attendance_ceg') ?>",
                "type": "POST",
                "data": function (data) {
                            // data.year_name = $('#year_name').val();
                            // data.month_name = $('#month_name').val();
                },
                        data:{[csrfName]: csrfHash}, 

            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
	
	//================= Attendance Report of CEGTH ======================
	var table2;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        // var compid = $('#companynames').val();
        table1 = $('#table2').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
			"scrollY":'65vh',
             "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('AttendanceReport_Controller/ajax_list_monthly_attendance_cegth') ?>",
                "type": "POST",
                "data": function (data) {
                            // data.year_name = $('#year_name').val();
                            // data.month_name = $('#month_name').val();
                },
                        data:{[csrfName]: csrfHash}, 

            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
</script>
<?php $this->load->view('admin/includes/footer'); ?>
</body>
