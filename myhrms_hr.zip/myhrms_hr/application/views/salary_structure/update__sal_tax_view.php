<?php
// echo "<pre>"; print_r($gpaiFixedAmt); die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    input[type='text'] {
        background-color:#fff;
    }
    .mytable, th, td {
        border: 1px solid black;
        text-align: center;
        background-color: #003943;
        padding: 8px;

    }
    .mytable, td{
        background-color: #d4e4e7;
        color: #003943;
    }
    .mytable, th{
        color: #fff;
    }
    </style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Monthly Tour Management</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                    <div class="">
                                <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (validation_errors()): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= validation_errors(); ?>
                                    </div>
                                <?php endif; ?>
                        </div>
                        <div class="card">
                            <div class="body">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <!--<div class="card-header" id="headingOne">-->
                                        <a class="btn btn-primary float-right" href="<?php echo $_SERVER['HTTP_REFERER'];?>" >Back</a>
                                        <h4>GPAI(Group Personal Accidental Insurance) & Telephone</h4>
                                        <form method="POST" action="<?php echo base_url('fixed_anx_amt')?>" name="" id="">
                                        <div class="row clearfix">
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                <label for="grade">Grade : </label>
                                                    <select class="form-control select2" id="grade" name="grade">
                                                        <option value=""> -- Select -- </option>
                                                            <?php 
                                                            $gradeArr = array(1 => 'A', 2=>'B', 3=>'C', 4=>'D', 5=>'E', 6=>'F');
                                                            if($gradeArr){ 
                                                                foreach($gradeArr as $key => $rOws){  ?>
                                                                <option value="<?= $key; ?>"> <?= $rOws; ?></option>
                                                            <?php } } ?>
                                                        </select>
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="gpai">GPAI : </label>
                                                    <input type="number" class="form-control" id="gpai" name="gpai">
                                                 </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="telephone">Telephone : </label>
                                                    <input type="number" class="form-control" id="telephone" name="telephone">
                                                 </div>
                                            </div>
                                            <div class="col-lg-3">
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="telephone">Education Allowance : </label>
                                                    <input type="number" class="form-control" id="telephone" name="telephone">
                                                 </div>
                                            </div>

                                            <div class="col-lg-2">
                                                <div class="mt-sm-3">
                                                <label for="s"></label><br>
                                                    <button type="submit" class="btn btn-primary" name="gpai_tele_submit" value="gpai_tele_submit">Submit</button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                        <h4>Mediclaim Preminum</h4>
                                    <form method="POST" action="<?php echo base_url('fixed_anx_amt')?>" name="mediclaim_form" id="mediclaim_form">
                                        <div class="row">
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label for="self">Self : </label>
                                                <span id="reqd" class="error_self"><?= form_error('self'); ?></span>
                                                <input type="number" class="form-control" name="self" id="self" >
                                                </div>
                                        </div>

                                        
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label for="spouse">Spouse : </label>
                                                <span id="reqd" class="error_spouse"><?= form_error('spouse'); ?></span>
                                                <input type="number" class="form-control" id="spouse" name="spouse" >
                                                </div>
                                        </div>

                                        
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label for="child">Child : </label>
                                                <span id="reqd" class="error_child"><?= form_error('child'); ?></span>
                                                <input type="number" class="form-control" id="child" name="child" >
                                                </div>
                                        </div>

                                        

                                        <div class="col-lg-2">
                                                <div class="mt-sm-3">
                                                    <button type="submit" class="btn btn-primary" name="mediclaim_submit" value="mediclaim_submit">Submit</button>
                                                </div>
                                        </div>
                                    </div>                    
                                    </form>
                                </div>  
                                
                            </div>
                        </div>


                        <div class="card">
                            <div class="body">
                                <div class="row">
                                <div class="col-md-6">
                                    <h4>GPAI & Telephone</h4>
                                    <table class="mytable" width="100%">
                                        <tr>
                                            <th>Grade</th>
                                            <th>GPAI</th>
                                            <th>Telephone</th>
                                        </tr>
                                        <?php if($gpaiFixedAmt) {

                                        foreach($gpaiFixedAmt as $amount) { 
                                            $gradeArr = array(1 => 'A', 2=>'B', 3=>'C', 4=>'D', 5=>'E', 6=>'F'); ?>
                                        <tr>
                                            <td><?php echo $gradeArr[$amount->grade];?></td>
                                            <td><?php echo $amount->gpai;?></td>
                                            <td><?php echo $amount->telephone;?></td>
                                        </tr>
                                        <?php } }?>
                                    </table>
                                <!-- <div class="table-responsive">
                                    <table id="" class="table table1 bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Grade</th>
                                                <th>GPAI</th>
                                                <th>Temephone</th>
                                            </tr>
                                        </thead>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Grade</th>
                                                <th>GPAI</th>
                                                <th>Temephone</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div> -->
                                </div>
                                <div class="col-md-6">
                                    <h4>Mediclaim Premium</h4>
                                    <table class="mytable" width="100%">
                                        <tr>
                                            <th>Self</th>
                                            <th>Spouse</th>
                                            <th>Child</th>
                                        </tr>
                                        <tr>
                                            <td><?php echo $mediPremFixedAmt->self;?></td>
                                            <td><?php echo $mediPremFixedAmt->spouse;?></td>
                                            <td><?php echo $mediPremFixedAmt->child;?></td>
                                        </tr>
                                    </table>
                                <!-- <div class="table-responsive">
                                    <table id="" class="table table2 bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Self</th>
                                                <th>Spouse</th>
                                                <th>Child</th>
                                            </tr>
                                        </thead>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Self</th>
                                                <th>Spouse</th>
                                                <th>Child</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div> -->
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
    </div>

    
    <script type="text/javascript">






        var table;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

          //  var compid = $('#companynames').val();
            table = $('.table1').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
				"scrollY":'62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_sal_anx_fixedAmt'); ?>",
                    "type": "POST",
                    "data": function (data) {
					//    data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [
                ],
                // "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });



            /**@abstract
             *  Premium data table
            */
            table = $('.table2').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
				"scrollY":'62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_sal_anx_mediclaim_premium'); ?>",
                    "type": "POST",
                    "data": function (data) {
					//    data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [
                ],
                // "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });
        });
    


    </script>
	<?php $this->load->view('admin/includes/footer'); ?>
    <script>

$(document).ready(function () {
            // alert("test")
            // $("#gpaiTele_form").submit(function (event) {
            $("#").submit(function () {
                // alert("mytest")
                // var formData =  $("#gpaiTele_form").serialize();
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                var formData =  $('form').serialize()
                // alert(formData + 'test')
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('updateSalAnextureAmt');?>",
                    data: formData,
                    dataType: "json",
                    success: function (data) {
                        toastr.success("Data Saved Successfully");
                    }
                    // event.preventDefault();
                });

                $('#gpaiTele_form').each(function(){
                        this.reset();
                    });
                        $('#grade').val(2);
            });

            /**
             * Add Mediclaim Premium ajax
             */
            // $(document).on('submit','#mediclaim_form', function (e) {
                // $('#mediclaim_form').submit(function(e) {

                    // e.preventDefault(); // avoid to execute the actual submit of the form.
// alert("test");
                    // var form = $(this);
                    // var actionUrl = form.attr('action');

                    // $.ajax({
                    //     type: "POST",
                    //     url: actionUrl,
                    //     data: form.serialize(), // serializes the form's elements.
                    //     success: function(data)
                    //     {
                    //     alert(data); // show response from the php script.
                    //     }
                    // });

                });
        });

    </script>
</body>