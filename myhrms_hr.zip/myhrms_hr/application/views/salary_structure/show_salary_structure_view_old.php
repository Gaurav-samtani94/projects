
<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
table thead {
    color: #000;
}
        .w-250{
            width: 250px;
        }
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="block-header stepper">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                            <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                        </ul>
                    </div> 
                </div>
            </div>
            <div class="container">
            <a class="btn btn-info float-left" target="_blank" href="<?php echo base_url('download_sal_anexture_pdf/'.$userDetails->user_id);?>"> Download</a>
            <a class="btn btn-primary float-right" href="<?php echo $_SERVER['HTTP_REFERER'];?>" >Back</a><br>

            <!-- base_url('download_sal_anexture_pdf/'.$userDetails->user_id)?> -->
            

                <!--<div class="container">-->
        <div class="card">
            <div class="body" id='print_div'>
            <div class="row">
                <div class="col-10">
                    <h2 class="mb-0 text-dark"><b><?php echo ($userDetails->company_name) ? $userDetails->company_name : "ON-PROJECT"; ?></b></h2>
                    <p>(HO) B - 11 (G) Malviya Industrial Area, Jaipur, Rajasthan 302017</p>
                    <p class="small-month mb-0">GSTIN : 08AFQPK1299C1Z8</p>
                    <p class="small-month"><span class="mr-5">Tel. : 9773356002</span><span>email  :  business@growthgrids.com</span></p>
                </div>
                <div class="col-2">
                    <img src="https://www.cegindia.com/public/assets/site//images/logo.png" class="w-100">
                </div>
            </div>
        
            <div class="row">
            <div class="col-md-6 pr-0">
                <div class="p-3 border h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        Name
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1"  >
                        <div  class="bg-light">
                            <b>: <?php echo ($userDetails->userfullname) ? $userDetails->userfullname : '-'; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Designation    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->position_name) ? $userDetails->position_name : '-'; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Dept / Project Name    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? $userDetails->department_name : $userDetails->department_name; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Location (HO RO / Project)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? "HO/RO" : "Project"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Group
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->jobtitle_name) ? $userDetails->jobtitle_name : "-"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        CTC Offered (Monthly)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ctc) ? number_format($salArrToObj->ctc) : "-"; ?></b>
                    </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Company Name              
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->company_name) ? $userDetails->company_name : "-"; ?></b>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pl-0">
                <div class="p-3 border border-left-0 h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        PF Applicable (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->pf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        VPF Applicable (Y/N)
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->vpf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        ESI Applicable (Y/N)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->esi_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Metro/Non Metro
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->metro_non == 1) ? "Metro" : "Non-Metro"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Gratuity
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->gratuity_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Mediclaim
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->mediclaim_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Annual Bonus offered (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ann_bonus_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        AB Amount (Included in CTC)         
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->annual_bonus) ? number_format($salArrToObj->annual_bonus) : "-"; ?></b>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="table-responsive mt-4">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Particulars</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.)</th>
                    <th class="white-space-nowrap w-250">Annually Amount (Rs.)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Earnings</th>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>Basic Salary</td>
                    <td><?php echo ($salArrToObj->basic_sal) ? number_format($salArrToObj->basic_sal) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->basic_sal) ? number_format(($salArrToObj->basic_sal * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>HRA</td>
                    <td><?php echo ($salArrToObj->hra) ? number_format($salArrToObj->hra) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->hra) ? number_format(($salArrToObj->hra * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>Education Allowance</td>
                    <td><?php echo ($salArrToObj->edu_allow) ? number_format($salArrToObj->edu_allow) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->edu_allow) ? number_format(($salArrToObj->edu_allow * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>Telephone Allowance</td>
                    <td><?php echo ($salArrToObj->tele_allow) ? number_format($salArrToObj->tele_allow) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->tele_allow) ? number_format(($salArrToObj->tele_allow * 12)) : "0"; ?></td>
                  </tr>
                  <tr>
                    <td>Special Allowance</td>
                    <td><?php echo ($salArrToObj->special_allowance) ? number_format($salArrToObj->special_allowance) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->special_allowance) ? number_format(($salArrToObj->special_allowance * 12)) : "-"; ?></td>
                  </tr>
                  
                </tbody>
                
            </table>
        </div>
        <div class="table-responsive ">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Gross Salary</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.) &nbsp;<?php echo ($salArrToObj->gross) ? number_format($salArrToObj->gross) : "-"; ?></th>
                    <th class="white-space-nowrap w-250">Annually Amount (Rs.)&nbsp;<?php echo ($salArrToObj->gross) ? number_format(($salArrToObj->gross*12)) : "-"; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Deductions</th>
                    <td></td>
                    <td></td>
                  </tr>
                 <tr>
                    <td>Employer's Contribution to PF *</td>
                    <td><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Employer's Contribution to ESI *</td>
                    <td><?php echo ($salArrToObj->employer_esi) ? number_format($salArrToObj->employer_esi) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employer_esi) ? number_format(($salArrToObj->employer_esi)*12) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Employer's Contribution to Gratuity *</td>
                    <td><?php echo ($salArrToObj->gratuity_amount) ? number_format($salArrToObj->gratuity_amount) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->gratuity_amount) ? number_format(($salArrToObj->gratuity_amount*12)) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Group Personal Accidental Insurance **</td>
                    <td><?php echo ($salArrToObj->gpai) ? number_format($salArrToObj->gpai) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->gpai) ? number_format(($salArrToObj->gpai*12)) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Group Mediclaim Insurance ***</td>
                    <td><?php echo ($salArrToObj->mediclaim_amount) ? number_format($salArrToObj->mediclaim_amount) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->mediclaim_amount) ? number_format(($salArrToObj->mediclaim_amount*12)) : "0"; ?></td>
                 </tr>
                </tbody>
               
            </table>
        </div>
       <div class="table-responsive">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Monthly CTC</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.)&nbsp;<?php echo ($salArrToObj->monthly_ctc) ? number_format($salArrToObj->monthly_ctc) : "0"; ?></th>
                    <th class="white-space-nowrap w-250" >Annually Amount (Rs.)&nbsp;<?php echo ($salArrToObj->monthly_ctc) ? number_format(($salArrToObj->monthly_ctc)*12) : "0"; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Annual Bonus ****</th>
                    <td><?php echo ($salArrToObj->annual_bonus) ? number_format($salArrToObj->annual_bonus) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->annual_bonus) ? number_format(($salArrToObj->annual_bonus * 12)) : "0"; ?></td>
                  </tr>
                 
                </tbody>
                <tfoot class="bg-light">
                    <tr>
                        <th class="text-right">Total CTC(round-off)</th>
                        <th><?php echo ($salArrToObj->total_ctc) ? number_format($salArrToObj->total_ctc) : "0"; ?></th>
                        <th><?php echo ($salArrToObj->total_ctc) ? number_format(($salArrToObj->total_ctc*12)) : "0"; ?></th>
                    </tr>
                    <tr>
                        <th class="text-left">CTC in Words -</th>
                        <th colspan="2"><?php echo $salArrToObj->ctc_in_words;?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="my-3 border">
            <div class="border-bottom p-3">
                * Gratuity shall be payable as per The Payment of Gratuity Act 1972.
            </div>
            <div class="border-bottom p-3 mt-3">
                ** Apart from your Gross Salary, you will be entitled for Group Personal Accident Insurance (GPAI) for a sum assured of Rs. 4000000/- for self only (applicable 24 hours’ coverage). Sum assured is subject to change as per the company’s agreement with Insurance Company.
            </div>
            <div class="border-bottom p-3 mt-3">
                *** You will be covered under Group Mediclaim Insurance Policy for a sum assured of Rs. 2,00,000/- for one year. The key features of the policy are available on HRMS under Policy section.
            </div>
            <div class="p-3 mt-3">
                **** The above CTC is inclusive of Annual Bonus (AB) of Rs. 235080. Annual Bonus will be paid after 12 Months and shall be paid in proportionate to the service rendered during one year of service.
            </div>
        </div>
    <!-- </div> -->

                <!--<div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <span><?php echo $salArr['userfullname']?></span>
                            <table style="width: 100%;margin-top: 15px;">
                                <tbody>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">PF Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['pf_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">VPF Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['vpf_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">ESI Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['esi_applicable']) ? 'Y' : 'N'; ?></td>
                                    </tr>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Gratuity</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['gratuity_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mediclaim</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['mediclaim_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Annual Bonus Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['ann_bonus_applicable']) ? 'Y' : 'N'; ?></td>
                                    </tr>
                                    <tr style="margin-top:10px">
                                    </tr>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Basic Salary</td>
                                        <td style="font-size:12px">: <?php echo $salArr['basic_sal']; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">HRA</td>
                                        <td style="font-size:12px">:<?php echo $salArr['hra']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Education Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['edu_allow'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Telephone Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['tele_allow']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Bonus (Adv)</td>
                                        <td style="font-size:12px">: <?php echo $salArr['bonus'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Special Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['special_allowance']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Gross</td>
                                        <td style="font-size:12px">: <?php echo $salArr['gross'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's PF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employer_pf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's ESI</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employer_esi']; ?></td>
                                    </tr>

                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's Gratuity</td>
                                        <td style="font-size:12px">: <?php echo $salArr['gratuity'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">GPAI</td>
                                        <td style="font-size:12px">:<?php echo $salArr['gpai']; ?> </td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mediclaim</td>
                                        <td style="font-size:12px">: <?php echo $salArr['mediclaim'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Monthly CTC</td>
                                        <td style="font-size:12px">:<?php echo $salArr['monthly_ctc']; ?> </td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Annual Bonus</td>
                                        <td style="font-size:12px">:<?php echo $salArr['annual_bonus']; ?> </td>
                                    </tr>

                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's PF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employees_pf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's VPF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employees_vpf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's ESI</td>
                                        <td style="font-size:12px">:<?php echo $salArr['employees_esi']; ?> </td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Total CTC</td>
                                        <td style="font-size:12px">: <?php echo $salArr['total_ctc'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Net Salary</td>
                                        <td style="font-size:12px">: <?php echo $salArr['net_sal'];?></td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            </div>
                        </div>
                    </div>
                </div>-->
            </div>
            </div>
    </div>
        </div>	
    </div>
</body>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
<script type="text/javascript">
    // modal for adding ctc
	
function showActive(value) {
	// alert("new")
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showInActive(value) {
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showAll() {
	$("#isactive").empty();
	$("#isactive").val('');
	table_active.ajax.reload(); 
}
function setUserIdForSalStructure(user_id) {
        $("#user_id").val(user_id);
    }


    var table_active;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_active = $('#table_active').DataTable({
                    "processing": true, //Feature control the processing indicator.
                   // "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('SalStructureController/ajax_employee_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.isactive = $('#isactive').val();
                            // data.company_name = $('#company_name').val();
                            // data.userfullname = $('#userfullname').val();
                            // data.employeeId = $('#employeeId').val();
                            // data.designation_name = $('#designation_name').val();
                            // data.department_name = $('#department_name').val();
                            // data.project_name = $('#project_name').val();
                            // data.status_type = $('#status_type').val();
                            // data.is_active = 1;
							data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';					
                        },
                                // data:{[csrfName]: csrfHash}, 

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('.btn-filter').click(function () { //button filter event click
                    table_active.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_active.ajax.reload();  //just reload table
                });
    });

</script> 
<script>
    $(document).ready(function () {
        var table = $('#employeeTable').DataTable();
        $("#all").trigger('click');
    });
</script>
<div class="modal" tabindex="-1" id="ctcModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= base_url('sal_structure');?>" method="POST">
                <div class="row">
                    <div class="col-sm-6">
                        <span id="reqd" class="error_ctc"><?= form_error('ctc'); ?></span>
                        <label for="">CTC Amount :</label>
                        <input type="text" value="" name="ctc" id="ctc" class="form-control" required>
                        <input type="hidden"  value="" name="user_id" id="user_id" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <span id="reqd" class="error_tax_figure"><?= form_error('tax_figure'); ?></span>
                        <label for="">Tax Figure:</label>
                        <input type="text" value="" name="tax_figure" id="tax_figure" class="form-control" required>
                    </div><br>
                    <div class="col-sm-6">
                        <label for=""><br></label>
                        <button type="submit" class="btn btn-primary">Show Structure</button>
                    </div>
                </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
    function printDiv() 
{

  var divToPrint=document.getElementById('print_div');

  var newWin=window.open('','Print-Window');

  newWin.document.open();

  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

  newWin.document.close();

  setTimeout(function(){newWin.close();},10);

}
</script>
<?php $this->load->view('admin/includes/footer'); ?>
 
