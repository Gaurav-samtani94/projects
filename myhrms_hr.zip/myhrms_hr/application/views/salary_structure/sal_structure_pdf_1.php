<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
  
<style>
table thead {
    color: #000;
}
        .w-250{
            width: 250px;
        }
        @page {
    size: auto;
    margin: 0;
}
</style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" >
<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet"> -->

  </head>
  <body style=" background-color: #f5f5f5; width: 100%;margin: 0;padding: 15px;">
  <div id="wrapper">
        <div id="main-content">
            <div class="container">

            <!-- base_url('download_sal_anexture_pdf/'.$userDetails->user_id)?> -->
            

                <!--<div class="container">-->
        <div class="card">
            <div class="body" id='print_div'>
            <div class="row">
                <div class="col-10">
                    <h2 class="mb-0 text-dark"><b>Growth Grids Pvt. Ltd.</b></h2>
                    <p>B - 11 (G) Malviya Industrial Area, Jaipur, Rajasthan 302017</p>
                    <p class="small-month mb-0">GSTIN : 08AFQPK1299C1Z8</p>
                    <p class="small-month"><span class="mr-5">Tel. : 9773356002</span><span>email  :  business@growthgrids.com</span></p>
                </div>
                <div class="col-2">
                    <img src="https://www.cegindia.com/public/assets/site//images/logo.png" class="w-100">
                </div>
            </div>
        
            <div class="row">
            <div class="col-md-6 pr-0">
                <div class="p-3 border h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        Name
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1"  >
                        <div  class="bg-light">
                            <b>: <?php echo ($userDetails->userfullname) ? $userDetails->userfullname : '-'; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Designation    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->position_name) ? $userDetails->position_name : '-'; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Dept / Project Name    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? $userDetails->department_name : $userDetails->department_name; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Location (HO RO / Project)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? "HO/RO" : "Project"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Group
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->jobtitle_name) ? $userDetails->jobtitle_name : "-"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        CTC Offered (Monthly)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ctc) ? number_format($salArrToObj->ctc) : "-"; ?></b>
                    </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Company Name              
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: CEG Ltd.</b>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pl-0">
                <div class="p-3 border border-left-0 h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        PF Applicable (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->pf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        VPF Applicable (Y/N)
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->vpf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        ESI Applicable (Y/N)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->esi_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Metro/Non Metro
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->metro_non == 1) ? "Metro" : "Non-Metro"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Gratuity
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->gratuity_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Mediclaim
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->mediclaim_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Annual Bonus offered (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ann_bonus_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        AB Amount (Included in CTC)         
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->annual_bonus) ? number_format($salArrToObj->annual_bonus) : "-"; ?></b>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="table-responsive mt-4">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Particulars</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.)</th>
                    <th class="white-space-nowrap w-250">Annually Amount (Rs.)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Earnings</th>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>Basic Salary</td>
                    <td><?php echo ($salArrToObj->basic_sal) ? number_format($salArrToObj->basic_sal) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->basic_sal) ? number_format(($salArrToObj->basic_sal * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>HRA</td>
                    <td><?php echo ($salArrToObj->hra) ? number_format($salArrToObj->hra) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->hra) ? number_format(($salArrToObj->hra * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>Education Allowance</td>
                    <td><?php echo ($salArrToObj->edu_allow) ? number_format($salArrToObj->edu_allow) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->edu_allow) ? number_format(($salArrToObj->edu_allow * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>Telephone Allowance</td>
                    <td><?php echo ($salArrToObj->tele_allow) ? number_format($salArrToObj->tele_allow) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->tele_allow) ? number_format(($salArrToObj->tele_allow * 12)) : "0"; ?></td>
                  </tr>
                  <tr>
                    <td>Special Allowance</td>
                    <td><?php echo ($salArrToObj->special_allowance) ? number_format($salArrToObj->special_allowance) : "-"; ?></td>
                    <td><?php echo ($salArrToObj->special_allowance) ? number_format(($salArrToObj->special_allowance * 12)) : "-"; ?></td>
                  </tr>
                  
                </tbody>
                
            </table>
        </div>
        <div class="table-responsive ">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Gross Salary</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.) &nbsp;<?php echo ($salArrToObj->gross) ? number_format($salArrToObj->gross) : "-"; ?></th>
                    <th class="white-space-nowrap w-250">Annually Amount (Rs.)&nbsp;<?php echo ($salArrToObj->gross) ? number_format(($salArrToObj->gross*12)) : "-"; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Deductions</th>
                    <td></td>
                    <td></td>
                  </tr>
                 <tr>
                    <td>Employer's Contribution to PF *</td>
                    <td><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Employer's Contribution to ESI *</td>
                    <td><?php echo ($salArrToObj->employer_esi) ? number_format($salArrToObj->employer_esi) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employer_esi) ? number_format(($salArrToObj->employer_esi)*12) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Employer's Contribution to Gratuity *</td>
                    <td><?php echo ($salArrToObj->gratuity_amount) ? number_format($salArrToObj->gratuity_amount) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->gratuity_amount) ? number_format(($salArrToObj->gratuity_amount*12)) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Group Personal Accidental Insurance **</td>
                    <td><?php echo ($salArrToObj->gpai) ? number_format($salArrToObj->gpai) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->gpai) ? number_format(($salArrToObj->gpai*12)) : "0"; ?></td>
                 </tr>
                 <tr>
                    <td>Group Mediclaim Insurance ***</td>
                    <td><?php echo ($salArrToObj->mediclaim_amount) ? number_format($salArrToObj->mediclaim_amount) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->mediclaim_amount) ? number_format(($salArrToObj->mediclaim_amount*12)) : "0"; ?></td>
                 </tr>
                </tbody>
               
            </table>
        </div>
       <div class="table-responsive">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Monthly CTC</th>
                    <th class="white-space-nowrap w-250">Monthly Amount (Rs.)<?php echo ($salArrToObj->monthly_ctc) ? number_format($salArrToObj->monthly_ctc) : "0"; ?></th>
                    <th class="white-space-nowrap w-250" >Annually Amount (Rs.)<?php echo ($salArrToObj->monthly_ctc) ? number_format(($salArrToObj->monthly_ctc)*12) : "0"; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Annual Bonus ****</th>
                    <td><?php echo ($salArrToObj->annual_bonus) ? number_format($salArrToObj->annual_bonus) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->annual_bonus) ? number_format(($salArrToObj->annual_bonus * 12)) : "0"; ?></td>
                  </tr>
                 
                </tbody>
                <tfoot class="bg-light">
                    <tr>
                        <th class="text-right">Total CTC(round-off)</th>
                        <th><?php echo ($salArrToObj->total_ctc) ? number_format($salArrToObj->total_ctc) : "0"; ?></th>
                        <th><?php echo ($salArrToObj->total_ctc) ? number_format(($salArrToObj->total_ctc*12)) : "0"; ?></th>
                    </tr>
                    <tr>
                        <th class="text-left">CTC in Words -</th>
                        <th colspan="2">Rupees Thirty One Lac Only</th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="my-3 border">
            <div class="border-bottom p-3">
                * Gratuity shall be payable as per The Payment of Gratuity Act 1972.
            </div>
            <div class="border-bottom p-3 mt-3">
                ** Apart from your Gross Salary, you will be entitled for Group Personal Accident Insurance (GPAI) for a sum assured of Rs. 4000000/- for self only (applicable 24 hours’ coverage). Sum assured is subject to change as per the company’s agreement with Insurance Company.
            </div>
            <div class="border-bottom p-3 mt-3">
                *** You will be covered under Group Mediclaim Insurance Policy for a sum assured of Rs. 2,00,000/- for one year. The key features of the policy are available on HRMS under Policy section.
            </div>
            <div class="p-3 mt-3">
                **** The above CTC is inclusive of Annual Bonus (AB) of Rs. 235080. Annual Bonus will be paid after 12 Months and shall be paid in proportionate to the service rendered during one year of service.
            </div>
        </div>
    <!-- </div> -->

                <!--<div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <span><?php echo $salArr['userfullname']?></span>
                            <table style="width: 100%;margin-top: 15px;">
                                <tbody>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">PF Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['pf_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">VPF Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['vpf_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">ESI Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['esi_applicable']) ? 'Y' : 'N'; ?></td>
                                    </tr>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Gratuity</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['gratuity_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mediclaim</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['mediclaim_applicable']) ? 'Y' : 'N'; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Annual Bonus Applicable</td>
                                        <td style="font-size:12px">: <?php echo ($salArr['ann_bonus_applicable']) ? 'Y' : 'N'; ?></td>
                                    </tr>
                                    <tr style="margin-top:10px">
                                    </tr>
                                    <tr style="margin-top:10px">
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Basic Salary</td>
                                        <td style="font-size:12px">: <?php echo $salArr['basic_sal']; ?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">HRA</td>
                                        <td style="font-size:12px">:<?php echo $salArr['hra']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Education Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['edu_allow'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Telephone Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['tele_allow']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Bonus (Adv)</td>
                                        <td style="font-size:12px">: <?php echo $salArr['bonus'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Special Allowance</td>
                                        <td style="font-size:12px">: <?php echo $salArr['special_allowance']; ?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Gross</td>
                                        <td style="font-size:12px">: <?php echo $salArr['gross'];?></td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's PF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employer_pf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's ESI</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employer_esi']; ?></td>
                                    </tr>

                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employeer's Gratuity</td>
                                        <td style="font-size:12px">: <?php echo $salArr['gratuity'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">GPAI</td>
                                        <td style="font-size:12px">:<?php echo $salArr['gpai']; ?> </td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mediclaim</td>
                                        <td style="font-size:12px">: <?php echo $salArr['mediclaim'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Monthly CTC</td>
                                        <td style="font-size:12px">:<?php echo $salArr['monthly_ctc']; ?> </td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Annual Bonus</td>
                                        <td style="font-size:12px">:<?php echo $salArr['annual_bonus']; ?> </td>
                                    </tr>

                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's PF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employees_pf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's VPF</td>
                                        <td style="font-size:12px">: <?php echo $salArr['employees_vpf'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee's ESI</td>
                                        <td style="font-size:12px">:<?php echo $salArr['employees_esi']; ?> </td>
                                    </tr>
                                    <tr>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Total CTC</td>
                                        <td style="font-size:12px">: <?php echo $salArr['total_ctc'];?></td>
                                        <td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Net Salary</td>
                                        <td style="font-size:12px">: <?php echo $salArr['net_sal'];?></td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            </div>
                        </div>
                    </div>
                </div>-->
            </div>
            </div>
    </div>
        </div>	
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" ></script>
  </body>
</html>