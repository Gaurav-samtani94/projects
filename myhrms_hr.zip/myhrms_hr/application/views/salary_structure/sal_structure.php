<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    input[type=text] {
        background-color: #fff;
        width: 100%;
    }
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="">
                            <?php if ($this->session->flashdata('success_msg')) : ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error_msg')) : ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (validation_errors()) : ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <strong>Error ! </strong> <?= validation_errors(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card">
                        <div class="body">
                                <form action="" method="POST">
                                <?php//= base_url("add_department");?>
                                    <div class="row">
                                        <div class="col-sm-3">
                                        <span id="reqd"
                                                            class="error_ctc"><?= form_error('ctc'); ?></span>
                                            <label for="">CTC Amount :</label>
                                            <input type="text" onkeyup="checkOtherDetails()" value="<?= set_value('ctc')?>" name="ctc" id="ctc" class="form-control">
                                        </div>
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_tax_figure"><?= form_error('tax_figure'); ?></span>
                                        <label for="">Tax Figure :</label>
                                        <input type="text" value="<?= set_value('tax_figure')?>" name="tax_figure" class="form-control">
                                    </div>

                                    <div class="col-sm-3">
                                        <span id="reqd" class="error_location"><?= form_error('location'); ?></span>
                                        <label for="">Location :</label>
                                        <select name="location" id="location" class="form-control " onchange="group_enable()">
                                            <option value="">-- Select Location --</option>
                                            <option value="1">HO/RO</option>
                                            <option value="2">Project</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-sm-3">
                                        <span id="reqd" class="error_group"><?= form_error('group'); ?></span>
                                        <label for="">Group :</label>
                                        <select name="group" id="group" class="form-control " disabled>
                                            <option value="">-- Select Group --</option>
                                            <?php $groups = array('A', 'B', 'C', 'D', 'E', 'F');
                                                if($groups) {
                                                    foreach($groups as $value):
                                            ?>
                                                <option value="<?php echo $value; ?>"><?php echo $value; ?></option>
                                            <?php endforeach; }?>
                                        </select>
                                    </div>
                                    <br>
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_company_name"><?= form_error('company_name'); ?></span>
                                        <label for="">Company :</label>
                                        <input type="hidden" value="<?= set_value('company_name_val')?>" name="company_name_val" id="company_name_val" class="form-control" disabled>
                                        <input type="text" value="<?= set_value('company_name')?>" name="company_name" id="company_name" class="form-control" readonly>
                                    </div>
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_gpai_amount"><?= form_error('gpai_amount'); ?></span>
                                        <label for="">GPAI :</label>
                                        <input type="text" value="<?= set_value('gpai_amount')?>" name="gpai_amount" id="gpai_amount" class="form-control" readonly>
                                    </div>
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_tele_amount"><?= form_error('tele_amount'); ?></span>
                                        <label for="">Telephone Allowance :</label>
                                        <input type="text"  name="tele_amount" id="tele_amount" class="form-control" readonly>
                                    </div>
                                    
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_metro_non_metro"><?= form_error('metro_non_metro'); ?></span>
                                        <label for="">Metro/Non-Metro :</label>
                                        <select name="metro_non_metro" id="metro_non_metro" class="form-control ">
                                            <option value="">-- Select Metro/Non-Metro --</option>
                                                <option value="1">Metro</option>
                                                <option value="2">Non-Metro</option>
                                        </select>
                                    </div>



                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_pf_applicable"><?= form_error('pf_applicable'); ?></span>
                                        <label for="">PF Applicable :</label>
                                        <select name="pf_applicable" id="pf_applicable" class="form-control ">
                                                <option value="1">Yes</option>
                                                <option value="2">No</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_vpf_applicable"><?= form_error('vpf_applicable'); ?></span>
                                        <label for="">VPF Applicable :</label>
                                        <select name="vpf_applicable" id="vpf_applicable" class="form-control ">
                                                <option value="1">Yes</option>
                                                <option value="2">No</option>
                                        </select>
                                    </div>

                                     <div class="col-sm-3">
                                    <span id="reqd" class="error_gratuity_applicable"><?= form_error('gratuity_applicable'); ?></span>
                                        <label for="">Gratuity Applicable :</label>
                                        <select name="gratuity_applicable" id="gratuity_applicable" class="form-control" disabled>
                                                <option value="1">Yes</option>
                                                <option value="2">No</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-sm-3">
                                    <span id="reqd" class="error_esi_applicable"><?= form_error('esi_applicable'); ?></span>
                                        <label for="">ESI Applicable :</label>
                                        <select name="esi_applicable" id="esi_applicable" class="form-control" disabled>
                                                <option value="1">Yes</option>
                                                <option value="2">No</option>
                                        </select>
                                    </div>

                                     <div class="col-sm-3">
                                    <span id="reqd" class="error_mediclaim_applicable"><?= form_error('mediclaim_applicable'); ?></span>
                                        <label for="">Mediclaim Applicable :</label>
                                        <input type="text" name="mediclaim_applicable_text" id="mediclaim_applicable_text" class="form-control" readonly>
                                        <input type="hidden" name="mediclaim_applicable_val" id="mediclaim_applicable_val" class="form-control">
                                    </div>
                                   <div class="col-sm-3">
                                    <span id="reqd" class="anuual_bonus_text"><?= form_error('anuual_bonus_text'); ?></span>
                                        <label for="">Annual Bonus :</label>
                                        <input type="text" name="anuual_bonus_text" id="anuual_bonus_text" class="form-control" readonly>
                                        <input type="hidden" name="anuual_bonus_val" id="anuual_bonus_val" class="form-control">
                                    </div>
                                  
                                    <div class="col-sm-4 mt-4">
                                      <input type="submit" class="btn btn-sm btn-primary" value="Download">
                                    </div>

                                  

                                </div>
                            </form>
                            </div>

</div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>

        $('#ctc').keyup(function() {
            var dInput = this.value;
            // round((($ctc*12)-($tax_fig*12))/13);
            $tax_fig = $("#tax_figure").val();
            $tax_fig = $("#company_name_val").val();
            alert("")
            if(this.value > 21000){
                $('#esi_applicable').val(2);
                $( "#esi_applicable" ).prop( "disabled", true );
                $("#mediclaim_applicable_text").val("Yes")
                $("#mediclaim_applicable_val").val(214)
            }else if(this.value <= 21000 && this.value > 0){
                $('#esi_applicable').val(1);
                $( "#esi_applicable" ).prop( "disabled", true );
                $("#mediclaim_applicable_text").val("No")
                $("#mediclaim_applicable_val").val(0)
            }
        });

        function group_enable() {
            var location_name = $("#location option:selected").text()
            var location_id = $("#location option:selected").val()
            if(location_id){
                // alert("test");
                $( "#group" ).prop( "disabled", false );
            }else{
                $( "#group" ).prop( "disabled", true );
                $( "#company_name" ).prop( "disabled", true );
                $( "#company_name_val" ).prop( "disabled", true );
            }
        }

        $( document ).ready(function() {

           

            $("#group").change(function () {
                var group = this.value;
                var group_names = ['A', 'B', 'C', 'D', 'E', 'F'];
                var location = $('#location').val();
                if(group == 'F'){
                    $( "#company_name" ).val('No');
                    $( "#company_name_val" ).val(2);
                }else{
                    $( "#company_name" ).val('Yes');
                    $( "#company_name_val" ).val(1);
                }

                $( "#company_name" ).prop( "disabled", false );
                $( "#company_name_val" ).prop( "disabled", false );
                
                if(group == 'A'){
                    $('#gpai_amount').val(71);
                    $('#tele_amount').val(800);
                }else if(group == 'B'){
                    $('#gpai_amount').val(57);
                    $('#tele_amount').val(500);
                }
                else if(group == 'C'){
                    $('#gpai_amount').val(45);
                    $('#tele_amount').val(350);
                }
                else if(group == 'D'){
                    $('#gpai_amount').val(40);
                    $('#tele_amount').val(250);
                }
                else if(group == 'E'){
                    $('#gpai_amount').val(28);
                    $('#tele_amount').val(200);
                }
                else if(group == 'F'){
                    if(location == 1){
                        $('#gpai_amount').val(23);
                        $('#tele_amount').val(150);
                    }else{
                        $('#gpai_amount').val(0);
                        $('#tele_amount').val(0);
                    }
                    
                }
            });
        });

      
        
       
    <?php $this->load->view('admin/includes/footer'); ?>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
    <script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
    </div>
</body>
<script>

</script>