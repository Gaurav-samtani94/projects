<?php
$GroupPerAccidentInsurArr = array(
    "A" => "5000000",
    "B" => "4000000",
    "C" => "3000000",
    "D" => "2500000",
    "E" => "2000000",
    "F" => "1500000",
    "" => "",
    "a" => "5000000",
    "b" => "4000000",
    "c" => "3000000",
    "d" => "2500000",
    "e" => "2000000",
    "f" => "1500000"
);

$TelephoneAllowanceArr = array(
    "A" => "800",
    "B" => "500",
    "C" => "350",
    "D" => "250",
    "E" => "200",
    "F" => "150",
    "" => "",
    "a" => "800",
    "b" => "500",
    "c" => "350",
    "d" => "250",
    "e" => "200",
    "f" => "150"
);


?>
<style>
    table thead {
        color: #000;
    }

    .w-250 {
        width: 250px;
    }

    @page {
        size: auto;
        margin: 0;
    }

    body {
        padding: 0;
        margin: 0;
    }

    .no-page-break {
        page-break-inside: avoid;
    }

    @page {
        margin: 0 !important;
        /* Removes default margins */
    }

    .logo_adjust {
        padding: 0 0 15px 0;
    }

    #print_div {
        margin-top: 30px !important;
        padding: 40px !important;
    }
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

<body class="theme-cyan">
    <div id="wrapper">
        <div id="main-content">
            <div class="container-fluid">

                <!-- base_url('download_sal_anexture_pdf/'.$userDetails->user_id)?> -->


                <!--<div class="container">-->
                <div class="card" style="padding:15px">
                    <div class="body" id='print_div'>
                        <div class="row logo_adjust" style="">
                            <!-- <div class="col-12"> -->
                            <?php if ($userDetails->company_id == "1") { ?>
                                <div class="col-2">
                                    <img src="https://www.cegindia.com/public/assets/site/images/logo.png" class="w-100">
                                </div>
                            <?php } ?>
                            <div class="col-7">
                                <div style="text-align:center;margin: 15px 0 0 0">
                                    <h6>CTC AND SALARY BREAK-UP (w.e.f <?php echo date('d-M-Y', strtotime($salArrToObj->effective_date)); ?>)</h6>
                                </div>
                            </div>
                            <div class="col-3"  style="text-align:center;margin: 10px 0 0 0">
                                <h4>Annexure 1</h4>
                            </div>
                            <!-- </div> -->
                        </div>

                        <div class="border">
                            <div class="pr-0" style="width: 49%; display: inline-block;">
                                <div class="p-3 h-100">
                                    <div class="row">
                                        <div class="col-md-5 col-6 mb-1">
                                            Name
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($userDetails->userfullname) ? $userDetails->userfullname : '-'; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Designation
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($userDetails->position_name) ? $userDetails->position_name : '-'; ?></b>
                                            </div>
                                        </div>
                                        <?php if ($userDetails->department_name != "Project"): ?>
                                            <div class="col-md-5 col-6 mb-1">
                                                Dept / Project Name
                                            </div>
                                            <div class="col-md-7 col-6 text-dark mb-1">
                                                <div class="bg-light">
                                                    <b>: <?php echo ($userDetails->businessunit_id != 3) ? $userDetails->department_name : $userDetails->department_name; ?></b>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="col-md-5 col-6 mb-1">
                                            Location (HO RO / Project)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($userDetails->businessunit_id != 3) ? "HO/RO" : "Project"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Group
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($userDetails->jobtitle_name) ? $userDetails->jobtitle_name : "-"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            CTC Offered (Monthly)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->ctc) ? number_format($salArrToObj->ctc) : "-"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Company Name
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: CEG Ltd.</b>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pl-0" style="width: 49%; display: inline-block;">
                                <div class="p-3 border-left h-100">
                                    <div class="row">
                                        <div class="col-md-5 col-6 mb-1">
                                            PF Applicable (Y/N)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->pf_applicable == 1) ? 'Y' : "N"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            VPF Applicable (Y/N)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->vpf_applicable == 1) ? 'Y' : "N"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            ESI Applicable (Y/N)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->esi_applicable == 1) ? 'Y' : "N"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Metro/Non Metro
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->metro_non_metro == 1) ? "Metro" : "Non-Metro"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Gratuity
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->gratuity_applicable == 1) ? "Y" : "N"; ?></b>
                                            </div>
                                        </div>
                                        <div class="col-md-5 col-6 mb-1">
                                            Mediclaim
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->mediclaim_applicable == 1) ? "Y" : "N"; ?></b>
                                            </div>
                                        </div>
                                        <!-- <div class="col-md-5 col-6 mb-1">
                                            Annual Bonus offered (Y/N)
                                        </div>
                                        <div class="col-md-7 col-6 text-dark mb-1">
                                            <div class="bg-light">
                                                <b>: <?php echo ($salArrToObj->annual_bonus_applicable == 1) ? "Y" : "N"; ?></b>
                                            </div>
                                        </div> -->
                                        <?php if ($salArrToObj->ann_bonus > 0): ?>
                                            <div class="col-md-5 col-6 mb-1">
                                                Project Completion Bonus
                                            </div>
                                            <div class="col-md-7 col-6 text-dark mb-1">
                                                <div class="bg-light">
                                                    <?php if ($salArrToObj->department == 1) { ?>
                                                        <b>: <?php echo ($salArrToObj->ann_bonus) ? number_format(($salArrToObj->ann_bonus * 12)) : "-"; ?></b>
                                                    <?php } else { ?>
                                                        <b>: <?php echo ($salArrToObj->ann_bonus) ? number_format($salArrToObj->ann_bonus) : "-"; ?></b>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                        $TelephoneAllowancAmount = $TelephoneAllowanceArr[trim($userDetails->jobtitle_name)];
                        ?>


                        <div class="table-responsive">
                            <table class="table table-bordered mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="white-space-nowrap">Particulars</th>
                                        <th class="white-space-nowrap w-250" style="text-align: right;">Monthly Amount (Rs.)</th>
                                        <th class="white-space-nowrap w-250" style="text-align: right;">Annually Amount (Rs.)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>Earnings</th>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>Basic Salary</td>
                                        <td align="right"><?php echo ($salArrToObj->basic_sal) ? number_format($salArrToObj->basic_sal) : "-"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->basic_sal) ? number_format(($salArrToObj->basic_sal * 12)) : "-"; ?></td>
                                    </tr>
                                    <tr>
                                        <td>HRA</td>
                                        <td align="right"><?php echo ($salArrToObj->hra) ? number_format($salArrToObj->hra) : "-"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->hra) ? number_format(($salArrToObj->hra * 12)) : "-"; ?></td>
                                        <?php if ($salArrToObj->edu_allow > 0) { ?>
                                    </tr>
                                    <tr>
                                        <td>Education Allowance</td>
                                        <td align="right"><?php echo ($salArrToObj->edu_allow) ? number_format($salArrToObj->edu_allow) : "-"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->edu_allow) ? number_format(($salArrToObj->edu_allow * 12)) : "-"; ?></td>
                                    </tr>
                                <?php }
                                        if ($salArrToObj->tele_allow > 0) { ?>
                                    <tr>
                                        <td>Telephone Allowance</td>
                                        <td align="right"><?php echo ($salArrToObj->tele_allow) ? number_format($salArrToObj->tele_allow) : "-"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->tele_allow) ? number_format(($salArrToObj->tele_allow * 12)) : "-"; ?></td>
                                        <!-- <td align="right"><?= ($TelephoneAllowancAmount) ? number_format($TelephoneAllowancAmount) : "0"; ?></td>
                                        <td align="right"><?= ($TelephoneAllowancAmount) ? number_format(($TelephoneAllowancAmount * 12)) : "0"; ?></td> -->
                                    </tr>
                                <?php  }
                                        if ($salArrToObj->gadget_allow > 0) { ?>
                                    <tr>
                                        <td>Gadget Allowance</td>
                                        <td align="right"><?php echo ($salArrToObj->gadget_allow) ? number_format($salArrToObj->gadget_allow) : "0"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->gadget_allow) ? number_format(($salArrToObj->gadget_allow * 12)) : "0"; ?></td>
                                    </tr>
                                <?php } ?>
                                <?php if ($salArrToObj->bonus_adv > 0) { ?>
                                    <tr>
                                        <td>Bonus (Adv.) </td>
                                        <td align="right"><?php echo ($salArrToObj->bonus_adv) ? number_format($salArrToObj->bonus_adv) : "0"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->bonus_adv) ? number_format(($salArrToObj->bonus_adv * 12)) : "0"; ?></td>
                                    </tr>
                                <?php }
                                if ($salArrToObj->special_allow > 0) { ?>

                                    <tr>
                                        <td>Special Allowance</td>
                                        <td align="right"><?php echo ($salArrToObj->special_allow) ? number_format($salArrToObj->special_allow) : "-"; ?></td>
                                        <td align="right"><?php echo ($salArrToObj->special_allow) ? number_format(($salArrToObj->special_allow * 12)) : "-"; ?></td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="table-responsive ">
                            <table class="table table-bordered mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="white-space-nowrap">Gross Salary</th>
                                        <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->gross) ? number_format($salArrToObj->gross) : "-"; ?></th>
                                        <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->gross) ? number_format(($salArrToObj->gross * 12)) : "-"; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th>Deductions</th>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php if ($salArrToObj->employer_pf > 0) { ?>
                                        <tr>
                                            <td>Employer's Contribution to PF *</td>
                                            <td align="right"><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                                            <td align="right"><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                                        </tr>
                                    <?php }
                                    if ($salArrToObj->employer_esi > 0) { ?>
                                        <tr>
                                            <td>Employer's Contribution to ESI *</td>
                                            <td align="right"><?php echo ($salArrToObj->employer_esi) ? number_format($salArrToObj->employer_esi) : "0"; ?></td>
                                            <td align="right"><?php echo ($salArrToObj->employer_esi) ? number_format(($salArrToObj->employer_esi) * 12) : "0"; ?></td>
                                        </tr>
                                    <?php }
                                    if ($salArrToObj->employer_gratuity > 0) { ?>
                                        <tr>
                                            <td>Employer's Contribution to Gratuity *</td>
                                            <td align="right"><?php echo ($salArrToObj->employer_gratuity) ? number_format($salArrToObj->employer_gratuity) : "0"; ?></td>
                                            <td align="right"><?php echo ($salArrToObj->employer_gratuity) ? number_format(($salArrToObj->employer_gratuity * 12)) : "0"; ?></td>
                                        </tr>
                                    <?php }
                                    if ($salArrToObj->gpai > 0) { ?>
                                        <tr>
                                            <td>Group Personal Accidental Insurance **</td>
                                            <td align="right"><?php echo ($salArrToObj->gpai) ? number_format($salArrToObj->gpai) : "0"; ?></td>
                                            <td align="right"><?php echo ($salArrToObj->gpai) ? number_format(($salArrToObj->gpai * 12)) : "0"; ?></td>
                                        </tr>
                                    <?php }
                                    if ($salArrToObj->mediclaim > 0) { ?>
                                        <tr>
                                            <td>Group Mediclaim Insurance ***</td>
                                            <td align="right"><?php echo ($salArrToObj->mediclaim) ? number_format($salArrToObj->mediclaim) : "0"; ?></td>
                                            <td align="right"><?php echo ($salArrToObj->mediclaim) ? number_format(($salArrToObj->mediclaim * 12)) : "0"; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        </div>
                        <div class="table-responsive" style="overflow: hidden;">
                            <table class="table table-bordered mb-0">
                                <!-- <thead class="bg-light">
                                    <tr>
                                        <th class="white-space-nowrap">Monthly CTC</th>
                                        <th class="white-space-nowrap w-250 text-right" style="text-align: right;"><?php echo ($salArrToObj->monthly_ctc) ? number_format($salArrToObj->monthly_ctc) : "0"; ?></th>
                                        <th class="white-space-nowrap w-250 text-right" style="text-align: right;"><?php echo ($salArrToObj->monthly_ctc) ? number_format(($salArrToObj->monthly_ctc) * 12) : "0"; ?></th>
                                    </tr>
                                </thead> -->
                                <tbody>
                                    <?php
                                    if ($salArrToObj->department == 1) {
                                        if ($salArrToObj->ann_bonus > 0) { ?>
                                            <tr>
                                                <th>Project Completion Bonus ****</th>
                                                <td class="text-right w-250" align="right"><?php echo ($salArrToObj->ann_bonus) ? number_format($salArrToObj->ann_bonus) : "0"; ?></td>
                                                <td class="text-right w-250" align="right"><?php echo ($salArrToObj->ann_bonus) ? number_format(($salArrToObj->ann_bonus * 12)) : "0"; ?></td>
                                            </tr>
                                    <?php }
                                    } ?>

                                </tbody>
                                <tbody class="bg-light">
                                    <tr>
                                        <th>Total CTC</th>
                                        <th class="text-right w-250" align="right"><?php echo ($salArrToObj->total_ctc) ? number_format($salArrToObj->total_ctc) : "0"; ?></th>
                                        <th class="text-right w-250" align="right"><?php echo ($salArrToObj->total_ctc) ? number_format(($salArrToObj->total_ctc * 12)) : "0"; ?></th>
                                    </tr>

                                    </tfoot>
                                <tbody>

                                    <?php /* //if(($salArrToObj->employees_pf>0) || ($salArrToObj->employees_vpf>0) || ($salArrToObj->employees_esi>0)){ ?>

                <?php if($salArrToObj->employees_pf > 0){ ?>
                  <tr>
                    <td>Employee's Contribution to PF * </td>
                    <td><?php echo ($salArrToObj->employees_pf) ? number_format($salArrToObj->employees_pf) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employees_pf) ? number_format(($salArrToObj->employees_pf*12)) : "0"; ?></td>
                 </tr>
                 <?php } if($salArrToObj->emp_vpf > 0) { ?>
                 <tr>
                    <td>Employee's Contribution to VPF *</td>
                    <td><?php echo ($salArrToObj->employees_vpf) ? number_format($salArrToObj->employees_vpf) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employees_vpf) ? number_format(($salArrToObj->employees_vpf)*12) : "0"; ?></td>
                 </tr>
                 <?php } if($salArrToObj->emp_esi > 0) { ?>
                 <tr>
                    <td>Employee's Contribution to ESI *</td>
                    <td><?php echo ($salArrToObj->employees_esi) ? number_format($salArrToObj->employees_esi) : "0"; ?></td>
                    <td><?php echo ($salArrToObj->employees_esi) ? number_format(($salArrToObj->employees_esi*12)) : "0"; ?></td>
                 </tr>
                <?php } */ ?>


                                </tbody>
                                <!-- <tfoot class="bg-light">
                <tr>
                        <th class="text-center">Net Salary (Subject to TDS as per applicable law)</th>
                        <th colspan="2"><?php echo number_format($salArrToObj->net_salary); ?></th>
                    </tr>
                    <tr>
                        <th class="text-left">CTC in Words -</th>
                        <th colspan="2">Rupees Thirty One Lac Only</th>
                    </tr>
                </tfoot> -->
                            </table>
                        </div>

                        <div class="my-3 border">

                            <?php
                            $GP_AccidentInsurAmount = $GroupPerAccidentInsurArr[trim($userDetails->jobtitle_name)];
                            ?>
                            <div class="">
                                <div class="col-md-12" style="padding:10px">
                                    <?php if ($salArrToObj->department == 1) { ?>
                                        <p>**** <b>Project Completion Bonus (PCB)</b> - The above annual CTC is inclusive of Project Completion Bonus (PCB) of Rs.<?php echo number_format(($salArrToObj->ann_bonus * 12)); ?>/-for the year 2024-25, towards your continuous deployment on this project and satisfactory services therein. You shall be eligible for this PCB, on successful completion of your man-months as per agreement (with revision, if any) and shall be paid on successful completion of the project. You shall be eligible for previous year(s)’ accumulated PCB, if any, on successful completion of your man-months input as per agreement (with revision, if any) and shall be paid on successful completion of the project. In case you leave the project or you are removed/terminated on disciplinary ground by the client / company, PCB shall not be payable.</p>
                                    <?php } else if ($salArrToObj->department == 2) { ?>
                                        <p>**** <b>In addition to the above mentioned ‘CTC’ you shall be paid Project Completion Bonus (PCB). With this revision of CTC your PCB is now fixed at Rs. <?php echo number_format($salArrToObj->ann_bonus); ?>/- subject to successful completion of your stipulated man-month (including revision, if any) or completion of the project whichever is earlier. The PCB will be paid at the discretion of the management and cannot be claimed as a right.
                                            <?php } ?>
                                </div>
                                <div style="border-right:1px solid #cdd8e3; width: 60%; display: inline-block;padding:5px">
                                    <p class="p-1">
                                        * <b>Gratuity </b> shall be payable as per The Payment of Gratuity Act, 1972. <br>
                                        ** <b>Group Personal Accident Insurance</b> Apart from your Gross Salary, you will be entitled for Group Personal Accident Insurance (GPAI) for a sum assured of Rs. <?= number_format($GP_AccidentInsurAmount, 0); ?> /- for self only (applicable 24 hours’ coverage). Sum assured is subject to change as per the company’s agreement with Insurance Company. <br>
                                        <?php if($salArrToObj->mediclaim_applicable == 1):?>
                                        *** <b>Group Mediclaim Insurance</b> You will be covered under Group Mediclaim Insurance Policy for a sum assured of Rs. 2,00,000/- for one year. <br>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div style="width: 39%; display: inline-block;">
                                    <?php if ($userDetails->company_id == "1") { ?>
                                        <p style="text-align:center;margin-bottom:60px">For CONSULTING ENGINEERS GROUP LTD.</p>

                                        <p style="padding: 61px 0 0px 0;text-align:center;">Col. VS Parmar (Retd.)<br>
                                            Chief General Manager (HR)</p>
                                    <?php } else { ?>
                                        <p style="padding: 61px 0 0px 0;text-align:center;"> Signature </p>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>
</body>

<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

<script type="text/javascript">
    function showActive(value) {
        $("#isactive").empty();
        $("#isactive").val(value);
        table_active.ajax.reload();
    }

    function showInActive(value) {
        $("#isactive").empty();
        $("#isactive").val(value);
        table_active.ajax.reload();
    }

    function showAll() {
        $("#isactive").empty();
        $("#isactive").val('');
        table_active.ajax.reload();
    }

    function setUserIdForSalStructure(user_id) {
        $("#user_id").val(user_id);
    }


    var table_active;
    $(document).ready(function() {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        table_active = $('#table_active').DataTable({
            "processing": true, //Feature control the processing indicator.
            // "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [],
            "scrollY": '62vh',
            "scrollX": true,
            "ajax": {
                "url": "<?= base_url('SalStructureController/ajax_employee_list') ?>",
                "type": "POST",
                "data": function(data) {
                    data.isactive = $('#isactive').val();
                    data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                },
            },
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ]
            }],
            //Set column definition initialisation properties.
            "columnDefs": [{
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            }, ],
            "aLengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
        });
        //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('.btn-filter').click(function() { //button filter event click
            table_active.ajax.reload(); //just reload table
        });
        $('#btn-reset').click(function() { //button reset event click
            $('#form-filter')[0].reset();
            table_active.ajax.reload(); //just reload table
        });
    });
</script>
<script>
    $(document).ready(function() {
        // alert("test")
        // printDiv();
        window.print();
    });

    function printDiv() {

        var divToPrint = document.getElementById('print_div');

        var newWin = window.open('', 'Print-Window');

        newWin.document.open();

        newWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</body></html>');

        newWin.document.close();

        setTimeout(function() {
            newWin.close();
        }, 5);

    }
</script>


<div class="modal" tabindex="-1" id="ctcModal" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <form action="<?= base_url('sal_structure'); ?>" method="POST">
                    <div class="row">
                        <div class="col-sm-6">
                            <span id="reqd" class="error_ctc"><?= form_error('ctc'); ?></span>
                            <label for="">CTC Amount :</label>
                            <input type="text" value="" name="ctc" id="ctc" class="form-control" required>
                            <input type="hidden" value="" name="user_id" id="user_id" class="form-control">
                        </div>

                        <div class="col-sm-6">
                            <span id="reqd" class="error_tax_figure"><?= form_error('tax_figure'); ?></span>
                            <label for="">Tax Figure:</label>
                            <input type="text" value="" name="tax_figure" id="tax_figure" class="form-control" required>
                        </div><br>

                        <div class="col-sm-6">
                            <label for=""><br></label>
                            <button type="submit" class="btn btn-primary">Show Structure</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php $this->load->view('admin/includes/footer'); ?>