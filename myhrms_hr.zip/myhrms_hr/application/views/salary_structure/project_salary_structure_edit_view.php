<?php
// echo base_url('salary_structure_edit/'.$salArrToObj->user_id); die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//$statusArr = TourStatusRec();
?>
<style>
textarea {
  resize: none;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
							<!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Policies</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <?php /* if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; */ ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?> 
                               
                                <div id="collapseOne" >
                                    <div class="body">
                                        <form action="<?php echo base_url('sal_structure_project'); ?>" id="basic-form" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <div class="row clearfix">
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Basic Salary : </label>
                                                        <input type="text" name="basic_salary" id="basic_salary" autocomplete="off" value="<?= $salArrToObj->basic_sal;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">HRA : </label>
                                                        <input type="text" name="hra" id="basic_salary" autocomplete="off" value="<?= $salArrToObj->hra;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Education Allowance : </label>
                                                        <input type="text" name="edu_allow" id="edu_allow" autocomplete="off" value="<?= $salArrToObj->edu_allow;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Telephone Allowance : </label>
                                                        <input type="text" name="tele_allow" id="tele_allow" autocomplete="off" value="<?= $salArrToObj->tele_allow;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Bonus (Adv.) : </label>
                                                        <input type="text" name="bonus_adv" id="bonus_adv" autocomplete="off" value="<?= $salArrToObj->bonus_adv;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Gadget Allowance : </label>
                                                        <input type="text" name="gadget_allow" id="gadget_allow" autocomplete="off" value="<?= $salArrToObj->gadget_allow;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Special Allowance : </label>
                                                        <input type="text" name="special_allow" id="special_allow" autocomplete="off" value="<?= $salArrToObj->special_allow;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Gross Salary : </label>
                                                        <input type="text" name="gross" id="gross" autocomplete="off" value="<?= $salArrToObj->gross;?>" class="form-control" required >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Employer's Contribution To Gratuity * : </label>
                                                        <input type="text" name="employer_gratuity" id="employer_gratuity" autocomplete="off" value="<?= $salArrToObj->employer_gratuity;?>" class="form-control" >
                                                    </div>
                                                </div>
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Group Personal Accidental Insurance ** : </label>
                                                        <input type="text" name="gpai" id="gpai" autocomplete="off" value="<?= $salArrToObj->gpai;?>" class="form-control" required>
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Group Mediclaim Insurance *** : </label>
                                                        <input type="text" name="mediclaim" id="mediclaim" autocomplete="off" value="<?= $salArrToObj->mediclaim;?>" class="form-control" required>
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Monthly CTC *** : </label>
                                                        <input type="text" name="monthly_ctc" id="monthly_ctc" autocomplete="off" value="<?= $salArrToObj->monthly_ctc;?>" class="form-control" required >
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Annual Bonus **** : </label>
                                                        <input type="text" name="ann_bonus" id="ann_bonus" autocomplete="off" value="<?= $salArrToObj->ann_bonus;?>" class="form-control" required>
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Total CTC : </label>
                                                        <input type="text" name="total_ctc" id="total_ctc" autocomplete="off" value="<?= $salArrToObj->total_ctc;?>" class="form-control" required >
                                                    </div>
                                                </div>
												
												
                                                <div class="col-lg-2 col-md-6">
                                                    <div class="mt-sm-3">
                                                        <input type="hidden" name="redirect_aft_upd" value="1">
                                                        <input type="hidden" name="ctc" value="<?= $salArrToObj->ctc;?>">
                                                        <input type="hidden" name="user_id" value="<?php echo $salArrToObj->user_id;?>">
                                                        <input type="submit" class="btn btn-one">
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>



			var timeout = 1000; // in miliseconds (3*1000)
			$('.alert').delay(timeout).fadeOut(3000);
		
			function check_dept_projectIDS(){
                             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
				var Bussiness_unit = $("#business_unit").val();
				if(Bussiness_unit!='' && Bussiness_unit=="3"){
					$("#ProjectID_Div").show();
				}else{
					$("#ProjectID_Div").hide();
				}
				$.ajax({
					url: '<?= base_url("Policylist_Controller/get_dept_name_base_unit"); ?>',
					data: ({unit_id: Bussiness_unit}),
					type: 'post',
					success: function (data) {
						console.log(data);
						var response = '';
						var data2 = jQuery.parseJSON(data);
						var $select = $('#dept_id'); 
						$select.find('option').remove();  
						//$select.append('<option value=' '>'-- Select --'</option>');
						$.each(data2,function(i, item) {
							$select.append('<option value=' + item.id + '>' + item.deptname + '</option>');
						});
						$("#dept_id option:first").before($('<option value="" disabled selected >-- Select -- </option>'));
					}
                                        data:{[csrfName]: csrfHash}, 
				});
			}


           
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>
        <script>
             $(document).ready(function () {
                alert("testing")
              
        });
            </script>
    </div>
</body>


