<?php
$GroupPerAccidentInsurArr = array(
    "A"=>"5000000",
    "B"=>"4000000",
    "C"=>"3000000",
    "D"=>"2500000",
    "E"=>"2000000",
    "F"=>"1500000",
    ""=>"",
    "a"=>"5000000",
    "b"=>"4000000",
    "c"=>"3000000",
    "d"=>"2500000",
    "e"=>"2000000",
    "f"=>"1500000");

$TelephoneAllowanceArr = array(
    "A"=>"800",
    "B"=>"500",
    "C"=>"350",
    "D"=>"250",
    "E"=>"200",
    "F"=>"150",
    ""=>"",
    "a"=>"800",
    "b"=>"500",
    "c"=>"350",
    "d"=>"250",
    "e"=>"200",
    "f"=>"150");

// echo $salArrToObj->ann_bonus_applicable.'_mhystetr'; die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');

?>

<style>
table thead {
    color: #000;
}
        .w-250{
            width: 250px;
        }
.logo_adjust {
    padding: 0 0 15px 0;
}
#print_div{
    margin-top: 30px;
    padding: 40px !important;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="block-header stepper">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">                        
                        <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                            <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                        </ul>
                    </div> 
                </div>
            </div>
            <div class="container">

            <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Warning ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif;  ?>
                <span class="btn btn-info">
            <a href="<?php echo base_url('download_sal_anexture_pdf/'.$userDetails->user_id);?>"> Download</a></span>
            <span class="btn btn-info">
            <a href="<?php echo base_url('salary_structure_edit/'.$userDetails->user_id);?>"> Edit</a></span>
            <a class="btn btn-primary float-right" href="<?php echo $_SERVER['HTTP_REFERER'];?>" >Back</a><br>

            <!-- base_url('download_sal_anexture_pdf/'.$userDetails->user_id)?> -->
            

                <!--<div class="container">-->
        <div class="card">
            <div class="body" id='print_div'>
            <div class="row logo_adjust">
                <div class="col-10">
                    <!-- <h3 class="mb-0 text-dark"><b><?php echo ($userDetails->company_name) ? $userDetails->company_name : "CONSULTING ENGINEERS GROUP LTD"; ?></b></h3> -->
                <?php if($userDetails->company_id=="1"){ ?>
                    <div class="col-2">
                        <img src="https://www.cegindia.com/public/assets/site/images/logo.png" class="w-100">
                    </div>
                <?php } ?>
                    <!-- <p>(HO) B - 11 (G) Malviya Industrial Area, Jaipur, Rajasthan 302017</p>
                    <p class="small-month mb-0">GSTIN : 08AFQPK1299C1Z8</p>
                    <p class="small-month"><span class="mr-5">Tel. : 9773356002</span><span>email  :  business@growthgrids.com</span></p> -->
                </div>
                <h4>Annexure 1</h4>
                <?php /* if($userDetails->company_name == "CONSULTING ENGINEERS GROUP LTD" || $userDetails->company_name == "CEG Ltd" ):?>
                
                <div class="col-2">
                    <img src="https://www.cegindia.com/public/assets/site//images/logo.png" class="w-100">
                </div>
                <?php endif; */ ?>
            </div>

            <?php 
              $TelephoneAllowancAmount = $TelephoneAllowanceArr[trim($userDetails->jobtitle_name)];
            ?>
        
            <div class="row">
            <div class="col-md-6 pr-0">
                <div class="p-3 border h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        Name
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1"  >
                        <div  class="bg-light">
                            <b>: <?php echo ($userDetails->userfullname) ? $userDetails->userfullname : '-'; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Designation    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->position_name) ? $userDetails->position_name : '-'; ?></b>
                        </div>
                    </div>
                    <?php if($userDetails->department_name != 'Project') { ?>
                    <div class="col-md-5 col-6 mb-1">
                        Dept / Project Name    
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? $userDetails->department_name : $userDetails->department_name; ?></b>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="col-md-5 col-6 mb-1">
                        Location (HO RO / Project)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->businessunit_id != 3) ? "HO/RO" : "Project"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Group
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->jobtitle_name) ? $userDetails->jobtitle_name : "-"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        CTC Offered (Monthly)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ctc) ? number_format($salArrToObj->ctc) : "-"; ?></b>
                    </div>
                    </div>
                    <?php if($userDetails->company_name != ''){?>
                    <div class="col-md-5 col-6 mb-1">
                        Company Name              
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($userDetails->company_name) ? $userDetails->company_name : "-"; ?></b>
                        </div>
                    </div>
                    <?php }?>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pl-0">
                <div class="p-3 border border-left-0 h-100">
                <div class="row">
                    <div class="col-md-5 col-6 mb-1">
                        PF Applicable (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->pf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        VPF Applicable (Y/N)
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->vpf_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        ESI Applicable (Y/N)   
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->esi_applicable == 1) ? 'Y': "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Metro/Non Metro
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->metro_non == 1) ? "Metro" : "Non-Metro"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Gratuity
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->gratuity_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Mediclaim
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->mediclaim_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <div class="col-md-5 col-6 mb-1">
                        Annual Bonus offered (Y/N)           
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->annual_bonus_applicable == 1) ? "Y" : "N"; ?></b>
                        </div>
                    </div>
                    <?php if($salArrToObj->ann_bonus > 0) {?>
                    <div class="col-md-5 col-6 mb-1">
                        AB Amount (Included in CTC)         
                    </div>
                    <div class="col-md-7 col-6 text-dark mb-1">
                        <div  class="bg-light">
                        <b>: <?php echo ($salArrToObj->ann_bonus) ? number_format(($salArrToObj->ann_bonus * 12)) : "-"; ?></b>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                </div>
            </div>
        </div>
        <div style="text-align:center;margin: 10px 0 10px 0"><h6>CTC AND SALARY BREAK-UP (w.e.f <?php echo date('d M Y', strtotime($salArrToObj->effective_date)); ?> )</h6></div>
        <div class="table-responsive">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Particulars</th>
                    <th class="white-space-nowrap w-250" style="text-align: right;">Monthly Amount (Rs.)</th>
                    <th class="white-space-nowrap w-250" style="text-align: right;">Annually Amount (Rs.)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Earnings</th>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>Basic Salary</td>
                    <td align="right"><?php echo ($salArrToObj->basic_sal) ? number_format($salArrToObj->basic_sal) : "-"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->basic_sal) ? number_format(($salArrToObj->basic_sal * 12)) : "-"; ?></td>
                  </tr>
                  <tr>
                    <td>HRA</td>
                    <td align="right"><?php echo ($salArrToObj->hra) ? number_format($salArrToObj->hra) : "-"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->hra) ? number_format(($salArrToObj->hra * 12)) : "-"; ?></td>
                  </tr>
                <?php if($salArrToObj->edu_allow > 0) {?>
                  <tr>
                    <td>Education Allowance</td>
                    <td align="right"><?php echo ($salArrToObj->edu_allow) ? number_format($salArrToObj->edu_allow) : "-"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->edu_allow) ? number_format(($salArrToObj->edu_allow * 12)) : "-"; ?></td>
                  </tr>
                <?php }if($salArrToObj->tele_allow > 0) {?>
                  <tr>
                    <td>Telephone Allowance</td>
                  <td align="right"><?php echo ($salArrToObj->tele_allow) ? number_format($salArrToObj->tele_allow) : "-"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->tele_allow) ? number_format(($salArrToObj->tele_allow * 12)) : "-"; ?></td>
                    <!-- <td align="right"><?= ($TelephoneAllowancAmount) ? number_format($TelephoneAllowancAmount) : "0"; ?></td>
                    <td align="right"><?= ($TelephoneAllowancAmount) ? number_format(($TelephoneAllowancAmount * 12)) : "0"; ?></td> -->
                  </tr>
                <?php } if($salArrToObj->bonus_adv > 0) {?>
                  <tr>
                    <td>Bonus (Adv.)</td>
                    <td align="right"><?php echo ($salArrToObj->bonus_adv) ? number_format($salArrToObj->bonus_adv) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->bonus_adv) ? number_format(($salArrToObj->bonus_adv * 12)) : "0"; ?></td>
                  </tr>
                  <?php }?>
                  <?php if($salArrToObj->gadget_allow > 0) {?>
                  <tr>
                    <td>Gadget Allowance</td>
                    <td align="right"><?php echo ($salArrToObj->gadget_allow) ? number_format($salArrToObj->gadget_allow) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->gadget_allow) ? number_format(($salArrToObj->gadget_allow * 12)) : "0"; ?></td>
                    </tr>
                    <?php }if($salArrToObj->special_allow > 0) {?>
                  <tr>
                    <td>Special Allowance</td>
                    <td align="right"><?php echo ($salArrToObj->special_allow) ? number_format($salArrToObj->special_allow) : "-"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->special_allow) ? number_format(($salArrToObj->special_allow * 12)) : "-"; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="table-responsive ">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Gross Salary</th>
                    <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->gross) ? number_format($salArrToObj->gross) : "-"; ?></th>
                    <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->gross) ? number_format(($salArrToObj->gross*12)) : "-"; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Deductions</th>
                    <td></td>
                    <td></td>
                  </tr>
                <?php if($salArrToObj->employer_pf > 0){ ?>
                 <tr>
                    <td>Employer's Contribution to PF *</td>
                    <td align="right"><?php echo ($salArrToObj->employer_pf) ? number_format($salArrToObj->employer_pf) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->employer_pf) ? number_format(($salArrToObj->employer_pf) * 12) : "0"; ?></td>
                 </tr>
                 <?php } if($salArrToObj->employer_esi > 0) { ?>
                 <tr>
                    <td>Employer's Contribution to ESI *</td>
                    <td align="right"><?php echo ($salArrToObj->employer_esi) ? number_format($salArrToObj->employer_esi) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->employer_esi) ? number_format(($salArrToObj->employer_esi)*12) : "0"; ?></td>
                 </tr>
                 <?php } if($salArrToObj->employer_gratuity > 0) { ?>
                 <tr>
                    <td>Employer's Contribution to Gratuity *</td>
                    <td align="right"><?php echo ($salArrToObj->employer_gratuity) ? number_format($salArrToObj->employer_gratuity) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->employer_gratuity) ? number_format(($salArrToObj->employer_gratuity*12)) : "0"; ?></td>
                 </tr>
                 <?php } if($salArrToObj->gpai > 0) { ?>
                 <tr>
                    <td>Group Personal Accidental Insurance **</td>
                    <td align="right"><?php echo ($salArrToObj->gpai) ? number_format($salArrToObj->gpai) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->gpai) ? number_format(($salArrToObj->gpai*12)) : "0"; ?></td>
                 </tr>
                 <?php }if($salArrToObj->mediclaim > 0) { ?>
                 <tr>
                    <td>Group Mediclaim Insurance ***</td>
                    <td align="right"><?php echo ($salArrToObj->mediclaim) ? number_format($salArrToObj->mediclaim) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->mediclaim) ? number_format(($salArrToObj->mediclaim*12)) : "0"; ?></td>
                 </tr>
                 <?php }?>
                </tbody>
            </table>
        </div>

       <div class="table-responsive" style="overflow: hidden;">
            <table class="table table-bordered mb-0">
                <thead class="bg-light">
                  <tr>
                    <th class="white-space-nowrap">Monthly CTC</th>
                    <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->monthly_ctc) ? number_format($salArrToObj->monthly_ctc) : "0"; ?></th>
                    <th class="white-space-nowrap w-250" style="text-align: right;"><?php echo ($salArrToObj->monthly_ctc) ? number_format(($salArrToObj->monthly_ctc)*12) : "0"; ?></th>
                  </tr>
                </thead>

                <tbody>
                <?php if($salArrToObj->ann_bonus > 0){ ?>
                  <tr>
                    <th>Annual Bonus ****</th>
                    <td align="right"><?php echo ($salArrToObj->ann_bonus) ? number_format($salArrToObj->ann_bonus) : "0"; ?></td>
                    <td align="right"><?php echo ($salArrToObj->ann_bonus) ? number_format(($salArrToObj->ann_bonus * 12)) : "0"; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>

                <tbody class="bg-light">
                    <tr>
                        <th>Total CTC</th>
                        <th class="text-right" align="right"><?php echo ($salArrToObj->total_ctc) ? number_format($salArrToObj->total_ctc) : "0"; ?></th>
                        <th class="text-right" align="right"><?php echo ($salArrToObj->total_ctc) ? number_format(($salArrToObj->total_ctc*12)) : "0"; ?></th>
                    </tr>
                </tfoot>

                <tbody>
                    <?php //if(($salArrToObj->emp_pf>0) || ($salArrToObj->emp_vpf>0) || ($salArrToObj->emp_esi>0)){ ?>
                        <!-- <tr>
                            <td>Employee's Contribution to PF *</td>
                            <td><?php echo ($salArrToObj->emp_pf) ? number_format($salArrToObj->emp_pf) : "0"; ?></td>
                            <td><?php echo ($salArrToObj->emp_pf) ? number_format(($salArrToObj->emp_pf*12)) : "0"; ?></td>
                        </tr>
                        <tr>
                            <td>Employee's Contribution to VPF *</td>
                            <td><?php echo ($salArrToObj->emp_vpf) ? number_format($salArrToObj->emp_vpf) : "0"; ?></td>
                            <td><?php echo ($salArrToObj->emp_vpf) ? number_format(($salArrToObj->emp_vpf)*12) : "0"; ?></td>
                        </tr>
                        <tr>
                            <td>Employee's Contribution to ESI *</td>
                            <td><?php echo ($salArrToObj->emp_esi) ? number_format($salArrToObj->emp_esi) : "0"; ?></td>
                            <td><?php echo ($salArrToObj->emp_esi) ? number_format(($salArrToObj->emp_esi*12)) : "0"; ?></td> -->
                        </tr>
                    <?php //} ?>
                </tbody>

                <!-- <tfoot class="bg-light">
                    <tr>
                        <th class="text-center">Net Salary (Subject to TDS as per applicable law)</th>
                        <th colspan="2"><?php echo number_format($salArrToObj->net_sal);?></th>
                    </tr>
                    <tr>
                        <th class="text-left">CTC in Words -</th>
                        <th colspan="2"><?php echo $salArrToObj->ctc_in_words;?></th>
                    </tr>
                </tfoot> -->

            </table>
        </div>

        <div class="my-3 border">

        <?php 
          $GP_AccidentInsurAmount = $GroupPerAccidentInsurArr[trim($userDetails->jobtitle_name)];
        ?>

<div class="row">
    <div class="col-md-8">
          <p class="p-1">* <b>Gratuity </b> shall be payable as per The Payment of Gratuity Act, 1972. <br>
          ** <b>Group Personal Accident Insurance</b> sum assured of Rs. <?= number_format($GP_AccidentInsurAmount,0); ?> /- <br> 
          *** <b>Group Mediclaim Insurance</b> Policy sum assured up to Rs. 2,00,000/-. <br>
          <!-- **** <b>Annual Bonus (AB)</b> - Shall accrue on Annual basis and paid on prorate basis from the date of applicability of this letter. Annual Bonus is payable annually and / or on separation.</p> -->
          **** <b>Annual Bonus (AB)</b> - Shall accrue on Annual basis and paid on prorate basis from the date of applicability of this letter. Annual Bonus is payable annually and / or on separation.</p>

        </div>
        <div class="col-md-4" style="border-left:1px solid #cdd8e3">
       <?php if($userDetails->company_id=="1"){ ?>
                      <p style="text-align:center;margin-top:8px"><b>For CONSULTING ENGINEERS GROUP LTD.</b></p>
               
        <p style="padding: 61px 0 0px 0;text-align:center;"><b>Col S Guha Roy (Retd.)</b><br>
Vice President – HR & Administration</p>
 <?php } else { ?>
<p style="padding: 61px 0 0px 0;text-align:center;"> Signature </p>
    <?php } ?>
        </div>
        </div>

    <!-- </div> -->


            </div>
        </div>
    </div>
        </div>	
    </div>
</body>

<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

<script type="text/javascript">
    function showActive(value) {
        $("#isactive").empty();
        $("#isactive").val(value);
        table_active.ajax.reload(); 
    }
    function showInActive(value) {
        $("#isactive").empty();
        $("#isactive").val(value);
        table_active.ajax.reload(); 
    }
    function showAll() {
        $("#isactive").empty();
        $("#isactive").val('');
        table_active.ajax.reload(); 
    }
    function setUserIdForSalStructure(user_id) {
        $("#user_id").val(user_id);
    }

    var table_active;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_active = $('#table_active').DataTable({
                    "processing": true, //Feature control the processing indicator.
                   // "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('SalStructureController/ajax_employee_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.isactive = $('#isactive').val();
                            // data.company_name = $('#company_name').val();
                            // data.userfullname = $('#userfullname').val();
                            // data.employeeId = $('#employeeId').val();
                            // data.designation_name = $('#designation_name').val();
                            // data.department_name = $('#department_name').val();
                            // data.project_name = $('#project_name').val();
                            // data.status_type = $('#status_type').val();
                            // data.is_active = 1;
							data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';					
                        },
                                // data:{[csrfName]: csrfHash}, 

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('.btn-filter').click(function () { //button filter event click
                    table_active.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_active.ajax.reload();  //just reload table
                });
    });

</script> 
<script>
    $(document).ready(function () {
        var table = $('#employeeTable').DataTable();
        $("#all").trigger('click');
    });
</script>
<div class="modal" tabindex="-1" id="ctcModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= base_url('sal_structure');?>" method="POST">
                <div class="row">
                    <div class="col-sm-6">
                        <span id="reqd" class="error_ctc"><?= form_error('ctc'); ?></span>
                        <label for="">CTC Amount :</label>
                        <input type="text" value="" name="ctc" id="ctc" class="form-control" required>
                        <input type="hidden"  value="" name="user_id" id="user_id" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <span id="reqd" class="error_tax_figure"><?= form_error('tax_figure'); ?></span>
                        <label for="">Tax Figure:</label>
                        <input type="text" value="" name="tax_figure" id="tax_figure" class="form-control" required>
                    </div><br>
                    <div class="col-sm-6">
                        <label for=""><br></label>
                        <button type="submit" class="btn btn-primary">Show Structure</button>
                    </div>
                </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
    function printDiv() 
{

  var divToPrint=document.getElementById('print_div');

  var newWin=window.open('','Print-Window');

  newWin.document.open();

  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

  newWin.document.close();

  setTimeout(function(){newWin.close();},10);

}
</script>
<?php $this->load->view('admin/includes/footer'); ?>
 
