<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
.table tbody tr td,
.table tbody th td {
	vertical-align: middle !important;
	white-space: normal !important;
   
}
input[type=text] {
       background-color: #ffffff;
    width: 100%;
}
.reqd {
    color: red;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form id="form-filter"> 
							    <input type="hidden" id="isactive" value="1" class="form-control">
								
								<button type="button" id="" onclick="showActive('1')" class="btn btn-sm btn-success btn-filter active">Active</button>
								<button type="button" onclick="showInActive('5')" class="btn btn-sm btn-danger btn-filter">In-Active</button>
                                <button type="button" id="" onclick="showAll()" class="btn btn-sm btn-default btn-filter">All</button>

                                <!-- <a href="<?= base_url('employee_add'); ?>" class="btn btn-sm btn-one btn-filter float-right"><i class="fa fa-user"></i> Add New </a> -->

                                <a class="btn btn-primary float-right" href="<?php echo $_SERVER['HTTP_REFERER'];?>" >Back</a>
								
</form>
                                
								
								<hr>
                                
                               
                                <div class="table-responsive table-dataTables_length">
                                    <table  id="table_active" class="table table-striped display nowrap table-bordered table-hover"> 
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th width="30%">Emp Name</th>
                                                <th>Mobile</th>
                                                <th width="2%">Email</th>
                                                <th>Department Name</th>
                                                <th>Bussiness Unit</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>	
    </div>
</body>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
<script type="text/javascript">
    // modal for adding ctc
	
function showActive(value) {
	// alert("new")
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showInActive(value) {
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showAll() {
	$("#isactive").empty();
	$("#isactive").val('');
	table_active.ajax.reload(); 
}
function setUserIdForSalStructure(user_id) {
        $("#user_id").val(user_id);
    }


    var table_active;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_active = $('#table_active').DataTable({
                    "processing": true, //Feature control the processing indicator.
                   // "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('SalStructureController/ajax_employee_list_project') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.isactive = $('#isactive').val();
                            // data.company_name = $('#company_name').val();
                            // data.userfullname = $('#userfullname').val();
                            // data.employeeId = $('#employeeId').val();
                            // data.designation_name = $('#designation_name').val();
                            // data.department_name = $('#department_name').val();
                            // data.project_name = $('#project_name').val();
                            // data.status_type = $('#status_type').val();
                            // data.is_active = 1;
							data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';					
                        },
                                // data:{[csrfName]: csrfHash}, 

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('.btn-filter').click(function () { //button filter event click
                    table_active.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_active.ajax.reload();  //just reload table
                });
    });

</script> 
<script>
    $(document).ready(function () {
        var table = $('#employeeTable').DataTable();
        $("#all").trigger('click');
    });

    function addAnuualBonus() {
        var abApplicable = $("#annual_bonus_applicable").val();
        if (abApplicable == "1") {
            // Show the element with ID 'ab_applicable'
            $('#ab_applicable').css("display", "block");
        } else {
            // Optionally, hide the element if "No" is selected
            $('#ab_applicable').css("display", "none");
            $('#annual_bonus').val("");
        }
    }
</script>
<div class="modal" tabindex="-1" id="ctcModal" role="dialog">
  <div class="modal-dialog modal-lg center" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Salary Structure</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= base_url('sal_structure_project');?>" method="POST">
                <div class="row">
                    <div class="col-sm-6 form-group">
                        <span id="reqd" class="error_ctc"><?= form_error('ctc'); ?></span>
                        <label for="">CTC Amount <span class="reqd">*</span></label>
                        <input type="text" value="" name="ctc" id="ctc" class="form-control" required>
                        <input type="hidden"  value="" name="user_id" id="user_id" class="form-control">
                    </div>
                    <!-- <div class="col-sm-6">
                        <span id="reqd" class="error_tax_figure"><?= form_error('tax_figure'); ?></span>
                        <label for="">Tax Figure <span class="reqd">*</span></label>
                        <input type="text" value="" name="tax_figure" id="tax_figure" class="form-control" required>
                    </div> -->
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_metro_non_metro"><?= form_error('metro_non_metro'); ?></span>
                        <label for="">Metro/Non-Metro <span class="reqd">*</span></label>
                        <select name="metro_non_metro" id="metro_non_metro" class="form-control" required>
                                <option value="0">Non-Metro</option>
                                <option value="1">Metro</option>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_pf_applicable"><?= form_error('pf_applicable'); ?></span>
                        <label for="">PF Applicable <span class="reqd">*</span></label>
                        <select name="pf_applicable" id="pf_applicable" class="form-control" required>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                        </select>
                    </div>
                    
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_vpf_applicable"><?= form_error('vpf_applicable'); ?></span>
                        <label for="">VPF Applicable <span class="reqd">*</span></label>
                        <select name="vpf_applicable" id="vpf_applicable" class="form-control" required>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                        </select>
                        
                        
                    </div>
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_effective_date"><?= form_error('effective_date'); ?></span>
                        <label for="">W.E.F. <span class="reqd">*</span></label>
                        <input type="date" name="effective_date" class="form-control" id="effective_date" value="<?php echo date('Y-m-d');?>">
                    </div>
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_department"><?= form_error('department'); ?></span>
                        <label for="">Department<span class="reqd">*</span></label>
                        <select name="department" id="department" class="form-control" required>
                                <option value="">Select Department</option>
                                <option value="1">Highways / Railways</option>
                                <option value="2">Metro</option>
                                <option value="3">Normal</option>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <span id="reqd" class="error_annual_bonus_applicable"><?= form_error('annual_bonus_applicable'); ?></span>
                        <label for="">Annual Bonus Applicable<span class="reqd">*</span></label>
                        <select name="annual_bonus_applicable" id="annual_bonus_applicable" class="form-control" onChange="addAnuualBonus()" required>
                                <option value="">Select AB Applicable</option>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                        </select>
                    </div>
                    <div class="col-md-6 form-group" id="ab_applicable" style="display:none">
                        <span id="reqd" class="error_annual_bonus"><?= form_error('annual_bonus'); ?></span>
                        <label for="">Annual Bonus Amount<span class="reqd">*</span></label>
                        <input type="text" name="annual_bonus" id="annual_bonus" class="form-control">
                    </div>
                    <div class="col-sm-6">
                        <label for=""><br></label><br>
                        <button type="submit" class="btn btn-primary">Show Structure</button>
                    </div>
                </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
</script>
<?php $this->load->view('admin/includes/footer'); ?>
 
