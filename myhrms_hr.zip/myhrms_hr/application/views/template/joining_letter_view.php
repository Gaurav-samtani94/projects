<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joining Letter</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 20px;
    }

    .letter-container {
        border: 1px solid #ccc;
        padding: 20px;
        max-width: 800px;
        margin: 0 auto;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .header {
        text-align: center;
        margin-bottom: 20px;
    }

    .header h1 {
        margin: 0;
        font-size: 24px;
    }

    .header p {
        margin: 0;
        font-size: 14px;
        color: #555;
    }

    .content {
        margin-top: 20px;
    }

    .signature {
        margin-top: 50px;
        text-align: right;
    }

    .signature p {
        margin: 0;
    }

    .btn-container {
        text-align: center;
        margin-top: 20px;
    }

    .btn {
        display: inline-block;
        margin: 10px;
        padding: 10px 15px;
        background-color: #007bff;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .btn:hover {
        background-color: #0056b3;
    }
    </style>
</head>

<body>

    <div class="letter-container" id="joining-letter">
        <div class="header">
            <h1>Company Name</h1>
            <p>123 Business Street, City, Country</p>
            <p>Phone: +1 234 567 890 | Email: contact@company.com</p>
            <p><strong>Letterhead No: <span><?=$letterheadNumber?></span></strong></p>
        </div>

        <div class="content">
            <p>Date: <strong>January 22, 2025</strong></p>

            <p>To,</p>
            <p><strong>Recipient's Name</strong></p>
            <p><strong>Recipient's Address</strong></p>

            <p>Subject: Joining Letter</p>

            <p>Dear <strong>Recipient's Name</strong>,</p>

            <p>
                We are pleased to inform you that you have been selected for the position of
                <strong>Job Title</strong> at <strong>Company Name</strong>. Your joining date is
                <strong>February 1, 2025</strong>.
            </p>

            <p>
                Please report to our office at 9:00 AM and bring the required documents as
                discussed during the interview. If you have any questions, feel free to reach
                out to us.
            </p>

            <p>We look forward to welcoming you to our team.</p>

            <p>Yours sincerely,</p>

            <div class="signature">
                <p><strong>HR Manager</strong></p>
                <p>Company Name</p>
            </div>
        </div>
    </div>
    <div class="btn-container">
        <?php if ($empId > 0): ?>
        <a href="<?= base_url('edit_emp_jobhistory/' . $empId) ?>" class="btn">
            << Back</a>
                <?php else: ?>
                <a href="<?= base_url('template') ?>" class="btn">
                    << Back</a>
                        <?php endif; ?>

                        <a href="#" class="btn" onclick="downloadPDF()">Download as PDF</a>
                        <a href="#" class="btn" onclick="printLetter()">Print</a>
    </div>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <!-- Load jQuery from a CDN -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


    <script>
    function downloadPDF() {
        const {
            jsPDF
        } = window.jspdf;

        // Select the element to convert to PDF
        const element = document.querySelector("#joining-letter");
        if (!element) {
            alert("Element #joining-letter not found.");
            return;
        }

        // Use html2canvas to take a screenshot of the element
        html2canvas(element, {
                scale: 2
            })
            .then(canvas => {
                const imgData = canvas.toDataURL("image/png");
                const pdf = new jsPDF("p", "mm", "a4");
                const empId = <?=$empId;?>

                // Calculate dimensions to fit A4 page
                const pdfWidth = 210; // A4 width in mm
                const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

                pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);

                // Create a Blob from the PDF output
                const pdfData = pdf.output("blob");
                const id = <?= json_encode($id)?>;
                const lhno = <?= json_encode($letterheadNumber)?>;

                // Use FormData to send the PDF blob to the server
                const formData = new FormData();
                formData.append("pdf", pdfData, "Joining_Letter.pdf");
                formData.append("id", id);
                formData.append("lh", lhno);

                // Use AJAX to send the file to the server
                $.ajax({

                    url: '<?= base_url("Latter_Template_Controller/save_pdf_by_ajax") ?>', // Replace with your server-side URL
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (empId > 0) {
                            window.location.href = "<?= base_url('edit_emp_jobhistory/'.$empId) ?>";
                        } else {
                            window.location.href = "<?= base_url('template') ?>";
                        }
                        alert("PDF saved on the server!");
                    },
                    error: function(error) {
                        console.error("Error saving PDF:", error);
                        alert("Failed to save the PDF. Please try again.");
                    }
                });

                // Optionally save to local disk as well
                pdf.save("Joining_Letter.pdf");
            })
            .catch(error => {
                console.error("Error generating PDF:", error);
                alert("Failed to download the PDF. Please try again.");
            });
    }


    // Function to print the letter
    function printLetter() {
        const printContents = document.getElementById("joining-letter").innerHTML;
        const originalContents = document.body.innerHTML;

        // Set the content to be printed
        document.body.innerHTML = printContents;

        // Print the content
        window.print();

        // Restore the original content
        document.body.innerHTML = originalContents;
    }
    </script>

</body>

</html>