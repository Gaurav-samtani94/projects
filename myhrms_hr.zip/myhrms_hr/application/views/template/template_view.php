<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <!-- <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i
                                            class="fa fa-users"></i> Employee List </a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Name</th>
                                            <th>EmployeeId</th>
                                            <th>Business Unit</th>
                                            <th>Department</th>
                                            <th>Job Title</th>
                                            <th>Designation</th>
                                            <th>Company</th>
                                            <th>From</th>
                                            <th>To</th>
                                            <th>Template</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$jobhistoryRecArr) {
                                          
                                            foreach (@$jobhistoryRecArr as $kEy => $recD) {
                                                ?>
                                        <tr>
                                            <td><?= $kEy + 1; ?></td>
                                            <td><?=$recD->userfullname?></td>
                                            <td><?= $recD->employeeId?></td>
                                            <td><?= ($recD->unitname) ? $recD->unitname : ""; ?></td>
                                            <td><?= ($recD->deptname) ? $recD->deptname : ""; ?></td>
                                            <td><?= ($recD->jobtitlename) ? $recD->jobtitlename : ""; ?></td>
                                            <td><?= ($recD->positionname) ? $recD->positionname : ""; ?></td>
                                            <td><?= ($recD->company_name) ? $recD->company_name : ""; ?></td>
                                            <td><?= ($recD->start_date) ? date("d-m-Y", strtotime($recD->start_date)) : ""; ?>
                                            </td>
                                            <td><?= ($recD->end_date) ? date("d-m-Y", strtotime($recD->end_date)) : ""; ?>
                                            </td>
                                            <?php if ($recD && $recD->pdf_lock == 0): ?>
                                            <!-- PDF is locked -->
                                            <td>
                                                <a href="<?=HOSTNAME.'uploads/job_history_pdf_files/'.$recD->tem_pdf; ?>"
                                                    title="Joining Letter" target="_blank">
                                                    <i class="fa fa-download"></i>
                                                </a> &nbsp;&nbsp;<span style="color:red">Locked</span>
                                            </td>
                                            <?php else: ?>
                                            <!-- PDF is unlocked -->
                                            <td>
                                                <a href="<?= base_url('joiningletter/'.$recD->id.'/0'); ?>"
                                                    title="Joining Letter">
                                                    <i class="fa fa-eye"></i>
                                                </a> &nbsp;&nbsp;<span style="color:green">Unlocked</span>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php
                                            }
                                        } else {
                                            ?>
                                        <tr>
                                            <td style="color:red" colspan="9"> Record Not Found. </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<style>
span#reqrd {
    color: red;
}
</style>