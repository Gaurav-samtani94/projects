<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<style>
    .table tbody tr td,
    .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }

    .req {
        color: red;
    }
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>



        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="card p-3">
                    <div class="">
                        <table id="table" class="table table-bordered display" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>S.no</th>
                                    <!-- <th>Meting Name</th> -->
                                    <th>Name</th>
                                    <th>Empl. Id</th>
                                    <th>Department</th>
                                    <th>Designation</th>
                                    <th>Edit Permission</th>

                                </tr>
                            </thead>

                            <tfoot>
                                <tr>
                                    <th>S.no</th>
                                    <!-- <th>Meting Name</th> -->
                                    <th>Name</th>
                                    <th>Empl. Id</th>
                                    <th>Department</th>
                                    <th>Designation</th>
                                    <th>Edit Permission</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
                <script type="text/javascript">
                    
                    function Send_request_no(emp_id) {
                        var csrfName = '<?= $this->security->get_csrf_token_name() ?>';
                        var csrfHash = '<?= $this->security->get_csrf_hash() ?>';
                        $.ajax({
                            url: '<?= base_url('project/EmplEdit_PermController/Send_request_no') ?>',
                            type: "POST",
                            dataType: "json",
                            data: {
                                [csrfName]: csrfHash,
                                'emp_id': emp_id
                            },
                            success: function(data) {
                                alert(data)
                                $('#table').DataTable().ajax.reload();

                            },
                            error: function() {
                                alert('Data not saved');
                            }
                        });
                    }



                    function Send_request_yes(emp_id) {

                        var csrfName = '<?= $this->security->get_csrf_token_name() ?>';
                        var csrfHash = '<?= $this->security->get_csrf_hash() ?>';
                        $.ajax({
                            url: '<?= base_url('project/EmplEdit_PermController/Send_request_yes'); ?>',
                            type: "POST",
                            dataType: "json",
                            data: {
                                [csrfName]: csrfHash,
                                'emp_id': emp_id
                            },
                            success: function(data) {
                                alert(data)
                                $('#table').DataTable().ajax.reload();

                            },
                            error: function() {
                                alert('Data not saved');
                            }
                        });
                    }




                    var table;
                    $(document).ready(function() {
                        //datatables
                        table = $('#table').DataTable({
                            "processing": true,
                            "serverSide": true,
                            "order": [],
                            "ajax": {
                                "url": "<?= base_url('project/EmplEdit_PermController/empldetail'); ?>",
                                "type": "POST",
                                "data": function(data) {
                                    //  data.meal_date_from = $('#meal_date_from').val();
                                    // data.meal_date_to = $('#meal_date_to').val();
                                    data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                                },
                            },
                            "dom": 'lBfrtip',
                            "buttons": [{
                                extend: 'collection',
                                text: 'Export',
                                buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                            }],
                            "columnDefs": [{
                                "targets": [0],
                                "orderable": false,
                            }, ],
                            "aLengthMenu": [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                            ],
                        });
                        $('#btn-filter').click(function() {
                            table.ajax.reload();
                        });
                        $('#btn-reset').click(function() { //button reset event click
                            $('#form-filter')[0].reset();
                            table.ajax.reload(); //just reload table
                        });
                    });
                </script>
                <?php

                $this->load->view('admin/includes/footer');
                ?>