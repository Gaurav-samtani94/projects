<?php
// error_reporting(0);
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
.ui-datepicker-calendar {
    display: none;
}
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>


                <h5>Assign Leave Balance</h5>

                <div class="card">

                    <div class="body">
 <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                        <form action="<?= base_url('Leave_assign_Controller/excel_leave_upload'); ?>" method="POST"
                            enctype="multipart/form-data">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <div class="row filter-row">




                                <div class="col-lg-3">
                                    <div class="deptinfo" id="" style="margin-bottom:15px;">
                                        <a href="https://apps.cegtechno.com/myhrms_hr/public/LeaveBalanceUpdateSample.xlsx"
                                            style="float:right" download>sample</a>
                                        <span id="reqd" class="error_designation"><?= form_error('file'); ?></span>
                                        <label class="email">Leave Csv File : </label>
                                        <input type="file" name="file" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="deptinfo" id="" style="margin-bottom:15px;">
                                        <span id="reqd" class=""><?= form_error('leave_years'); ?></span>
                                        <label class="email">Year: </label>

                                        <select class="form-control show-tick ms select2" name="leave_years"
                                            data-placeholder="Select">
                                            <option value="">-Select Year-</option>
                                            <?php
                            $curYear = date('Y');
                            foreach (range($curYear - 1, $curYear + 1) as $year) {
                                echo "<option value='$year'>$year</option>";
                            } ?>
                                        </select>
                                    </div>
                                </div>





                                <div class="col-sm-3">
                                    <div class="mt-sm-3">
                                        <input type="submit" value="uploads" class="btn btn-primary">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg">
                        <div class="card">

                            <div class="body">


                                <form action="<?= base_url('updateleave'); ?>" method="post">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">




                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Employee Name : </label>
                                                <select class="form-control show-tick ms select2" name="user_id"
                                                    data-placeholder="Select" required>
                                                    <option value="">-Select Name-</option>
                                                    <?php
                                                    if ($Employeerecord) :
                                                        foreach ($Employeerecord as $unit_row) {
                                                            ?>
                                                    <option value="<?= $unit_row->user_id; ?>">
                                                        <?= $unit_row->userfullname, '&nbsp;&nbsp;', '(', $unit_row->employeeId, ')'; ?>
                                                    </option>
                                                    <?php
                                                        }
                                                    endif; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Year: </label>
                                                <select class="form-control show-tick ms select2" name="leave_year"
                                                    data-placeholder="Select" required>
                                                    <option value="">-Select Year-</option>
                                                    <?php
                                                    $curYear = date('Y');
                                                    foreach (range($curYear - 1, $curYear + 1) as $year) {
                                                        echo "<option value='$year'>$year</option>";
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>



                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo"
                                                class="form-control show-tick ms select2">
                                                <label class="email">Leave Balance: </label>
                                                <input type="text" value="" name="leave_day" autocomplete="off"
                                                    class="form-control" required>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="mt-sm-3">
                                                <button type="submit" name="submit" class="btn btn-one"> Submit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="tabledata" class="table table-bordered table-striped table-hover display"
                                        cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>Department</th>
                                                <th>Designation</th>
                                                <th>Year</th>
                                                <th>Total Leave</th>
                                                <th>Used Leaves</th>

                                            </tr>
                                        </thead>

                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>Department</th>
                                                <th>Designation</th>
                                                <th>Year</th>
                                                <th>Total Leave</th>
                                                <th>Used Leaves</th>


                                            </tr>
                                        </tfoot>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
            <script
                src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"
                integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ=="
                crossorigin="anonymous" referrerpolicy="no-referrer">
            </script>
            <script>
            $('.date-own').datepicker({
                minViewMode: 2,
                format: 'yyyy'
            });
            var table;

            $(document).ready(function() {
                //datatables
                table = $('#tabledata').DataTable({
                    // "processing": true,
                    "serverSide": true,
                    "order": [],
                    "ajax": {
                        "url": "<?= base_url('Leave_assign_Controller/Leave_assign_report'); ?>",
                        "type": "POST",
                        "data": function(data) {
                            // data.unit_name = $('#unit_name').val();

                            // data.start_date = $('#start_date').val();
                            // data.end_date = $('#end_date').val();
                            data.<?php echo $this->security->get_csrf_token_name(); ?> =
                                "<?php echo $this->security->get_csrf_hash(); ?>";
                        }
                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                        extend: 'collection',
                        text: 'Export',
                        buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                    }],
                    "columnDefs": [{
                        "targets": [0],
                        "orderable": false,
                    }, ],
                    "aLengthMenu": [
                        [10, 25, 50, -1],
                        [10, 25, 50, "All"]
                    ],
                });
                $('#btn-filter').click(function() {
                    table.ajax.reload();
                });
                $('#btn-reset').click(function() { //button reset event click
                    $('#form-filter')[0].reset();
                    table.ajax.reload(); //just reload table
                });
            });
            </script>

            <?php

           $this->load->view('admin/includes/footer_new');
            ?>