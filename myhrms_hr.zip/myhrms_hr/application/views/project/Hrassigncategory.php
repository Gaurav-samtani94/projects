<?php
// print_r($projectlist);
// die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<style>
    /* .table tbody tr td,
    .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }

    .req {
        color: red;
    } */
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        $title = 'Add Project To TimeSheet Request';
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form action="<?= base_url('Hrassigncate') ?>" method="post">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">




                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Category : </label>
                                                <select class="form-control show-tick ms select2" name="c_name" data-placeholder="Select" required>
                                                    <option value="">-Select Category-</option>
                                                    <?php
                                                    if ($Category) :
                                                        foreach ($Category as $unit_row) {
                                                    ?>
                                                            <option value="<?= $unit_row->fld_id ?>"><?= $unit_row->c_name ?></option>
                                                    <?php }
                                                    endif; ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-lg-3 col-md-4 col-sm-6">
                                            <div class="form-group">

                                                <label class="text-muted">Hr List: <span id="reqd"> * </span></label>
                                                <select class="form-control show-tick ms select2" name="userfullname" data-placeholder="Select" required>
                                                    <option value=""> -- Select -- </option>
                                                    <?php

                                                    if ($hrlist) {
                                                        foreach ($hrlist as $keyy => $vs) {
                                                    ?>
                                                            <option value="<?= $vs->user_id; ?>"><?= $vs->userfullname; ?></option>
                                                            <!-- <option value="<?= $vs->id ?>" <?= $projectid == $vs->id ? 'Selected' : ''; ?>><?= $vs->project_name; ?></option> -->
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="mt-sm-3">
                                                <button type="submit" name="submit" class="btn btn-one"> Assign</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="card">
                    <div class="body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                <thead>
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Hr Name</th>
                                        <th>No of Assign Category</th>
                                        <th>Assign date</th>
                                    </tr>
                                </thead>
                                <?php
                                $i = 1;
                                foreach ($assignlist as $row => $vs) {
                                ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><?= $vs->userfullname ?></td>
                                        <td> <a onclick="seteditupdatedata('<?= $vs->hruser_id; ?>')" data-toggle="modal" data-target="#myModal" href="javascript:void(0);"><?= $vs->abc ?></i></a></td>

                                        <td><?= $vs->assign_date ?></td>


                                    </tr>

                                <?php
                                    $i++;
                                }
                                ?>

                                <tfoot>
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Hr Name</th>
                                        <th>No of Assign Category</th>
                                        <th>Assign date</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="container">

        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">

                        <h5>Assign Model list: </h5>
                        <button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
                    </div>
                    <div class="modal-body">
                        <div id="purpose">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>




    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        function seteditupdatedata(hruser_id) {

            var csrfName = '<?php echo $this->security->get_csrf_token_name();

                            ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash();

                            ?>';
            $.ajax({

                url: '<?= base_url('project/HrassignCategory_Controller/ajax_getsinglecate_id'); ?>',
                data: ({
                    [csrfName]: csrfHash,
                    hruser_id: hruser_id
                }),
                type: 'post',
                success: function(data) {

                    // var arr = JSON.parse(data);
                    // console.log(arr);
                    $("#purpose").html(data);


                    // $("#purpose").append(data);




                }
            });
        }
    </script>
    <?php

    $this->load->view('admin/includes/footer');
    ?>