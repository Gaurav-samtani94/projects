<?php
// print_r($projectlist);
// die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<style>
    /* .table tbody tr td,
    .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }

    .req {
        color: red;
    } */
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        $title = 'Add Project To TimeSheet Request';
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="body">

                        <form action="<?= base_url('hrassignpro') ?>" id="basic-form" method="post" autocomplete="off">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <div class="row clearfix">
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="form-group">

                                        <label class="text-muted"> Project List : <span id="reqd"> * </span></label>
                                        <select class="form-control show-tick ms select2" name="project_name" data-placeholder="Select" required>
                                            <option value=""> -- Select -- </option>
                                            <?php

                                            if ($projectlist) {
                                                foreach ($projectlist as $keyy => $vs) {
                                            ?>
                                                    <option value="<?= $vs->id; ?>"><?= $vs->project_name; ?></option>
                                                    <!-- <option <?= set_select('id', $vs->id, (!empty($data) && $data == $vs->id ? TRUE : FALSE)); ?> value="<?= $vs->project_name; ?>"><?= $vs->project_name; ?></option> -->
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="form-group">

                                        <label class="text-muted">Hr List: <span id="reqd"> * </span></label>
                                        <select class="form-control show-tick ms select2" name="userfullname" data-placeholder="Select" required>
                                            <option value=""> -- Select -- </option>
                                            <?php

                                            if ($hrlist) {
                                                foreach ($hrlist as $keyy => $vs) {
                                            ?>
                                                    <option value="<?= $vs->user_id; ?>"><?= $vs->userfullname; ?></option>
                                                    <!-- <option value="<?= $vs->id ?>" <?= $projectid == $vs->id ? 'Selected' : ''; ?>><?= $vs->project_name; ?></option> -->
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="mt-4 pt-1">
                                        <input type="submit" name="submit" class="btn btn-one">
                                    </div>
                                </div>
                            </div>
                        </form>


                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Hr Name</th>
                                                <th>Assign Project</th>
                                                <th>Assign date</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $i = 1;
                                        foreach ($assignlist as $row => $vs) {
                                        ?>
                                            <tr>
                                                <td><?php echo $i ?></td>
                                                <td><?= $vs->userfullname ?></td>
                                                <td> <a onclick="seteditupdatedata('<?= $vs->hruser_id; ?>')" data-toggle="modal" data-target="#myModal" href="javascript:void(0);"><?= $vs->abc ?></i></a></td>

                                                <td><?= $vs->assign_date ?></td>


                                            </tr>

                                        <?php
                                            $i++;
                                        }
                                        ?>

                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Hr Name</th>
                                                <th>No of Project</th>
                                                <th>Assign date</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="container">
                <form action="<?= base_url('updatebook') ?>" method="post">
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">

                                    <h5>Assign project list: </h5>
                                    <button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
                                </div>
                                <div class="modal-body">
                                    <div id="purpose">

                                    </div>








                                    <? // form_close();
                                    ?>
                                </div>

                            </div>
                        </div>
                    </div>
            </div>

            </form>

        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>
            function seteditupdatedata(hruser_id) {

                var csrfName = '<?php echo $this->security->get_csrf_token_name();

                                ?>',
                    csrfHash = '<?php echo $this->security->get_csrf_hash();

                                ?>';

                $.ajax({

                    url: '<?= base_url('project/HrassignProject_Controller/ajax_getsingleproby_tid'); ?>',
                    data: ({
                        [csrfName]: csrfHash,
                        hruser_id: hruser_id
                    }),
                    type: 'post',
                    success: function(data) {

                        // var arr = JSON.parse(data);
                        // console.log(arr);



                        $("#purpose").html(data);


                        // $("#purpose").append(data);




                    }
                });
            }
        </script>

        <?php
        $this->load->view('admin/includes/footer');

        ?>