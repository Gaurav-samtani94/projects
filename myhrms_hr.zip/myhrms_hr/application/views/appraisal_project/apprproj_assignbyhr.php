<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<link href="<?= HOSTNAME . 'assets/datatables/css/jquery.dataTables.min.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/datatables/css/dataTables.colVis.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/datatables/css/buttons.dataTables.min.css' ?>" rel="stylesheet">

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2>
                                <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                                    <i class="fa fa-arrow-left"></i>
                                </a>Assign Appraisal on Project
                            </h2>

                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link active"> Assign Appraisal on CEG-Project
                                        </a></li>
                                </ul>
                            </div>

                            <div class="tab-content">
                                <form id="form-filter">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">

                                        <div class="col-sm-2 col-xs-4">
                                            <label class="control-label">Appraisal Session/Name : </label> <br>
                                            <span style="color:green"><?= (@$AppraisalSession) ? @$AppraisalSession : ""; ?></span>
                                        </div>

                                        <div class="col-sm-3 col-xs-6">
                                            <div class="form-group form-focus select-focus">
                                                <label class="control-label">Business Unit : </label>
                                                <select id="businessunit_name" class="form-control">
                                                    <option value="3"> CEG-Project </option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-3 col-xs-6">
                                            <div class="form-group form-focus select-focus">
                                                <label class="control-label">Emp Group : </label>
                                                <select id="jobtitgroup" class="form-control">
                                                    <option value="" selected="selected"> -- All -- </option>
                                                    <?php 
                                                    foreach ($jobgroupArr as $row) { ?>
                                                       <option value="<?= $row->id; ?>"><?= $row->jobtitlename; ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-sm-2 col-xs-4"> <br>
                                            <button type="button" id="btn-filter" class="btn btn-success btn-block">
                                                Filter </button>
                                        </div>
                                        <div class="col-sm-2 col-xs-4"> <br>
                                            <a href="<?= base_url("appraisal_assign"); ?>" type="button"
                                                class="btn btn-round btn-primary"> Back </a>
                                        </div>
                                    </div>
                                </form>
                                <hr>

                                <!-- Start Professional -->
                                <div class="tab-pane active" id="official">
                                    <div class="panel panel-default">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div id="colvis"></div>
                                            </div>
                                        </div>

                                        <div class="table-responsive">
                                            <table id="table" class="table table-striped display" style="width:100%;">
                                                <thead>
                                                    <tr>
                                                        <th style="width:10%">Sr. No. </th>
                                                        <th style="width:10%">Employee Name </th>
                                                        <th style="width:10%">EmployeeID </th>
                                                        <th style="width:10%">Email </th>
                                                        <th style="width:10%">Job Group </th>
                                                        <th style="width:10%">Department </th>
                                                        <th style="width:10%">Designation </th>
                                                        <th style="width:10%">Status </th>
                                                        <th style="width:10%">Action </th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th style="width:10%">Sr. No. </th>
                                                        <th style="width:10%">Employee Name </th>
                                                        <th style="width:10%">EmployeeID </th>
                                                        <th style="width:10%">Email </th>
                                                        <th style="width:10%">Job Group </th>
                                                        <th style="width:10%">Department </th>
                                                        <th style="width:10%">Designation </th>
                                                        <th style="width:10%">Status </th>
                                                        <th style="width:10%">Action </th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style="width:1000px">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body" id="teamdivsection"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>



        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="<?= HOSTNAME . 'assets/datatables/js/jquery.dataTables.min.js'; ?>"></script>
        <script src="<?= HOSTNAME . 'assets/datatables/js/dataTables.colVis.js'; ?>"></script>
        <script src="<?= HOSTNAME . 'assets/datatables/js/pdfmake.min.js'; ?>"></script>

        <script type="text/javascript">
        var table;
        //$(document).ready(function() {
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>';
            var csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
                "ajax": {
                    "url": "<?= base_url('appronproj_employeelistajax_list'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        data.jobtitgroupID = $('#jobtitgroup').val();
                        data.businessunit_name = $('#businessunit_name').val();
                    },

                    /*data: {
                        [csrfName]: csrfHash
                    },*/
                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                //Set column definition initialisation properties.
                "columnDefs": [{
                    "targets": [0],
                    "orderable": false,
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            var colvis = new $.fn.dataTable.ColVis(table);
            $('#colvis').html(colvis.button());

            $('#btn-filter').click(function() {
                table.ajax.reload();
            });
            
            $('#btn-reset').click(function() {
                $('#form-filter')[0].reset();
                table.ajax.reload();
            });
        //});
        </script>


        <script>
        function assignbyhrajax(userid) {
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $("#asssign_" + userid).html("Done");
            $("#asssign_" + userid).css("background", "Green");
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $.ajax({
                type: 'POST',
                url: '<?= base_url('appronproj_assigninsert'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'uid': userid
                },
                success: function(res) {
                    // var result = JSON.parse(res);
                    $("#asssign_" + res).html("Done");
                    $("#asssign_" + res).css("background", "Green");
                },
            });
        }


        function displayteam(repmanagerID) {
            $("#teamdivsection").html('');
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
            if (repmanagerID) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('teamlistview_ajax'); ?>',
                    data: {
                        [csrfName]: csrfHash,
                        'uid': repmanagerID
                    },
                    success: function(res) {
                        $("#teamdivsection").html(res);
                    },

                });
            }
        }
        </script>


        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>