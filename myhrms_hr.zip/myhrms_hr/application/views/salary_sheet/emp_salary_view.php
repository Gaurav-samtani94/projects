<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>


<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <!-- <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div> -->
                </div>
                <div id="content">
                    <div class="row clearfix">
                        <div id="loading"
                            style="display: none; position: absolute; top: 10%; left: 42%; text-align: center; z-index: 999999999999;">
                            <img src="<?= FRONTASSETS; ?>images/loader.gif" />
                        </div>

                        <div class="col-lg-12">
                            <?php if ($this->session->flashdata('msg')) { ?>
                            <div class="alert alert-success alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>
                                    <div id="msgs"> Success ! </div>
                                </strong> <?= $this->session->flashdata('msg'); ?>
                            </div>
                            <?php } ?>

                            <?php if ($this->session->flashdata('error')) { ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>
                                    <div id="error"> Oops ! </div>
                                </strong> <?= $this->session->flashdata('error'); ?>
                            </div>
                            <?php } ?>


                            <div class="card">
                                <div class="body">

                                    <form action="<?= base_url("verify");?>" method="post" id="import_form">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="col-sm-4">Select Month Year: </label>
                                                <div class="mb-3">
                                                    <select class="form-control" name="monthyear" onchange="this.form.submit()">
                                                    <option value="<?= $filtermonth;?>" <?= ($filtermonth) ? "selected" : "" ?>><?= $filtermonth;?></option>
                                                        <?php
                                                       if($monthyear){
                                                        foreach($monthyear as $key=>$roWs){ ?>
                                                            <option value="<?= $roWs->month_year;?>" <?= ($filtermonth == $roWs->month_year) ? "selected" : "" ?>><?= $roWs->month_year;?></option>
                                                      
                                                        <?php }}
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3 mt-4">
                                                <input type="submit" name="go_reset" id="btn-filter"
                                                    class="btn btn-primary" value="Reset" /> 
                                            </div>
                                            <div class="col-sm-2">
                                                <div class="col-sm-11">
                                                <input type="submit" name="go_Approved" id="btn-filter"
                                                    class="btn btn-primary" value="Click & Approved" /> 
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <div class="table-responsive">
                                                <table
                                                    class="table table-bordered table-striped table-hover dataTable js-exportable">
                                                    <thead>
                                                        <tr>
                                                            <!-- <th><input type="checkbox" onclick="toggle(this);">&nbsp; Check all</th> -->
                                                           
                                                            <th>EMP Id</th>
                                                            <th>Payroll Code</th>
                                                            <th>User Name</th>
                                                            <th>Month Year</th>
                                                            <th>Ctc</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <?php
                                        if($emplist){
                                            foreach($emplist as $key=>$roWs){
                                            ?>
                                                    <tr>
                                                        <td><?=$roWs->employeeId;?></td>
                                                        <td><?=$roWs->payroll_code;?></td>
                                                        <td><?=$roWs->userfullname;?></td>
                                                        <td><?=$roWs->month_year;?></td>
                                                        <td><?=$roWs->ctc;?></td>
                                                        <td><?=$roWs->appr_status==0?"Pending":"Approved";?></td>
                                                    </tr>
                                                    <?php
                                            }
                                        }
                                        ?>
                                                    <tbody>
                                                    </tbody>

                                                </table>
                                            </div>
                                            <!-- </form> -->
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>


    <?php $this->load->view('admin/includes/footer'); ?>

    <script>
    var my_project_table;
    $(document).ready(function() {

        my_project_table = $('#my_project').DataTable({
            "processing": true,
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
            // "ajax": {
            //     "url": "<?=base_url('salary/Salary_upload_controller/show_emp_list_by_ajax');?>",
            //     "type": "POST",
            //     // "data": function(data) {
            //     //     data.fin_id = $('#fin_id').val();
            //     //     data.expense_id = $('#expense_id').val();
            //     //     // data.file_type = $('#file_type').val();
            //     //     data.exp_type = $('#exp_type').val();
            //     // },

            // },
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ]
            }],
            "columnDefs": [{
                "targets": [0, 10], //first column / numbering column
                "orderable": false, //set not orderable
                "className": 'select-checkbox',
            }, ],
            select: {
                style: 'os',
                selector: 'td:first-child'
            },

            "aLengthMenu": [
                [100, 25, 50, -1],
                [100, 25, 50, "All"]
            ],
            "aLengthChange": true,
        });

        $('#btn-filter').click(function() { //button filter event click
            my_project_table.ajax.reload(); //just reload table
        });
        $('#btn-reset').click(function() { //button reset event click
            $('#form-filter')[0].reset();
            my_project_table.ajax.reload(); //just reload table
        });
    });
    </script>

</body>