<?PHP
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('sorry_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('sorry_msg'); ?>
                    </div>
                <?php endif; ?>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form action="<?= base_url('Book_airlines') ?>" method="post">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">




                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Airlines Name: </label>
                                                <input type="text" value="" name="air_lines" autocomplete="off" class="form-control" required>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Airlines Slug: </label>
                                                <input type="text" value="" name="slug" autocomplete="off" class="form-control" required>
                                            </div>
                                        </div>



                                        <div class="col-sm-3">
                                            <div class="mt-sm-3">
                                                <button type="submit" name="submit" class="btn btn-one"> Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="tabledata" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Airlines Name</th>
                                                <th>Air Slug</th>
                                            </tr>
                                        </thead>

                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Airlines Name</th>
                                                <th>Air Slug</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
            <script>
                var table;

                $(document).ready(function() {
                    //datatables
                    table = $('#tabledata').DataTable({
                        // "processing": true,
                        "serverSide": true,
                        "order": [],
                        "ajax": {
                            "url": "<?= base_url('Ticket/Airlines_controller/Airlines_data'); ?>",
                            "type": "POST",
                            "data": function(data) {
                                // data.unit_name = $('#unit_name').val();

                                // data.start_date = $('#start_date').val();
                                // data.end_date = $('#end_date').val();
                                data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                            }
                        },
                        "dom": 'lBfrtip',
                        "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                        }],
                        "columnDefs": [{
                            "targets": [0],
                            "orderable": false,
                        }, ],
                        "aLengthMenu": [
                            [10, 25, 50, -1],
                            [10, 25, 50, "All"]
                        ],
                    });
                    $('#btn-filter').click(function() {
                        table.ajax.reload();
                    });
                    $('#btn-reset').click(function() { //button reset event click
                        $('#form-filter')[0].reset();
                        table.ajax.reload(); //just reload table
                    });
                });
            </script>
            <?PHP
            $this->load->view('admin/includes/footer');
            ?>