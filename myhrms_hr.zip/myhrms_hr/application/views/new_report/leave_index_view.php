<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Monthly Leave Management</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        
                                        <form method="post" action="<?= base_url('joining_report_data'); ?>" id="visitingcard_form">
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <div class="row clearfix">
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Start Date :</b>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" name="" class="form-control datetimepicker" id="start_dates">
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>End Date :</b>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" name="" class="form-control datetimepicker" id="end_dates">
                                                    </div>
                                                </div>

                                                <div class="col-lg-2 col-md-6">
                                                    <div class="mt-sm-3">
                                                        <button  type="button" id="btn-filter" class="btn btn-one"> Filter </button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                          
                                            <!--</div> -->      
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display table-bordered table-hover" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Name</th>
                                                <th>Business Unit</th>
                                                <th>Department</th>
                                                <th>I.O</th>
                                                <th>Leave From</th>
                                                <th>Leave To</th>
                                                <th>No of Day</th>
                                                <th>L.Type</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Name</th>
                                                <th>Business Unit</th>
                                                <th>Department</th>
                                                <th>I.O</th>
                                                <th>Leave From</th>
                                                <th>Leave To</th>
                                                <th>No of Day</th>
                                                <th>L.Type</th>
                                                <th>Status</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>

    <script type="text/javascript">
        var table;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            //datatables
            var compid = $('#companynames').val();

            table = $('#table').DataTable({
                "processing": true, //Feature control the processing indicator.
                "serverSide": true, //Feature control DataTables' server-side processing mode.
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
				"scrollY":'62vh',
             "scrollX": true,
                "ajax": {
                    "url": "<?php echo base_url('ajax_list_leave') ?>",
                    "type": "POST",
                    "data": function (data) {
                        data.start_dates = $('#start_dates').val();
                        data.end_dates = $('#end_dates').val();
					   data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';
                    },
                            // data:{[csrfName]: csrfHash}, 

                },
                "dom": 'lBfrtip',
                "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [
                    {
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],

            });

            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });

        });



    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>