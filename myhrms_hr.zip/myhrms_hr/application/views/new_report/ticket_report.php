<?PHP
// $dataarr = data_model();
// print_r($dataarr);
// die;
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form action="<?= base_url('updateleave') ?>" method="post">
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">




                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Category : </label>
                                                <select class="form-control show-tick ms select2" name="c_name" id="catgory_id" data-placeholder="Select" required>
                                                    <option value="">-Select Category-</option>
                                                    <?php
                                                    if ($Category) :
                                                        foreach ($Category as $unit_row) {
                                                    ?>
                                                            <option value="<?= $unit_row->fld_id ?>"><?= $unit_row->c_name ?></option>
                                                    <?php }
                                                    endif; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Employee Name: </label>
                                                <select class="form-control show-tick ms select2" name="userfullname" id="emp_id" data-placeholder="Select" required>
                                                    <option value="">-Select Name-</option>
                                                    <?php
                                                    if ($Employee) :
                                                        foreach ($Employee as $unit_row) {
                                                    ?>
                                                            <option value="<?= $unit_row->entry_by ?>"><?= $unit_row->userfullname ?></option>
                                                    <?php }
                                                    endif; ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Status: </label>
                                                <select class="form-control show-tick ms select2" name="fld_id" id="fld_id" data-placeholder="Select" required>
                                                    <option value="">-Select Status-</option>
                                                    <option value="1">Open</option>
                                                    <option value="2">In Progress</option>
                                                    <option value="3">Done</option>


                                                </select>
                                            </div>
                                        </div>



                                        <div class="col-sm-3">
                                            <div class="mt-sm-3">
                                                <button type="button" id="btn-filter" class="btn btn-one"> Filter</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="tabledata" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Ticket No.</th>
                                                <th>Ticket By</th>
                                                <th>Department</th>
                                                <th>Category</th>
                                                <th>No Of Reply</th>
                                                <th>Status</th>
                                                <th>Ticket Raise Datetime</th>


                                            </tr>
                                        </thead>

                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Ticket No.</th>
                                                <th>Ticket By</th>
                                                <th>Department</th>
                                                <th>Category</th>
                                                <th>No Of Reply</th>
                                                <th>Status</th>
                                                <th>Ticket Raise date</th>


                                            </tr>
                                        </tfoot>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

            <script>
                var table;

                $(document).ready(function() {
                    //datatables
                    table = $('#tabledata').DataTable({
                        // "processing": true,
                        "serverSide": true,
                        "order": [],
                        "ajax": {
                            "url": "<?= base_url('Ticket/TicketRport_Controller/Ticket_report'); ?>",
                            "type": "POST",
                            "data": function(data) {
                                data.catgory_id = $('#catgory_id').val();

                                data.emp_id = $('#emp_id').val();
                                data.tick_status = $('#fld_id').val();
                                data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                            }
                        },
                        "dom": 'lBfrtip',
                        "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                        }],
                        "columnDefs": [{
                            "targets": [0],
                            "orderable": false,
                        }, ],
                        "aLengthMenu": [
                            [10, 25, 50, -1],
                            [10, 25, 50, "All"]
                        ],
                    });
                    $('#btn-filter').click(function() {
                        table.ajax.reload();
                    });
                    $('#btn-reset').click(function() { //button reset event click
                        $('#form-filter')[0].reset();
                        table.ajax.reload(); //just reload table
                    });
                });
            </script>
            <?PHP
            $this->load->view('admin/includes/footer');
            ?>