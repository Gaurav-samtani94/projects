<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$this->load->model("Accountdept_model");
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Monthly Tour Management</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">



                        <div class="card">
                            <div class="body">
                                <h4>
                                    <a href="<?= base_url("project_mm_report"); ?>">
                                        <button class="btn btn-one mr-2">
                                            << Back </button>
                                    </a>
                                    <?= $ProjectInfoArr->project_name; ?>

                                </h4>
                                <div class="table-responsive">




                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable" cellspacing="0" border="1" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Designation / Position</th>
                                                <th>Employee Name </th>
                                                <th>Total MM </th>
                                                <th>Tot. MM+EOT-MM </th>
                                                <th>Total Cum. Prev. MM </th>
                                                <th>Balance MM </th>
                                                <th>EOT <br><small style="color:red">un approved</small> </th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php
                                            if ($DesignationCategArr) {
                                                foreach ($DesignationCategArr as $kEy => $roWs) {
                                            ?>

                                                    <tr>
                                                        <th style="color:green" colspan="8"> <?= $roWs->ktype_name; ?> </th>
                                                    </tr>

                                                    <?php
                                                    // print_r($DesignationListArr);
                                                    $designationAllRecd = $DesignationListArr[$roWs->design_categid];
                                                    // print_r($designationAllRecd);
                                                    if ($designationAllRecd) {
                                                        foreach ($designationAllRecd as $key => $keyRow) {

                                                            $sum_ApprvEOTRec = $this->Accountdept_model->ApprvEOTDetails_SumMM($keyRow->hrms_projid, $keyRow->designation_id);
                                                            $sum_UnApprvEOTRec = $this->Accountdept_model->UnApprvEOTDetails_SumMM($keyRow->hrms_projid, $keyRow->designation_id);
                                                    ?>
                                                            <tr>
                                                                <td><?= $key + 1; ?></td>
                                                                <td>
                                                                    <?= $keyRow->designation_name; ?><br>
                                                                    <span style="color:green">(<?= $keyRow->company_name; ?>)</span>
                                                                </td>
                                                                <td>
                                                                    <?php
                                                                    $empFullName = '';
                                                                    if ($keyRow->company_id == "74" or $keyRow->company_id == null) {
                                                                        if ($keyRow->userfullname_repl != "") {
                                                                            $empFullName = $keyRow->userfullname_repl . " / ";
                                                                        }
                                                                        $empFullName .= $keyRow->prefix_name . " " . $keyRow->userfullname;
                                                                    }
                                                                    if ($keyRow->company_id != "74") {
                                                                        $empFullName = $keyRow->emp_name;
                                                                    }

                                                                    if ($keyRow->flag_of_repl == "2") {
                                                                        $empFullName = $keyRow->emp_name;
                                                                    }

                                                                    echo ($keyRow->repl_other_tbl_empl) ? $keyRow->repl_other_tbl_empl . " / " : "";
                                                                    echo ($empFullName) ? $empFullName : "<span style='color:red'>TBN</span>";
                                                                    ?>
                                                                </td>
                                                                <td> <?= number_format($keyRow->mm, 2); ?></td>
                                                                <td> <?= number_format(($keyRow->mm + $sum_ApprvEOTRec), 2); ?> </td>
                                                                <td> <?= number_format($keyRow->cumul_prev_mm, 2); ?></td>
                                                                <td> <?= number_format(($keyRow->mm + $sum_ApprvEOTRec) - $keyRow->cumul_prev_mm, 2); ?></td>
                                                                <td> <?= number_format($sum_UnApprvEOTRec, 2); ?> </td>
                                                            </tr>
                                            <?php
                                                        }
                                                    }
                                                }
                                            }
                                            ?>

                                        </tbody>


                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Designation / Position</th>
                                                <th>Employee Name </th>
                                                <th>Total MM </th>
                                                <th>Tot. MM+EOT-MM </th>
                                                <th>Total Cum. Prev. MM </th>
                                                <th>Balance MM </th>
                                                <th>EOT <small>un approved</small> </th>
                                            </tr>
                                        </tfoot>
                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    </div>


    <?php $this->load->view('admin/includes/footer'); ?>
</body>