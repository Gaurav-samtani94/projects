<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$this->load->model("Accountdept_model");
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                           <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                   
					<div class="col-lg-12">
						
                        <div class="card">
                            <div class="body">
								<form id="form-filter"> 
								<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
									<div class="row">
										<div class="col-md-4 mb-2 mb-sm-0">
											<select class="form-control" name="bunit_name" id="bunit_name">
												<!--<option value="">--Select Business Unit</option>-->
												<option value="1">CEG</option>
												<option value="2">CEG-TH</option>
												<option value="3">CEG-Project</option>
											</select>
											
										</div>
										
										<div class="col-md-4 mb-2 mb-sm-0">
											<select class="form-control" name="isactive" id="isactive">
												<option value="1">Active</option>
												<option value="6">In-Active</option>
												
											</select>
											
										</div>
										<div class="col-md-4">
										
											<button type="button" class="btn btn-one" id="btn-filter">Filter</button>
											<button type="button" class="btn btn-success" id="btn-reset">Reset</button>
										</div>
									</div>
								</form>
								<br>
								<hr>
                                <div class="table-responsive">
                                    <table id="table" class="table table-bordered table-striped table-hover" cellspacing="0" border="1" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Employee Name </th>
                                                <th>Employee ID </th>
                                                <th>B-Unit</th>
                                                <th>Dpt</th>
                                                <th>Sub-Dpt</th>
                                                <th>Position</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>Project </th>
                                                <th>Company Name</th>
                                                <th>Payroll Code</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Employee Name </th>
                                                <th>Employee ID </th>
                                                <th>B-Unit</th>
                                                <th>Dpt</th>
                                                <th>Sub-Dpt</th>
                                                <th>Position</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>Project </th>
                                                <th>Company Name</th>
                                                <th>Payroll Code</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    </div>

	<script type="text/javascript">
        var table;
        $(document).ready(function () {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>', csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
				"scrollY":'62vh',
				"scrollX": true,
                "ajax": {
                    "url": "<?php echo base_url('job_exp_history_report_ajax') ?>",
                    "type": "POST",
                    "data": function (data) {
                        data.bunit_name = $('#bunit_name').val();
                        data.isactive = $('#isactive').val();
						data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                    },
                    // data: {[csrfName]: csrfHash},
                },
                "dom": 'lBfrtip',
                "buttons": [{
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [{
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });

            $('#btn-filter').click(function () { //button filter event click
                // alert($('#isactive').val())
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });
        });
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>