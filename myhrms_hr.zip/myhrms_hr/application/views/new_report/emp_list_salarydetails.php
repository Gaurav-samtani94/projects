<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <form id="form-filter"> 
                                            <div class="row clearfix">
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Business Unit :</b>
                                                    <div class="input-group mb-3">
                                                        <select id="businessunit_name" name="businessunit_name" class="form-control">
                                                            <option value="" selected="selected"> Select Business </option>
                                                            <?php
                                                            $all_businessunit = get_businessunits();
                                                            if ($all_businessunit):
                                                                foreach ($all_businessunit as $unitrow) {
                                                                    ?>
                                                                    <option <?= (@$bus_unit == $unitrow->id) ? "Selected" : "" ?> value="<?= $unitrow->id; ?>"><?= $unitrow->unitname; ?></option>
                                                                    <?php
                                                                }
                                                            endif;
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Company Name :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="company_name" name="company_name" class="form-control">
                                                            <option value="" selected="selected">Select Company</option>
                                                            <?php
                                                            $all_company = get_companyname();
                                                            if ($all_company):
                                                                foreach ($all_company as $companyrow) {
                                                                    ?>
                                                                    <option <?= (@$company == $companyrow->id) ? "Selected" : "" ?> value="<?= $companyrow->id; ?>"><?= $companyrow->company_name; ?></option>
                                                                    <?php
                                                                }
                                                            endif;
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Department :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="department_id" name="department_id" class="form-control">
                                                            <option value="" selected="selected"> Select Department </option>
                                                            <?php
                                                            $all_Activedepartment = get_departments();
                                                            if ($all_Activedepartment):
                                                                foreach ($all_Activedepartment as $deprow) {
                                                                    ?>
                                                                    <option <?= (@$dpt == $deprow->id) ? "Selected" : "" ?> value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
                                                                    <?php
                                                                }
                                                            endif;
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Designation :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="potion_design_id" name="potion_design" class="select floating form-control">
                                                            <option value=""> Select Designation </option>
                                                            <?php
                                                            $all_Activedesignation = get_designation();
                                                            if ($all_Activedesignation):
                                                                foreach ($all_Activedesignation as $desigrow) {
                                                                    ?>
                                                                    <option <?= (@$design == $desigrow->id) ? "Selected" : "" ?> value="<?= $desigrow->id; ?>"><?= $desigrow->positionname; ?></option>
                                                                    <?php
                                                                }
                                                            endif;
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>From Date (DOL) :</b>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" name="from_date" value="<?= @$from_date; ?>" class="form-control datetimepicker" id="from_date">
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>To Date (DOL) :</b>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" name="to_date" value="<?= @$to_date; ?>" class="form-control datetimepicker" id="to_date">
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Employee Name :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="userfullname" value="" class="form-control" id="userfullname">
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">   
														<div class="mt-sm-3">
													<!--<input type="submit" style="margin-top: 20px;" id="" value="Filter" name="filter" class="btn btn-round btn-success">-->
                                                        <button type="button" id="btn-filter" class="btn btn-one"> Filter </button>
                                                  
                                                        <button type="button" id="btn-reset" class="btn btn-success"> Reset </button>
                                                        <!--<input type="reset" style="margin-top: 20px;" id="" value="Reset" name="submit" class="btn btn-round btn-primary">-->
                                                    </div>
                                                </div>


                                            </div>
                                            
                                            <!--</div> -->                               

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Bank Name</th>
                                                <th>A/C Holder</th>
                                                <th>Branch</th>
                                                <th>Account No.</th>
                                                <th>Payrollcode</th>
                                                <th>IFSC Code</th>
                                                <th>PAN No.</th>
                                                <th>CTC</th>
                                                <th>Gross Salary</th>
                                                <th>Salary Apply From</th>
                                                <th>Basic Salary</th>
                                                <th>Appraisal Due Date</th>
                                                <th>HRA</th>
                                                <th>Edu. Allowance</th>
                                                <th>Teleph. Allowance</th>
                                                <th>Medic. Allowance</th>
                                                <th title="Transportation Allowance">Transport. Allowance</th>
                                                <th>Special Allowance</th>
                                                <th>Project Allowance</th>
                                                <th>Statutory deductions</th>
                                                <th>Emp. Cont. PF</th>
                                                <th>Emp. Cont. ESI</th>
                                                <th>Gratuity</th>
                                                <th>GPAI</th>
                                                <th>Loyalty Bonus</th>
                                                <th>Project Comp Bonus</th>
                                                <th>P1</th>
                                                <th>P2</th>
                                                <th>Driver Wagers</th>
                                                <th>Vehicle Agreement</th>
                                                <th>Fuel Expenses</th>
                                                <th>Food Expenses</th>
                                                <th>Leave Travel Allowance</th>
                                                <th>Other</th>
                                            </tr>
                                        </thead>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Bank Name</th>
                                                <th>A/C Holder</th>
                                                <th>Branch</th>
                                                <th>Account No.</th>
                                                <th>Payrollcode</th>
                                                <th>IFSC Code</th>
                                                <th>PAN No.</th>
                                                <th>CTC</th>
                                                <th>Gross Salary</th>
                                                <th>Salary Apply From</th>
                                                <th>Basic Salary</th>
                                                <th>Appraisal Due Date</th>
                                                <th>HRA</th>
                                                <th>Edu. Allowance</th>
                                                <th>Teleph. Allowance</th>
                                                <th>Medic. Allowance</th>
                                                <th title="Transportation Allowance">Transport. Allowance</th>
                                                <th>Special Allowance</th>
                                                <th>Project Allowance</th>
                                                <th>Statutory deductions</th>
                                                <th>Emp. Cont. PF</th>
                                                <th>Emp. Cont. ESI</th>
                                                <th>Gratuity</th>
                                                <th>GPAI</th>
                                                <th>Loyalty Bonus</th>
                                                <th>Project Comp Bonus</th>
                                                <th>P1</th>
                                                <th>P2</th>
                                                <th>Driver Wagers</th>
                                                <th>Vehicle Agreement</th>
                                                <th>Fuel Expenses</th>
                                                <th>Food Expenses</th>
                                                <th>Leave Travel Allowance</th>
                                                <th>Other</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>


    <script type="text/javascript">
        var table;
        $(document).ready(function () {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>', csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
				"scrollY":'62vh',
             "scrollX": true,
                "ajax": {
                    "url": "<?php echo base_url('ajax_list_empsalarydetails') ?>",
                    "type": "POST",
                    "data": function (data) {
                        data.businessunit_name = $('#businessunit_name').val();
                       data.company_name = $('#company_name').val();
                       data.department_id = $('#department_id').val();
                       data.potion_design_id = $('#potion_design_id').val();
                       data.from_date = $('#from_date').val();
                       data.to_date = $('#to_date').val();
                       data.userfullname = $('#userfullname').val();
					   data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';
                    },
                    // data: {[csrfName]: csrfHash},
                },
                "dom": 'lBfrtip',
                "buttons": [{
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [{
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });

            $('#btn-filter').click(function () { //button filter event click
                // alert($('#department_id').val())
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });
        });
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>