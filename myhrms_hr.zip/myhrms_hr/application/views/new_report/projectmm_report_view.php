<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
#pageloader
{
	background: rgba( 255, 255, 255, 0.8 );
	display: none;
	height: 100%;
	position: fixed;
	width: 100%;
	z-index: 9999;
}

#pageloader img
{
	left: 50%;
	margin-left: -32px;
	margin-top: -32px;
	position: absolute;
	top: 50%;
}
</style>
<div id="pageloader">
<img src="http://cdnjs.cloudflare.com/ajax/libs/semantic-ui/0.16.1/images/loader-large.gif" alt="processing..." />
</div>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Man Month on Project</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">

                        <!--                        <div class="card">
                                                    <div class="body">
                                                        <div class="accordion" id="accordion">
                                                            <div>
                                                                <form method="post" action="<?php // base_url('joining_report_data');     ?>" id="visitingcard_form">
                                                                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">  
                        <div class="card-header" id="headingOne">
                                                                    <div class="row clearfix">
                                                                        <div class="col-lg-3 col-md-6">
                                                                            <b>Session Master :</b>
                                                                            <div class="input-group mb-3">
                                                                                <select class="form-control" name="session_id" id="session_id">
                                                                                    <option value="10-2020">10-2020 </option>
                                                                                    
                                                                                </select>
                                                                            </div>
                                                                        </div>
                        
                                                                        <div class="col-lg-3 col-md-6">
                                                                            <b>Reporting Manager :</b>
                                                                            <div class="input-group mb-3">
                                                                                <select class="form-control select2" name="rep_mngr_id" id="rep_mngr_id">
                                                                                    <option value=""> -- All -- </option>
                        <?php
//                                                            if ($ReportingManagerArr) {
//                                                                foreach ($ReportingManagerArr as $key => $roWs) {
//                                                                    
                        ?>
                                                                                            <option value="<?php // $roWs->rep_manager_id;     ?>"><?php // $roWs->userfullname;     ?> [ <?php // $roWs->employeeId;     ?> ] </option>
                                                                                            //<?php
//                                                                }
//                                                            }
                        ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-lg-2 col-md-6">
                                                                            <div class="mb-2">
                                                                                <b></b>
                                                                                <button style="margin-top: 20px;" type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>-->


                        
                        
                        <div class="card">
                            <div class="body">
							
                                <div class="table-responsive">
								<button onclick="downloadProjectMMExcel()" class="btn btn-info btn-sm pull-right ml-sm-2" title="View" >Excel-Download</button>
                                    <table id="table" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Project Name</th>
                                                <th> Action </th>
                                                <!--<th> Excel-Download </th>-->                                             
                                                
                                            </tr>
                                        </thead>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Project Name</th>
                                                <th> Action </th>   
                                                <!--<th> Excel-Download </th>-->                                            
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>


    <script type="text/javascript">
        var table;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
				"scrollY":'62vh',
             "scrollX": true,
                "ajax": {
                    "url": "<?php echo base_url('ajax_list_ceg_project_mm_report') ?>",
                    "type": "POST",
                    "data": function (data) {
//                        data.session_id = $('#session_id').val();
//                        data.rep_mngr_id = $('#rep_mngr_id').val();
					   data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';
                    },
                            // data:{[csrfName]: csrfHash}, 

                },
                "dom": 'lBfrtip',
                "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: ['copy','excel','csv','pdf','print']
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [
                    {
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });

            $('#btn-filter').click(function () { //button filter event click
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });
        });
		
		
		function downloadProjectMMExcel(projID) {
			// alert(projID)
            // selsector= $("#sectorinput").val();
			$('#pageloader').fadeIn();
            $.ajax({
                type: 'POST',
                url: '<?= base_url('Project_MM_excel_export_controller/projectMM_reportExcelDownload/'); ?>'+projID,
                data: function (data) {
                       // data.projID = projID;
                       data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                    },
                success: function (responData) {
					$('#pageloader').fadeOut();
					// alert(responData)
                    window.location=responData;
                },
            });
        }
	
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>