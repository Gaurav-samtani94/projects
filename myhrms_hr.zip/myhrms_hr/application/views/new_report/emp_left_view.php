<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Left Report</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
									<form method="post" action="<?= base_url('employee_left'); ?>" id="visitingcard_form">
                                                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>Business Unit :</b>
                                                        <div class="input-group mb-3">
                                                            
                                                           <select id="businessunit_name" name="businessunit_name" class="select floating form-control">
															<option value="" selected="selected"> Select Business </option>
															<?php 
															$all_businessunit = get_businessunits();
															if ($all_businessunit):
															foreach ($all_businessunit as $unitrow) {
															?>
															<option <?=(@$bus_unit == $unitrow->id)?"Selected":""?> value="<?= $unitrow->id; ?>"><?= $unitrow->unitname; ?></option>
															<?php
															}
															endif;
															 ?>
															</select>
                                                        </div>
                                                    </div>
													<div class="col-lg-3 col-md-6">
                                                        <b>Company Name :</b>
                                                        <div class="input-group mb-3">
                                                            
                                                           <select id="company_name" name="company_name" class="select floating form-control">
															<option value="" selected="selected">Select Company</option>
															<?php
															$all_company = get_companyname();
															if ($all_company):
															foreach ($all_company as $companyrow) {
															?>
															<option <?=(@$company == $companyrow->id)?"Selected":""?> value="<?= $companyrow->id; ?>"><?= $companyrow->company_name; ?></option>
															<?php
															}
															endif;
															?>
															</select>
                                                        </div>
                                                    </div>
													<div class="col-lg-3 col-md-6">
                                                        <b>Select Department :</b>
                                                        <div class="input-group mb-3">
                                                            
                                                           <select id="department_id" name="department_id" class="select floating form-control">
															<option value="" selected="selected"> Select Department </option>
															<?php
															$all_Activedepartment = get_departments();
															if ($all_Activedepartment):
															foreach ($all_Activedepartment as $deprow) {
															?>
															<option <?=(@$dpt == $deprow->id)?"Selected":""?> value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
															<?php
															}
															endif;
															?>
															</select>
                                                        </div>
                                                    </div>
													<div class="col-lg-3 col-md-6">
                                                        <b>Select Designation :</b>
                                                        <div class="input-group mb-3">
                                                            
                                                        <select id="potion_design_id" name="potion_design" class="select floating form-control">
														<option value=""> Select Designation </option>
														<?php
														$all_Activedesignation = get_designation();
														if ($all_Activedesignation):
														foreach ($all_Activedesignation as $desigrow) {
														?>
														<option <?=(@$design == $desigrow->id)?"Selected":""?> value="<?= $desigrow->id; ?>"><?= $desigrow->positionname; ?></option>
														<?php
														}
														endif;
														?>
														</select>
                                                        </div>
                                                    </div>
													
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>From Date (DOL) :</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" name="from_date" value="<?= @$from_date; ?>" class="form-control datetimepicker" id="from_date">
                                                        </div>
                                                    </div>
													
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>To Date (DOL) :</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" name="to_date" value="<?= @$to_date; ?>" class="form-control datetimepicker" id="to_date">
                                                        </div>
                                                    </div>
													
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>Employee Name :</b>
                                                        <div class="input-group mb-3">
														<input type="text" name="userfullname" value="<?= @$emp_name; ?>" class="form-control floating" id="userfullname">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mt-sm-2">
                                                            
															<input type="submit"  id="" value="Filter" name="filter" class="btn btn-one">
                                                       
															<input type="reset"  id="" value="Reset" name="submit" class="btn btn-success">
                                                        </div>
                                                    </div>
													
													
                                                </div>
                                        <!--</div> -->                               
                                        
										</form>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="card">
                            <div class="body">
							<div class="col-lg-4 col-md-6">
							<b>Select Year :</b>
							<div class="input-group mb-3">
							<form action="<?= base_url('employee_left'); ?>" method="POST">
							<select name="yearsel" class="form-control" onchange="this.form.submit()" id="yearsel">
							<!--<option>---Select Year---</option>-->
							<option>2020</option>
							<option>2019</option>
							<option>2018</option>
							<option>2017</option>
							</select>
							</form>
							</div>
							</div>
							<div id="columnchart_values" class="w-100"></div>
							</div>
						</div>
						<div class="card">
                            <div class="body">
							<div class="table-responsive bootstrapTable ">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                        <th>Emp Code</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>DOJ</th>
                        <th>Res. Type</th>
                        <th>Last Working Date</th>
                        <th>CTC Leav Time</th>
                        <th>IO</th>
                        <th>RO</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php  
                                            if ($leftEmpArr) {
                                                foreach ($leftEmpArr as $kEy => $data) { 
												 if (!empty($data->reviewing_officer_ro)) {
												$results = getUsernameByID($data->reviewing_officer_ro);
												$RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
											} else {
												$RO = '';
											}?>
                                                    <tr style="">
                                                        <td><?= $kEy + 1; ?></td>
														<td><?= ($data->employeeId) ? $data->employeeId : ""; ?></td>
                                                        <td><?= ($data->userfullname) ? $data->userfullname : ""; ?></td>
														<td><?= ($data->department_name) ? $data->department_name : ""; ?></td>
														<td><?= ($data->position_name) ? $data->position_name : ""; ?></td>
                                                        <td><?= ($data->date_of_joining) ? $data->date_of_joining : ""; ?></td>
                                                        
                                                        <td><?= ($data->emp_status_name) ? $data->emp_status_name : ""; ?></td>
                                                        <td><?= ($data->date_of_leaving) ? $data->date_of_leaving : ""; ?></td>
                                                        <td><?= ($data->empctc) ? $data->empctc : ""; ?></td>
                                                        <td><?= ($data->reporting_manager_name) ? $data->reporting_manager_name : ""; ?></td>
                                                        <td><?= $RO; ?></td> </tr>
                                                    <?php
											}
											}
											
											else {  ?>
                                                <tr>
                                                    <td style="color:red;text-align:center;" colspan="9"> Record Not Found.  </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                        <th>Emp Code</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>DOJ</th>
                        <th>Resignation Date</th>
                        <th>Res. Type</th>
                        <th>Last Working Date</th>
                        <th>CTC Leav Time</th>
                        <th>IO</th>
                        <th>RO</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
       
    </div>
	
<script type="text/javascript">
  document.getElementById('yearsel').value = "<?php echo $_POST['yearsel'];?>";
</script>
<!--<script type="text/javascript">
    var table;
    $(document).ready(function () {
        table = $('#table').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [],
            "ajax": {
                "url": "<?= base_url('ajax_list_empleftreport') ?>",
                "type": "POST",
                "data": function (data) {
                    data.userfullname = $('#userfullname').val();
                    data.businessunit_name = $('#businessunit_name').val();
                    data.company_name = $('#company_name').val();
                    data.department_id = $('#department_id').val();
                    data.potion_design_id = $('#potion_design_id').val();
                    data.from_date = $('#from_date').val();
                    data.to_date = $('#to_date').val();
                    
                },
            },
            "dom": 'lBfrtip',
            "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table);
        // $('#colvis').html(colvis.button());
        $('#btn-filter').click(function () {
            table.ajax.reload();
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });



</script>-->

</body>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">

google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "Emp left", { role: "style" } ],
		<?php if ($data1) { 
		foreach($data1 as $kKeY => $val): ?>
			[<?= "'".$kKeY."'"; ?>, <?= $val; ?>, "#b87333"],
		<?php endforeach; }?>
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Employee Left Details Yearwise",
        //width: 1000,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  } 
    </script>
	 <?php $this->load->view('admin/includes/footer'); ?>