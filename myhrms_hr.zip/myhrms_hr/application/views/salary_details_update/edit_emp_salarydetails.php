<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$currencyARR = getAllActiveCurrency();
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
						<div class="col-lg-4 col-md-4 col-sm-12"><br>
							<a style="margin:15px 15px 0 0" class="btn btn-primary pull-right" href="javascript:window.history.go(-1);">Back</a>
						</div>
                    </div>
                </div>
				
				<?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>
				
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
										<div class="body">
											<form action="<?= base_url('updateSalaryDetails');?>" method="POST">
											<div class="row clearfix">
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Salary Currency</b>
														<select class="form-control" name="sal_currency" data-placeholder="Select">
															<option value=""> -- Select -- </option>
															<?php foreach($currencyARR as $val):?>
																<option <?= ($list->id == $val->id) ? "Selected" : "";?> value="<?= $val->id;?>"> <?= $val->currencyname;?> </option>
															<?php endforeach;?>
														</select>
														   
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Pay Frequency</b>
														<select class="form-control" name="pay_freq" data-placeholder="Select">
															<option value=""> -- Select -- </option>
															<option value="1"> Day </option>
															<option value="2"> Monthly </option>
														</select>
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Gross Salary</b>
														<input type="text" name="gross_sal" value="<?= $list->salary;?>" class="form-control">
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Bank Name</b>
														<input type="text" name="bank_name" value="<?= ($list->bankname) ? $list->bankname : "";?>" class="form-control">
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<b>Account Holder Name</b>
													<input type="text" name="acc_holder" value="<?= ($list->accountholder_name) ? $list->accountholder_name : "";?>" class="form-control">
												</div>
												
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Branch name of Bank</b>
														<input type="text" name="bank_branch" value="<?= ($list->branchname) ? $list->branchname : "";?>" class="form-control">
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>IFSC Code</b>
														<input type="text" name="ifsc_code" value="<?= ($list->ifsc_code) ? $list->ifsc_code : "";?>"  id="" class="form-control">
													</div>
												</div>
												
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>PAN Number</b>
														<input name="pan_number" type="text" value="<?= ($list->pancard_no) ? $list->pancard_no : "--";?>" id="" class="form-control">
													</div>
												</div>
												
												<div class="col-lg-3 col-md-6">
													<div class="mb-3">
														<b>Account Number</b>
														<input name="acc_number" value="<?= ($list->accountnumber) ? $list->accountnumber : "";?>" type="number"  value="" id="" class="form-control">
														<input type="hidden" name="emp_id" value="<?= $this->uri->segment(2); ?>">
													</div>
												</div>
												<div class="col-lg-3 col-md-6">
													<b>Appraisal Due Date</b>
													<div class="input-group mb-3">
														<div class="input-group-prepend">
															<span class="input-group-text"><i class="icon-calendar"></i></span>
														</div>
														<input type="date" class="form-control date" value="<?= ($list->appraisalduedate) ? date('Y-m-d',strtotime($list->appraisalduedate)) : "";?>" name="appr_due_date" placeholder="Ex: dd/mm/YYYY">
													</div>
												</div>
												<br>
												<div class="col-lg-2 col-md-6">
													<div class="mb-2">
														<b>&nbsp;</b><br>
														<input type="submit" id="" class="btn btn-round btn-primary">
													</div>
												</div>
											</div>
											</form>
										</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--<div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Leave Type </th>
                                                <th>Reason</th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Days</th>
                                                <th>Applied On</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($myallAppliedLeaveRecArr) {
                                                foreach ($myallAppliedLeaveRecArr as $kEy => $dataRow) {   ?>
                                                    <tr style="<?= ($dataRow->leavetypeid == 5) ? "color:#bd2727" : ""; ?>">
                                                        <td><?= $kEy + 1; ?></td>
                                                        <td><?= ($dataRow->leavetype_name) ? $dataRow->leavetype_name : ""; ?></td>
                                                        <td><?= ($dataRow->reason) ? $dataRow->reason : ""; ?></td>
                                                        <td><?= ($dataRow->from_date) ? date("d-m-Y", strtotime($dataRow->from_date)) : ""; ?></td>
                                                        <td><?= ($dataRow->to_date) ? date("d-m-Y", strtotime($dataRow->to_date)) : ""; ?></td>
                                                        <td><?= ($dataRow->appliedleavescount) ? $dataRow->appliedleavescount : ""; ?></td>
                                                        <td><?= ($dataRow->createddate) ? date("d-m-Y", strtotime($dataRow->createddate)) : ""; ?></td>
                                                        <td><?= ($dataRow->leavestatus) ? $dataRow->leavestatus : ""; ?></td>
                                                        <td><i class="fa fa-eye"></i></td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {  ?>
                                                <tr>
                                                    <td style="color:red" colspan="9"> Record Not Found. </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Leave Type </th>
                                                <th>Reason</th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Days</th>
                                                <th>Applied On</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<script>
	// function emptyInputBox(name) {
		// alert("test")
	// }
</script>