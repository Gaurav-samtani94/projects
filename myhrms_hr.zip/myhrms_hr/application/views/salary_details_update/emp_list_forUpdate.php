<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$currencyARR = getAllActiveCurrency();
?>
<style>
    .table tbody tr td, .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }
    .req { color:red; }
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
				<?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        

                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table"  class="table table-bordered table-striped table-hover dataTable js-exportable" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Employee</th>
                                                <th>Business-Unit</th>
                                                <!--<th>Job-title</th>-->
                                                <th>Salary Currency</th>
                                                <th>Gross Sal</th>
                                                <th>Bank-Name</th>
                                                <th>Acc-Holder</th>
                                                <th>Bank-Branch</th>
                                                <th>IFSC Code</th>
                                                <th>Pan-No</th>
                                                <th>Acc-No</th>
                                                <th>Appr Due Date</th>
                                                <th>Update</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php $emplist = getEmpWithSalDetails();
										   if($emplist):
											foreach($emplist as $kEy=>$dataRow):?>
												
												<tr>
													<td><?= $kEy + 1; ?><a href="<?= base_url('updateAppr_relatedDetailsView/'.$dataRow->user_id);?>" class="btn btn-success" title="Appraisal Related Form"><i class="fa fa-refresh "></i></a></td>
													<td><?= ($dataRow->userfullname) ? $dataRow->userfullname : ""; ?></td>
													<td><?= ($dataRow->businessunit_name) ? $dataRow->businessunit_name : ""; ?></td>
													<!--<td><?= ($dataRow->jobtitle_name) ? $dataRow->jobtitle_name : ""; ?></td>-->
													<td><select style="width: 95px;" class="form-control" name="sal_currency" id="sal_currency_<?= $dataRow->empID;?>" data-placeholder="Select">
															<option value=""> -- Select -- </option>
															<?php foreach($currencyARR as $val):?>
																<option <?= ($dataRow->currencyid == $val->id) ? "Selected" : "";?> value="<?= $val->id;?>"> <?= $val->currencyname;?> </option>
															<?php endforeach;?>
														</select></td>
													
													<td><input style="width: 95px;" type="text" id="gross_sal_<?= $dataRow->empID;?>" name="gross_sal" value="<?= $dataRow->salary;?>" class="form-control"></td>
													<td><input style="width: 95px;" type="text" id="bank_name_<?= $dataRow->empID;?>" name="bank_name" value="<?= ($dataRow->bankname) ? $dataRow->bankname : "";?>" class="form-control"></td>
													<td><input style="width: 95px;" type="text" id="acc_holder_<?= $dataRow->empID;?>" name="acc_holder" value="<?= ($dataRow->accountholder_name) ? $dataRow->accountholder_name : "";?>" class="form-control"></td>
													<td><input style="width: 95px;" type="text" id="bank_branch_<?= $dataRow->empID;?>" name="bank_branch" value="<?= ($dataRow->branchname) ? $dataRow->branchname : "";?>" class="form-control"></td>
													<td><input style="width: 95px;" type="text" id="ifsc_code_<?= $dataRow->empID;?>" name="ifsc_code" value="<?= ($dataRow->ifsc_code) ? $dataRow->ifsc_code : "";?>"  id="" class="form-control"></td>
													<td><input style="width: 95px;" type="text" id="pan_number_<?= $dataRow->empID;?>" name="pan_number" value="<?= ($dataRow->pancard_no) ? $dataRow->pancard_no : "--";?>" id="" class="form-control"></td>
													<td><input style="width: 95px;" type="number" id="acc_number_<?= $dataRow->empID;?>" name="acc_number" value="<?= ($dataRow->accountnumber) ? $dataRow->accountnumber : "";?>"   value="" id="" class="form-control"></td>
													<td><input style="width: 150px;" type="date" id="appr_due_date_<?= $dataRow->empID;?>" class="form-control date" value="<?= ($dataRow->appraisalduedate) ? date('Y-m-d',strtotime($dataRow->appraisalduedate)) : "";?>" name="appr_due_date" placeholder="Ex: dd/mm/YYYY">
														<input type="hidden" class="form-control" name="userid" value="<?= $dataRow->empID;?>">
														<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
													</td>
													<td><span id="msg_<?= $dataRow->empID; ?>" class="alert alert-success" style="display:none;width:100px;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success ! </strong></span><span onclick="update_salaryDetails('<?= $dataRow->empID; ?>')" class="btn btn-info">Update</span></td>
													
													<!--<td><a href="<?= base_url('UpdateEmployee_salarydetails/'.$dataRow->empID);?>" class="btn btn-info">Update</a></td>-->
													<!--<td><a href="<?= base_url('updateAppr_relatedDetailsView/'.$dataRow->empID);?>" class="btn btn-success"><i class="fa fa-refresh "></i></a></td>-->
												</tr>
										   <?php endforeach; 
										    endif;?>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Employee</th>
                                                <th>Business-Unit</th>
                                                <!--<th>Job-title</th>-->
                                                <th>Salary Currency</th>
                                                <th>Gross Sal</th>
                                                <th>Bank-Name</th>
                                                <th>Acc-Holder</th>
                                                <th>Bank-Branch</th>
                                                <th>IFSC Code</th>
                                                <th>Pan-No</th>
                                                <th>Acc-No</th>
                                                <th>Appr Due Date</th>
                                                <th>Salary Details</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
		
    </div>
<script>
	function update_salaryDetails(userID) {
		var sal_currency = $('#sal_currency_' + userID).val();
		var gross_sal = $('#gross_sal_' + userID).val();
		var bank_name = $('#bank_name_' + userID).val();
		var acc_holder = $('#acc_holder_' + userID).val();
		var bank_branch = $('#bank_branch_' + userID).val();
		var ifsc_code = $('#ifsc_code_' + userID).val();
		var pan_number = $('#pan_number_' + userID).val();
		var acc_number = $('#acc_number_' + userID).val();
		var appr_due_date = $('#appr_due_date_' + userID).val();
		// alert(formId)
		
		// var tableId = $('table:visible').attr('id');
		// var data = $("#" + formId).serialize();
		// alert(data)
		$.ajax({
			type: 'GET',
			// url: "<?php echo base_url('Emp_sal_Controller/updateSalaryDetails'); ?>",
			url: "<?= base_url('Emp_sal_Controller/updateSalaryDetails?sal_currency='); ?>" + sal_currency + '&gross_sal=' + gross_sal + '&bank_name=' + bank_name + '&acc_holder=' + acc_holder + '&bank_branch=' + bank_branch + '&ifsc_code=' + ifsc_code + '&pan_number=' + pan_number + '&acc_number=' + acc_number + '&appr_due_date=' + appr_due_date+ '&userID=' + userID,
			// data: data,
			dataType: "json",
			success: function (responData) {
				// $('#alert').css('display', 'block');
				toastr.success(responData.msg, 'Message', {timeOut: 5000});
				// reloadDataTable(tableId);
				// alert("test")
				// $('#msg_' + userID).show();
				// $('#msg_' + userID).html('Updated! Record successfully').fadeOut(5000);
				// location.reload();
			}
		});
	}
</script>
</body>
<?php $this->load->view('admin/includes/footer'); ?>