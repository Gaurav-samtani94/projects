<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
						<div class="col-lg-4 col-md-4 col-sm-12"><br>
							<a style="margin:15px 15px 0 0" class="btn btn-primary pull-right" href="javascript:window.history.go(-1);">Back</a>
						</div>
                    </div>
                </div>
				<?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>
				<form action="<?= base_url('update_appr_related_details1');?>" method="POST">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <div class="card-header" id="headingOne">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    Salary Head :
                                                </button>
                                            </h5>
                                        </div> 
										<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">

                                            <div class="body">
                                                <div class="row clearfix">
													<div class="col-lg-3 col-md-6">
                                                        <b>Appraisal Due Date </b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" name="appr_due_date" value="<?= ($list->appraisal_datemmyy) ? date('Y-m-d',strtotime($list->appraisal_datemmyy)) : "";?>" class="form-control date" placeholder="Ex: dd/mm/YYYY">
                                                        </div>
                                                    </div>
													
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Basic Salary : </b>
                                                            <input type="text" class="form-control" value="<?= $list->basicsalary;?>" name="basic_sal" >    
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>HRA </b>
                                                            <input type="text" name="hra" value="<?= $list->emp_hra;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Educational Allowance : </b>
                                                            <input type="text" name="educational_allow"  value="<?= $list->education_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Telephone Allowance :  </b>
                                                            <input type="text" name="teleph_allow" value="<?= $list->tele_empsal_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Medical Allowance : </b>
                                                            <input type="text" name="medical_allow" value="<?= $list->medical_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Transportation Allowance  : </b>
                                                            <input type="text" name="transport_allow" value="<?= $list->transportation_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Special Allowance  : </b>
                                                            <input type="text" name="spcl_allow" value="<?= $list->special_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Project Allowance : </b>
                                                            <input type="text" name="project_allow" value="<?= $list->project_allowance;?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Bonus (Adv) : </b>
                                                            <input type="text" name="bonus_adv" value="<?= ($list->bonus_adv) ? $list->bonus_adv : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                   <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Other : </b>
                                                            <input type="text" name="salery_head_other" value="<?= ($list->sal_other) ? $list->sal_other : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                        </div>
										<!--//========================================================================= -->
										<br>
										<div class="card-header" id="headingTwo">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                                    Gross Salary :
                                                </button>
                                            </h5>
                                        </div>
										<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                            
                                            <div class="body">
                                                <div class="row clearfix">
                                                     <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Statutory deductions : </b>
                                                            <input type="text" class="form-control" value="<?= ($list->statutory_deduct) ? $list->statutory_deduct : "0";?>" name="statutory_deduct" >    
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Employer's Contribution to PF </b>
                                                            <input type="text" name="contribut_pf" value="<?= ($list->empepf) ? $list->empepf : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Employer's Contribution to ESI : </b>
                                                            <input type="text" name="contribut_esi" value="<?= ($list->emp_esi) ? $list->emp_esi : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Gratuity  :  </b>
                                                            <input type="text" name="gratuity" value="<?= ($list->emp_gratuity) ? $list->emp_gratuity : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>GPAI  : </b>
                                                            <input type="text" name="gpai" value="<?= ($list->emp_sal_gpai) ? $list->emp_sal_gpai : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Assured Loyalty Bonus   : </b>
                                                            <input type="text" name="loyalty_bonus" value="<?= ($list->loyaltybonus) ? $list->loyaltybonus : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Project compilation Bonus : </b>
                                                            <input type="text" name="project_compl_bonus" value="<?= ($list->projectcomp_bonus) ? $list->projectcomp_bonus : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>MediClaim  : </b>
                                                            <input type="text" name="medi_clain" value="<?= ($list->grosssal_mediclaim) ? $list->grosssal_mediclaim : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>CTC : </b>
                                                            <input type="text" name="ctc" value="<?= ($list->empctc) ? $list->empctc : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                   <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Other : </b>
                                                            <input type="text" name="gross_sal_other" value="<?= ($list->grosssal_other) ? $list->grosssal_other : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										
										<!--//========================================================================= -->
										<br>
										<div class="card-header" id="headingThree">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                                                    Additional / Reimbursement :-
                                                </button>
                                            </h5>
                                        </div>
										<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                            
                                            <div class="body">
                                                <div class="row clearfix">
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>P1 :</b>
                                                            <input type="text" class="form-control" value="<?= ($list->empctcp1) ? $list->empctcp1 : "0";?>" name="p1" >    
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>P2 : </b>
                                                            <input type="text" name="p2" value="<?= ($list->empctcp2) ? $list->empctcp2 : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Driver Wagers  : </b>
                                                            <input type="text" class="form-control" value="<?= ($list->driver_wagers) ? $list->driver_wagers : "0";?>" name="driver_wagers" >    
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Vehicle Agreement  </b>
                                                            <input type="text" name="vehicle_agreement" value="<?= ($list->vehicle_agreement) ? $list->vehicle_agreement : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Fuel Expenses  : </b>
                                                            <input type="text" name="fuel_exp" value="<?= ($list->fuel_expenses) ? $list->fuel_expenses : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Food Expenses :  </b>
                                                            <input type="text" name="food_exp" value="<?= ($list->food_expenses) ? $list->food_expenses : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Leave Travel Allowance   : </b>
                                                            <input type="text" name="leave_travel_allow" value="<?= ($list->leave_travel_allowance) ? $list->leave_travel_allowance : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>PCB (Employer's) : </b>
                                                            <input type="text" name="emp_pcb" value="<?= ($list->pcb_employer) ? $list->pcb_employer : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                   <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Other : </b>
                                                            <input type="text" name="Reimbursement_other" value="<?= ($list->salsec_other) ? $list->salsec_other : "0";?>" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										<!--//========================================================================= -->
										<br>
										<div class="card-header" id="headingFour">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                                                    Other :-
                                                </button>
                                            </h5>
                                        </div>                                
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                            
                                            <div class="body">
                                                <div class="row clearfix">
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Increment Amount :</b>
                                                            <input type="text" value="<?= ($list->increment_amnt) ? $list->increment_amnt : "0";?>" class="form-control" name="increment_amt">    
															<input type="hidden" name="emp_id" value="<?= $this->uri->segment(2); ?>">
															<input type="hidden" name="fld_id" value="<?= $list->id; ?>">
														</div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mb-3">
                                                            <b>Rating</b>
                                                            <input type="text" value="<?= $list->salsec_other;?>" name="rating" class="form-control">
                                                        </div>
                                                    </div>
                                                   
                                                    <!--<div class="col-lg-2 col-md-6">
                                                        <div class="mb-2">
                                                            <b>&nbsp;</b>
                                                            <input type="submit"  class="btn btn-round btn-primary">
                                                        </div>
                                                    </div>-->
                                                </div>
                                            </div>
                                        </div>
										
										
										
										
                                    </div>
                                </div><br>
								<input type="submit" value="Update" class="btn btn-round btn-primary">
                            </div>
                        </div>
						
                        
                    </div>
                </div>
				</form>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>