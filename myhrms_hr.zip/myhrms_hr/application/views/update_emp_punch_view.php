<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
<div class="row clearfix">
                    <div class="col-lg-12">
						<div class="card">
                         <!--<div class="header">
                           <form id="form-filter"> 
                         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <div class="row clearfix">
													<div class="col-lg-3 col-md-6">
                                                        <b>Department :</b>
                                                        <div class="input-group mb-3">
                                                          <select id="department_id" class="select floating form-control">
															<option value="" selected="selected"> Select Department </option>
															<?php
															$all_Activedepartment = get_departments();
															if ($all_Activedepartment):
															foreach ($all_Activedepartment as $deprow) {
															?>
															<option value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
															<?php
															}
															endif;
															?>
															</select>
                                                        </div>
                                                    </div>
													
													
                                                   
                                                    <div class="col-lg-1 col-md-6">
                                                        <div class="mb-2">
                                                            <b></b>
															<button type="button" id="btn-filter" class="btn btn-success btn-block" style="margin-top:20px;"> Filter </button>
                                                        </div>
                                                    </div>
													<div class="col-lg-1 col-md-6">
                                                        
														<div class="mb-2">
                                                            <b></b>
															<button type="button" id="btn-reset" class="btn btn-primary btn-block" style="margin-top:20px;"> Reset </button>
                                                        </div>
                                                    </div>
													
													
													
                                                </div>                          
                                        
										</form> 
										
								
                        </div>-->
						<div class="body">
							
							<ul class="nav nav-tabs-new">
								<li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#all-new">In-Out Time</a></li>
                                <!--<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Home-new">Out Time</a></li>-->
                                
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane show active" id="all-new">
                                    <div class="table-responsive">
								 <table id="table" class="table table-striped display" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sr. No</th>
											<th>Emp Code</th>
											<th>Emp Name</th>
											<th>Department</th>
											<th>In Time</th>
											<th>MachineID</th>
											<th>Action</th>
										</tr> 
									</thead>
									<tbody>
									</tbody>
									<tfoot>
										<tr>
											<th>Sr. No</th>
											<th>Emp Code</th>
											<th>Emp Name</th>
											<th>Department</th>
											<th>In Time</th>
											<th>MachineID</th>
											<th>Action</th>
										</tr> 
									</tfoot>
									</table>
                            </div>
                            </div>
								<div class="tab-pane" id="Home-new">
                                    <div class="table-responsive">
									<table id="table1" class="table table-striped display" cellspacing="0" width="100%">
									<thead>
										<tr>
											<th>Sr. No</th>
											<th>Emp Code</th>
											<th>Emp Name</th>
											<th>Department</th>
											<th>Out Time</th>
											<th>MachineID</th>
											<th>Action</th>
										</tr> 
									</thead>
									<tbody>
									</tbody>
									<tfoot>
										<tr>
											<th>Sr. No</th>
											<th>Emp Code</th>
											<th>Emp Name</th>
											<th>Department</th>
											<th>Out Time</th>
											<th>MachineID</th>
											<th>Action</th>
										</tr> 
									</tfoot>
									</table>
                            </div>
                                </div>
                                
                            </div>
							<!--  ===============  -->
                                
								
                           
                        </div>
                    </div>
					</div>
				</div>
</div>
                </div>
            </div>
			<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
    </body>
<script type="text/javascript">
    var table;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "ajax": {
                "url": "<?php echo base_url('ajax_update_punch_report'); ?>",
                "type": "POST",
                "data": function (data) {
                    data.department_id = $('#department_id').val();
                    
                },
                        data:{[csrfName]: csrfHash}, 
            },
            "dom": 'lBfrtip',
            "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
		//new $.fn.dataTable.FixedHeader( table );
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
	
	//==========For Out Time ====================//
	var table1;
    $(document).ready(function () {
     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table1').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "ajax": {
                "url": "<?php echo base_url('ajax_update_outPunch_report'); ?>",
                "type": "POST",
                "data": function (data) {
                    data.department_id = $('#department_id').val();
                    
                },
                        data:{[csrfName]: csrfHash}, 
            },
            "dom": 'lBfrtip',
            "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
		//new $.fn.dataTable.FixedHeader( table );
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
    
    
    
</script>
<script>
    function update_punch_time(emplid)
    {
		// alert(emplid)
        var In_time = $('#Intime_' + emplid).val();
        var Out_time = $('#Outtime_' + emplid).val();
        var machine_id = $('#machine_' + emplid).val();
		// alert(machine_id)
		// alert(Out_time)
        $.ajax({
            url: "<?php echo base_url('Update_emp_punchController/updateInTime?empid='); ?>" + emplid + '&In_time=' + In_time + '&Out_time=' + Out_time+ '&machine_id=' + machine_id,
            type: "GET",
            dataType: 'json',
            success: function (response) {
                $('#msg_' + emplid).show();
                $('#msg_' + emplid).html('Updated! Record successfully').fadeOut('30000');
            }
           
        });
    }
	
	function update_punchOut_time(emplid)
    {
		// alert(emplid)
        var Out_time = $('#Outtime_' + emplid).val();
        var machine_id = $('#machine_' + emplid).val();
		// alert(machine_id)
		// alert(Out_time)
        $.ajax({
            url: "<?php echo base_url('Update_emp_punchController/updateOutTime?empid='); ?>" + emplid +  '&Out_time=' + Out_time+ '&machine_id=' + machine_id,
            type: "GET",
            dataType: 'json',
            success: function (response) {
                $('#msgs_' + emplid).show();
                $('#msgs_' + emplid).html('Updated! Record successfully').fadeOut('30000');
            }
            
        });
    }
</script>
<?php $this->load->view('admin/includes/footer'); ?>

