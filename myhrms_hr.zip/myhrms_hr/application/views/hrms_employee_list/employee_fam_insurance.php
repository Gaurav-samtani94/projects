<?php
    $this->load->view('admin/includes/head');
    $this->load->view('admin/includes/header');
?>
<style>
    .table tbody tr td,
    .table tbody th td {
        vertical-align: middle !important;
        white-space: normal !important;
    }
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                               
                                <h4> Family Member Insured </h4>
                                <hr>


                                <div class="table-responsive table-dataTables_length">
                                    <table id="table_active" class="table table-striped display nowrap table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th width="40%">EMP CODE</th>
                                                <th>EMPLOYEE NAME</th>
                                                <th width="5%">FAMILY MEMBER NAME</th>
                                                <th>RELATIONSHIP WITH MEMBER</th>
                                                <th>DOB OF MEMBER</th>
                                                <th>GENDER OF MEMBER</th>
                                                <!-- <th>Action</th> -->
                                            </tr>
                                        </thead>

                                        <tbody>
                                            
                                        </tbody>

                                        <!-- <tfoot>
                                            <tr>
                                                <th>S.No.</th>
                                                <th width="40%">Emp Name</th>
                                                <th>Mobile</th>
                                                <th width="5%">Email</th>
                                                <th>Department Name</th>
                                                <th>Bussiness Unit</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot> -->
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

<script type="text/javascript">

    var table_active;
    $(document).ready(function() {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table_active = $('#table_active').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [],
            "scrollY": '62vh',
            "scrollX": true,
            "ajax": {
                "url": "<?= base_url('Hrms_emp_fam_insurance_Controller/ajax_employee_list') ?>",
                "type": "POST"
            },
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ]
            }],
            //Set column definition initialisation properties.
            "columnDefs": [{
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            }, ],
            "aLengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
        });
        //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('.btn-filter').click(function() { //button filter event click
            table_active.ajax.reload(); //just reload table
        });
        $('#btn-reset').click(function() { //button reset event click
            $('#form-filter')[0].reset();
            table_active.ajax.reload(); //just reload table
        });
    });

</script>

<script>
    $(document).ready(function() {
        var table = $('#employeeTable').DataTable();
        $("#all").trigger('click');
    });
</script>
<?php $this->load->view('admin/includes/footer'); ?>