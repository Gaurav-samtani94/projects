<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
.table tbody tr td,
.table tbody th td {
    vertical-align: middle !important;
    white-space: normal !important;
}
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">

                                <form action="<?= base_url('FetchEmp_ReportData'); ?>" method="POST">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                <label class="text-muted">Business Unit : <span
                                                        id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control show-tick ms select2" name="business_unit"
                                                    id="business_unit" onchange="setAllDeptByBunit()"
                                                    data-placeholder="Select" required>
                                                    <option
                                                        <?= set_select('business_unit', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select Business Unit -- </option>
                                                    <?php
                                                    if ($busineess_unit) {
                                                        foreach ($busineess_unit as $keyy => $recD) {
                                                    ?>
                                                    <option
                                                        <?= set_select('business_unit', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <label for="">Department</label>
                                            <select id="department" name="department_id" onchange="set_subdepartment()"
                                                class="form-control">
                                                <option>-- Select Department --</option>

                                            </select>
                                        </div>
                                        <!-- sub department -->
                                        <div class="col-md-3">
                                            <label for="">Sub Department</label>
                                            <select id="subdepartment" name="subdepartment"
                                                onchange="setRepManagerByBunit()" class="form-control">
                                                <option>-- Select Sub Department --</option>

                                            </select>
                                        </div>
                                        <!-- end code sub department -->
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reporting_manager"><?= form_error('reporting_manager'); ?></span>
                                                <label class="text-muted">Reporting Manager (IO) : <span
                                                        id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control show-tick ms select2" name="reporting_manager"
                                                    id="reporting_manager" onchange="setEmployee()"
                                                    data-placeholder="Select">
                                                    <option
                                                        <?= set_select('reporting_manager', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select Reporting Manager -- </option>
                                                    <?php
                                                    if (set_value('reporting_manager')) {
                                                        @$reportngmngrArr = GetAllRepManagerByBUnit(set_value('business_unit'));
                                                        if (@$reportngmngrArr) {
                                                            foreach (@$reportngmngrArr as $rePmngr) {
                                                    ?>
                                                    <option
                                                        <?= set_select('reporting_manager', $rePmngr->user_id, (!empty($data) && $data == $rePmngr->user_id ? TRUE : FALSE)); ?>
                                                        value="<?= $rePmngr->user_id; ?>">
                                                        <?= $rePmngr->userfullname . " [" . $rePmngr->employeeId . "] "; ?>
                                                    </option>
                                                    <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">Employee</label>
                                            <select class="form-control" name="Employe_id" id="employe">
                                                <option>-- Select Employee --</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">Employee</label>
                                            <select class="form-control" name="EmployeActive_Inactive"
                                                id="EmployeActive_Inactive">
                                                <option value="A">-- Select Status --</option>
                                                <option value="1">Active</option>
                                                <option value="0">In-Active</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <br> <input class="btn btn-one" type="submit" value="Submit">
                                        </div>
                                    </div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
function setEmployee() {
    var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    var bunitID = $("#business_unit").val();
    var department_id = $('#department').val();
    var reporting_manager = $('#reporting_manager').val();
    $('#employe').html('');

    if (bunitID) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('set_employee'); ?>',
            data: {
                [csrfName]: csrfHash,
                'bunitid': bunitID,
                'department_id': department_id,
                'reporting_manager': reporting_manager
            },
            success: function(response) {
                var data = jQuery.parseJSON(response);
                $('#employe').append('<option value="">--Select Employe -- </option>');

                if (data) {
                    $.each(data, function(index, val) {
                        $('#employe').append('<option value="' + val.user_id + '">' + val
                            .userfullname + ' [' + val.employeeId + '] </option>');
                    });
                }
            },

        });
    }
}

function set_subdepartment() {
    $("#subdepartment").html('');
    var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    var bunitID = $("#business_unit").val();
    var department_id = $('#department').val();
    // $('#reporting_manager').html('');
    // $('#reporting_manager').val('');
    // $('#reporting_manager').trigger("change");

    if (bunitID) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('set_subdepartment'); ?>',
            data: {
                [csrfName]: csrfHash,
                'bunitid': bunitID,
                'department_id': department_id
            },
            success: function(response) {

                var data = jQuery.parseJSON(response);
                $('#subdepartment').append('<option value="">--Select Sub Department -- </option>');
                if (data) {
                    $.each(data, function(index, val) {
                        $('#subdepartment').append('<option value="' + val.id + '">' + val
                            .subdepartment + '</option>');
                    });
                } else {
                    // $('#reporting_manager').append('<option value="">--Select Reporting Manager -- </option>');
                    // $('#reporting_manager').html('');
                    // $('#reporting_manager').val('');
                }
            },

        });
    }
}

function setRepManagerByBunit() { //reporting manager comes
    var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    var bunitID = $("#business_unit").val();
    var department_id = $('#department').val();
    // alert(department_id);
    $('#reporting_manager').html('');
    $('#reporting_manager').val('');
    $('#reporting_manager').trigger("change");

    if (bunitID) {
        $.ajax({
            type: 'POST',
            url: '<?= base_url('set_reportingmanager_bybunit_dropd'); ?>',
            data: {
                [csrfName]: csrfHash,
                'bunitid': bunitID,
                'department_id': department_id
            },
            success: function(response) {
                var data = jQuery.parseJSON(response);
                $('#reporting_manager').append('<option value="">--Select Reporting Manager -- </option>');
                if (data) {
                    $.each(data, function(index, val) {
                        $('#reporting_manager').append('<option value="' + val.user + '">' + val
                            .userfull + ' [' + val.emp + '] </option>');
                    });
                } else {
                    $('#reporting_manager').append(
                        '<option value="">--Select Reporting Manager -- </option>');
                    $('#reporting_manager').html('');
                    $('#reporting_manager').val('');
                }
            },

        });
    }
}

function setAllDeptByBunit() { //department comes
    // alert('hi');
    // $('#department').html();
    $('#department').val();
    $('#department').html('');
    $('#reporting_manager').html('');
    var bunitID = $("#business_unit").val();
    //  alert(bunitID);
    var csrfName = '<?= $this->security->get_csrf_token_name() ?>'
    var csrfHash = '<?= $this->security->get_csrf_hash() ?>'
    if (bunitID == '') {
        $('#department').html();
        $('')
    } else {


        // $('#department').val('');
        // $('#department').trigger("change");

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_department_bybunit_dropd_ajax') ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $('#department').append('<option value="">-- Select Department --</option>');
                        $.each(data, function(index, val) {
                            $('#department').append('<option value="' + val.id + '">' + val
                                .deptname + '</option>');
                        });
                    } else {
                        $('#department').html();
                    }
                },
            });
        }
    }
}
</script>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->
<?php $this->load->view('admin/includes/footer'); ?>