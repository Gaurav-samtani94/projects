<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
.table tbody tr td,
.table tbody th td {
	vertical-align: middle !important;
	white-space: normal !important;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= isset($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= isset($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="body">
                                <form id="form-filter"> 
							    <input type="hidden" id="isactive" value="1" class="form-control">
								
								<button type="button" id="" onclick="showActive('1')" class="btn btn-sm btn-success btn-filter active">Active</button>
								<button type="button" onclick="showInActive('5')" class="btn btn-sm btn-danger btn-filter">In-Active</button>
                                <button type="button" id="" onclick="showAll()" class="btn btn-sm btn-default btn-filter">All</button>

                                <a href="<?= base_url('employee_add'); ?>" class="btn btn-sm btn-one btn-filter float-right"><i class="fa fa-user"></i> Add New </a>
   &nbsp;&nbsp; <a href="<?= base_url('Fetch_Employee_Report'); ?>" class="btn btn-sm btn-one btn-filter float-right mr-2"><i class="fa fa-user"></i> Fetch Report</a>
								
</form>
                                
								
								<hr>
                                
                               
                                <div class="table-responsive">
                                    <table  id="table_active" class="table table-striped display nowrap table-bordered table-hover"> 
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Emp Name</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>Department Name</th>
                                                <th>Bussiness Unit</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php /*
                                            if ($Hr_EmpDetailsArr) {
                                                $i = 1;
                                                foreach ($Hr_EmpDetailsArr as $kEy => $dataRow) {

                                                    $image1 = '<img src="' . HOSTNAME . "public/uploads/profile/profile_pic.png" . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
                                                    if ($dataRow->profileimg) {
                                                        $image = '';
                                                        // $image = EMPLPROFILE;
                                                        $image .= isset($dataRow->profileimg) ? $dataRow->profileimg : '';
                                                        $imageCr = str_replace("index.php/", "", $image);
                                                        $image1 = '<img src="' . EMPLPROFILE . $imageCr . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
                                                    }
                                                    ?>
                                                    <tr data-status="<?php
                                                    $employeeStatus = $dataRow->isactive ? $dataRow->isactive : '0';
                                                    echo $employeeStatus;
                                                    ?>">
                                                        <td><?= $i; ?></td>
                                                        <td>
                                                            <p class="c_name"><?= isset($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '' ?></p>
                                                        </td>
                                                        <td><?= ($dataRow->contactnumber) ? $dataRow->contactnumber : ""; ?></td>
                                                        <td><?= ($dataRow->emailaddress) ? $dataRow->emailaddress : ""; ?></td>
                                                        <td><?= ($dataRow->department_name) ? $dataRow->department_name : ""; ?></td>
                                                        <td><?= ($dataRow->businessunit_name) ? $dataRow->businessunit_name : ""; ?></td>
                                                        <td>
                                                            <!--<span class="badge badge-default m-l-10 hidden-sm-down">-->
															<?php
                                                                if ($employeeStatus == "0") {
                                                                    echo "<span class='btn btn-danger'>Inactive</span>";
                                                                } elseif ($employeeStatus == "1") {
                                                                    echo "<span class='btn btn-success'>Active</span>";
                                                                } elseif ($employeeStatus == "2") {
                                                                    echo "<span class='btn btn-danger'>Resigned</span>";
                                                                } elseif ($employeeStatus == "3") {
                                                                    echo "<span class='btn btn-info'>Left</span>";
                                                                } elseif ($employeeStatus == "4") {
                                                                    echo "<span class='btn btn-info'>Suspended</span>";
                                                                }
                                                                ?>
                                                            </span>
                                                        </td>

                                                        <td style="display:flex;flex-direction: row-reverse;">
                                                            <a href="<?= base_url("pdfgenerate/".$dataRow->user_id); ?>" class="btn btn-info" target="_blank" title="Download"><i class="fa fa-download"></i></a>&ensp;
                                                            <a href="<?= base_url("employee_edit/".$dataRow->user_id); ?>" class="btn btn-info" title="Edit"><i class="fa fa-edit"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                            } else {  ?>
                                                <tr>
                                                    <td style="color:red" colspan="8"> Record Not Found. </td>
                                                </tr>
                                            <?php } */?>
                                        </tbody>

                                        <!-- <tfoot>
                                            <tr>
                                                <th>S.No.</th>
                                                <th width="40%">Emp Name</th>
                                                <th>Mobile</th>
                                                <th width="5%">Email</th>
                                                <th>Department Name</th>
                                                <th>Bussiness Unit</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot> -->
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>	
    </div>
</body>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
<script type="text/javascript">
	
function showActive(value) {
	// alert("new")
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showInActive(value) {
	$("#isactive").empty();
	$("#isactive").val(value);
	table_active.ajax.reload(); 
}
function showAll() {
	$("#isactive").empty();
	$("#isactive").val('');
	table_active.ajax.reload(); 
}


    var table_active;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                table_active = $('#table_active').DataTable({
                    "autoWidth": false,
                    "processing": true, //Feature control the processing indicator.
                   // "serverSide": true, //Feature control DataTables' server-side processing mode.
                    "order": [],
					"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('Hrms_emp_list_Controlller/ajax_employee_list') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.isactive = $('#isactive').val();
                            // data.company_name = $('#company_name').val();
                            // data.userfullname = $('#userfullname').val();
                            // data.employeeId = $('#employeeId').val();
                            // data.designation_name = $('#designation_name').val();
                            // data.department_name = $('#department_name').val();
                            // data.project_name = $('#project_name').val();
                            // data.status_type = $('#status_type').val();
                            // data.is_active = 1;
							data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';					
                        },
                                // data:{[csrfName]: csrfHash}, 

                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0,2,3,4,5,6,7], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                //  var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('.btn-filter').click(function () { //button filter event click
                    table_active.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table_active.ajax.reload();  //just reload table
                });
    });

</script> 
<script>
    $(document).ready(function () {
        var table = $('#employeeTable').DataTable();
        $("#all").trigger('click');
    });
</script>
<?php $this->load->view('admin/includes/footer'); ?>
 
