<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <form id="form-filter">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <!--<div class="card-header" id="headingOne">-->
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-6">
                                            <lable>Date :</lable>
                                            <div class="input-group mb-3">
                                                <input type="date" class="form-control" value="<?= date('Y-m-d', strtotime('-1 day')) ?>" id="atten_report">

                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <lable>Job Title :</lable>
                                            <div class="input-group mb-3">
                                                <select id="atten_jobtitle" class="form-control">
                                                    <option value="">Select Jobtitle</option>
                                                    <?php
                                                    if (@$jobtitle) {
                                                        foreach ($jobtitle as $jobtitleRow) {
                                                            ?>
                                                            <option value="<?= $jobtitleRow->id; ?>"><?= $jobtitleRow->jobtitlename; ?></option>
                                                        <?php }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <lable>Business Title :</lable>
                                            <div class="input-group mb-3">
                                                <select id="atten_busintitle" class="form-control">
                                                    <option value="">Select Business Unit</option>
                                                    <?php
                                                    if (@$business_title) {
                                                        foreach ($business_title as $bustitleRow) {
                                                            ?>
                                                            <option value="<?= $bustitleRow->id; ?>"><?= $bustitleRow->unitname; ?></option>
                                                        <?php }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>



                                        <div class="col-lg-3 col-md-6">
                                            <div class="mb-3 mt-3 pt-1 mt-xs-0 pt-xs-0 mb-xs-0">
                                                <button type="button" id="btn-filter" class="btn btn-one"> Filter </button>
                                                <button type="button" id="btn-reset" class="btn btn-success" > Reset </button>
                                            </div>
                                        </div>



                                    </div>
                                    <!--</div> -->                               

                                </form>


                            </div>
                            <div class="body pt-0">
                                <ul class="nav nav-tabs-new">
                                    <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#all-new">9:30AM - 9:35 AM</a></li>
                                    <li class="nav-item ml-2"><a class="nav-link" data-toggle="tab" href="#Home-new">9:35AM - 9:45 AM</a></li>
                                    <li class="nav-item ml-2"><a class="nav-link" data-toggle="tab" href="#Profile-new">After 9:45</a></li>
                                    <li class="nav-item ml-2"><a class="nav-link" data-toggle="tab" href="#Contact-new">All</a></li>

                                </ul>
                                <div class="tab-content mt-2">
                                    <div class="tab-pane show active" id="all-new">
								<div class="table-responsive table-dataTables_length">
                                            <table id="table" class="table table-striped display nowrap table-bordered table-hover" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </thead>
                                                <tbody>
                                                </tbody>
                                                <!-- <tfoot>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </tfoot> -->
                                            </table>
                                    </div>
                                    <div class="tab-pane" id="Home-new">
                                        <div class="table-responsive table-dataTables_length">
                                            <table id="table1" class="table table-striped display nowrap table-bordered table-hover" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </thead>
                                                <tbody>
                                                </tbody>
                                                <!-- <tfoot>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </tfoot> -->
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="Profile-new">
                                        <div class="table-responsive table-dataTables_length">
                                            <table id="table2" class="table table-striped display nowrap table-bordered table-hover" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </thead>
                                                <tbody>
                                                </tbody>
                                                <!-- <tfoot>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Emp Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Location</th>
                                                        <th>Time</th>
                                                        <th>Date</th>
                                                    </tr> 
                                                </tfoot> -->
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

</body>
<script type="text/javascript">
    var table;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "scrollY":'60vh',
            "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('ajax_attendance_report_list'); ?>",
                "type": "POST",
                "data": function (data) {
                    data.atten_report = $('#atten_report').val();
                    data.atten_jobtitle = $('#atten_jobtitle').val();
                    data.atten_busintitle = $('#atten_busintitle').val();
                },
                        data:{[csrfName]: csrfHash}, 

            },
            "dom": 'lBfrtip',
            "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        //new $.fn.dataTable.FixedHeader( table );
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });

    var table1;
    $(document).ready(function () {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        //datatables
        table1 = $('#table1').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "scrollY":'60vh',
            "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('ajax_attendance_report_leave_list') ?>",
                "type": "POST",
                "data": function (data) {
                    data.atten_report = $('#atten_report').val();
                    data.atten_jobtitle = $('#atten_jobtitle').val();
                    data.atten_busintitle = $('#atten_busintitle').val();
                },
                        data:{[csrfName]: csrfHash},
            },

            "dom": 'lBfrtip',
            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
            ],

            "columnDefs": [{"targets": [0], "orderable": false}],

            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
        // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table1.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table1.ajax.reload();  //just reload table
        });
    });

    var table2;
    $(document).ready(function () {
     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        //datatables
        table2 = $('#table2').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "scrollY":'60vh',
            "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('ajax_attendance_report_tour_list') ?>",
                "type": "POST",
                "data": function (data) {
                    data.atten_report = $('#atten_report').val();
                    data.atten_jobtitle = $('#atten_jobtitle').val();
                    data.atten_busintitle = $('#atten_busintitle').val();
                },
                        data:{[csrfName]: csrfHash}, 


            },

            "dom": 'lBfrtip',
            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
            ],

            "columnDefs": [{"targets": [0], "orderable": false}],

            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis2 = new $.fn.dataTable.ColVis(table2); //initial colvis
        // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table2.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table2.ajax.reload();  //just reload table
        });
    });

    var table3;
    $(document).ready(function () {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        //datatables
        table3 = $('#table3').DataTable({
            "processing": true,
            "serverSide": true,
            "pageLength": -1,
            "order": [],
            "scrollY":'60vh',
            "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('attendance_report/attendancereport/ajax_attendance_report_list_all') ?>",
                "type": "POST",
                "data": function (data) {
                    data.atten_report = $('#atten_report').val();
                    data.atten_jobtitle = $('#atten_jobtitle').val();
                    data.atten_busintitle = $('#atten_busintitle').val();
                },
              data:{[csrfName]: csrfHash}, 



            },

            "dom": 'lBfrtip',
            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
            ],

            "columnDefs": [{"targets": [0], "orderable": false}],

            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis2 = new $.fn.dataTable.ColVis(table3); //initial colvis
        // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table3.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table3.ajax.reload();  //just reload table
        });
    });

</script>
<?php $this->load->view('admin/includes/footer'); ?>

