<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
$this->load->view("back_end/includes/footer");
$login_user_id = $this->session->userdata('user_id');
?>
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/jquery.dataTables.min.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/dataTables.colVis.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/buttons.dataTables.min.css' ?>" rel="stylesheet">
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <h4 class="page-title">Attendance Report</h4>
            </div>
        </div>  
        <br/>



        <form id="form-filter"> 
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <div class="row filter-row">


                <div class="col-sm-3 col-xs-6">
                    <div class="form-group">
                        <label for="control-label"> Date : </label>
                        <input type="date" class="form-control" value="<?= date('Y-m-d', strtotime('-1 day')) ?>" id="atten_report">
                    </div>
                </div>  

                <div class="col-sm-3 col-xs-6">
                    <div class="form-group">
                        <label for="control-label">Job Title : </label>
                        <select id="atten_jobtitle" class="form-control">
                            <option value="">Select Jobtitle</option>
                            <?php
                            if (@$jobtitle) {
                                foreach ($jobtitle as $jobtitleRow) {
                                    ?>
                                    <option value="<?= $jobtitleRow->id; ?>"><?= $jobtitleRow->jobtitlename; ?></option>
                                <?php }
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <br/>
                <div class="col-sm-2 col-xs-4">  
                    <button type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>
                </div>  

                <div class="col-sm-2 col-xs-4"> 
                    <button type="button" id="btn-reset" class="btn btn-primary btn-block"> Reset </button>
                </div>

            </div>
        </form>   


        <br/><br/>


        <div class="panel panel-default">

            <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'report1')" id="defaultOpen">Report 9:30 AM And 9:45 AM</button>
                <button class="tablinks" onclick="openCity(event, 'report2')">Leave</button>
                <button class="tablinks" onclick="openCity(event, 'report3')">Tour</button>
            </div>

            <div class="tabcontent" id="report1">
                <div id="home" class="tab-pane fade in active">  
                    <div class="row">
                        <div class="col-md-12">
                            <div id="colvis"></div>
                        </div>
                    </div>

                    <div class="table-responsive">

                        <table id="table" class="table table-striped display">
                            <thead>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Emp Code</th>
                                    <th>Emp Name</th>
                                    <th>Job Grade</th>
                                    <th>Time</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Emp Code</th>
                                    <th>Emp Name</th>
                                    <th>Job Grade</th>
                                    <th>Time</th>
                                    <th>Date</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>   

            <div class="tabcontent" id="report2">

                <div class="row">
                    <div class="col-md-12">
                        <div id="colvis1"></div>
                    </div>
                </div>

                <div class="table-responsive">

                    <table id="table1" style="width:100%;" class="table table-striped display">
                        <thead>
                            <tr>
                                <th>Sr. No</th>
                                <th>Emp Code</th>
                                <th>Emp Name</th>
                                <th>Job Grade</th>
                                <th>Leave Status</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Sr. No</th>
                                <th>Emp Code</th>
                                <th>Emp Name</th>
                                <th>Job Grade</th>
                                <th>Leave Status</th>
                            </tr>
                        </tfoot>
                        <tbody>
                        </tbody>
                    </table>

                </div>

            </div>   

            <div class="tabcontent" id="report3">

                <div class="row">
                    <div class="col-md-12">
                        <div id="colvis2"></div>
                    </div>
                </div>

                <div class="table-responsive">

                    <table id="table2" style="width:100%;" class="table table-striped display">
                        <thead>
                            <tr>
                                <th>Sr. No</th>
                                <th>Emp Code</th>
                                <th>Emp Name</th>
                                <th>Job Grade</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Sr. No</th>
                                <th>Emp Code</th>
                                <th>Emp Name</th>
                                <th>Job Grade</th>
                                <th>Date</th>
                            </tr>
                        </tfoot>
                        <tbody>
                        </tbody>
                    </table>

                </div>

            </div>   

        </div>



    </div>
</div>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>



<script type="text/javascript">
                    var table;
                    $(document).ready(function () {
                         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                        table = $('#table').DataTable({
                            "processing": true,
                            "serverSide": true,
                            "pageLength": -1,
                            "order": [],
                            "ajax": {
                                "url": "<?php echo base_url('ajax_attendance_report_list'); ?>",
                                "type": "POST",
                                "data": function (data) {
                                    data.atten_report = $('#atten_report').val();
                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                },
                                        data:{[csrfName]: csrfHash}, 
                            },
                            "dom": 'lBfrtip',
                            "buttons": [{
                                    extend: 'collection',
                                    text: 'Export',
                                    buttons: [
                                        'copy',
                                        'excel',
                                        'csv',
                                        'pdf',
                                        'print'
                                    ]
                                }
                            ],
                            //Set column definition initialisation properties.
                            "columnDefs": [{
                                    "targets": [0], //first column / numbering column
                                    "orderable": false, //set not orderable
                                },
                            ],
                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        });
                        var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                        //new $.fn.dataTable.FixedHeader( table );
                        $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                        $('#btn-filter').click(function () { //button filter event click
                            table.ajax.reload();  //just reload table
                        });
                        $('#btn-reset').click(function () { //button reset event click
                            $('#form-filter')[0].reset();
                            table.ajax.reload();  //just reload table
                        });
                    });

                    var table1;
                    $(document).ready(function () {
                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                        //datatables
                        table1 = $('#table1').DataTable({
                            "processing": true,
                            "serverSide": true,
                            "pageLength": -1,
                            "order": [],
                            "ajax": {
                                "url": "<?php echo base_url('ajax_attendance_report_leave_list') ?>",
                                "type": "POST",
                                "data": function (data) {
                                    data.atten_report = $('#atten_report').val();
                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                },
                                        data:{[csrfName]: csrfHash}, 
                            },

                            "dom": 'lBfrtip',
                            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                            ],

                            "columnDefs": [{"targets": [0], "orderable": false}],

                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        });
                        var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
                        $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
                        $('#btn-filter').click(function () { //button filter event click
                            table1.ajax.reload();  //just reload table
                        });
                        $('#btn-reset').click(function () { //button reset event click
                            $('#form-filter')[0].reset();
                            table1.ajax.reload();  //just reload table
                        });
                    });

                    var table2;
                    $(document).ready(function () {
                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                        //datatables
                        table2 = $('#table2').DataTable({
                            "processing": true,
                            "serverSide": true,
                            "pageLength": -1,
                            "order": [],
                            "ajax": {
                                "url": "<?php echo base_url('ajax_attendance_report_tour_list') ?>",
                                "type": "POST",
                                "data": function (data) {
                                    data.atten_report = $('#atten_report').val();
                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                },
                                        data:{[csrfName]: csrfHash}, 
                            },

                            "dom": 'lBfrtip',
                            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                            ],

                            "columnDefs": [{"targets": [0], "orderable": false}],

                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        });
                        var colvis2 = new $.fn.dataTable.ColVis(table2); //initial colvis
                        $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
                        $('#btn-filter').click(function () { //button filter event click
                            table2.ajax.reload();  //just reload table
                        });
                        $('#btn-reset').click(function () { //button reset event click
                            $('#form-filter')[0].reset();
                            table2.ajax.reload();  //just reload table
                        });
                    });

</script>
<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    document.getElementById("defaultOpen").click();

</script>
<style>
    #table_wrapper {
        width: 88em;
        white-space: nowrap;
    }

</style>
<style>
    .tablespace {
        padding: 7px 7px !important;
        text-align: left;
    }

    .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
    }
    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
    }
    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }
    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #ccc;
    }
    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-top: none;
    }
    /* Style the close button */
    .topright {
        float: right;
        cursor: pointer;
        font-size: 28px;
    }
    .topright:hover {color: red;}
    /*        .dt-buttons, .dataTables_filter {
    display: none;
    }*/
    .panel-title a[aria-expanded="true"] {
        background: #1c4e7f!important;
        padding: 10px 30px 10px 10px!important;
        border-radius: 5px!important;
        margin: -15px!important;
    }
    .panel-title a[aria-expanded="true"]:active {
        background: #1c4e7f!important;
        padding: 10px 30px 10px 10px!important;
        border-radius: 5px!important;
        margin: -15px!important;
    }
    .panel-title a[data-toggle="collapse"] {
        padding: 10px 30px 10px 10px!important;
        margin: -15px!important;
    }

    .chosen-container{width:100%!important;}

</style>
</body>
</html>

