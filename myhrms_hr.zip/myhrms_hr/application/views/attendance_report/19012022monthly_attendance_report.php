
<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    ul, #myUL {
        list-style-type: none;
    }
    #myUL {
        margin: 0;
        padding: 0;
    }
    .caret {
        cursor: pointer;
        -webkit-user-select: none; /* Safari 3.1+ */
        -moz-user-select: none; /* Firefox 2+ */
        -ms-user-select: none; /* IE 10+ */
        user-select: none;
    }
    .caret::before {
        content: "\25B6";
        color: black;
        display: inline-block;
        margin-right: 6px;
    }
    .nested {
        display: none;
    }
    .active {
        display: block;
    }
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <form method="post" action="<?= base_url("monthlyAttendance"); ?>">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <!--<div class="card-header" id="headingOne">-->
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email">Business Unit : </label> 

                                                <select required name="businessunit" class="form-control">
                                                    <option value="1"> CEG </option>
                                                    <option value="2"> CEG TH </option>
                                                    <option value="3"> CEG Project </option>
                                                </select>
                                            </div> 
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email"> Employee Name: </label> 
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="user_id" id="project_id" data-placeholder="Select" >
                                                    <option value=""> -- Select Employee-- </option>
                                                    <?php
                                                    if ($userrecArr) {
                                                        foreach ($userrecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$userid == $recD->user_id) ? "Selected" : ""; ?> value="<?= $recD->user_id; ?>"><?= $recD->userfullname; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email"> Department: </label> 
                                                <select class="form-control show-tick ms select2" name="department" id="department" data-placeholder="Select" >
                                                    <option value=""> -- Select -- </option>
                                                    <?php
                                                    $all_Activedepartment = get_departments();
                                                    if ($all_Activedepartment) {
                                                        foreach ($all_Activedepartment as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$dpt_id == $recD->id) ? "Selected" : ""; ?> value="<?= $recD->id; ?>"><?= $recD->deptname; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <label class="email"> Month : </label>
                                            <select class="form-control" name="attendance_month" data-placeholder="Select">
<!--<option <?= (@$atten_month == "") ? "Selected" : ""; ?> value=""> -- All -- </option>-->
                                                <option <?= (@$atten_month == "01") ? "Selected" : ""; ?> value="01"> January </option>
                                                <option <?= (@$atten_month == "02") ? "Selected" : ""; ?> value="02"> February </option>
                                                <option <?= (@$atten_month == "03") ? "Selected" : ""; ?> value="03"> March </option>
                                                <option <?= (@$atten_month == "04") ? "Selected" : ""; ?> value="04"> April </option>
                                                <option <?= (@$atten_month == "05") ? "Selected" : ""; ?> value="05"> May </option>
                                                <option <?= (@$atten_month == "06") ? "Selected" : ""; ?> value="06"> June </option>
                                                <option <?= (@$atten_month == "07") ? "Selected" : ""; ?> value="07"> July </option>
                                                <option <?= (@$atten_month == "08") ? "Selected" : ""; ?> value="08"> August </option>
                                                <option <?= (@$atten_month == "09") ? "Selected" : ""; ?> value="09"> September </option>
                                                <option <?= (@$atten_month == "10") ? "Selected" : ""; ?> value="10"> October </option>
                                                <option <?= (@$atten_month == "11") ? "Selected" : ""; ?> value="11"> November </option>
                                                <option <?= (@$atten_month == "12") ? "Selected" : ""; ?> value="12"> December </option>
                                            </select>

                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <label class="email"> Year : </label>
                                            <select class="form-control" name="attendance_year" data-placeholder="Select">  
                                                <option <?= (@$atten_year == "2019") ? "Selected" : ""; ?> value="2019"> 2019 </option>
                                                <option <?= (@$atten_year == "2020") ? "Selected" : ""; ?> value="2020"> 2020 </option>
                                                <option <?= (@$atten_year == "2021") ? "Selected" : ""; ?> value="2021"> 2021 </option>
                                                <option <?= (@$atten_year == "2022") ? "Selected" : ""; ?> value="2022"> 2022 </option>
                                                <option <?= (@$atten_year == "2023") ? "Selected" : ""; ?> value="2023"> 2023 </option>
                                                <option <?= (@$atten_year == "2024") ? "Selected" : ""; ?> value="2024"> 2024 </option>
                                                <option <?= (@$atten_year == "2025") ? "Selected" : ""; ?> value="2025"> 2025 </option>
                                                <option <?= (@$atten_year == "2026") ? "Selected" : ""; ?> value="2026"> 2025 </option>
                                            </select>
                                        </div>



                                        <div class="col-lg-1 col-md-6">
                                            <div class="mb-2">
                                                <b></b>
                                                <button type="submit" id="btn-filter" class="btn btn-success btn-block" style="margin-top:20px;"> Filter </button>
                                            </div>
                                        </div>
                                        <div class="col-lg-1 col-md-6">

                                            <div class="mb-2">
                                                <b></b>
                                                <button type="reset" id="btn-reset" class="btn btn-primary btn-block" style="margin-top:20px;"> Reset </button>
                                            </div>
                                        </div>



                                    </div>
                                    <!--</div> -->                               

                                </form>


                            </div>
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table23" class="table table-striped display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EMP Name</th>
                                                <!--<th>Position</th>
                                                <th>Department </th>-->
                        <!--                            <th>No of HD </th>-->
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                <th>24</th>
                                                <th>25</th>
                                                <th>26</th>
                                                <th>27</th>
                                                <th>28</th>
                                                <th>29</th>
                                                <th>30</th>
                                                <th>31</th>
                                            </tr> 
                                        </thead>
                                        <tbody>
                                            <?php
                                            $userRecnew = $userrec;
                                            //echo "<pre>"; print_r($userRec); die;
                                            $no = 1;
                                            if ($userRecnew):
                                                foreach ($userRecnew as $value):
                                                    ?>
                                                    <tr>
                                                        <td><?= $no; ?></td>
                                                        <td><?= ($value->userfullname) ? $value->userfullname : "No name" ?></td>
                                                        <?php
                                                        //$from_date = date("Y")."-02"."-01";
                                                        //$to_date = date("t-m-Y", strtotime($from_date));
                                                        //$dateRangeArr = $this->Mastermodel->getDatesFromRange($from_date, $to_date); 
                                                        foreach ($dateRangeArr as $dates):

                                                            $Attendlist = GetAllPunchDetailNew($dates, $value->machine_id);
                                                            ?>

                                                            <td><?php
                                                                if (isset($Attendlist['intime'][0]) && isset($Attendlist['outtime'][0])) {
                                                                    echo $Attendlist['intime'][0] . '<br>' . $Attendlist['outtime'][0];
                                                                } else {
                                                                    echo '<span style="color:red">Not Punched</span>';
                                                                }
                                                                ?></td>
                                                        <?php endforeach; ?>

                                                    </tr>
                                                    <?php
                                                    $no++;
                                                endforeach;
                                            else:
                                                ?>
                                                <tr>
                                                    <td></td>
                                                    <td style="color:red;margin-left:20px;">Filter for Attendance Record</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EMP Name</th>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                                <th>18</th>
                                                <th>19</th>
                                                <th>20</th>
                                                <th>21</th>
                                                <th>22</th>
                                                <th>23</th>
                                                <th>24</th>
                                                <th>25</th>
                                                <th>26</th>
                                                <th>27</th>
                                                <th>28</th>
                                                <th>29</th>
                                                <th>30</th>
                                                <th>31</th>
                                            </tr> 
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

</body>
<script type="text/javascript">
                                                    var table;
                                                    $(document).ready(function () {
                                                        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                                                        table = $('#table').DataTable({
                                                            "processing": true,
                                                            "serverSide": true,
                                                            "pageLength": -1,
                                                            "order": [],
                                                            "ajax": {
                                                                "url": "<?php echo base_url('attendance_report/Attendance_controller/ajax_list'); ?>",
                                                                "type": "POST",
                                                                "data": function (data) {
                                                                    data.atten_report = $('#repmonth').val();
                                                                    data.atten_jobtitle = $('#repyear').val();
                                                                },
                                                                        data:{[csrfName]: csrfHash}, 

                                                            },
                                                            "dom": 'lBfrtip',
                                                            "buttons": [{
                                                                    extend: 'collection',
                                                                    text: 'Export',
                                                                    buttons: [
                                                                        'copy',
                                                                        'excel',
                                                                        'csv',
                                                                        'pdf',
                                                                        'print'
                                                                    ]
                                                                }
                                                            ],
                                                            //Set column definition initialisation properties.
                                                            "columnDefs": [{
                                                                    "targets": [0], //first column / numbering column
                                                                    "orderable": false, //set not orderable
                                                                },
                                                            ],
                                                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                                                        });
                                                        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                                                        //new $.fn.dataTable.FixedHeader( table );
                                                        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                                                        $('#btn-filter').click(function () { //button filter event click
                                                            table.ajax.reload();  //just reload table
                                                        });
                                                        $('#btn-reset').click(function () { //button reset event click
                                                            $('#form-filter')[0].reset();
                                                            table.ajax.reload();  //just reload table
                                                        });
                                                    });

                                                    var table1;
                                                    $(document).ready(function () {
                                                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                                                        //datatables
                                                        table1 = $('#table1').DataTable({
                                                            "processing": true,
                                                            "serverSide": true,
                                                            "pageLength": -1,
                                                            "order": [],
                                                            "ajax": {
                                                                "url": "<?php echo base_url('ajax_attendance_report_leave_list') ?>",
                                                                "type": "POST",
                                                                "data": function (data) {
                                                                    data.atten_report = $('#atten_report').val();
                                                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                                                    data.atten_busintitle = $('#atten_busintitle').val();
                                                                },
                                                                        data:{[csrfName]: csrfHash}, 

                                                            },

                                                            "dom": 'lBfrtip',
                                                            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                                                            ],

                                                            "columnDefs": [{"targets": [0], "orderable": false}],

                                                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                                                        });
                                                        // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
                                                        // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
                                                        $('#btn-filter').click(function () { //button filter event click
                                                            table1.ajax.reload();  //just reload table
                                                        });
                                                        $('#btn-reset').click(function () { //button reset event click
                                                            $('#form-filter')[0].reset();
                                                            table1.ajax.reload();  //just reload table
                                                        });
                                                    });

                                                    var table2;
                                                    $(document).ready(function () {
                                                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                                                        //datatables
                                                        table2 = $('#table2').DataTable({
                                                            "processing": true,
                                                            "serverSide": true,
                                                            "pageLength": -1,
                                                            "order": [],
                                                            "ajax": {
                                                                "url": "<?php echo base_url('ajax_attendance_report_tour_list') ?>",
                                                                "type": "POST",
                                                                "data": function (data) {
                                                                    data.atten_report = $('#atten_report').val();
                                                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                                                    data.atten_busintitle = $('#atten_busintitle').val();
                                                                },
                                                                 data:{[csrfName]: csrfHash}, 
       
                                                            },

                                                            "dom": 'lBfrtip',
                                                            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                                                            ],
                                                            "columnDefs": [{"targets": [0], "orderable": false}],
                                                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                                                        });
                                                        // var colvis2 = new $.fn.dataTable.ColVis(table2); //initial colvis
                                                        // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
                                                        $('#btn-filter').click(function () { //button filter event click
                                                            table2.ajax.reload();  //just reload table
                                                        });
                                                        $('#btn-reset').click(function () { //button reset event click
                                                            $('#form-filter')[0].reset();
                                                            table2.ajax.reload();  //just reload table
                                                        });
                                                    });

                                                    var table3;
                                                    $(document).ready(function () {
                                                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                                                        //datatables
                                                        table3 = $('#table3').DataTable({
                                                            "processing": true,
                                                            "serverSide": true,
                                                            "pageLength": -1,
                                                            "order": [],
                                                            "ajax": {
                                                                "url": "<?php echo base_url('attendance_report/attendancereport/ajax_attendance_report_list_all') ?>",
                                                                "type": "POST",
                                                                "data": function (data) {
                                                                    data.atten_report = $('#atten_report').val();
                                                                    data.atten_jobtitle = $('#atten_jobtitle').val();
                                                                    data.atten_busintitle = $('#atten_busintitle').val();
                                                                },
                                                                        data:{[csrfName]: csrfHash}, 
                                                                    },

                                                            "dom": 'lBfrtip',
                                                            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                                                            ],

                                                            "columnDefs": [{"targets": [0], "orderable": false}],

                                                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                                                        });
                                                        // var colvis2 = new $.fn.dataTable.ColVis(table3); //initial colvis
                                                        // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
                                                        $('#btn-filter').click(function () { //button filter event click
                                                            table3.ajax.reload();  //just reload table
                                                        });
                                                        $('#btn-reset').click(function () { //button reset event click
                                                            $('#form-filter')[0].reset();
                                                            table3.ajax.reload();  //just reload table
                                                        });
                                                    });

</script>
<?php $this->load->view('admin/includes/footer'); ?>

