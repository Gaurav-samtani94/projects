<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$course_arr = array(
	'bca'=>'BCA',
	'mca'=>'MCA',	
	'b-tech'=>'B.E/B-Tech',
	'm-tech'=>'M.E/M-Tech',
	'ba'=>'BA',
	'ma'=>'MA',
	'b-com'=>'B.Com',
	'm-com'=>'M.Com'
);
?>
<div id="wrapper">
	<?php $this->load->view('admin/includes/sidebar'); ?>
	<div id="main-content">
		<div class="container-fluid">
			<div class="block-header" style="margin-top: 0px;">
				<div class="row">
					<div class="col-lg-5 col-md-8 col-sm-12">                        
						<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
						<i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
							<li class="breadcrumb-item">Home</li>
							<li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li> 
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="card">
						<div class="body">
							<form action="<?=base_url('save_manpower_data');?>" method="post" id="manpower_form">  
								<input type="hidden" name="mrf_id" value="<?=$tracker_manpower_list->fld_id?>">
								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Position: </label>
											<select required class="form-control" name="position" id="position" onchange="pos_function()">
												<option value="">Select Position</option>
												<option <?= ((!empty($tracker_manpower_list->position) && ($tracker_manpower_list->position == 'new'))? 'selected':'selected')?> value="new" >New</option>
												<option <?= ((!empty($tracker_manpower_list->position) && ($tracker_manpower_list->position == 'replacement'))? 'selected':'')?> value="replacement">Replacement</option>
											</select>
										</div>
									</div> 
									<div class="col-md-4" id="select_emp_name" style="display:none;">
										<div class="form-group">
											<label class="control-label">Emp Name: </label>
											<select class="form-control select2" name="emp_name" id="emp_name" onchange="empchange()">
												<option value="">Select Emp</option>
												<?php if(@$emp_list){ ?>
													<?php foreach($emp_list as $emp_row){ ?>
														<option <?= ((!empty($tracker_manpower_list->emp_name) && ($tracker_manpower_list->emp_name == $emp_row->id))? 'selected':'')?> value="<?=@$emp_row->id;?>"><?=@$emp_row->userfullname;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Position Initiated On: </label>
											<input type="date" readonly class="form-control" name="position_initiated_on" id="position_initiated_on" value="<?= ((!empty($tracker_manpower_list->position_initiated_on))? date('Y-m-d',strtotime($tracker_manpower_list->position_initiated_on)):date('Y-m-d'))?>">
										</div>
									</div> 
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Position Initiated By: </label>
											<input type="text" readonly class="form-control" name="position_initiated_by" id="position_initiated_by" value="<?= ((!empty($tracker_manpower_list->position_initiated_userfullname))? $tracker_manpower_list->position_initiated_userfullname:$this->session->userdata('username'))?>">
										</div>
									</div> 
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Position Name: </label>
											<select required class="form-control select2" name="position_name" id="position_name">
												<option value="">Select Position</option>
												<?php if(@$desig_list){ ?>
													<?php foreach($desig_list as $desig_row){ ?>
														<option <?= ((!empty($tracker_manpower_list->position_name) && ($tracker_manpower_list->position_name == $desig_row->position_id))? 'selected':'')?> value="<?=@$desig_row->position_id;?>"><?=@$desig_row->position_name;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Base Location: </label>
											<select required class="form-control select2" name="base_location" id="base_location">
												<option value="">Select Location</option>
												<?php if(@$comp_list){ ?>
													<?php foreach($comp_list as $comp_row){ ?>
														<option <?= ((!empty($tracker_manpower_list->base_location) && ($tracker_manpower_list->base_location == $comp_row->id))? 'selected':'')?> value="<?=@$comp_row->id;?>"><?=@$comp_row->city_name;?></option> 
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">No. of Positions Vacant: </label>
											<input type="text" required class="form-control" name="position_vacant" id="position_vacant" value='<?= ((!empty($tracker_manpower_list->no_of_position_vacant))? $tracker_manpower_list->no_of_position_vacant:1)?>'>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Technical/ Non Tech: </label>
											<select class="form-control" required name="technical_non_technical" id="technical_non_technical">
												<option value="">Select Technical/ Non Tech</option>
												<option <?= ((!empty($tracker_manpower_list->technical_non_technical) && ($tracker_manpower_list->technical_non_technical == 'technical'))? 'selected':'')?>  value="technical">Technical</option>
												<option <?= ((!empty($tracker_manpower_list->technical_non_technical) && ($tracker_manpower_list->technical_non_technical == 'non technical'))? 'selected':'')?> value="non technical">Non Technical</option>
											</select>										
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Department: </label>
											<select class="form-control select2" required name="department_name" id="department_name">
												<option value="">Select Department</option>
												<?php if(@$dept_list){ ?>
													<?php foreach($dept_list as $dept_row){ ?>
														<option <?= ((!empty($tracker_manpower_list->department) && ($tracker_manpower_list->department == $dept_row->department_id))? 'selected':'')?> value="<?=@$dept_row->department_id;?>"><?=@$dept_row->department_name;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Tenure: </label>
											<select class="form-control" required name="tenure" id="tenure">
												<option value="">Select Tenure</option>
												<option <?= ((!empty($tracker_manpower_list->tenture) && ($tracker_manpower_list->tenture == 'permanent'))? 'selected':'')?> value="permanent" >Permanent</option>
												<option <?= ((!empty($tracker_manpower_list->tenture) && ($tracker_manpower_list->tenture == 'temporary'))? 'selected':'')?>  value="temporary">Temporary</option>
											</select>										
										</div>
									</div> 
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Budgeted/Non Budgeted: </label>
											<select class="form-control" required name="budgeted_non_budgeted" id="budgeted_non_budgeted">
												<option value="">Select Budgeted/Non Budgeted</option>
												<option <?= ((!empty($tracker_manpower_list->budgeted_non_budgeted) && ($tracker_manpower_list->budgeted_non_budgeted == 'budgeted'))? 'selected':'')?>  value="budgeted">Budgeted</option>
												<option <?= ((!empty($tracker_manpower_list->budgeted_non_budgeted) && ($tracker_manpower_list->budgeted_non_budgeted == 'non budgeted'))? 'selected':'')?> value="non budgeted">Non Budgeted</option>
											</select>										
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Reason for Requirement: </label>
											<textarea class="form-control" required name="reason_for_requirement" id="reason_for_requirement"><?= ((!empty($tracker_manpower_list->reason_of_requirement))? $tracker_manpower_list->reason_of_requirement:'')?></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Qualifications Desired:</label>
											<div class="row">
												<div class="col-md-6">
													<select class="form-control" name="qualifications_desired" id="qualifications_desired">
														<option value="">Select Qualifications</option>
														<?php if(@$edulevel_list){ ?>
															<?php foreach($edulevel_list as $edulevel_row){ ?>
																<option <?= ((!empty($tracker_manpower_list->qualifications_desired) && ($tracker_manpower_list->qualifications_desired == $edulevel_row->id))? 'selected':'')?> value="<?=@$edulevel_row->id;?>"><?=@$edulevel_row->educationlevelcode;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
												<div class="col-md-6">
													<select class="form-control" name="qualifications_desired_course" id="qualifications_desired_course">
														<option value="">Select Course</option>
														<?php if(@$course_arr){ ?>
															<?php foreach($course_arr as $course_row_key=>$course_row_value){ ?>
																<option <?= ((!empty($tracker_manpower_list->qualifications_desired_course) && ($tracker_manpower_list->qualifications_desired_course == $course_row_key))? 'selected':'')?> value="<?=@$course_row_key;?>"><?=@$course_row_value;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
											</div>
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Age Group Range (From-To): </label>
											<div class="row">
												<div class="col-md-6">
													<input type="number" required class="form-control" name="age_group_from_range" id="age_group_from_range" value="<?= ((!empty($tracker_manpower_list->age_group_from))? $tracker_manpower_list->age_group_from:'')?>">
												</div>
												<div class="col-md-6">
													<input type="number" required class="form-control" name="age_group_to_range" id="age_group_to_range" value="<?= ((!empty($tracker_manpower_list->age_group_to))? $tracker_manpower_list->age_group_to:'')?>">
												</div>
											</div>
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Relevant Qualification: </label>
											<div class="row">
												<div class="col-md-6">
													<select class="form-control" name="relevant_qualification" id="relevant_qualification">
														<option value="">Select Qualifications</option>
														<?php if(@$edulevel_list){ ?>
															<?php foreach($edulevel_list as $edulevel_row){ ?>
																<option <?= ((!empty($tracker_manpower_list->relevant_qualification) && ($tracker_manpower_list->relevant_qualification == $edulevel_row->id))? 'selected':'')?> value="<?=@$edulevel_row->id;?>"><?=@$edulevel_row->educationlevelcode;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
												<div class="col-md-6">
													<select class="form-control select2" name="relevant_qualification_course" id="relevant_qualification_course">
														<option value="">Select Course</option>
														<?php if(@$course_arr){ ?>
															<?php foreach($course_arr as $course_row_key=>$course_row_value){ ?>
																<option <?= ((!empty($tracker_manpower_list->relevant_qualification_course) && ($tracker_manpower_list->relevant_qualification_course == $course_row_key))? 'selected':'')?> value="<?=@$course_row_key;?>"><?=@$course_row_value;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Relevant Experience (From-To):</label>
											<div class="row">
												<div class="col-md-6">
													<input type="number" required class="form-control" name="relevant_from_exp" id="relevant_from_exp" value="<?= ((!empty($tracker_manpower_list->relevant_exp_from))? $tracker_manpower_list->relevant_exp_from:'')?>">
												</div>
												<div class="col-md-6">
													<input type="number" required class="form-control" name="relevant_to_exp" id="relevant_to_exp" value="<?= ((!empty($tracker_manpower_list->relevant_exp_to))? $tracker_manpower_list->relevant_exp_to:'')?>">
												</div>
											</div>
										</div>
									</div>  
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Work Experience Range (From-To):</label>
											<div class="row">
												<div class="col-md-6">
													<input type="number" required class="form-control" name="work_exp_from_range" id="work_exp_from_range" value="<?= ((!empty($tracker_manpower_list->work_exp_from))? $tracker_manpower_list->work_exp_from:'')?>">
												</div>
												<div class="col-md-6">
													<input type="number" required class="form-control" name="work_exp_to_range" id="work_exp_to_range" value="<?= ((!empty($tracker_manpower_list->work_exp_to))? $tracker_manpower_list->work_exp_to:'')?>">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Gross Salary Range (From-To):</label>
											<div class="row">
												<div class="col-md-6">
													<input type="number" required class="form-control" name="gross_salary_from_range" id="gross_salary_from_range" value="<?= ((!empty($tracker_manpower_list->gross_salary_from))? $tracker_manpower_list->gross_salary_from:'')?>">
												</div>
												<div class="col-md-6">
													<input type="number" required class="form-control" name="gross_salary_to_range" id="gross_salary_to_range" value="<?= ((!empty($tracker_manpower_list->gross_salary_to))? $tracker_manpower_list->gross_salary_to:'')?>">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Reporting Location:</label>
											<div class="row">
												<div class="col-md-4">
													<select class="form-control" name="reporting_location_country" id="reporting_location_country" onchange="changecountry()">
														<option value="">Select Country</option>
														<?php if(@$country_list){ ?>
															<?php foreach($country_list as $country_row){ ?>
																<option <?= ((!empty($tracker_manpower_list->reporting_location_country) && ($tracker_manpower_list->reporting_location_country == $country_row->id))? 'selected':'')?> value="<?=@$country_row->id;?>"><?=@$country_row->country_name;?></option>
															<?php } ?>
														<?php } ?>
													</select>
												</div>
												<div class="col-md-4">
													<select class="form-control" name="reporting_location_state" id="reporting_location_state" onchange="changestate()">
														<option value="">Select State</option>
													</select>
												</div>
												<div class="col-md-4">
													<select class="form-control" name="reporting_location_city" id="reporting_location_city">
														<option value="">Select City</option> 
													</select>
												</div>
											</div>
										</div>
									</div>	
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Reporting Officer:</label>
											<select class="form-control" name="reporting_officer" id="reporting_officer">
												<option value="">Select Reporting Officer</option>
												<?php if(@$ro_list){ ?>
													<?php foreach($ro_list as $ro_row){ ?>
														<option <?= ((!empty($tracker_manpower_list->reporting_officer) && ($tracker_manpower_list->reporting_officer == $ro_row->id))? 'selected':'')?> value="<?=@$ro_row->id;?>"><?=@$ro_row->userfullname;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Expected Date of Joining:</label>
											<input type="date" required class="form-control" name="expected_date_of_joining" id="expected_date_of_joining" value="<?= ((!empty($tracker_manpower_list->expected_date_joining))? date('Y-m-d',strtotime($tracker_manpower_list->expected_date_joining)):'')?>">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Job Description (KRA to be Delivered):</label>
											<textarea class="form-control" required name="job_description" id="job_description"><?= ((!empty($tracker_manpower_list->job_description))? $tracker_manpower_list->job_description:'')?></textarea>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">MRF Handed Over To CRU</label>
											<input type="date" class="form-control" name="mrf_handed_over_cru" id="mrf_handed_over_cru" value="<?= ((!empty($tracker_manpower_list->mrf_handed_over_cru))? date('Y-m-d',strtotime($tracker_manpower_list->mrf_handed_over_cru)):'')?>">
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Expected Date Of Position Closure</label>
											<input type="date" class="form-control" name="expected_date_position_closure" id="expected_date_position_closure" value="<?= ((!empty($tracker_manpower_list->expected_date_position_closure))? date('Y-m-d',strtotime($tracker_manpower_list->expected_date_position_closure)):'')?>">
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Offer Issued</label>
											<input type="date" class="form-control" name="offer_issued" id="offer_issued"  value="<?= ((!empty($tracker_manpower_list->offer_issued))? date('Y-m-d',strtotime($tracker_manpower_list->offer_issued)):'')?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label"></label>
											<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
											<?php 
											if($tracker_manpower_list->lock==1){ ?>
												<span class="btn btn-info btn-sm">Locked</span>
												<?php 
											} else { ?>
												<input type="submit" class="btn btn-success btn-sm"  name="save_data" id="save_data" value="Save">
												<input type="reset" class="btn btn-secondary btn-sm" value="Reset">
												<?php 
											} ?>
											
										</div>
									</div> 
									</div> 
								</div>
							</from>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('admin/includes/footer'); ?>
<style>
	#pageloader
	{
		background: rgba( 255, 255, 255, 0.8 );
		display: none;
		height: 100%;
		position: fixed;
		width: 100%;
		z-index: 9999;
		margin-left: -32px!important;
		margin-top: -32px!important;
		text-align:center!important
	}
	#pageloader img
	{
		left: 50%;
		margin-left: -32px;
		margin-top: -32px;
		position: absolute;
		top: 50%;
	}
</style>
<script>
	function pos_function(){
		var pos_val = $('#position').val();
		//alert(pos_val); 
		if(pos_val == 'replacement'){
			$('#select_emp_name').show();
		}
		else{
				$('#select_emp_name').hide(); 
		}
	}

	function empchange(){
			var emp_name_val = $('#emp_name').val();
			if(emp_name_val){
				$.ajax({
					type: "GET", 
					url: "<?= base_url('Tracker_Controller/getAjaxRequestData/?emp_name_val='); ?>"+emp_name_val,
					success: function(response) {
						//alert(response);
						var result = JSON.parse(response);
						if(response){
							$('#position_name').val(result['position_id']);
							$('#department_name').val(result['department_id']);
							$('#base_location').val(result['id']);
							$('#position_name').prop('disabled', true);
						}
						else{
							alert('Please Select Any Person Name');
						}
					
					}
				});
			}
			else{  
				$('#position_name').val('');
				$('#department_name').val('');
				$('#base_location').val('');
				alert('Please Select Any Person Name');
			}
	}

	$('#manpower_form').submit(function(e){
		e.preventDefault();
		var form_action = $('#manpower_form').attr('action');
		var data = $("#manpower_form").serialize();
		$.ajax({
			type: 'POST',
			url: form_action,
			data: data,
			dataType: "json",
			beforeSend: function () {
				$('#pageloader').fadeIn();
			},
			success: function (responData) {
				toastr.info(responData.msg, 'Message', {timeOut: 5000});
				//$('#manpower_form')[0].reset();
				
			},
			complete: function () {
				$('#pageloader').fadeOut(5000);
			}
		});
	});

	function changecountry(){
		var reporting_location_country = $('#reporting_location_country').val();
		if (reporting_location_country) {
			$.ajax({
				url: '<?php echo base_url('Tracker_Controller/state/'); ?>' + reporting_location_country,
				type: "GET",
				dataType: "json",
				success: function (data) {
					$('select[name="reporting_location_state"]').empty();
					$('select[name="reporting_location_state"]').append('<option value=""> -- Select State Name -- </option>');
					$.each(data, function (key, value) {
						$('select[name="reporting_location_state"]').append('<option value="' + value.id + '">' + value.state_name + '</option>');
					});
				}

			});
		} else {
			alert('Please Select Country');
		}
	}


	function changestate(){
		var reporting_location_state = $('#reporting_location_state').val();
		//alert(reporting_location_state);
		if (reporting_location_state) {
			$.ajax({
				url: '<?php echo base_url('Tracker_Controller/city/'); ?>' + reporting_location_state,
				type: "GET",
				dataType: "json",
				success: function (data) {
					$('select[name="reporting_location_city"]').empty();
					$('select[name="reporting_location_city"]').append('<option value=""> -- Select City Name -- </option>');
					$.each(data, function (key, value) {
						$('select[name="reporting_location_city"]').append('<option value="' + value.id + '">' + value.city_name + '</option>');
					});
				}

			});
		} else {
			alert('Please Select State');
		}
	}
</script>