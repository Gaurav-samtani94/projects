<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$course_arr = array(
	'bca'=>'BCA',
	'mca'=>'MCA',
	'b-tech'=>'B.E/B-Tech',
	'm-tech'=>'M.E/M-Tech',
	'ba'=>'BA',
	'ma'=>'MA',
	'b-com'=>'B.Com',
	'm-com'=>'M.Com'
);
?>
<!--<div id="pageloader">
    <img src="http://cdnjs.cloudflare.com/ajax/libs/semantic-ui/0.16.1/images/loader-large.gif" alt="processing...">
</div>-->
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
							<i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li> 
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<div class="body">
								<form action="<?=base_url('save_manpower_data');?>" method="post" id="manpower_form">  
								<div class="row">	
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Position: </label>
											<select required class="form-control" name="position" id="position" onchange="pos_function()">
												<option value="">Select Position</option>
												<option value="new" selected>New</option>
												<option value="replacement">Replacement</option>
											</select>
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6" id="select_emp_name" style="display:none;">
										<div class="form-group">
											<label class="control-label">Emp Name: </label>
											<select class="form-control" name="emp_name" id="emp_name" onchange="empchange()">
												<option value="">Select Emp</option>
												<?php if(@$emp_list){ ?>
													<?php foreach($emp_list as $emp_row){ ?>
														<option value="<?=@$emp_row->id;?>"><?=@$emp_row->userfullname;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Position Initiated On: </label>
											<input type="date" readonly class="form-control" name="position_initiated_on" id="position_initiated_on" value="<?=date('Y-m-d');?>">
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Position Initiated By: </label>
											<input type="text" readonly class="form-control" name="position_initiated_by" id="position_initiated_by" value="<?=$this->session->userdata('username');?>">
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Position Name: </label>
											<select required class="form-control" name="position_name" id="position_name">
												<option value="">Select Position</option>
												<?php if(@$desig_list){ ?>
													<?php foreach($desig_list as $desig_row){ ?>
														<option value="<?=@$desig_row->position_id;?>"><?=@$desig_row->position_name;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Base Location: </label>
											<select required class="form-control" name="base_location" id="base_location">
												<option value="">Select Location</option>
												<?php if(@$comp_list){ ?>
													<?php foreach($comp_list as $comp_row){ ?>
														<option value="<?=@$comp_row->id;?>"><?=@$comp_row->city_name;?></option> 
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">No. of Positions Vacant: </label>
											<input type="text" required class="form-control" name="position_vacant" id="position_vacant" value='1'>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Technical/ Non Tech: </label>
											<select class="form-control" required name="technical_non_technical" id="technical_non_technical">
												<option value="">Select Technical/ Non Tech</option>
												<option value="technical">Technical</option>
												<option value="non technical">Non Technical</option>
											</select>										
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Department: </label>
											<select class="form-control" required name="department_name" id="department_name">
												<option value="">Select Department</option>
												<?php if(@$dept_list){ ?>
													<?php foreach($dept_list as $dept_row){ ?>
														<option value="<?=@$dept_row->department_id;?>"><?=@$dept_row->department_name;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Tenure: </label>
											<select class="form-control" required name="tenure" id="tenure">
												<option value="">Select Tenure</option>
												<option value="permanent" selected>Permanent</option>
												<option value="temporary">Temporary</option>
											</select>										
										</div>
									</div> 
									<div class="col-lg-3 col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Budgeted/Non Budgeted: </label>
											<select class="form-control" required name="budgeted_non_budgeted" id="budgeted_non_budgeted">
												<option value="">Select Budgeted/Non Budgeted</option>
												<option value="budgeted">Budgeted</option>
												<option value="non budgeted">Non Budgeted</option>
											</select>										
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Reason for Requirement: </label>
											<textarea class="form-control" required name="reason_for_requirement" id="reason_for_requirement"></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Qualifications Desired:</label>
											<div class="row">
												<div class="col-sm-6">
													<select class="form-control" name="qualifications_desired" id="qualifications_desired">
														<option value="">Select Qualifications</option>
														<?php if(@$edulevel_list){ ?>
															<?php foreach($edulevel_list as $edulevel_row){ ?>
																<option value="<?=@$edulevel_row->id;?>"><?=@$edulevel_row->educationlevelcode;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<select class="form-control" name="qualifications_desired_course" id="qualifications_desired_course">
														<option value="">Select Course</option>
														<?php if(@$course_arr){ ?>
															<?php foreach($course_arr as $course_row_key=>$course_row_value){ ?>
																<option value="<?=@$course_row_key;?>"><?=@$course_row_value;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
											</div>
										</div>
									</div> 
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Age Group Range (From-To): </label>
											<div class="row">
												<div class="col-sm-6">
													<input type="number" required class="form-control" name="age_group_from_range" id="age_group_from_range">
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<input type="number" required class="form-control" name="age_group_to_range" id="age_group_to_range">
												</div>
											</div>
										</div>
									</div> 
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Relevant Qualification: </label>
											<div class="row">
												<div class="col-sm-6">
													<select class="form-control" name="relevant_qualification" id="relevant_qualification">
														<option value="">Select Qualifications</option>
														<?php if(@$edulevel_list){ ?>
															<?php foreach($edulevel_list as $edulevel_row){ ?>
																<option value="<?=@$edulevel_row->id;?>"><?=@$edulevel_row->educationlevelcode;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<select class="form-control" name="relevant_qualification_course" id="relevant_qualification_course">
														<option value="">Select Course</option>
														<?php if(@$course_arr){ ?>
															<?php foreach($course_arr as $course_row_key=>$course_row_value){ ?>
																<option value="<?=@$course_row_key;?>"><?=@$course_row_value;?></option>
															<?php } ?>
														<?php } ?>
													</select>												
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Relevant Experience (From-To):</label>
											<div class="row">
												<div class="col-sm-6">
													<input type="number" required class="form-control" name="relevant_from_exp" id="relevant_from_exp">
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<input type="number" required class="form-control" name="relevant_to_exp" id="relevant_to_exp">
												</div>
											</div>
										</div>
									</div>  
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Work Experience Range (From-To):</label>
											<div class="row">
												<div class="col-sm-6">
													<input type="number" required class="form-control" name="work_exp_from_range" id="work_exp_from_range">
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<input type="number" required class="form-control" name="work_exp_to_range" id="work_exp_to_range">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Gross Salary Range (From-To):</label>
											<div class="row">
												<div class="col-sm-6">
													<input type="number" required class="form-control" name="gross_salary_from_range" id="gross_salary_from_range">
												</div>
												<div class="col-sm-6 mt-2 mt-sm-0">
													<input type="number" required class="form-control" name="gross_salary_to_range" id="gross_salary_to_range">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Reporting Location:</label>
											<div class="row">
												<div class="col-sm-4">
													<select class="form-control" name="reporting_location_country" id="reporting_location_country" onchange="changecountry()">
														<option value="">Select Country</option>
														<?php if(@$country_list){ ?>
															<?php foreach($country_list as $country_row){ ?>
																<option value="<?=@$country_row->id;?>"><?=@$country_row->country_name;?></option>
															<?php } ?>
														<?php } ?>
													</select>
												</div>
												<div class="col-sm-4 mt-2 mt-sm-0">
													<select class="form-control" name="reporting_location_state" id="reporting_location_state" onchange="changestate()">
														<option value="">Select State</option>
													</select>
												</div>
												<div class="col-sm-4 mt-2 mt-sm-0">
													<select class="form-control" name="reporting_location_city" id="reporting_location_city">
														<option value="">Select City</option> 
													</select>
												</div>
											</div>
										</div>
									</div>	
									<div class="col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Reporting Officer:</label>
											<select class="form-control" name="reporting_officer" id="reporting_officer">
												<option value="">Select Reporting Officer</option>
												<?php if(@$ro_list){ ?>
													<?php foreach($ro_list as $ro_row){ ?>
														<option value="<?=@$ro_row->id;?>"><?=@$ro_row->userfullname;?></option>
													<?php } ?>
												<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-md-3 col-sm-6">
										<div class="form-group">
											<label class="control-label">Expected Date of Joining:</label>
											<input type="date" required class="form-control" name="expected_date_of_joining" id="expected_date_of_joining">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Job Description (KRA to be Delivered):</label>
											<textarea class="form-control" required name="job_description" id="job_description"></textarea>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label class="control-label">MRF Handed Over To CRU</label>
											<input type="date" class="form-control" name="mrf_handed_over_cru" id="mrf_handed_over_cru">
										</div>
									</div> 
									<div class="col-sm-4">
										<div class="form-group">
											<label class="control-label">Expected Date Of Position Closure</label>
											<input type="date" class="form-control" name="expected_date_position_closure" id="expected_date_position_closure">
										</div>
									</div> 
									<div class="col-sm-4">
										<div class="form-group">
											<label class="control-label">Offer Issued</label>
											<input type="date" class="form-control" name="offer_issued" id="offer_issued">
										</div>
									</div>
									<div class="col-lg-12 text-center">
										<div class="form-group">
											<label class="control-label"></label>
											<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
											<input type="submit" class="btn btn-one"  name="save_data" id="save_data" value="Save">
											<input type="reset" class="btn btn-success" value="Reset">
										</div>
									</div> 
									</div> 
								</div>
								</from> 
							</div>
						</div>
					</div>
				</div>
		 
            </div>
        </div>
    </div>
<?php $this->load->view('admin/includes/footer'); ?>
	<style>
		#pageloader
		{
			background: rgba( 255, 255, 255, 0.8 );
			display: none;
			height: 100%;
			position: fixed;
			width: 100%;
			z-index: 9999;
			margin-left: -32px!important;
			margin-top: -32px!important;
			text-align:center!important
		}
		#pageloader img
		{
			left: 50%;
			margin-left: -32px;
			margin-top: -32px;
			position: absolute;
			top: 50%;
		}
	</style>
	<script>
	function pos_function(){
		var pos_val = $('#position').val();
		//alert(pos_val); 
		if(pos_val == 'replacement'){
			$('#select_emp_name').show();
		}
		else{
				$('#select_emp_name').hide(); 
		}
	}

	function empchange(){
			var emp_name_val = $('#emp_name').val();
			if(emp_name_val){
				$.ajax({
					type: "GET", 
					url: "<?= base_url('Tracker_Controller/getAjaxRequestData/?emp_name_val='); ?>"+emp_name_val,
					success: function(response) {
						//alert(response);
						var result = JSON.parse(response);
						if(response){
							$('#position_name').val(result['position_id']);
							$('#department_name').val(result['department_id']);
							$('#base_location').val(result['id']);
							$('#position_name').prop('disabled', true);
						}
						else{
							alert('Please Select Any Person Name');
						}
					
					}
				});
			}
			else{  
				$('#position_name').val('');
				$('#department_name').val('');
				$('#base_location').val('');
				alert('Please Select Any Person Name');
			}
	}

	$('#manpower_form').submit(function(e){
		e.preventDefault();
		var form_action = $('#manpower_form').attr('action');
		var data = $("#manpower_form").serialize();
		$.ajax({
			type: 'POST',
			url: form_action,
			data: data,
            dataType: "json",
			beforeSend: function () {
				$('#pageloader').fadeIn();
			},
			success: function (responData) {
				toastr.info(responData.msg, 'Message', {timeOut: 5000});
				$('#manpower_form')[0].reset();
			},
			complete: function () {
				$('#pageloader').fadeOut(5000);
			}
		});
	});

	function changecountry(){
		var reporting_location_country = $('#reporting_location_country').val();
		if (reporting_location_country) {
			$.ajax({
				url: '<?php echo base_url('Tracker_Controller/state/'); ?>' + reporting_location_country,
				type: "GET",
				dataType: "json",
				success: function (data) {
					$('select[name="reporting_location_state"]').empty();
					$('select[name="reporting_location_state"]').append('<option value=""> -- Select State Name -- </option>');
					$.each(data, function (key, value) {
						$('select[name="reporting_location_state"]').append('<option value="' + value.id + '">' + value.state_name + '</option>');
					});
				}

			});
		} else {
			alert('Please Select Country');
		}
	}


	function changestate(){
		var reporting_location_state = $('#reporting_location_state').val();
		//alert(reporting_location_state);
		if (reporting_location_state) {
			$.ajax({
				url: '<?php echo base_url('Tracker_Controller/city/'); ?>' + reporting_location_state,
				type: "GET",
				dataType: "json",
				success: function (data) {
					$('select[name="reporting_location_city"]').empty();
					$('select[name="reporting_location_city"]').append('<option value=""> -- Select City Name -- </option>');
					$.each(data, function (key, value) {
						$('select[name="reporting_location_city"]').append('<option value="' + value.id + '">' + value.city_name + '</option>');
					});
				}

			});
		} else {
			alert('Please Select State');
		}
	}
	</script>
</body>
                                                         