<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$course_arr = array(
	'bca'=>'BCA',
	'mca'=>'MCA',
	'b-tech'=>'B.E/B-Tech',
	'm-tech'=>'M.E/M-Tech',
	'ba'=>'BA',
	'ma'=>'MA',
	'b-com'=>'B.Com',
	'm-com'=>'M.Com'
);
?>
<!--<div id="pageloader">
    <img src="http://cdnjs.cloudflare.com/ajax/libs/semantic-ui/0.16.1/images/loader-large.gif" alt="processing...">
</div>-->
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content" >
            <div class="container-fluid">
                <div class="block-header stepper" >
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
							<i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li> 
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<div class="body">
                                <div class="row">
                                    <div class="col-sm-12"> 
                                        <?php /*
                                        <a href="<?=base_url('mrf');?>" target="_blank" class="btn btn-one  pull-right"><i class="fa fa-plus"></i>Add</a> */ ?>
                                    </div>
                                </div>
								<form id="form-filter"> 
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for ="position">Position</label>
                                                <select id="position_name" name="position_name" class="form-control"> 
                                                    <option value="">Select Position</option>
                                                    <option value="new">New</option>
                                                    <option value="replacement">Replacement</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for ="department">Department</label>
                                                <select id="dept_name" name="dept_name" class="form-control"> 
                                                    <option value="">Select Department</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for ="designation">Designation</label>
                                                <select id="desig_name" name="desig_name" class="form-control"> 
                                                    <option value="">Select Designation</option>
                                                </select>
                                            </div>
                                        </div>
                                    
                                        <div class="col-sm-3">
                                            <div class="form-group mt-sm-3">
                                                <input type="submit" class="btn btn-one" value="Filter">
                                                <input type="reset" class="btn btn-success" value="Reset">
                                            </div>
                                        </div>
                                      
                                    </div>
                                </form>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<div class="body">
                                <div class="table-responsive bootstrapTable ">
                                    <table id="table" class="table table-striped display">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Position</th>
                                                <th>Position Name</th>
                                                <th>Position Initiated On</th>
                                                <th>Position Initiated By</th>
                                                <th>Department</th>
                                                <th>Position Vacant</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php if(@$manpower_list){ 
                                                //epd($manpower_list);
                                                $sno=0; 
                                                foreach(@$manpower_list as $manpower_Row){ $sno++; ?>
                                            <tr>
                                                <td><?=$sno;?></td>
                                                <td><?=$manpower_Row->position;?></td>
                                                <td><?=$manpower_Row->position_name;?></td>
                                                <td><?=$manpower_Row->position_initiated_on;?></td>
                                                <td><?=$manpower_Row->userfullname;?></td>
                                                <td><?=$manpower_Row->department_name;?></td>
                                                <td><?=$manpower_Row->no_of_position_vacant;?></td> 
                                                <td><a href="<?=base_url('edit_mrf/'.$manpower_Row->fld_id);?>" class="btn btn-success btn-sm" target="_blank">Edit</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                <?php 
                                                if($manpower_Row->lock==1){ ?>
                                                    <span class="btn  btn-sm">Locked</span>
                                                    <?php 
                                                } else {  ?>
                                                    <button type="button" data-lock_id="<?=$manpower_Row->fld_id?>"  class="btn btn-info btn-sm locks">Lock</button>
                                                    <?php
                                                } ?>
                                                
                                            </td>
                                            </tr>
											<?php } } ?>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>S No.</th>
                                                <th>Position</th>
                                                <th>Position Name</th>
                                                <th>Position Initiated On</th>
                                                <th>Position Initiated By</th>
                                                <th>Department</th>
                                                <th>Tensure</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>


	<style>
		#pageloader
		{
			background: rgba( 255, 255, 255, 0.8 );
			display: none;
			height: 100%;
			position: fixed;
			width: 100%;
			z-index: 9999;
			margin-left: -32px!important;
			margin-top: -32px!important;
			text-align:center!important
		}
		#pageloader img
		{
			left: 50%;
			margin-left: -32px;
			margin-top: -32px;
			position: absolute;
			top: 50%;
		}
	</style>
    <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
	<script>
		function lock(fld_id, row_id){
            alert(fld_id);
            alert(row_id);
			$.ajax({
				type: 'POST',
				url: "<?=base_url('lock');?>",
				data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>','fld_id':fld_id,'row_id':row_id},
				dataType: "json",
				beforeSend: function () {
					$('#pageloader').fadeIn();
				},
				success: function (responData) {
					toastr.info(responData.msg, 'Message', {timeOut: 5000});
                    location.reload();
				},
				complete: function () {
					$('#pageloader').fadeOut(5000);
				}
			});
		}
        $(document).on('click','.locks',function(){
            var fld_id = $(this).data('lock_id');
            var row_id = 1;
            lock(fld_id, row_id);
        });
	</script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>
                                                         