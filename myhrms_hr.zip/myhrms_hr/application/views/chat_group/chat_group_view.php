<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Chat</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
						
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (validation_errors()): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= validation_errors(); ?>
                                    </div>
                                <?php endif; ?>
                        </div>

                        <div class="card">
                            <div class="body">
								<a class="btn btn-primary" style="color:white" data-toggle="modal" data-target="#myModal" href="javascript:void(0);">Add Chat Group</a>
								<div class="table-responsive" style="margin-top:20px;" >
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
										<thead>
											<tr>
												<th>S.No.</th>
												<th width="20%">Group Name</th>
												<th width="20%">Group Department</th>
												<th width="20%">Group Members</th>
												<th width="20%">Group Admin</th>
												<th width="20%">Group Image</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										 <?php 
										 if ($group_list) {
                                            foreach ($group_list as $kEy => $dataRow) {
												$file_path = ($dataRow->group_image) ? CHAT_GROUP_IMAGE.$dataRow->group_image : "";
												?>
												<tr>
													<td width="5%"><?= $kEy + 1; ?></td>
													<td width="20%"><?= ($dataRow->group_name) ? $dataRow->group_name : ""; ?></td>
													<td width="20%"><?= ($dataRow->dept_id) ? get_dept_name($dataRow->dept_id) : ""; ?></td>
													<td width="20%">
													<ul>
													<?php 
													if($dataRow->group_members){
														$emp = explode(',',$dataRow->group_members);
														foreach ($emp as $data){?>
															<li><?= get_ro_details_by_Id($data); ?></li>
														<?php }
													}	
													 ?>
													 </ul>
													</td>
													<td width="20%"><?= ($dataRow->group_admin_id) ? get_ro_details_by_Id($dataRow->group_admin_id) : ""; ?></td>
													<td width="20%">
														<a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal" style="cursor:pointer" onclick="show_pic('<?= $file_path?>')">
															<img src="<?= $file_path;?>" style="width:50px; height:50px;" alt="group image">
														</a>
													</td>
													<td width="10%"><a class="btn" href="javascript:void(0);" onclick="seteditupdatedata('<?= $dataRow->id; ?>')" data-toggle="modal" data-target="#myModal2"><i class="fa fa-edit"></i></a><a title="Delete" class="btn" href="javascript:void(0);"  onclick="GroupDelete('<?= $dataRow->id; ?>')"><i class="fa fa-trash"></i></a></td>
												</tr>												
											<?php }
										}?>
										</tbody>
										<tfoot>
											<tr>
												<th>S.No.</th>
												<th width="20%">Group Name</th>
												<th width="20%">Group Department</th>
												<th width="20%">Group Members</th>
												<th width="20%">Group Admin</th>
												<th width="20%">Group Image</th>
												<th>Action</th>
											</tr>
										</tfoot> 
										<tbody>  
										</tbody>
									</table>
                                </div>
                            </div>
                            </div>
                        </div>
                </div>
            </div>
				
	
	<div class="container">
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog" style="margin-top:100px;">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<h5>Add Chat Group</h5>
							<button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
						</div>
						<div class="modal-body">
							<form method="post" action="<?= base_url('group_add');?>" name="frmmChats" id="frmmChats" enctype="multipart/form-data">
                                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
								<div class="row">
									<div class="form-group col-md-12">
										<label >Group Name: </label>
										<input type="text" class="form-control" name="group_name" id="group_name" required>
									</div>
								</div>
								<div class="row">
									<div class="form-group  col-md-12">
										<label >Group Image: </label>
										<input type="file" accept=".gif,.jpg,.jpeg,.png" class="form-control" name="group_image" id="group_image" >
									</div>
								</div>
								
								<div class="row">
									<div class="form-group col-md-12">
										<label>Department: </label>
										<select name="dept_name" class="form-control show-tick ms search-select" id="department" onchange="setSubdptByDpt()" data-placeholder="Select">
											<option value="" selected="selected"> Select Department </option>
												<?php
												$all_Activedepartment = get_departments();
												if ($all_Activedepartment):
													foreach ($all_Activedepartment as $deprow) {
														?>
														<option value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
														<?php
													}
												endif;
												?>
                                        </select>
									</div>
								</div>
								
								<div class="row">
									<div class="form-group col-md-12">
										<label>Group Members: </label>
										<select name="group_members[]" class="form-control select select2" id="group_members" data-placeholder="Select" multiple="multiple">
                                        </select>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-12">
										<input type="hidden" name="group_admin" id="group_admin" value="<?= $user_id;?>" >
										<center><input type="submit" class="btn btn-primary" value="Submit" id="submit"></center>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container">
		<div class="modal fade" id="myModal2" role="dialog">
			<div class="modal-dialog" style="margin-top:100px;">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<h5>Edit Chat Group</h5>
						<button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
					</div>
					<div class="modal-body">
						<form method="post" action="<?= base_url('Chat_Controller/group_update'); ?>" name="frmmGroupupdate" id="frmmGroupupdate" enctype="multipart/form-data">
                                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
							
							<div class="row">
								<div class="form-group col-md-12">
									<label class="email">Group Name: </label>
									<input type="text" class="form-control" name="edit_group_name" id="edit_group_name" required>
								</div>
							</div>
							
							<div class="row">
								<div class="form-group  col-md-12">
									<label class="email">Old Group Image: </label>
									<img src="" name="edit_old_group_image" id="edit_old_group_image" style="width:100px; height:100px; margin-left:20px;" >
								</div>
							</div>
							
							<div class="row">
								<div class="form-group  col-md-12">
									<label class="email">Group Image: </label>
									<input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="edit_group_image" id="edit_group_image">
								</div>
								<input type="hidden" name="old_image_name" id="old_image_name" >
							</div>
							
							<div class="row">
								<div class="form-group col-md-12">
									<label>Department: </label>
									<select name="edit_dept_name" class="form-control show-tick ms search-select" id="edit_department" onchange="setSubdptByDpt2()" data-placeholder="Select">
										<option value="" selected="selected"> Select Department </option>
											<?php
											$all_Activedepartment = get_departments();
											if ($all_Activedepartment):
												foreach ($all_Activedepartment as $deprow) {
													?>
													<option value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
													<?php
												}
											endif;
											?>
									</select>
								</div>
							</div>
							
							<div class="row">
								<div class="form-group col-md-12">
									<label>Group Members: </label>
									<select name="edit_group_members[]" class="form-control select select2" id="edit_group_members" data-placeholder="Select" multiple="multiple">
									</select>
								</div>
								
							</div>
							
							
							<div class="row">
								<div class="form-group col-md-12">
									<input type="hidden" id="group_id" name="group_id">
									<center><input type="submit" class="btn btn-primary" value="Update"></center>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
		
	<div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel"  >
		<div class="modal-dialog" role="document" style="margin-top:200px;">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				<img src="" style="height:450px; width:450px;" id="image_name" name="image_name">
			  </div>
			</div>
		</div>
	</div>	
		
		
	
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script>
		
			//$('#OpenImgUpload').click(function(){ $('#imgupload').trigger('click'); });
			/* function upload_image(){
				alert("ddd");
				file_name = $("#imgupload").val();
				alert(file_name);	
			}
			*/
		
			var timeout = 1000; // in miliseconds (3*1000)
			$('.alert').delay(timeout).fadeOut(3000);
			function setSubdptByDpt() {
                             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
				var dptid = $('#department').val();
				$('#group_members').empty('');
				$.ajax({
					url: "<?= base_url('Chat_Controller/ajax_emp_getbydept'); ?>",
					type: "post",
					dataType: 'json',
					data:{department:dptid},
					success: function (response) {
						$('#group_members').val();
						$('#group_members').append('<option disabled selected>-- Select Group Members --</option>')
						$.each(response, function (index, data){
							$('#group_members').append('<option value="' + data['user_id'] + '">' + data['userfullname'] + '</option>')
						});
						
					}
                                        data:{[csrfName]: csrfHash}, 
				});
			}
			
			function setSubdptByDpt2(){
                         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
			var dptid = $('#edit_department').val();
			$('#edit_group_members').empty('');
			$.ajax({
				url: "<?= base_url('Chat_Controller/ajax_emp_getbydept'); ?>",
				type: "post",
				dataType: 'json',
				data:{department:dptid},
				success: function (response) {
					$('#edit_group_members').val();
					$('#edit_group_members').append('<option disabled selected>-- Select Group Members --</option>')
					$.each(response, function (index, data){
						$('#edit_group_members').append('<option value="' + data['user_id'] + '">' + data['userfullname'] + '</option>')
					});	
				}
                                data:{[csrfName]: csrfHash}, 
			});
		}
			
			
			
		$('form').on('submit', function(){
			var minimum = 1;
			if($("#group_members").select2('data').length>=minimum || $("#edit_group_members").select2('data').length>=minimum){
			}
			else{ 
				alert("Need at least one group member");
				event.preventDefault();
			}
		});
		
		
		
		function GroupDelete(group_id){
			 if (confirm("Are You sure Delete this ? ")){
			  window.location = "<?= base_url('Chat_Controller/delete_group/'); ?>" + group_id;
			}	
		}
	
		function seteditupdatedata(group_id){
                
                 var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
			var path ="<?= CHAT_GROUP_IMAGE?>";
			$.ajax({
				url: '<?= base_url("Chat_Controller/ajax_getsinglegroup_id"); ?>',
				data: ({group_id: group_id}),
				type: 'post',
				success: function (data) {
					var arr = $.parseJSON(data);
					console.log(arr.group_members);
					$("#edit_group_name").val(arr.group_name);
					$("#edit_department").select2("val",arr.dept_id); 
					$("#edit_old_group_image").attr("src",path+arr.group_image);
					$("#old_image_name").val(arr.group_image);
					$("#group_id").val(group_id);
				}
                                data:{[csrfName]: csrfHash}, 
			}); 
		}
		
		function show_pic(image_name){
			//alert(image_name);
			$("#image_name").attr("src",image_name);
		}
		
		
		
		
		</script>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
                                                         