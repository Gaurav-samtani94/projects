<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
#table_length {
    margin-left: 20px;
}

#table_filter {
    margin-right: 2%;
}
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="content">
                    <div class="row clearfix">
                        <div id="loading"
                            style="display: none; position: absolute; top: 10%; left: 42%; text-align: center; z-index: 999999999999;">
                            <img src="<?= FRONTASSETS; ?>images/loader.gif" />
                        </div>

                        <div class="col-lg-12">
                            <?php if ($this->session->flashdata('msg')) { ?>
                            <div class="alert alert-success alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>
                                    <div id="msgs"> Success ! </div>
                                </strong> <?= $this->session->flashdata('msg'); ?>
                            </div>
                            <?php } ?>

                            <?php if ($this->session->flashdata('error')) { ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>
                                    <div id="error"> Oops ! </div>
                                </strong> <?= $this->session->flashdata('error'); ?>
                            </div>
                            <?php } ?>


                            <div class="card">
                                <div class="body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="card-text">
                                                <h6>Financial Year Salary Upload BY Excel.</h6>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="link"><a
                                                        href="<?= HOSTNAME; ?>uploads/salarysheet/salary_sheet.xlsx"
                                                        target="_blank"><i class="fa fa-download"></i> Sample Xlsx
                                                        File</a></label>
                                            </div>
                                        </div>

                                    </div>
                                    <form action="<?= base_url('create_salary_by_csv');?>"
                                        enctype="multipart/form-data" method="post" id="import_form">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="col-sm-4">Month Year: </label>
                                                <div class="mb-3">
                                                    <input type="month" name="from_date" id="from_date"
                                                        class="form-control" value="<?= $fromDates;?>" required>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <label for="salary_file">Salary Upload Excel</label>
                                                <input type="file" class="form-control" id="salary_file"
                                                    name="salary_file" >
                                            </div>

                                            <div class="col-md-3 mt-4">
                                                <div class="col-sm-11">
                                                    <input type="submit" name="go_upload" id="btn-filter"
                                                        class="btn btn-primary" value="Upload" /> &nbsp;&nbsp;
                                                    &nbsp; <a
                                                        href="<?= base_url("Salarysheet_Controller/empSalarySheet"); ?>"
                                                        class="btn btn-default"> Reset </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-2">
                                                <div class="col-sm-11">
                                                    <a href="<?= base_url("verify"); ?>"
                                                        class="btn btn-primary"> Check & Approved</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>


    <?php $this->load->view('admin/includes/footer'); ?>

    <script>
    $(function() {
        $("#emp_id").customselect();
    });

    function get_empId_ajax() {
        //alert("hey");
        var emp_id = $('#emp_id').val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        if (emp_id) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('Salarysheet_Controller/getPayrollCode_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'emp_id': emp_id
                },
                success: function(response) {
                    $('#payrollCode_id').find('option').not(':first').remove();
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $('#payrollCode_id').val(data.payrollcode);
                        // $.each(data, function(index, val) {
                        // $('#payrollCode_id').append('<option value="' + data.payrollcode + '">' +
                        //     data.payrollcode + ' </option>');
                        // });
                    }
                },
            });
        }
    }
    </script>


</body>