<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
				<?php if ($this->session->flashdata('successmsg')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong> <?= $this->session->flashdata('successmsg'); ?>
                    </div>
                <?php } ?>

                <?php if ($this->session->flashdata('errormsg')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('errormsg'); ?>
                    </div>
                <?php } ?>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
								<div style="padding:10px">
									<h5 class="page-title" >Upload Salary Increment CSV:
										<a href="<?= SALARYSAMPLECSV."sample_csv.csv"; ?>" class="btn btn-one">Download Sample Csv</a></h5>
								</div>
                                <form action="<?php echo base_url('update_salary_increment_by_csv'); ?>" method="post" enctype="multipart/form-data">  
									<div class="row filter-row">
										<div class="col-lg-4 col-md-6">
											<label>Select CSV :</label>
											<div class="input-group mb-3">
												<input type="file" required="required" class="form-control" name="salary_file" >
											</div>
										</div>

										<div class="col-sm-2 col-xs-4">  
											<div class="input-group mb-3">
												<button type="submit"  class="btn btn-one pull-right mt-4">Upload</button>
											</div>
										</div>  

									</div>
                                </form> 
                            </div>
                        </div>
                    </div>          
                </div>
                <!--<div class="row clearfix">

                    <div class="col-lg-12">
                        <div class="card">

                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp-Code</th>
                                                <th>Currency</th>
                                                <th>Salary Type </th>
                                                <th>Basic Salary</th>
                                                <th>Bank</th>
                                                <th>Account Holder Name</th>
                                                <th>Account number</th>
                                                <th>Branch Name</th>
                                                <th>IFSC-code</th>
                                                <th>Pan-no</th>
                                                <th>Appraisal Date</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        </tbody>

                                        <tfoot>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp-Code</th>
                                                <th>Currency</th>
                                                <th>Salary Type </th>
                                                <th>Basic Salary</th>
                                                <th>Bank</th>
                                                <th>Account Holder Name</th>
                                                <th>Account number</th>
                                                <th>Branch Name</th>
                                                <th>IFSC-code</th>
                                                <th>Pan-no</th>
                                                <th>Appraisal Date</th>
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>
								<input type="submit" value="Confirm" class="btn btn-success pull-right" style="margin:15px 5px 10px 0">
                            </div>
                        </div>
                    </div>
                </div>-->

            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>
</div>
</div>

<!--================= Modal End ====================-->
<script>


            var table;
            $(document).ready(function () {
                //datatables
                table = $('#table').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "pageLength": -1,
                    "order": [],
                    "ajax": {
                        "url": "<?= base_url('ajax_list_temp_sal_details') ?>",
                        "type": "POST",
                        "data": function (data) {
                            // data.project_id = $('#project_id').val();
                            data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";

                        },
                    },

                    "dom": 'lBfrtip',
                    "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                    ],

                    "columnDefs": [{"searchable": true, "targets": [0], "orderable": false}],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                $('#btn-filter').click(function () {
                    table.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table.ajax.reload();  //just reload table
                });
            });
			
				
function update_main_salary_details(fld_id) {
	alert(fld_id)
	$.ajax({
		url: "<?= base_url('update_temp_to_real_sal_details?fld_id='); ?>" + fld_id,
		type: "POST",
		dataType: 'json',
		success: function (response) {
			alert(response)
			// table.ajax.reload();
			// $('#msg_' + emplid).show();
			// $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
		}
	});
}

function delete_temp_salary_details(fld_id) {
	alert(fld_id)
	// alert(atm_id+"__"+machine_id+"__"+floor_id+"__"+extension_number_)
	$.ajax({
		url: "<?= base_url('delete_temp_salary?fld_id='); ?>" + fld_id,
		type: "GET",
		dataType: 'json',
		success: function (response) {
			alert(response)
			table.ajax.reload();
			// $('#msg_' + emplid).show();
			// $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
		}
	});
}
        </script>
</body>
<?php $this->load->view('admin/includes/footer_updateSal'); ?>