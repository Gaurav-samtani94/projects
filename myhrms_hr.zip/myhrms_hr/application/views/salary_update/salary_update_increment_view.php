<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
.table tbody tr td, .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
				<?php if ($this->session->flashdata('successmsg')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong> <?= $this->session->flashdata('successmsg'); ?>
                    </div>
                <?php } ?>

                <?php if ($this->session->flashdata('errormsg')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('errormsg'); ?>
                    </div>
                <?php } ?>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
								<div class="row">
									<div class="col-md-3">
										<input type="date" class="form-control" name="start_date" id="start_date">
									</div>
									
									<div class="col-md-3">
										<input type="date" class="form-control" name="end_date" id="end_date">
									</div>
									
									<div class="col-md-3">
										<button class="btn btn-one" id="btn-filter">Filter</button>
										<button class="btn btn-success" id="btn-reset">Reset</button>
									</div>
									
									<div class="col-md-3">
										<label>Upload Increment CSV</label>
										<a href="<?= base_url('upload_increment_csv');?>" class="btn btn-one">Go-To</a>
									</div>
									
								</div>
								
								<!--<br><br>
								<div style="padding:10px">
									<h5 class="page-title" >Upload Salary CSV:
										<a href="<?= SALARYSAMPLECSV."sample_csv.csv"; ?>" class="btn btn-primary">Download Sample Csv</a></h5>
								</div>
                                <form action="<?php echo base_url('update_salary_increment_by_csv'); ?>" method="post" enctype="multipart/form-data">  
									<div class="row filter-row">
										<div class="col-lg-4 col-md-6">
											<label>Select CSV :</label>
											<div class="input-group mb-3">
													<input type="file" required="required" class="form-control" name="salary_file" >
											</div>
										</div>

										<div class="col-sm-2 col-xs-4">  
											<div class="input-group mb-3">
												<button type="submit"  class="btn btn-info pull-right mt-4">Upload</button>
											</div>
										</div>  

									</div>
                                </form> -->
                            </div>
                        </div>
                    </div>          
                </div>
                <div class="row clearfix">

                    <div class="col-lg-12">
                        <div class="card">

                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>ID</th>
                                                <th>UserID</th>
                                                <th>Salary ID</th>
                                                <th>salary historyID</th>
                                                <th>appraisal datemmyy</th>
                                                <th>empctc</th>
                                                <th>grosssalary</th>
                                                <th>basicsalary</th>
                                                <th>empepf</th>
                                                <th>loyaltybonus</th>
                                                <th>emp hra</th>
                                                <th>emp esi</th>
                                                <th>projectcomp bonus</th>
                                                <th>special allowance</th>
                                                <th>emp gratuity</th>
                                                <th>transportation allowance</th>
                                                <th>emp sal gpai</th>
                                                <th>tele empsal allowance</th>
                                                <th>education allowance</th>
                                                <th>medical allowance</th>
                                                <th>statutory deduct</th>
                                                <th>sal other</th>
                                                <th>leave travel allowance</th>
                                                <th>food expenses</th>
                                                <th>fuel expenses</th>
                                                <th>vehicle agreement</th>
                                                <th>driver wagers</th>
                                                <th>empctcp1</th>
                                                <th>empctcp2</th>
                                                <th>project allowance</th>
                                                <th>bonus adv</th>
                                                <th>salsec other</th>
                                                <th>grosssal mediclaim</th>
                                                <th>grosssal other</th>
                                                <th>pcb employer</th>
                                                <th>createdby</th>
                                                <th>modifiedby</th>
                                                <th>createddate</th>
                                                <th>modifieddate</th>
                                                <th>isactive</th>
                                                <th>rating grade</th>
                                                <th>increment amnt</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        </tbody>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>ID</th>
                                                <th>UserID</th> 
                                                <th>Salary ID</th>
                                                <th>salary historyID</th>
                                                <th>appraisal datemmyy</th>
                                                <th>empctc</th>
                                                <th>grosssalary</th>
                                                <th>basicsalary</th>
                                                <th>empepf</th>
                                                <th>loyaltybonus</th>
                                                <th>emp hra</th>
                                                <th>emp esi</th>
                                                <th>projectcomp bonus</th>
                                                <th>special allowance</th>
                                                <th>emp gratuity</th>
                                                <th>transportation allowance</th>
                                                <th>emp sal gpai</th>
                                                <th>tele empsal allowance</th>
                                                <th>education allowance</th>
                                                <th>medical allowance</th>
                                                <th>statutory deduct</th>
                                                <th>sal other</th>
                                                <th>leave travel allowance</th>
                                                <th>food expenses</th>
                                                <th>fuel expenses</th>
                                                <th>vehicle agreement</th>
                                                <th>driver wagers</th>
                                                <th>empctcp1</th>
                                                <th>empctcp2</th>
                                                <th>project allowance</th>
                                                <th>bonus adv</th>
                                                <th>salsec other</th>
                                                <th>grosssal mediclaim</th>
                                                <th>grosssal other</th>
                                                <th>pcb employer</th>
                                                <th>createdby</th>
                                                <th>modifiedby</th>
                                                <th>createddate</th>
                                                <th>modifieddate</th>
                                                <th>isactive</th>
                                                <th>rating grade</th>
                                                <th>increment amnt</th>
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>
</div>
</div>

<!--================= Modal End ====================-->
<script>


            var table;
            $(document).ready(function () {
                //datatables
                table = $('#table').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "pageLength": -1,
                    "order": [],
			"scrollY":'62vh',
             "scrollX": true,
                    "ajax": {
                        "url": "<?= base_url('download_increment_sal_csv') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.start_date = $('#start_date').val();
                            data.end_date = $('#end_date').val();
                            data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";

                        },
                    },

                    "dom": 'lBfrtip',
                    "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                    ],

                    "columnDefs": [{"searchable": true, "targets": [0], "orderable": false}],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                $('#btn-filter').click(function () {
                    table.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
					$('#start_date').val('')
					$('#end_date').val('')
                    $('#form-filter')[0].reset();
                    table.ajax.reload();  //just reload table
                });
            });
			
				
function update_main_salary_details(fld_id) {
	alert(fld_id)
	$.ajax({
		url: "<?= base_url('update_temp_to_real_sal_details?fld_id='); ?>" + fld_id,
		type: "POST",
		dataType: 'json',
		success: function (response) {
			alert(response)
			// table.ajax.reload();
			// $('#msg_' + emplid).show();
			// $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
		}
	});
}

function delete_temp_salary_details(fld_id) {
	alert(fld_id)
	// alert(atm_id+"__"+machine_id+"__"+floor_id+"__"+extension_number_)
	$.ajax({
		url: "<?= base_url('delete_temp_salary?fld_id='); ?>" + fld_id,
		type: "GET",
		dataType: 'json',
		success: function (response) {
			alert(response)
			table.ajax.reload();
			// $('#msg_' + emplid).show();
			// $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
		}
	});
}
        </script>
</body>
<?php $this->load->view('admin/includes/footer_updateSal'); ?>