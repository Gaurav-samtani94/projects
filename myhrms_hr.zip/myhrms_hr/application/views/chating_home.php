<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
#company_data_length{
	float: right !important;
	margin-left: 10px;
}
 
.btn{
	margin: 0 2px 0 2px !important;
}

</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
		<div id="main-content">
            <div class="container-fluid">
                <iframe id="myIframe" src="http://172.16.3.154/chat_app"  style="width:100%;height:90vh;background-color:#fff" width="100%" height="90vh" ></iframe>

               
		
        

    </div>
    </div>
    </div>
	
</body>
<?php $this->load->view('admin/includes/footer'); ?>
	<script>
 $('iframe').each(function(){
    function injectCSS(){
        $iframe.contents().find('head').append('<style>.mega-menu:last-child{display:none !important}</style>' );
    }

    var $iframe = $(this);
    $iframe.on('load', injectCSS);
    injectCSS();
});
</script>
  

 
