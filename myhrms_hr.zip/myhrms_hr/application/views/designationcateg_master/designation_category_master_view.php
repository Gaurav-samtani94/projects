<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$ModeofEmployeementArr = ModeofEmployeement();
?>
<body class="theme-cyan">



    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <h5> Manage Designation Category (HRMS & BD) </h5>
                            </div>

                            <form method="post" action="<?= base_url("save_designation_category"); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="tab-pane active" id="official">
                                    <div class="body">
                                        <div class="row clearfix">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Designation Category For : <span id="reqd">*</span></label> <br>
                                                    <select required="required" class="form-control show-tick ms select2" name="bd_hrms" id="bd_hrms" data-placeholder="Select" >
                                                        <option value=""> -- Select-- </option>
                                                        <option value="1"> HRMS </option>
                                                        <option value="2"> BD </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="text-muted">New Designation Category Name : <span id="reqd">*</span></label> <br>
                                                    <input required="required" autocomplete="off" class="form-control" placeholder="eg:- HR Director.." type="text" name="designation_categ" id="designation_categ" value="" >
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-primary" type="submit" value="Add" name="submit" id="submit" >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <h5> Assign Designation on Designation Category </h5>
                            </div>

                            <form method="post" action="<?= base_url("saveupd_assign_designation_oncategory"); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="tab-pane active" id="official">
                                    <div class="body">
                                        <div class="row clearfix">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted">Category Group : <span id="reqd">*</span></label> <br>
                                                    <select required="required" class="form-control show-tick ms select2" onchange="setDesigByDesigCategory()" name="category_group" id="category_group" data-placeholder="Select" >
                                                        <option value=""> -- Select-- </option>
                                                        <option value="1"> HRMS </option>
                                                        <option value="2"> BD </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="text-muted">Designation Category : <span id="reqd">*</span></label> <br>
                                                    <select required="required" class="form-control show-tick ms select2" onchange="setDesignationByDesCategory()" name="DesignationCategory" id="DesignationCategory" data-placeholder="Select" >
                                                        <option value=""> -- Select-- </option> 
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="text-muted">Designation  : <span id="reqd">*</span></label> <br>
                                                    <select multiple="multiple" required="required" class="form-control show-tick ms select2" name="designation_rec[]" id="designation_rec" data-placeholder="Select" >
                                                        <option value=""> -- Select-- </option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-1">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-primary" type="submit" value="Assign" name="submit" id="submit" >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>




                <div class="row clearfix">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">
                                <h5> Designation Category - HRMS </h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Category Name</th>
                                                <th>Tot. Designation</th> 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($DesignationCategoryHrmsArr) {
                                                foreach ($DesignationCategoryHrmsArr as $kEy => $rows) {
                                                    $CountDesignin = CountAssignDesignin_desigCateg($rows->fld_id);
                                                    ?>
                                                    <tr>
                                                        <td><?= ($kEy + 1); ?></td>
                                                        <td><?= ($rows->designation_categ) ? $rows->designation_categ : ""; ?></td>
                                                        <td><span onclick="setdesignation('<?= $rows->bd_hrms ?>', '<?= $rows->fld_id ?>')" data-toggle="modal" data-target="#myModal" style="cursor: pointer; color:green"><?= $CountDesignin; ?></span></td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Category Name</th>
                                                <th>Tot. Designation</th> 
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="body">
                                <h5> Designation Category - BD </h5>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Category Name</th>
                                                <th>Tot. Designation</th> 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($DesignationCategoryBdArr) {
                                                foreach ($DesignationCategoryBdArr as $kEy => $rows) {
                                                    $CountDesignin2 = CountAssignDesignin_desigCateg($rows->fld_id);
                                                    ?>
                                                    <tr>
                                                        <td><?= ($kEy + 1); ?></td>
                                                        <td><?= ($rows->designation_categ) ? $rows->designation_categ : ""; ?></td>
                                                        <td><span onclick="setdesignation('<?= $rows->bd_hrms ?>', '<?= $rows->fld_id ?>')" data-toggle="modal" data-target="#myModal" style="cursor: pointer; color:green"><?= $CountDesignin2; ?></span></td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Category Name</th>
                                                <th>Tot. Designation</th> 
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
                                                    function setDesigByDesigCategory() {
                                                         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                                        var desGroupID = $("#category_group").val();
                                                        $('#DesignationCategory').val("");
                                                        $('#DesignationCategory').empty();
                                                        $('#designation_rec').val("");
                                                        $('#designation_rec').empty();
                                                        if (desGroupID) {
                                                            $.ajax({
                                                                type: 'POST',
                                                                url: '<?= base_url('set_designationcateg_bydesgroup_ajax'); ?>',
                                                                data: {'designgroupid': desGroupID},
                                                                success: function (response) {
                                                                    var data = jQuery.parseJSON(response);
                                                                    if (data) {
                                                                        $.each(data, function (index, val) {
                                                                            $('#DesignationCategory').append('<option value="' + val.fld_id + '">' + val.designation_categ + ' </option>');
                                                                        });
                                                                    }
                                                                },
                                                                        data:{[csrfName]: csrfHash}, 
                                                            });
                                                        }
                                                    }

                                                    //Set Designation By Designation Category And Group..
                                                    function setDesignationByDesCategory() {
                                                     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                                        var desGroupID = $("#category_group").val();
                                                        $.ajax({
                                                            type: 'POST',
                                                            url: '<?php echo base_url('set_designation_bycategory_ajax'); ?>',
                                                            data: {'designgroupid': desGroupID},
                                                            success: function (response) {
                                                                var data = jQuery.parseJSON(response);
                                                                if (data) {
                                                                    $.each(data, function (index, val) {
                                                                        $('#designation_rec').append('<option value="' + val.id + '">' + val.positionname + ' </option>');
                                                                    });
                                                                }
                                                            },
                                                                    data:{[csrfName]: csrfHash}, 
                                                        });
                                                    }

                                                    //Set Designation By Design Category ID
                                                    function setdesignation(GroupID, DesigCategID) {
                                                     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                                        $('#resultSection').html('');
                                                        $.ajax({
                                                            type: 'POST',
                                                            url: '<?= base_url('display_designation_bycategoryid_ajax'); ?>',
                                                            data: {'groupcid': GroupID, 'designgcatid': DesigCategID},
                                                            success: function (response) {
                                                                $('#resultSection').html(response);
                                                            },
                                                                    data:{[csrfName]: csrfHash}, 
                                                        });
                                                    }

    </script>

    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Assign Designation</h4>
                </div>
                <div class="modal-body" id="resultSection"> </div>
                <div class="modal-footer">
                    <button type="button" style="color:red" class="btn btn-default" data-dismiss="modal">X</button>
                </div>
            </div>

        </div>
    </div>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>