<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                   <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>" >Education</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course_name"><?= form_error('course_name'); ?></span>
                                                <label class="text-muted">Course Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="course_name" id="course_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_course_level"><?= form_error('course_level'); ?></span>
                                                <label class="text-muted">Course Level : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="course_level" id="course_level" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_level'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course_offered_by"><?= form_error('course_offered_by'); ?></span>
                                                <label class="text-muted">Course Offered By : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="course_offered_by" id="course_offered_by" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_offered_by'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                                <label class="text-muted">Description : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="description" id="description" onclick="rmvalidationerror(this.id)" value="<?= set_value('description'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_certification_name"><?= form_error('certification_name'); ?></span>
                                                <label class="text-muted">Certification Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="certification_name" id="certification_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('certification_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_marks_obtained"><?= form_error('marks_obtained'); ?></span>
                                                <label class="text-muted">Marks Obtained : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="marks_obtained" id="marks_obtained" onclick="rmvalidationerror(this.id)" value="<?= set_value('marks_obtained'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_issued_date"><?= form_error('issued_date'); ?></span>
                                                <label class="text-muted">Issued Date : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                    <input  type="text" class="form-control" name="issued_date" autocomplete="off" id="issued_date" value="<?= set_value('issued_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit" name="submit" id="submit" >
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Course Name</th>
                                            <th>Course Level</th>
                                            <th>Course Offered By</th>
                                            <th>Description</th>
                                            <th>Certification Name</th>
                                            <th>Marks Obtained</th>
                                            <th>Issued Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$TrainingCertificationRecArr) {
                                            foreach (@$TrainingCertificationRecArr as $kEy => $recD) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= ($recD->course_name) ? $recD->course_name : ""; ?></td>
                                                    <td><?= ($recD->course_level) ? $recD->course_level : ""; ?></td>
                                                    <td><?= ($recD->course_offered_by) ? $recD->course_offered_by : ""; ?></td>
                                                    <td><?= ($recD->description) ? $recD->description : ""; ?></td>
                                                    <td><?= ($recD->certification_name) ? $recD->certification_name : ""; ?></td>
                                                    <td><?= ($recD->marks_obtained) ? $recD->marks_obtained : ""; ?></td>
                                                    <td><?= ($recD->issued_date) ? $recD->issued_date : ""; ?></td>
                                                    <td>
                                                    
                                                    <a class="fa fa-edit"
                                                    data-toggle="modal" data-target="#editTraningModal" href="#" onclick="edit_emp_traning_detail('<?= $recD->id ?>')"></a><br>
&nbsp;&nbsp;
                                                        <a style="cursor:pointer" onclick="deletetrainingcertif('<?= $recD->id ?>')">
                                                            <i class="fa fa-trash"></i>
                                                        </a> 
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                            <tr>
                                                <td style="color:red" colspan="10"> Record Not Found. </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
 <!-- Abbhishek editTraning this  18-10-2022-->
 <div class="modal fade " id="editTraningModal" tabindex="-1" role="dialog" aria-labelledby="editTraningModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTraningModalLabel">Edit Traning</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                 </button>
                </div>
                <form method="post" action="<?= base_url('edit_traning') ?>" >
               
                <div class="modal-body">
                                   <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                 
                                 <input type="hidden" name="emp_id" value="<?= $this->uri->segment(2)?>">
                                   <input type="hidden" name="certificate_id" id="certificate_id">
                                   <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course_name"><?= form_error('course_name'); ?></span>
                                                <label class="text-muted">Course Name : <span id="reqd">*</span></label> <br>
                                                <input type="text" name="course_name" id="edit_course_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_course_level"><?= form_error('course_level'); ?></span>
                                                <label class="text-muted">Course Level : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="course_level" id="edit_course_level" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_level'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course_offered_by"><?= form_error('course_offered_by'); ?></span>
                                                <label class="text-muted">Course Offered By : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="course_offered_by" id="edit_course_offered_by" onclick="rmvalidationerror(this.id)" value="<?= set_value('course_offered_by'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                                <label class="text-muted">Description : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="description" id="edit_description" onclick="rmvalidationerror(this.id)" value="<?= set_value('description'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_certification_name"><?= form_error('certification_name'); ?></span>
                                                <label class="text-muted">Certification Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="certification_name" id="edit_certification_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('certification_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_marks_obtained"><?= form_error('marks_obtained'); ?></span>
                                                <label class="text-muted">Marks Obtained : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="marks_obtained" id="edit_marks_obtained" onclick="rmvalidationerror(this.id)" value="<?= set_value('marks_obtained'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_issued_date"><?= form_error('issued_date'); ?></span>
                                                <label class="text-muted">Issued Date : <span id="reqd">*</span></label> <br>
                                                <div class="input-group ">
                                                    <!-- data-date-autoclose="true" data-provide="datepicker" -->
                                                    <input  type="date" class="form-control" name="issued_date" autocomplete="off" id="edit_issued_date" value="<?= set_value('issued_date'); ?>">
                                                    <!-- <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit" name="submit" id="submit" >
                                            </div>
                                        </div> -->

                                    </div>
                               
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Abhoishek  model for add company -->
    <script>
        function edit_emp_traning_detail(traning_id)
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                url: "<?=base_url('fetch_employee_traning'); ?>",
                type: "POST",
                data: {
                    traning_id: traning_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                // dataType: 'json',
                success: function(ress) {
                    var res = JSON.parse(ress);
                    // alert(a.course_name);
                    $("#certificate_id").val(res.id);
                    $('#edit_course_name').val(res.course_name);
                    $('#edit_course_level').val(res.course_level);
                    $('#edit_course_offered_by').val(res.course_offered_by);
                    $('#edit_description').val(res.description);
                    $('#edit_certification_name').val(res.certification_name);
                    $('#edit_marks_obtained').val(res.marks_obtained);
                    $('#edit_issued_date').val(res.issued_date);

            //         $('#edit_course').html('');
            //         $('#edit_course').append("<option value=''>-- Select degree --</option>");
            //         $.each(res, function(key,val) {
                      
            //             $('#edit_course').append("<option value="+val.id+">"+val.degreename+"</option>");
            //            // $('#Templete_id').html("<option>'"val.letter_templete_name"'</option>")
            //  // alert(val.letter_templete_name);
            //          });

                  

                }
            });

        }
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
        function deletetrainingcertif(fld_id) {
            if (confirm("Are you sure Delete this?")) {
                window.location = "<?= base_url("delete_trainingcertification/"); ?>" + fld_id;
            }
        }
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>

<style>
    span#reqrd {  color: red; }
</style>