<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$skillArrlv = array("" => "", "" => "", "" => "");
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                   <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <div class="tab-content">
                                    <?php $this->load->view("admin/includes/upper-tab"); ?>
                                    <form method="post" action="<?= thisurl(); ?>" >
                                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <div class="row clearfix">
                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_skillname"><?= form_error('skillname'); ?></span>
                                                    <label class="text-muted">Skill Name : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="skillname" id="skillname" onclick="rmvalidationerror(this.id)" value="<?= set_value('skillname'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_training_type"><?= form_error('training_type'); ?></span>
                                                    <label class="text-muted">Training Type : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="training_type" id="training_type" onclick="rmvalidationerror(this.id)" value="<?= set_value('training_type'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_institute_clg_name"><?= form_error('institute_clg_name'); ?></span>
                                                    <label class="text-muted">Name Institute/College : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="institute_clg_name" id="institute_clg_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('institute_clg_name'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_university"><?= form_error('university'); ?></span>
                                                    <label class="text-muted">University : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="university" id="university" onclick="rmvalidationerror(this.id)" value="<?= set_value('university'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">  
                                                    <span id="reqd" class="error_marks_obtained"><?= form_error('marks_obtained'); ?></span>
                                                    <label class="text-muted">Marks Obtained : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="marks_obtained" id="marks_obtained" onclick="rmvalidationerror(this.id)" value="<?= set_value('marks_obtained'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_tenure_from_to"><?= form_error('tenure_from_to'); ?></span>
                                                    <label class="text-muted">Tenure (From - To) : <span id="reqd">*</span></label> <br>
                                                    <input placeholder="eg:- 2018-2019.." autocomplete="off" type="text" name="tenure_from_to" id="tenure_from_to" onclick="rmvalidationerror(this.id)" value="<?= set_value('tenure_from_to'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_percentage_grade"><?= form_error('percentage_grade'); ?></span>
                                                    <label class="text-muted">Percentage / Grade : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" name="percentage_grade" id="percentage_grade" onclick="rmvalidationerror(this.id)" value="<?= set_value('percentage_grade'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_competency_level"><?= form_error('competency_level'); ?></span>
                                                    <label class="text-muted">Competency Level : <span id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="competency_level" id="competency_level" data-placeholder="Select" >
                                                        <option <?= set_select('competency_level', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                        <option <?= set_select('competency_level', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?> value="1"> Basic </option>
                                                        <option <?= set_select('competency_level', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?> value="2"> Expert </option>
                                                        <option <?= set_select('competency_level', "3", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="2"> Medium </option>
                                                    </select>
                                                </div>
                                            </div> 

                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                    <span id="reqd" class="error_year_skill_last_used"><?= form_error('year_skill_last_used'); ?></span>
                                                    <label class="text-muted">Skill Last Used Year : <span id="reqd">*</span></label> <br>
                                                    <input type="date" name="year_skill_last_used" id="year_skill_last_used" onclick="rmvalidationerror(this.id)" value="<?= set_value('year_skill_last_used'); ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">   
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-primary" type="submit" value="Submit" name="extension_number" id="extension_number" >
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>


                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Skill Name</th>
                                            <th>Training Type</th>
                                            <th>Institute/College</th>
                                            <th>University</th>
                                            <th>Tenure</th>
                                            <th>Percentage/Grade</th>
                                            <th>Competency Level</th>
                                            <th>Last Use</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$RecEmplSkillsDetails) {
                                            foreach (@$RecEmplSkillsDetails as $kEy => $recD) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= (@$recD->skillname) ? @$recD->skillname : ""; ?></td>
                                                    <td><?= (@$recD->training_type) ? @$recD->training_type : ""; ?></td>
                                                    <td><?= (@$recD->institute_clg_name) ? @$recD->institute_clg_name : ""; ?></td>
                                                    <td><?= (@$recD->university) ? @$recD->university : ""; ?></td>
                                                    <td><?= (@$recD->tenure_from_to) ? @$recD->tenure_from_to : ""; ?></td>
                                                    <td><?= (@$recD->percentage_grade) ? @$recD->percentage_grade : ""; ?></td>
                                                    <td><?php echo ($recD->competencylevel) ? $recD->competencylevel : "";  ?></td>
                                                    <td><?php echo (@$recD->year_skill_last_used) ? date("Y-m", strtotime($recD->year_skill_last_used)) : "--";  ?></td>
                                                    <td>
                                                       <a href="javascript:void(0)" onclick="editskills('<?= $recD->id ?>')">
                                                    <i class="fa fa-edit" data-toggle="modal"
                                                        data-target="#skillsEditModal"></i>
                                                </a> &nbsp;&nbsp;
                                                        <a style="cursor:pointer" onclick="deleteskills('<?= $recD->id ?>')">
                                                            <i class="fa fa-trash"></i>
                                                        </a> 
                                                    </td>
                                                </tr>
    <?php }
} else { ?>
                                            <tr>
                                                <td style="color:red" colspan="10"> Record Not Found. </td>
                                            </tr>
<?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	 <div class="container">
        <!-- The Modal -->
        <div class="modal" id="skillsEditModal">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h6 class="modal-title">Skills Details</h6>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <form action="<?= base_url('employee/Employee_controller/skillsUpdate')?>" method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Skill Name:</label>
                                        <input type="text" name="skillName" id="skillName" class="form-control"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label> Name Institute/College :</label>
                                        <input type="text" name="institute" id="institute" class="form-control"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label>Marks Obtained:</label>
                                        <input type="text" name="obtained" id="obtained" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Percentage / Grade :</label>
                                        <input type="text" name="percentage" id="percentage" class="form-control"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label>Skill Last Used Year:</label>
                                        <input type="date" name="skillYear" id="skillYear" class="form-control"
                                            required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Training Type:</label>
                                        <input type="text" name="training" id="training" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>University:</label>
                                        <input type="text" name="skillsuniversity" id="skillsuniversity"
                                            class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Tenure (From - To):</label>
                                        <input type="text" name="tenure" id="tenure" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Competency Level:</label>
                                        <select name="competency" id="competency" class="form-control">
                                            <option value="1">Basic</option>
                                            <option value="2">Expert</option>
                                            <option value="3">Medium</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <input type="hidden" name="skillsempId" id="skillsempId" value="<?=$skillsempId;?>">
                            <input type="hidden" name="fId" id="fId" value="">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <button type="button" class="btn btn-secondary float-right"
                                data-dismiss="modal">Close</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
        function deleteskills(fld_id) {
            if (confirm("Are you sure Delete this?")) {
                window.location = "<?= base_url("delete_skill/"); ?>" + fld_id;
            }
        }
    </script>
	 <script>
    function editskills(fld_id) {
        $.ajax({
            type: 'POST',
            dataType: "text",
            url: "<?= base_url('employee/Employee_controller/Get_Single_Record_By_Ajax'); ?>",
            data: {
                'editId': fld_id
            },
            method: 'POST',
            dataType: 'json',
            success: function(response) {
                $('#skillName').val(response.skillname)
                $('#training').val(response.training_type)
                $('#institute').val(response.institute_clg_name)
                $('#skillsuniversity').val(response.university)
                $('#obtained').val(response.marks_obtained)
                $('#tenure').val(response.tenure_from_to)
                $('#percentage').val(response.percentage_grade)
                $('#competency').val(response.competency_level)
                $('#skillYear').val(response.year_skill_last_used)
                $('#fId').val(response.id)

            }
        });
    }
    </script>
<?php $this->load->view('admin/includes/footer'); ?>
</body>