<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>" >Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>" >Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-12">
                                            <div class="card">
                                                <div class="header">
                                                    <h2>Recent Pay Slips </h2>
                                                </div>
                                                <div class="body">
                                                    <div class="row clearfix">
                                                        <div class="col-md-3">  <div class="form-group">  <b class="text-muted"> Sr. No. </b> </div> </div>
                                                        <div class="col-md-3"> <div class="form-group">  <b class="text-muted"> Year </b> </div> </div>
                                                        <div class="col-md-3"> <div class="form-group"> <b class="text-muted"> Month </b>  </div> </div>
                                                        <div class="col-md-3"> <div class="form-group"> <b class="text-muted"> PayRoll Name </b>  </div> </div>
                                                    </div>
                                                    <?php
                                                    if ($RecEmplRecentPayslip) {
                                                        foreach ($RecEmplRecentPayslip as $kEyy1 => $recD) {
                                                            ?>
                                                            <div class="row">
                                                                <div class="col-md-3"> <div class="form-group">
                                                                        <span><?= $kEyy1 + 1; ?></span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <span><?= ($recD->year) ? $recD->year : ""; ?> </span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <span><?= ($recD->month) ? $recD->month : ""; ?> </span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <span><?= ($recD->payroll_with_name) ? $recD->payroll_with_name : ""; ?></span>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12">
                                            <div class="card">
                                                <div class="header">
                                                    <h2>ITR Form </h2>
                                                </div>
                                                <div class="body">
                                                    <div class="row clearfix">
                                                        <div class="col-md-3">  <div class="form-group">  <b class="text-muted"> Sr. No. </b> </div> </div>
                                                        <div class="col-md-4"> <div class="form-group">  <b class="text-muted"> Year </b> </div> </div>
                                                        <div class="col-md-4"> <div class="form-group"> <b class="text-muted"> Pan No. </b>  </div> </div>
                                                    </div>
                                                    <?php
                                                    if ($ITrRecArr) {
                                                        foreach ($ITrRecArr as $kEyy => $recD) { ?>
                                                            <div class="row">
                                                                <div class="col-md-3"> <div class="form-group">
                                                                        <span><?= $kEyy + 1; ?></span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <span><?= ($recD->finyear) ? $recD->finyear : ""; ?></span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <span><?= ($recD->pancardno) ? $recD->pancardno : ""; ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>                     
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $this->load->view('admin/includes/footer'); ?>
    <style>
        span#reqrd { color: red; }
    </style>