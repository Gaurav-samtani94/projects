<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$ModeofEmployeementArr = ModeofEmployeement();
?>
<style>
#pageloader {
    background: rgba(255, 255, 255, 0.8);
    display: none;
    height: 100%;
    position: fixed;
    width: 100%;
    z-index: 9999;
}

#pageloader img {
    left: 50%;
    margin-left: -32px;
    margin-top: -32px;
    position: absolute;
    top: 50%;
}
</style>

<div id="pageloader">
    <img src="http://cdnjs.cloudflare.com/ajax/libs/semantic-ui/0.16.1/images/loader-large.gif" alt="processing..." />
</div>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a>Employee Details </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i
                                            class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active"
                                            href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>">Official</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other
                                            Official</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>">Salary</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>">Personal</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>">Contact</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job
                                            History</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <form method="post" action="<?= thisurl(); ?>" id="empform" name="hrmsempform"
                                enctype="multipart/form-data">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                    value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="tab-content">
                                    <div class="body">

                                        <?php $this->load->view("admin/includes/upper-tab.php"); ?>

                                        <!-- Start Professional -->
                                        <div class="row clearfix">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_recruitment_for"><?= form_error('recruitment_for'); ?></span>
                                                    <label class="text-muted">Recruitment For : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select disabled="disabled" onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="recruitment_for"
                                                        id="recruitment_for" data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->recruitment_for == "") ? "selected" : ""; ?>
                                                            <?= set_select('recruitment_for', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <option
                                                            <?= ($RecEmplDetails->recruitment_for == "1") ? "selected" : ""; ?>
                                                            <?= set_select('recruitment_for', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?>
                                                            value="1"> New </option>
                                                        <option
                                                            <?= ($RecEmplDetails->recruitment_for == "2") ? "selected" : ""; ?>
                                                            <?= set_select('recruitment_for', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?>
                                                            value="2"> Replacement </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="div_replacedwithuserid"
                                                style="<?= ($RecEmplDetails->recruitment_for != "2") ? 'display:none' : ''; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_replaced_with_userid"><?= form_error('replaced_with_userid'); ?></span>
                                                    <label class="text-muted"> Replaced With : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select readonly onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="replaced_with_userid" id="replaced_with_userid"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->replaced_with_userid == "") ? "selected" : ""; ?>
                                                            <?= set_select('replaced_with_userid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if (@$ReplacedWithAllUserListArr) {
                                                            foreach (@$ReplacedWithAllUserListArr as $empRow) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->replaced_with_userid == $empRow->id) ? "selected" : ""; ?>
                                                            <?= set_select('replaced_with_userid', $empRow->id, (!empty($data) && $data == $empRow->id ? TRUE : FALSE)); ?>
                                                            value="<?= $empRow->id; ?>">
                                                            <?= $empRow->userfullname . " [ " . $empRow->employeeId . " ]"; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_prefix_id"><?= form_error('prefix_id'); ?></span>
                                                    <label class="text-muted">Prefix : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="prefix_id"
                                                        id="prefix_id" data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->prefix_id == "") ? "selected" : ""; ?>
                                                            <?= set_select('prefix_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($preFixRecArr) {
                                                            foreach ($preFixRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->prefix_id == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('prefix_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->prefix; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_first_name"><?= form_error('first_name'); ?></span>
                                                    <label class="text-muted">First Name : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" type="text" name="first_name"
                                                        id="first_name"
                                                        value="<?= set_value('first_name', $RecEmplDetails->firstname); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Middle Name : </label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="middle_name" id="middle_name"
                                                        value="<?= set_value('middle_name', $RecEmplDetails->middle_name); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Last Name : </label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="last_name" id="last_name"
                                                        value="<?= set_value('last_name', $RecEmplDetails->lastname); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-1">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employee_code"><?= form_error('employee_code'); ?></span>
                                                    <label class="text-muted">Empid:</label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="employee_code" id="employee_code" readonly
                                                        value="<?= @$EMPCodeRow; ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employee_id"><?= form_error('employee_id'); ?></span>
                                                    <label class="text-muted">Employee ID : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input disabled="disabled" autocomplete="off"
                                                        onclick="rmvalidationerror(this.id)" class="form-control"
                                                        type="text" name="employee_id" id="employee_id"
                                                        value="<?= set_value('employee_id', $RecEmplDetails->employeeId); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_mode_employment"><?= form_error('mode_employment'); ?></span>
                                                    <label class="text-muted">Mode of Employment : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="mode_employment"
                                                        id="mode_employment" data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->modeofentry == '') ? "selected" : ""; ?>
                                                            <?= set_select('mode_employment', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($ModeofEmployeementArr) {
                                                            foreach ($ModeofEmployeementArr as $RecD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->modeofentry == $RecD) ? "selected" : ""; ?>
                                                            <?= set_select('mode_employment', $RecD, (!empty($data) && $data == $RecD ? TRUE : FALSE)); ?>
                                                            value="<?= $RecD; ?>"><?= $RecD; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_role"><?= form_error('role'); ?></span>
                                                    <label class="text-muted"> Role : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms " name="role" id="role"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->emprole == '') ? "selected" : ""; ?>
                                                            <?= set_select('role', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($roleRecArr) {
                                                            foreach ($roleRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->emprole == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('role', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->rolename; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_official_emailid"><?= form_error('official_emailid'); ?></span>
                                                    <label class="text-muted">Official Email : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input class="form-control" autocomplete="off" type="text"
                                                        onclick="rmvalidationerror(this.id)" name="official_emailid"
                                                        id="official_emailid"
                                                        value="<?= set_value('official_emailid', $RecEmplDetails->emailaddress); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                    <label class="text-muted">Business Unit : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="business_unit"
                                                        id="business_unit" onchange="setAllDeptByBunit()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->businessunit_id == '') ? "selected" : ""; ?>
                                                            <?= set_select('business_unit', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($BunitsRecArr) {
                                                            foreach ($BunitsRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->businessunit_id == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('business_unit', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_company_id"><?= form_error('company_id'); ?></span>
                                                    <label class="text-muted">Company : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="company_id"
                                                        id="company_id" data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->company_nameid == '') ? "selected" : ""; ?>
                                                            <?= set_select('company_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($CompanyRecArr) {
                                                            foreach ($CompanyRecArr as $Ckey => $Crows) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->company_nameid == $Crows->id) ? "selected" : ""; ?>
                                                            <?= set_select('company_id', $Crows->id, (!empty($data) && $data == $Crows->id ? TRUE : FALSE)); ?>
                                                            value="<?= $Crows->id; ?>"><?= $Crows->company_name; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_department"><?= form_error('department'); ?></span>
                                                    <label class="text-muted">Department : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="department"
                                                        id="department" onchange="setRepManagerByBunit()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->department_id == '') ? "selected" : ""; ?>
                                                            <?= set_select('department', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($RecEmplDetails->businessunit_id) {
                                                            @$deptArr = GetAllDepartmentByBUnit($RecEmplDetails->businessunit_id);
                                                            if (@$deptArr) {
                                                                foreach (@$deptArr as $reCdd) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->department_id == $reCdd->id) ? "selected" : ""; ?>
                                                            <?= set_select('department', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>
                                                            value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>

                                                        <?php
                                                        if (set_value('business_unit')) {
                                                            @$deptArr = GetAllDepartmentByBUnit(set_value('business_unit'));
                                                            if (@$deptArr) {
                                                                foreach (@$deptArr as $reCdd) {
                                                        ?>
                                                        <option
                                                            <?= set_select('department', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>
                                                            value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_reporting_manager"><?= form_error('reporting_manager'); ?></span>
                                                    <label class="text-muted">Reporting Manager (IO) : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="reporting_manager" id="reporting_manager"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->reporting_manager == '') ? "selected" : ""; ?>
                                                            <?= set_select('reporting_manager', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$RecEmplDetails->reporting_manager) {
                                                            @$reportngmngrArr = GetAllRepManagerByBUnit($RecEmplDetails->businessunit_id);
                                                            if (@$reportngmngrArr) {
                                                                foreach (@$reportngmngrArr as $rePmngr) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->reporting_manager == $rePmngr->user_id) ? "selected" : ""; ?>
                                                            <?= set_select('reporting_manager', $rePmngr->user_id, (!empty($data) && $data == $rePmngr->user_id ? TRUE : FALSE)); ?>
                                                            value="<?= $rePmngr->user_id; ?>">
                                                            <?= $rePmngr->userfullname . " [" . $rePmngr->employeeId . "] "; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }

                                                        if (set_value('reporting_manager')) {
                                                            @$reportngmngrArr = GetAllRepManagerByBUnit(set_value('business_unit'));
                                                            if (@$reportngmngrArr) {
                                                                foreach (@$reportngmngrArr as $rePmngr) {
                                                                ?>
                                                        <option
                                                            <?= set_select('reporting_manager', $rePmngr->user_id, (!empty($data) && $data == $rePmngr->user_id ? TRUE : FALSE)); ?>
                                                            value="<?= $rePmngr->user_id; ?>">
                                                            <?= $rePmngr->userfullname . " [" . $rePmngr->employeeId . "] "; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_job_titlegroup"><?= form_error('job_titlegroup'); ?></span>
                                                    <label class="text-muted">Job Title/Group : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="job_titlegroup"
                                                        id="job_titlegroup" onchange="setDesignationByJobTitID()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->jobtitle_id == '') ? "selected" : ""; ?>
                                                            <?= set_select('job_titlegroup', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($JobGroupRecArr) {
                                                            foreach ($JobGroupRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->jobtitle_id == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('job_titlegroup', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_designation"><?= form_error('designation'); ?></span>
                                                    <label class="text-muted">Designation : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="designation"
                                                        id="designation" data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->position_id == '') ? "selected" : ""; ?>
                                                            <?= set_select('designation', '', (!empty($data) && $data == '' ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($RecEmplDetails->jobtitle_id) {
                                                            @$allDesignationArr = GetAllDesignationByJtitID($RecEmplDetails->jobtitle_id);
                                                            if (@$allDesignationArr) {
                                                                foreach (@$allDesignationArr as $desRow) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->position_id == $desRow->id) ? "selected" : ""; ?>
                                                            <?= set_select('designation', $desRow->id, (!empty($data) && $data == $desRow->id ? TRUE : FALSE)); ?>
                                                            value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }

                                                        if (set_value('designation')) {
                                                            @$allDesignationArr = GetAllDesignationByJtitID(set_value('job_titlegroup'));
                                                            if (@$allDesignationArr) {
                                                                foreach (@$allDesignationArr as $desRow) {
                                                                ?>
                                                        <option
                                                            <?= set_select('designation', $desRow->id, (!empty($data) && $data == $desRow->id ? TRUE : FALSE)); ?>
                                                            value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employment_status"><?= form_error('employment_status'); ?></span>
                                                    <label class="text-muted">Employment Status : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onchange="onemployeeestatus()"
                                                        class="form-control show-tick ms select2"
                                                        name="employment_status" id="employment_status"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->emp_status_id == '') ? "selected" : ""; ?>
                                                            <?= set_select('employment_status', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($EmpStatusArr) {
                                                            foreach ($EmpStatusArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->emp_status_id == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('employment_status', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->employemnt_status; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_dateofjoining"><?= form_error('dateofjoining'); ?></span>
                                                    <label class="text-muted">Date of Joining : <span
                                                            id="reqd">*</span></label> <br>
                                                    <div class="input-group date" data-date-autoclose="true"
                                                        data-provide="datepicker">
                                                        <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                            type="text" class="form-control" name="dateofjoining"
                                                            autocomplete="off" id="dateofjoining"
                                                            value="<?= set_value('dateofjoining', $RecEmplDetails->date_of_joining); ?>">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" type="button"><i
                                                                    class="fa fa-calendar"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Years of Experience (Previous ) : </label>
                                                    <br>
                                                    <input autocomplete="off" type="text"
                                                        value="<?= set_value('yearofexp_prev', $RecEmplDetails->years_exp); ?>"
                                                        name="yearofexp_prev" id="yearofexp_prev" class="form-control">
                                                </div>
                                            </div>
                                            <!-- country code  -->
                                            <div class="col-md-1 pr-0">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_country_mobcode_id"><?= form_error('country_mobcode_id'); ?></span>
                                                    <label class="text-muted">M. Code:</label> <br>
                                                    <?php //= //$RecEmplDetails->country_mobcode_id;?>
                                                    <select name="country_mobcode_id" class="form-control select2 px-1"
                                                        id="country_mobcode_id">
                                                        <option value=""></option>
                                                        <?php $country_code = get_all_country_code();
                                                        $mobile_codes = $RecEmplDetails->country_mobcode_id !="0"?$RecEmplDetails->country_mobcode_id: 100;
                                                        foreach($country_code as $key=>$val)
                                                        {
                                                            ?>
                                                        <option value="<?= $val->id ?>"
                                                            <?= $val->id == $mobile_codes ? "Selected":'';?>>
                                                            <?= $val->country_mob_code?></option>
                                                        <?php
                                                        }
                                                        ?>

                                                    </select>

                                                </div>
                                            </div>
                                            <!-- end country  code -->

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_mob_number"><?= form_error('mob_number'); ?></span>
                                                    <label class="text-muted">Mobile Number : <span
                                                            id="reqd">*</span></label> <br>

                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        type="number"
                                                        value="<?= set_value('mob_number', $RecEmplDetails->office_number); ?>"
                                                        name="mob_number" id="mob_number" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Extension : </label> <br>
                                                    <input autocomplete="off" type="text"
                                                        value="<?= set_value('extension_number', $RecEmplDetails->extension_number); ?>"
                                                        name="extension_number" id="extension_number"
                                                        class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_joining_at"><?= form_error('joining_at'); ?></span>
                                                    <label class="text-muted"> Joining at : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="joining_at"
                                                        id="joining_at" onchange="onprojcondition()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->ofc_locationid == '') ? "selected" : ""; ?>
                                                            <?= set_select('joining_at', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <option
                                                            <?= ($RecEmplDetails->ofc_locationid == '1') ? "selected" : ""; ?>
                                                            <?= set_select('joining_at', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?>
                                                            value="1"> HO - Jaipur </option>
                                                        <option
                                                            <?= ($RecEmplDetails->ofc_locationid == '2') ? "selected" : ""; ?>
                                                            <?= set_select('joining_at', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?>
                                                            value="2"> RO - Delhi </option>
                                                        <option
                                                            <?= ($RecEmplDetails->ofc_locationid == '3') ? "selected" : ""; ?>
                                                            <?= set_select('joining_at', "3", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?>
                                                            value="3"> RO - Mumbai </option>
                                                        <option
                                                            <?= ($RecEmplDetails->ofc_locationid == '4') ? "selected" : ""; ?>
                                                            <?= set_select('joining_at', "4", (!empty($data) && $data == "4" ? TRUE : FALSE)); ?>
                                                            value="4"> On Project </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="onproj_devsection1"
                                                style="<?= ((set_value('joining_at') == '4') or ($RecEmplDetails->ofc_locationid == '4')) ? '' : 'display:none'; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_project_id"><?= form_error('project_id'); ?></span>
                                                    <label class="text-muted"> Project : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="project_id"
                                                        id="project_id" onchange="setproj_designation()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->emp_onproject == '') ? "selected" : ""; ?>
                                                            <?= set_select('project_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if ($ActiveProjectListArr) {
                                                            foreach ($ActiveProjectListArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->emp_onproject == $recD->id) ? "selected" : ""; ?>
                                                            <?= set_select('project_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->project_name; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <!-- project status -->
                                            <div class="col-md-3" id="onemployeestatus1" style="<?php
                                                                                                if ($RecEmplDetails->emp_status_id == '4') {
                                                                                                    echo "";
                                                                                                } elseif ($RecEmplDetails->emp_status_id == '8') {
                                                                                                    echo "";
                                                                                                 } elseif ($RecEmplDetails->emp_status_id == '9') {
                                                                                                    echo "";
                                                                                                 } elseif ($RecEmplDetails->emp_status_id == '10') {
                                                                                                    echo "";
                                                                                                } else {
                                                                                                    echo "display:none";
                                                                                                } ?>">
                                                <div class="form-group">
                                                    <!-- <span id="reqd" class="error_project_id"><? //= form_error('project_id'); 
                                                                                                    ?></span> -->
                                                    <label class="text-muted"> Date (Resigned Date/Demobilized Date) :
                                                        <span id="resigned">*</span></label> <br>
                                                    <input class="form-control" type="date" name="resigned_date"
                                                        id="resignedid"
                                                        value="<?= $RecEmplDetails->date_of_leaving; ?>">
                                                </div>
                                            </div>
                                            <!-- projectstatus end -->
                                            <div class="col-md-3" id="onproj_devsection2"
                                                style="<?= ((set_value('joining_at') == '4') or ($RecEmplDetails->ofc_locationid == '4')) ? '' : 'display:none'; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_project_designationid"><?= form_error('project_designationid'); ?></span>
                                                    <label class="text-muted"> Project Designation : <span
                                                            id="reqd">*</span></label> <br>

                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="project_designationid" id="project_designationid"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= ($RecEmplDetails->emp_project_designation == '') ? "selected" : ""; ?>
                                                            <?= set_select('project_designationid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if (set_value('project_id') or $RecEmplDetails->emp_onproject) {
                                                            @$allProjDesignationArr = GetAllProjDesignationByProjID(set_value('project_id'));
                                                            if (@$allProjDesignationArr == "") {
                                                                @$allProjDesignationArr = GetAllProjDesignationByProjID($RecEmplDetails->emp_onproject);
                                                            }
                                                            if (@$allProjDesignationArr) {
                                                                foreach (@$allProjDesignationArr as $prjRow) {
                                                        ?>
                                                        <option
                                                            <?= ($RecEmplDetails->emp_project_designation == $prjRow->designation_id) ? "selected" : ""; ?>
                                                            <?= set_select('project_designationid', $prjRow->designation_id, (!empty($data) && $data == $desRow->designation_id ? TRUE : FALSE)); ?>
                                                            value="<?= $prjRow->designation_id; ?>">
                                                            <?= $prjRow->designation_name; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Leave Balance : </label>
                                                    <input type="text" value="<?=$RecEmplDetails->emp_leave_limit; ?>"
                                                        class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <!-- <input class="btn btn-primary" type="submit" value="Update"
                                                        name="submit" id="submit"> -->
                                                    <input class="btn btn-primary" type="submit" value="Update"
                                                        name="submit" id="submitButton">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input type="hidden" name="" id="userID"
                                                        value="<?= $this->uri->segment(2); ?>" class="form-control">
                                                    <span class="btn btn-primary pull-right" id="sendMail"
                                                        onclick="sendWelcome_mail()">Send Welcome Mail</span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal HTML (Bootstrap modal) -->
        <div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog"
            aria-labelledby="confirmationModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmationModalLabel">Job History Saved</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        The job history has been successfully saved. You can now proceed.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="proceedButton">Proceed</button>
                    </div>
                </div>
            </div>
        </div>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <?php if ($this->session->userdata('inserted_job_history')): ?>
        <script>
        $(document).ready(function() {
            $('#confirmationModal').modal('show');
        });
        </script>
        <?php endif; ?>

        <script>
        $(document).ready(function() {
            $('#proceedButton').click(function() {
                // Fetch session data from PHP
                $('#confirmationModal').modal('hide');
                $.ajax({
                    url: '<?= base_url("employee/Employee_controller/save_job_history") ?>', // Replace with your controller method
                    type: 'POST',
                    data: {
                        job_history: <?= json_encode($this->session->userdata('inserted_job_history')) ?>
                    },
                    success: function(response) {
                        var parsedResponse = JSON.parse(response);
                        if (parsedResponse.success) {
                            alert('Data saved successfully!');
                        } else {
                            alert('Failed to save data.');
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                    }
                });
            });
        });
        //Send welcome mail to new employee
        // 12bf2f14a86dfa4e5d7ec61bcea7f1a0 
        function sendWelcome_mail() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            var fname = $('#first_name').val();
            var mname = $('#middle_name').val();
            var lname = $('#last_name').val();
            var prefix = $('#prefix_id').val();
            var userID = $('#userID').val();
            // alert(lname)
            $('#pageloader').fadeIn();
            $.ajax({
                type: 'POST',
                url: "<?= base_url('employee/employee_controller/send_welcome_mail_to_new_emp'); ?>",
                data: {
                    'fname': fname,
                    'mname': mname,
                    'lname': lname,
                    'userID': userID
                },
                // data: {[csrfName]: csrfHash},
                success: function(responData) {
                    console.log(responData);
                    // alert("testing ")
                    $('#pageloader').fadeOut();
                    if (responData == 1) {
                        toastr.success("Mail Sent Successfully...!", 'Message', {
                            timeOut: 5000
                        });
                    } else if (responData == 2) {
                        toastr.error("Something Went Wrong...!", 'Message', {
                            timeOut: 5000
                        });
                    }
                },
            });
        }


        function setAllDeptByBunit() {
            var bunitID = $("#business_unit").val();

            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#department').val('');
            $('#department').trigger("change");

            if (bunitID) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                    data: {
                        [csrfName]: csrfHash,
                        'bunitid': bunitID
                    },
                    success: function(response) {
                        var data = jQuery.parseJSON(response);
                        if (data) {
                            $.each(data, function(index, val) {
                                $('#department').append('<option value="' + val.id + '">' + val
                                    .deptname + '</option>');
                            });
                        }
                    },

                });
            }
        }

        //Set Reporting Manager By Bunit..
        function setRepManagerByBunit() {
            var bunitID = $("#business_unit").val();

            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#reporting_manager').val('');
            $('#reporting_manager').trigger("change");

            if (bunitID) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('set_reportingmanager_bybunit_dropd_ajax'); ?>',
                    data: {
                        [csrfName]: csrfHash,
                        'bunitid': bunitID
                    },
                    success: function(response) {
                        var data = jQuery.parseJSON(response);
                        if (data) {
                            $.each(data, function(index, val) {
                                $('#reporting_manager').append('<option value="' + val.user_id +
                                    '">' + val.userfullname + ' [' + val.employeeId +
                                    '] </option>');
                            });
                        }
                    },
                });
            }
        }

        //Set Designation By Job Title..
        function setDesignationByJobTitID() {
            var jobtitleID = $('#job_titlegroup').val();

            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#designation').val('');
            $('#designation').trigger("change");


            if (jobtitleID) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                    data: {
                        [csrfName]: csrfHash,
                        'jtitleid': jobtitleID
                    },
                    success: function(response) {
                        var data = jQuery.parseJSON(response);
                        if (data) {
                            $.each(data, function(index, val) {
                                $('#designation').append('<option value="' + val.id + '">' + val
                                    .positionname + ' </option>');
                            });
                        }
                    },
                });
            }
        }


        //On project Condition..
        function onprojcondition() {
            var joiningat = $('#joining_at').val();
            $('#onproj_devsection1').hide();
            $('#onproj_devsection2').hide();
            if (joiningat == "4") {
                $('#onproj_devsection1').show();
                $('#onproj_devsection2').show();
            }
        }

        function onemployeeestatus() {
            var status = $('#employment_status').val();
            $('#onemployeestatus1').hide();
            var someNumbers = ["4", "8", "10", "9"];
            if ($.inArray(status, someNumbers) >= 0) {
                $('#onemployeestatus1').show();
            }
        }

        function setproj_designation() {
            var projectid = $('#project_id').val();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#project_designationid').empty().append('<option selected="selected" value="">-- Select --</option>');
            $('#project_designationid').trigger("change");

            if (projectid) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url('set_prodesignation_byprojidbd_dropd_ajax'); ?>',
                    data: {
                        [csrfName]: csrfHash,
                        'projid': projectid
                    },
                    success: function(response) {
                        var data = jQuery.parseJSON(response);
                        if (data) {
                            $.each(data, function(index, val) {
                                $('#project_designationid').append('<option value="' + val
                                    .designation_id + '">' + val.designation_name + ' </option>'
                                );
                            });
                        }
                    },

                });
            }
        }

        //Validation Error Removed..
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
        </script>

        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>