<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
@$language_knownArr = array();
@$language_known = @$RecEmplPersonalDetails->language_known;
if (@$language_known) {
    @$language_knownArr = json_decode(@$language_known);
}
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                   <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link active" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_father_nm"><?= form_error('father_nm'); ?></span>
                                                <label class="text-muted">Father Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('father_nm', @$RecEmplPersonalDetails->father_nm); ?>" onclick="rmvalidationerror(this.id)" name="father_nm" id="father_nm" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_mother_nm"><?= form_error('mother_nm'); ?></span>
                                                <label class="text-muted">Mother Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('mother_nm', @$RecEmplPersonalDetails->mother_nm); ?>" onclick="rmvalidationerror(this.id)" name="mother_nm" id="mother_nm" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_genderid"><?= form_error('genderid'); ?></span>
                                                <label class="text-muted">Gender : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="genderid" id="genderid" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplPersonalDetails->genderid == '') ? "selected" : ""; ?> <?= set_select('genderid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($GenderRecArr) {
                                                        foreach ($GenderRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplPersonalDetails->genderid == $recD->id) ? "selected" : ""; ?> <?= set_select('genderid', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->gendername; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_maritalstatusid"><?= form_error('maritalstatusid'); ?></span>
                                                <label class="text-muted">Marital Status : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="maritalstatusid" id="maritalstatusid" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplPersonalDetails->maritalstatusid == '') ? "selected" : ""; ?> <?= set_select('maritalstatusid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($MaritalStatusRecArr) {
                                                        foreach ($MaritalStatusRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplPersonalDetails->maritalstatusid == $recD->id) ? "selected" : ""; ?> <?= set_select('genderid', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->maritalstatusname; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_nationalityid"><?= form_error('nationalityid'); ?></span>
                                                <label class="text-muted">Nationality : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="nationalityid" id="nationalityid" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplPersonalDetails->nationalityid == '') ? "selected" : ""; ?> <?= set_select('nationalityid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($NationalityRecArr) {
                                                        foreach ($NationalityRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplPersonalDetails->nationalityid == $recD->id) ? "selected" : ""; ?> <?= set_select('nationalityid', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->nationalitycode; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_religion"><?= form_error('religion'); ?></span>
                                                <label class="text-muted">Religion : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="religion" id="religion" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplPersonalDetails->religion == '') ? "selected" : ""; ?> <?= set_select('religion', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($ReligionRecArr) {
                                                        foreach ($ReligionRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplPersonalDetails->religion == $recD->id) ? "selected" : ""; ?> <?= set_select('religion', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->religion_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_languageid"><?= form_error('languageid'); ?></span>
                                                <label class="text-muted">Mother Tongue : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="languageid" id="languageid" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplPersonalDetails->languageid == '') ? "selected" : ""; ?> <?= set_select('languageid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($LanguageRecArr) {
                                                        foreach ($LanguageRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplPersonalDetails->languageid == $recD->id) ? "selected" : ""; ?> <?= set_select('religion', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->languagename; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_language_known"><?= form_error('language_known'); ?></span>
                                                <label class="text-muted">Language Known : </label> <br>
                                                <select multiple="multiple" onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="language_known[]" id="language_known" data-placeholder="Select Language Known.." >
                                                    <?php
                                                    if ($LanguageRecArr) {
                                                        foreach ($LanguageRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (in_array($recD->id, @$language_knownArr)) ? "selected" : ""; ?> <?= set_select('language_known', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->languagename; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_dob"><?= form_error('dob'); ?></span>
                                                <label class="text-muted">Date of Birth : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                    <input type="text" class="form-control" value="<?= set_value('dob', @$RecEmplPersonalDetails->dob); ?>" onclick="rmvalidationerror(this.id)" name="dob" autocomplete="off" id="dob" value="">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_bloodgroup"><?= form_error('bloodgroup'); ?></span>
                                                <label class="text-muted">Blood Group : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('bloodgroup', @$RecEmplPersonalDetails->bloodgroup); ?>" name="bloodgroup" id="bloodgroup" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_skypee_id"><?= form_error('skypee_id'); ?></span>
                                                <label class="text-muted">Skypee ID : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('skypee_id', @$RecEmplPersonalDetails->skypee_id); ?>" name="skypee_id" id="skypee_id" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_aadhar_no_enrolment"><?= form_error('aadhar_no_enrolment'); ?></span>
                                                <label class="text-muted">Aadhar No/Enrolment : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('aadhar_no_enrolment', @$RecEmplPersonalDetails->aadhar_no_enrolment); ?>" name="aadhar_no_enrolment" id="aadhar_no_enrolment" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted">Height in Cms : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('height_cms', @$RecEmplPersonalDetails->height_cms); ?>" name="height_cms" id="height_cms" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted">Weight : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('weight', @$RecEmplPersonalDetails->weight); ?>" name="weight" id="weight" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted">Driving Liscence : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('driving_liscence', @$RecEmplPersonalDetails->driving_liscence); ?>" name="driving_liscence" id="driving_liscence" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">   
                                                <label class="text-muted">Ration Card : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('ration_card', @$RecEmplPersonalDetails->ration_card); ?>" name="ration_card" id="ration_card" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">   
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit/Update" name="submit" id="submit" >
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
    </script>

<?php $this->load->view('admin/includes/footer'); ?>
</body>


<style>
    span#reqrd {
        color: red;
    }
</style>