<?php 

$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$ModeofEmployeementArr = ModeofEmployeement();
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class=""><i class="fa fa-users"></i> Employee
                                        List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')) : ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs profile-tabs">
                                    <li class="nav-item"><a class="nav-link active">Official</a></li>
                                    <li class="nav-item"><a class="nav-link">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link">Salary</a></li>
                                    <li class="nav-item"><a class="nav-link">Personal</a></li>
                                    <li class="nav-item"><a class="nav-link">Contact</a></li>
                                    <li class="nav-item"><a class="nav-link">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link">Education</a></li>
                                    <li class="nav-item"><a class="nav-link">Training</a></li>
                                    <li class="nav-item"><a class="nav-link">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link">Family</a></li>
                                    <li class="nav-item"><a class="nav-link">Account</a></li>
                                </ul>
                            </div>


                            <form method="post" action="<?= thisurl(); ?>" id="empform" name="hrmsempform"
                                enctype="multipart/form-data">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                    value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <div class="media">
                                                <div class="media-left m-r-15">
                                                    <img id="blah" height="105" width="100"
                                                        src="<?= HOSTNAME; ?>assets/images/avatar2.jpg"
                                                        class="rounded-circle" alt="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-2">
                                            <div class="media-body">
                                                <input type="text" class="btn btn-default-dark" value="" />
                                                <span style="color:red" id="uploaderror2"> File Upload Error </span>
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input btn"
                                                        name="empprofile_pic" id="inputGroupFile03">
                                                    <label class="custom-file-label" for="inputGroupFile03">Choose
                                                        file</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-8">
                                            <div class="row">
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">CEG </label>
                                                        <p> <?= ($Lt_EMPID_CEG) ? $Lt_EMPID_CEG : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">CEGTH </label>
                                                        <p> <?= ($Lt_EMPID_CEGTH) ? $Lt_EMPID_CEGTH : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">PCC </label>
                                                        <p> <?= ($Lt_EMPID_PCC) ? $Lt_EMPID_PCC : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">TECHNO </label>
                                                        <p> <?= ($Lt_EMPID_TECHNO) ? $Lt_EMPID_TECHNO : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">KCPL </label>
                                                        <p> <?= ($Lt_EMPID_KCPL) ? $Lt_EMPID_KCPL : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">SKES </label>
                                                        <p> <?= ($Lt_EMPID_SKES) ? $Lt_EMPID_SKES : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">VDP </label>
                                                        <p> <?= ($Lt_EMPID_VDP) ? $Lt_EMPID_VDP : ""; ?> </p>
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <div class="form-group">
                                                        <label for="email">CEG Project </label>
                                                        <p> <?= ($Lt_EMPID_CegProj) ? $Lt_EMPID_CegProj : ""; ?> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                </div>


                                <!-- Start Professional -->
                                <div class="tab-pane active" id="official">
                                    <div class="body">

                                        <div class="row clearfix">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_recruitment_for"><?= form_error('recruitment_for'); ?></span>
                                                    <label class="text-muted">Recruitment For : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onchange="ReplacementConSection()"
                                                        onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="recruitment_for"
                                                        id="recruitment_for" data-placeholder="Select">
                                                        <option
                                                            <?= set_select('recruitment_for', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <option
                                                            <?= set_select('recruitment_for', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?>
                                                            value="1"> New </option>
                                                        <option
                                                            <?= set_select('recruitment_for', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?>
                                                            value="2"> Replacement </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="div_replacedwithuserid"
                                                style="<?= (set_value('recruitment_for') != '2') ? 'display:none' : ''; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_replaced_with_userid"><?= form_error('replaced_with_userid'); ?></span>
                                                    <label class="text-muted"> Replaced With : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="replaced_with_userid" id="replaced_with_userid"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('replaced_with_userid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if (@$ReplacedWithAllUserListArr) {
                                                            foreach (@$ReplacedWithAllUserListArr as $empRow) {
                                                        ?>
                                                        <option
                                                            <?= set_select('replaced_with_userid', $empRow->id, (!empty($data) && $data == $empRow->id ? TRUE : FALSE)); ?>
                                                            value="<?= $empRow->id; ?>">
                                                            <?= $empRow->userfullname . " [ " . $empRow->employeeId . " ]"; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_prefix_id"><?= form_error('prefix_id'); ?></span>
                                                    <label class="text-muted">Prefix : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="prefix_id"
                                                        id="prefix_id" data-placeholder="Select">
                                                        <option
                                                            <?= set_select('prefix_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($preFixRecArr) {
                                                            foreach ($preFixRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('prefix_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->prefix; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_first_name"><?= form_error('first_name'); ?></span>
                                                    <label class="text-muted">First Name : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" type="text" name="first_name"
                                                        id="first_name" value="<?= set_value('first_name'); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Middle Name : </label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="middle_name" id="middle_name"
                                                        value="<?= set_value('middle_name'); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Last Name : </label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="last_name" id="last_name"
                                                        value="<?= set_value('last_name'); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-1">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employee_code"><?= form_error('employee_code'); ?></span>
                                                    <label class="text-muted">EmpCode</label> <br>
                                                    <input autocomplete="off" class="form-control" type="text"
                                                        name="employee_code" id="employee_code" readonly
                                                        value="<?= @$EMPCodeRow; ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employee_id"><?= form_error('employee_id'); ?></span>
                                                    <label class="text-muted">Employee ID : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" type="text" name="employee_id"
                                                        id="employee_id" value="<?= set_value('employee_id'); ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_mode_employment"><?= form_error('mode_employment'); ?></span>
                                                    <label class="text-muted">Mode of Employment : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="mode_employment"
                                                        id="mode_employment" data-placeholder="Select">
                                                        <option
                                                            <?= set_select('mode_employment', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($ModeofEmployeementArr) {
                                                            foreach ($ModeofEmployeementArr as $RecD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('mode_employment', $RecD, (!empty($data) && $data == $RecD ? TRUE : FALSE)); ?>
                                                            value="<?= $RecD; ?>"><?= $RecD; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_role"><?= form_error('role'); ?></span>
                                                    <label class="text-muted"> Role : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="role" id="role"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('role', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($roleRecArr) {
                                                            foreach ($roleRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('role', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->rolename; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_official_emailid"><?= form_error('official_emailid'); ?></span>
                                                    <label class="text-muted">Official Email : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text"
                                                        onclick="rmvalidationerror(this.id)"
                                                        value="<?= set_value('official_emailid'); ?>"
                                                        name="official_emailid" id="official_emailid"
                                                        class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                    <label class="text-muted">Business Unit : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="business_unit"
                                                        id="business_unit" onchange="setAllDeptByBunit()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('business_unit', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($BunitsRecArr) {
                                                            foreach ($BunitsRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('business_unit', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_company_id"><?= form_error('company_id'); ?></span>
                                                    <label class="text-muted">Company : <span id="reqd">*</span></label>
                                                    <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="company_id"
                                                        id="company_id" data-placeholder="Select">
                                                        <option
                                                            <?= set_select('company_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($CompanyRecArr) {
                                                            foreach ($CompanyRecArr as $Ckey => $Crows) {
                                                        ?>
                                                        <option
                                                            <?= set_select('company_id', $Crows->id, (!empty($data) && $data == $Crows->id ? TRUE : FALSE)); ?>
                                                            value="<?= $Crows->id; ?>"><?= $Crows->company_name; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_department"><?= form_error('department'); ?></span>
                                                    <label class="text-muted">Department : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="department"
                                                        id="department" onchange="setRepManagerByBunit()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('department', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if (set_value('business_unit')) {
                                                            @$deptArr = GetAllDepartmentByBUnit(set_value('business_unit'));
                                                            if (@$deptArr) {
                                                                foreach (@$deptArr as $reCdd) {
                                                        ?>
                                                        <option
                                                            <?= set_select('department', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>
                                                            value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_reporting_manager"><?= form_error('reporting_manager'); ?></span>
                                                    <label class="text-muted">Reporting Manager (IO) : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="reporting_manager" id="reporting_manager"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('reporting_manager', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if (set_value('reporting_manager')) {
                                                            @$reportngmngrArr = GetAllRepManagerByBUnit(set_value('business_unit'));
                                                            if (@$reportngmngrArr) {
                                                                foreach (@$reportngmngrArr as $rePmngr) {
                                                        ?>
                                                        <option
                                                            <?= set_select('reporting_manager', $rePmngr->user_id, (!empty($data) && $data == $rePmngr->user_id ? TRUE : FALSE)); ?>
                                                            value="<?= $rePmngr->user_id; ?>">
                                                            <?= $rePmngr->userfullname . " [" . $rePmngr->employeeId . "] "; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_job_titlegroup"><?= form_error('job_titlegroup'); ?></span>
                                                    <label class="text-muted">Job Title/Group : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="job_titlegroup"
                                                        id="job_titlegroup" onchange="setDesignationByJobTitID()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('job_titlegroup', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($JobGroupRecArr) {
                                                            foreach ($JobGroupRecArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('job_titlegroup', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_designation"><?= form_error('designation'); ?></span>
                                                    <label class="text-muted">Designation : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="designation"
                                                        id="designation" data-placeholder="Select">
                                                        <option
                                                            <?= set_select('designation', '', (!empty($data) && $data == '' ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if (set_value('designation')) {
                                                            @$allDesignationArr = GetAllDesignationByJtitID(set_value('job_titlegroup'));
                                                            if (@$allDesignationArr) {
                                                                foreach (@$allDesignationArr as $desRow) {
                                                        ?>
                                                        <option
                                                            <?= set_select('designation', $desRow->id, (!empty($data) && $data == $desRow->id ? TRUE : FALSE)); ?>
                                                            value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?>
                                                        </option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_employment_status"><?= form_error('employment_status'); ?></span>
                                                    <label class="text-muted">Employment Status : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="employment_status" id="employment_status"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('employment_status', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select -- </option>
                                                        <?php
                                                        if ($EmpStatusArr) {
                                                            foreach ($EmpStatusArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('employment_status', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->employemnt_status; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_dateofjoining"><?= form_error('dateofjoining'); ?></span>
                                                    <label class="text-muted">Date of Joining : <span
                                                            id="reqd">*</span></label> <br>
                                                    <div class="input-group date" data-date-autoclose="true"
                                                        data-provide="datepicker">
                                                        <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                            type="text" class="form-control" name="dateofjoining"
                                                            autocomplete="off" id="dateofjoining"
                                                            value="<?= set_value('dateofjoining'); ?>">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" type="button"><i
                                                                    class="fa fa-calendar"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Years of Experience (Previous ) : </label>
                                                    <br>
                                                    <input autocomplete="off" type="text"
                                                        value="<?= set_value('yearofexp_prev'); ?>"
                                                        name="yearofexp_prev" id="yearofexp_prev" class="form-control">
                                                </div>
                                            </div>
                                           <!-- country code  -->
                                          <?php /* <div class="col-md-2">
                                                    <span id="reqd"
                                                        class="error_country_mobcode_id"><?= form_error('country_mobcode_id'); ?></span>
                                                    <label class="text-muted">M. Code:</label> <br>
                                                    <select name="country_mobcode_id" class="form-control show-tick ms select2" id="country_mobcode_id">
                                                        <option value=""></option>
                                                        <?php $country_code = get_all_country_code();
                                                        foreach($country_code as $key=>$val)
                                                        {
                                                            ?>
                                                            <option value="<?= $val->id ?>"<?= ($val->id == 100) ? "selected" : "" ?><?=set_select('country_mobcode_id', "$val->id", (!empty($data) && $data == "$val->id" ? TRUE : FALSE)); ?>><?= $val->country_mob_code?></option>
                                                            <?php
                                                        }
                                                        ?>

                                                    </select>
                                            </div>
                                            */ ?>
                                            <!-- end country  code -->
                                            <?php /* <div class="col-md-2">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_mob_number"><?= form_error('mob_number'); ?></span>
                                                    <label class="text-muted">Mobile Number : <span
                                                            id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        type="number" value="<?= set_value('mob_number'); ?>"
                                                        name="mob_number" id="mob_number" class="form-control">
                                                </div>
                                            </div>
                                            */ ?>
                                             <div class="col-md-3">
                                                        <span id="reqd"
                                                            class="error_mob_number"><?= form_error('mob_number'); ?></span>
                                                        <label class="text-muted">Mobile Number : <span
                                                                id="reqd">*</span></label> <br>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <select name="country_mobcode_id"
                                                                    class="form-control show-tick ms select2"
                                                                    id="country_mobcode_id">
                                                                    <?php $country_code = get_all_country_code();
                                                            foreach($country_code as $key=>$val)
                                                            {
                                                                ?>
                                                                    <option value="<?= $val->id ?>"
                                                                        <?= ($val->id == 100) ? "selected" : "" ?>
                                                                        <?=set_select('country_mobcode_id', "$val->id", (!empty($data) && $data == "$val->id" ? TRUE : FALSE)); ?>>
                                                                        <?= $val->country_mob_code?></option>
                                                                    <?php
                                                            } ?>
                                                                </select>
                                                            </div>
                                                            <input autocomplete="off"
                                                                onclick="rmvalidationerror(this.id)" type="number"
                                                                value="<?= set_value('mob_number'); ?>"
                                                                name="mob_number" id="mob_number" class="form-control">
                                                        </div>
                                                    </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Extension : </label> <br>
                                                    <input autocomplete="off" type="text"
                                                        value="<?= set_value('extension_number'); ?>"
                                                        name="extension_number" id="extension_number"
                                                        class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_joining_at"><?= form_error('joining_at'); ?></span>
                                                    <label class="text-muted"> Joining at : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="joining_at"
                                                        id="joining_at" onchange="onprojcondition()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('joining_at', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <option
                                                            <?= set_select('joining_at', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?>
                                                            value="1"> HO - Jaipur </option>
                                                        <option
                                                            <?= set_select('joining_at', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?>
                                                            value="2"> RO - Delhi </option>
                                                        <option
                                                            <?= set_select('joining_at', "3", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?>
                                                            value="3"> RO - Mumbai </option>
                                                        <option
                                                            <?= set_select('joining_at', "4", (!empty($data) && $data == "4" ? TRUE : FALSE)); ?>
                                                            value="4"> On Project </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="onproj_devsection1"
                                                style="<?= (set_value('joining_at') != '4') ? 'display:none' : ''; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_project_id"><?= form_error('project_id'); ?></span>
                                                    <label class="text-muted"> Project : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2" name="project_id"
                                                        id="project_id" onchange="setproj_designation()"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('project_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if ($ActiveProjectListArr) {
                                                            foreach ($ActiveProjectListArr as $keyy => $recD) {
                                                        ?>
                                                        <option
                                                            <?= set_select('project_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                            value="<?= $recD->id; ?>"><?= $recD->project_name; ?>
                                                        </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="onproj_devsection2"
                                                style="<?= (set_value('joining_at') != '4') ? 'display:none' : ''; ?>">
                                                <div class="form-group">
                                                    <span id="reqd"
                                                        class="error_project_designationid"><?= form_error('project_designationid'); ?></span>
                                                    <label class="text-muted"> Project Designation : <span
                                                            id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)"
                                                        class="form-control show-tick ms select2"
                                                        name="project_designationid" id="project_designationid"
                                                        data-placeholder="Select">
                                                        <option
                                                            <?= set_select('project_designationid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                            value=""> -- Select-- </option>
                                                        <?php
                                                        if (set_value('project_id')) {
                                                            @$allProjDesignationArr = GetAllProjDesignationByProjID(set_value('project_id'));
                                                            if (@$allProjDesignationArr) {
                                                                foreach (@$allProjDesignationArr as $prjRow) {
                                                        ?>
                                                        <option
                                                            <?= set_select('project_designationid', $prjRow->designation_id, (!empty($data) && $data == $desRow->designation_id ? TRUE : FALSE)); ?>
                                                            value="<?= $prjRow->designation_id; ?>">
                                                            <?= $prjRow->designation_name; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-one" type="submit" value="Submit"
                                                        name="submit" id="submit">
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
    function setAllDeptByBunit() {
        var bunitID = $("#business_unit").val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#department').val('');
        $('#department').trigger("change");

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
   $('#department').html('');
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#department').append('<option value="' + val.id + '">' + val
                                .deptname + '</option>');
                        });
                    }
                },
            });
        }
    }

    //Set Reporting Manager By Bunit..
    function setRepManagerByBunit() {
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        var bunitID = $("#business_unit").val();

        $('#reporting_manager').val('');
        $('#reporting_manager').trigger("change");
        $('#reporting_manager').val('');
        $('#reporting_manager').html('');

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_reportingmanager_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#reporting_manager').append('<option value="' + val.user_id + '">' +
                                val.userfullname + ' [' + val.employeeId + '] </option>');
                        });
                    }
                },

            });
        }
    }

    function setDesignationByJobTitID() {
        var jobtitleID = $('#job_titlegroup').val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#designation').val('');
        $('#designation').trigger("change");

        if (jobtitleID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'jtitleid': jobtitleID
                },
                success: function(response) {
  $('#designation').html('');
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#designation').append('<option value="' + val.id + '">' + val
                                .positionname + ' </option>');
                        });
                    }
                },
            });
        }
    }

    //On project Condition..
    function onprojcondition() {
        var joiningat = $('#joining_at').val();
        $('#onproj_devsection1').hide();
        $('#onproj_devsection2').hide();
        if (joiningat == "4") {
            $('#onproj_devsection1').show();
            $('#onproj_devsection2').show();
        }
    }

    function setproj_designation() {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        var projectid = $('#project_id').val();

        $('#project_designationid').empty().append('<option selected="selected" value="">-- Select --</option>');
        $('#project_designationid').trigger("change");

        if (projectid) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_prodesignation_byprojidbd_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'projid': projectid
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#project_designationid').append('<option value="' + val
                                .designation_id + '">' + val.designation_name + ' </option>');
                        });
                    }
                },
            });
        }
    }

    //Validation Error Removed..
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#blah').removeAttr('src');
                $('#blah').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $(document).ready(function() {
        $("#uploaderror2").hide();
        $("#uploaderror3").hide();
        $('INPUT[type="file"]').change(function() {
            var ext = this.value.match(/\.(.+)$/)[1];
            switch (ext) {
                case 'jpg':
                case 'JPG':
                case 'jpeg':
                case 'JPGE':
                case 'png':
                case 'PNG':
                    $('#uploadButton').attr('disabled', false);
                    $("#uploaderror2").hide();
                    break;
                default:
                    $("#uploaderror2").show();
                    $("#uploaderror2").html('This is not an allowed file type.');
                    this.value = '';
            }
        });
        $('INPUT[type="file"]').bind('change', function() {
            var imgfilesize = (this.files[0].size / 1020);
            if (imgfilesize > 1020) {
                $("#uploaderror2").show();
                $("#uploaderror2").html('Reducing File Size Max Uploads (1000 KB). ');
                this.value = '';
            } else {
                $("#uploaderror2").hide();
                readURL(this);
            }
        });
    });


    $(function() {
        // photo upload
        $('#btn-upload-photo').on('click', function() {
            $(this).siblings('#filePhoto').trigger('click');
        });
        // Plans
        $('.btn-choose-plan').on('click', function() {
            $('.plan').removeClass('selected-plan');
            $('.plan-title span').find('i').remove();
            $(this).parent().addClass('selected-plan');
            $(this).parent().find('.plan-title').append(
                '<span><i class="fa fa-check-circle"></i></span>');
        });
    });


    //Condition Script for Replaced By..
    function ReplacementConSection() {
        var recruitment_for = $('#recruitment_for').val();

        $('#replaced_with_userid').val("");
        $('#replaced_with_userid').trigger("change");

        $('#div_replacedwithuserid').hide();
        if (recruitment_for == "2") {
            $('#div_replacedwithuserid').show();
        }
    }
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>