<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
  
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">

  </head>
  <body style=" background-color: #f5f5f5; width: 100%;margin: 0;padding: 15px;">
	<table style="width: 100%;">
		<tbody>
			<tr>
				<th style="text-align: left;">
					<img src="https://www.cegindia.com/public/assets/site//images/logo.png" style="width: 150px;">
				</th>
				<th style="text-align: right;">
					<p style="font-size: 12px;" >CEG Tower, B-11(G), Malviya Industrial Area, Jaipur, Rajasthan, 302017 <i class="fas fa-map-marker-alt ml-3 fa-1x"></i></p>
								<p style="font-size: 12px;">+91-141-2751801-02-05  <i class="fas fa-phone ml-3 fa-1x"></i></p>
				</th>
			</tr>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 15px;">
		<tbody>
			<tr>
				<td style="width: 80px;" rowspan="2">
				<?php 
						if($empDetail->profileimg): ?>
							<img src="<?= EMPLPROFILE.$empDetail->profileimg;?>" style="width:80px">
						<?php else: ?>
							<img src="https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg" style="width:80px">
						<?php endif;?>
					<!--<img src="https://hrms.cegindia.com/myhrms/public/login-short-img.jpg" style="width:80px">-->
				</td>
				<td colspan="3">
					<h3 style="font-size: 22px;;font-weight: bold;"><?= $empDetail->userfullname;?></h3>
				</td>
			</tr>
			<tr style="padding-top:5px">
				<td colspan="3">
					<p style="font-size: 16px;color:red"><?= $empDetail->position_name;?></p>
				</td>
			</tr>
			<tr style="padding-top:10px">
				<td colspan="4">
					<h4 style="font-size: 18px;"><u>Personal Details</u></h4>
				</td>
			</tr>
			<tr style="margin-top:10px">
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mother's Name</td>
				<td style="font-size:12px">: <?= $empDetail->mother_nm;?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mother's Contact No</td>
				<td style="font-size:12px">: <?= ($empDetail->mothers_contact_no) ? $empDetail->mothers_contact_no : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Father's Name</td>
				<td style="font-size:12px">: <?= $empDetail->father_nm;?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Father's Contact No</td>
				<td style="font-size:12px">: <?= ($empDetail->fathers_contact_no) ? $empDetail->fathers_contact_no : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Gender</td>
				<td style="font-size:12px">: <?= ($empDetail->gendername) ? $empDetail->gendername : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Marital Status</td>
				<td style="font-size:12px">: <?= $empDetail->maritalstatusname;?></td>
			</tr>
			<?php if($empDetail->maritalstatusname == "Married"):?>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Marriage Date</td>
				<td style="font-size:12px">: <?= ($empDetail->marriage_date) ? date("d-m-Y",strtotime($empDetail->marriage_date)) : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Spouse Name</td>
				<td style="font-size:12px">: <?= ($empDetail->spouse_name) ? $empDetail->spouse_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Spouse Occupation</td>
				<td style="font-size:12px">: <?= ($empDetail->spouse_occupation) ? $empDetail->spouse_occupation : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Spouse Contact No.</td>
				<td style="font-size:12px">: <?= ($empDetail->spouse_contact_no) ? $empDetail->spouse_contact_no : "--";?></td>
			</tr>
			<?php endif;?>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Nationality</td>
				<td style="font-size:12px">: <?= $empDetail->nationalitycode;?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mother Tongue</td>
				<td style="font-size:12px">: ---</td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Date of Birth</td>
				<td style="font-size:12px">: <?= ($empDetail->dob) ? date("d-m-Y",strtotime($empDetail->dob)) : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Blood Group</td>
				<td style="font-size:12px">: <?= ($empDetail->bloodgroup) ? $empDetail->bloodgroup : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Height (cm)</td>
				<td style="font-size:12px">: <?= ($empDetail->height_cms) ? $empDetail->height_cms : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Weight</td>
				<td style="font-size:12px">: <?= ($empDetail->weight) ? $empDetail->weight : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Religion</td>
				<td style="font-size:12px">: <?= $empDetail->religion_name;?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Passport No.</td>
				<td style="font-size:12px">: <?= ($empDetail->passport_no) ? $empDetail->passport_no : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Pan No.</td>
				<td style="font-size:12px">: <?= ($empDetail->pancard_no) ? $empDetail->pancard_no : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Driving License No.</td>
				<td style="font-size:12px">: <?= ($empDetail->driving_liscence) ? $empDetail->driving_liscence : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Ration Card</td>
				<td style="font-size:12px">: <?= ($empDetail->ration_card) ? $empDetail->ration_card : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Aadhar No.</td>
				<td style="font-size:12px">: <?= ($empDetail->aadhar_no_enrolment) ? $empDetail->aadhar_no_enrolment : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">SkyPee (Personal)</td>
				<td style="font-size:12px">: ---</td>
			</tr>
		</tbody>
	</table>
	
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;">
		<tbody>
			<tr style="padding-top:10px">
				<td colspan="4">
					<h4 style="font-size: 18px;"><u>Official Details</u></h4>
				</td>
			</tr>
			<tr style="margin-top:10px">
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employee Code</td>
				<td style="font-size:12px">: <?= ($empDetail->employeeId) ? $empDetail->employeeId : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Title</td>
				<td style="font-size:12px">: ---</td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">First Name</td>
				<td style="font-size:12px">: <?= ($empDetail->firstname) ? $empDetail->firstname : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Last Name</td>
				<td style="font-size:12px">: <?= ($empDetail->lastname) ? $empDetail->lastname : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Official Email</td>
				<td style="font-size:12px">: <?= ($empDetail->emailaddress) ? $empDetail->emailaddress : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Business Unit</td>
				<td style="font-size:12px">: <?= ($empDetail->businessunit_name) ? $empDetail->businessunit_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Notice Period</td>
				<td style="font-size:12px">: <?= ($empDetail->noticeperiod) ? $empDetail->noticeperiod : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Reporting Manager (RO)</td>
				<td style="font-size:12px">: <?= ($empDetail->roName) ? get_ro_details_by_Id($empDetail->roName) : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Reporting Manager (IO)</td>
				<td style="font-size:12px">: <?= ($empDetail->reporting_manager_name) ? $empDetail->reporting_manager_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Job Group</td>
				<td style="font-size:12px">: <?= ($empDetail->jobtitle_name) ? $empDetail->jobtitle_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Role</td>
				<td style="font-size:12px">: <?= ($empDetail->rolename) ? $empDetail->rolename : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Employment Status</td>
				<td style="font-size:12px">: <?= ($empDetail->emp_status_name) ? $empDetail->emp_status_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Designation</td>
				<td style="font-size:12px">: <?= ($empDetail->position_name) ? $empDetail->position_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Sub Department</td>
				<td style="font-size:12px">: <?= ($empDetail->sub_department) ? $empDetail->sub_department : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Department</td>
				<td style="font-size:12px">: <?= ($empDetail->department_name) ? $empDetail->department_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Company Name</td>
				<td style="font-size:12px">: <?= ($empDetail->sub_department) ? $empDetail->sub_department : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Date of Joining</td>
				<td style="font-size:12px">: <?= ($empDetail->date_of_joining) ? date("d-m-Y",strtotime($empDetail->date_of_joining)) : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Mobile Number</td>
				<td style="font-size:12px">: <?= ($empDetail->contactnumber) ? $empDetail->contactnumber : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Years of Experience</td>
				<td style="font-size:12px">: <?= ($empDetail->years_exp) ? $empDetail->years_exp : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Probation Period</td>
				<td style="font-size:12px">: <?= ($empDetail->probation_period_no) ? $empDetail->probation_period_no." days" : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Extension</td>
				<td style="font-size:12px">: <?= ($empDetail->extension_number) ? $empDetail->extension_number : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Date of Leaving</td>
				<td style="font-size:12px">: <?= ($empDetail->date_of_leaving) ? date("d-m-Y",strtotime($empDetail->date_of_leaving)) : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Notice Period</td>
				<td style="font-size:12px">: <?= ($empDetail->noticeperiod) ? $empDetail->noticeperiod." Days" : "--";?></td>
			</tr>
		</tbody>
	</table>
	
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;">
		<tbody>
			<tr style="padding-top:10px">
				<td colspan="4">
					<h4 style="font-size: 18px;"><u>Permanent Address</u></h4>
				</td>
			</tr>
			<tr style="margin-top:10px">
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Street Address</td>
				<td style="font-size:12px" colspan="3">: <?= ($contact->perm_streetaddress) ? $contact->perm_streetaddress : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Country</td>
				<td style="font-size:12px">: <?= ($contact->per_country_name) ? $contact->per_country_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">State</td>
				<td style="font-size:12px">: <?= ($contact->perm_state_name) ? $contact->perm_state_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">City</td>
				<td style="font-size:12px">: <?= ($contact->perm_city_name) ? $contact->perm_city_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Pin Code</td>
				<td style="font-size:12px">: <?= ($contact->perm_pincode) ? $contact->perm_pincode : "--";?></td>
			</tr>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;">
		<tbody>
			<tr style="padding-top:10px">
				<td colspan="4">
					<h4 style="font-size: 18px;"><u>Current Address</u></h4>
				</td>
			</tr>
			<tr style="margin-top:10px">
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Street Address</td>
				<td style="font-size:12px" colspan="3">: <?= ($contact->current_streetaddress) ? $contact->current_streetaddress : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Country</td>
				<td style="font-size:12px">: <?= ($contact->current_country_name) ? $contact->current_country_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">State</td>
				<td style="font-size:12px">: <?= ($contact->current_state_name) ? $contact->current_state_name : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">City</td>
				<td style="font-size:12px">: <?= ($contact->current_city_name) ? $contact->current_city_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Pin Code</td>
				<td style="font-size:12px">: <?= ($contact->current_pincode) ? $contact->current_pincode : "--";?></td>
			</tr>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;">
		<tbody>
			<tr style="padding-top:10px">
				<td colspan="4">
					<h4 style="font-size: 18px;"><u>Emergency Details</u></h4>
				</td>
			</tr>
			
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Name</td>
				<td style="font-size:12px">: <?= ($contact->emergency_name) ? $contact->emergency_name : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Relation</td>
				<td style="font-size:12px">: <?= ($contact->emergency_namerelation) ? $contact->emergency_namerelation : "--";?></td>
			</tr>
			<tr>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Email</td>
				<td style="font-size:12px">: <?= ($contact->emergency_email) ? $contact->emergency_email : "--";?></td>
				<td style="color: #20247b;font-weight: 600;width: 120px;font-size:12px">Contact No</td>
				<td style="font-size:12px">: <?= ($contact->emergency_number) ? $contact->emergency_number : "--";?></td>
			</tr>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
		
		<thead>
		<tr >
			<td colspan="9"  style="padding:10px"><h4 style="font-size: 18px;"><u>Experience Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Company Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Company Website</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Company Location</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Designation</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">From</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">To</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Last Salary (Withdrawn)</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Reason for Leaving</th>
			</tr>
		</thead>
		<tbody>
			
			<?php
				if($experience):
				foreach($experience as $key => $value):?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->comp_name) ? $value->comp_name : ""; ?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->comp_website) ? $value->comp_website : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->comp_location) ? $value->comp_location : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->designation) ? $value->designation : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->from_date) ? date("d-m-Y",strtotime($value->from_date)) : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->to_date) ? date("d-m-Y",strtotime($value->to_date)) : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->last_salary_drawn) ? $value->last_salary_drawn : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->reason_for_leaving) ? $value->reason_for_leaving : "--";?></td>	
					</tr>
				<?php endforeach; else:?>
					<tr>
						<td colspan="9" style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red">No Record Found</td>	
					</tr>
				<?php endif;?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
	
		<thead>
		<tr >
			<td colspan="5"  style="padding:10px"><h4 style="font-size: 18px;"><u>Skills Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Skill Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Years Experience</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Competency Level</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Last Use</th>
			</tr>
		</thead>
		<tbody>
			<?php
				if($skill):
				foreach($skill as $key => $value):?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->skillname) ? $value->skillname : ""; ?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->yearsofexp) ? $value->yearsofexp : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->competencylevel) ? $value->competencylevel : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->year_skill_last_used) ? date("d-m-Y",strtotime($value->year_skill_last_used)) : "--";?></td>
					</tr>
				<?php endforeach; else:?>
					<tr>
						<td colspan="5" style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red">No Record Found</td>	
					</tr>
				<?php endif;?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
		
		<thead>
		<tr >
			<td colspan="9"  style="padding:10px"><h4 style="font-size: 18px;"><u>Education Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Education Level</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Institution Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Course</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Location</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Specialization</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Passing Year</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Marks Obtained</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Percentage</th>
			</tr>
		</thead>
		<tbody>
			<?php
				if($eduDetail):
				foreach($eduDetail as $key => $value):?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->educationlevel) ? $value->educationlevel : ""; ?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->institution_name) ? $value->institution_name : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->course) ? $value->course : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->spc_location) ? $value->spc_location : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->specialization) ? $value->specialization : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->from_date) ? date("d-m-Y",strtotime($value->from_date)) : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->marks_obtained) ? $value->marks_obtained : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->percentage) ? $value->percentage : "--";?></td>	
					</tr>
				<?php endforeach; else:?>
					<tr>
						<td colspan="9" style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red">No Record Found</td>	
					</tr>
				<?php endif;?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
		
		<thead>
		<tr >
			<td colspan="6"  style="padding:10px"><h4 style="font-size: 18px;"><u>Family Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Family Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Family Relation</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Family DOB</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Aadhar Number</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Dependent or Not</th>
				
			</tr>
		</thead>
		<tbody>
			<?php
				if($family):
				foreach($family as $key => $value):?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->dependent_name) ? $value->dependent_name : ""; ?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->dependent_relation) ? $value->dependent_relation : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->dependent_dob) ? date("d-m-Y",strtotime($value->dependent_dob)) : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->aadhar_no) ? $value->aadhar_no : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->dependent_select) ? $value->dependent_select : "--";?></td>
					</tr>
				<?php endforeach; else:?>
					<tr>
						<td colspan="6" style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red">No Record Found</td>	
					</tr>
				<?php endif;?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
		
		<thead>
		<tr >
			<td colspan="6"  style="padding:10px"><h4 style="font-size: 18px;"><u>References Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Reference Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Organisation</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Designation</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Contact Number</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Reference Type</th>
				
			</tr>
		</thead>
		<tbody>
			<?php
				if($referencesDetails):
				foreach($referencesDetails as $key => $value):?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->reference_name) ? $value->reference_name : ""; ?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->organisation) ? $value->organisation : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->designation) ? $value->designation : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->contact_no) ? $value->contact_no : "--";?></td>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= ($value->reference_type) ? $value->reference_type : "--";?></td>
					</tr>
				<?php endforeach; else:?>
					<tr>
						<td colspan="6" style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red">No Record Found</td>	
					</tr>
				<?php endif;?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;background-color:#e5e5e5;padding:15px;border-radius: 10px;border-collapse: collapse;">
		
		<thead>
		<tr >
			<td colspan="3"  style="padding:10px"><h4 style="font-size: 18px;"><u>Documents Details</u></h4></td>
		</tr>
			<tr>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Sr.No.</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Doc Name</th>
				<th style="color: #fff;background-color: #5a919b;border: 1px solid #ccc;font-weight: 600;font-size:12px;padding:3px">Doc Detail</th>
				
			</tr>
		</thead>
		<tbody>
			<?php
				if ($empDocs) {
					foreach ($empDocs as $kEy => $recD) {
						if ($recD->attachments) {
							$docsArray = json_decode($recD->attachments);
						}
						?>
						<tr>
							<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= $key+1;?></td>
							<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?= (@$recD->name) ? @$recD->name : ""; ?></td>
							<td style="font-size:12px;border: 1px solid #ccc;padding:3px"><?php
								echo (@$docsArray[0]->new_name) ? "<a target='_blank' href='" . EMPLOYEEDOCS . $docsArray[0]->new_name . "'> View / Download </a>" : "";
								?></td>
						</tr>
						
						<?php
					}
				} else {
					?>
					<tr>
						<td style="font-size:12px;border: 1px solid #ccc;padding:3px; text-align:center;color:red" colspan="3"> Record Not Found. </td>
					</tr>
				<?php } ?>
		</tbody>
	</table>
	<table style="width: 100%;margin-top: 25px;padding:15px;">
		
		
		<tbody style="border-top: 1px solid #ccc;">
		<tr>
			<td colspan="2"  style="padding-top:10px;padding-bottm:10px"><h4 style="font-size: 18px;"><u>Others Detail</u></h4></td>
		</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Candidate Source</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->candidate_source) ? $empOtherDetail->candidate_source : "--"; ?></td>
			</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Have you ever been convicted of a criminal offence</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->criminal_offense) ? $empOtherDetail->criminal_offense : "--"; ?></td>
			</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Have you ever been under medical treatment / counselling for drug or alcohol abuse</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->drug_alcohal_abuse) ? $empOtherDetail->drug_alcohal_abuse : "--"; ?></td>
			</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Have you any pre existing medical condition / illness</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->pre_existing_illness) ? $empOtherDetail->pre_existing_illness : "--"; ?></td>
			</tr>
			<tr >
				<td style="font-size:12px;width:80%; padding-top:10px;">Do you suffer from any partial defect or partial disability</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->partial_disabilities) ? $empOtherDetail->partial_disabilities : "--"; ?></td>
			</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Do you have any relative employed in CEG or any subsidiary of CEG</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->relative_employed_ceg) ? $empOtherDetail->relative_employed_ceg : "--"; ?></td>
			</tr>
			<tr>
				<td style="font-size:12px;width:80%; padding-top:10px;">Have you been previously employed with CEG</td>
				<td style="font-size:12px; padding-top:10px;">: <?= ($empOtherDetail->previous_employed_with_ceg) ? $empOtherDetail->previous_employed_with_ceg : "--"; ?></td>
			</tr>
		</tbody>
	</table>
	
	<table style="width: 100%;margin-top: 25px;padding:15px;">
		
		
		<tbody>
		
			<tr>
				<td style="font-size:12px;width:15%; padding-top:10px;">Date & Time</td>
				<td style="font-size:12px;width:45%; padding-top:10px;">_ _ _ _ _ _ _ _ _ _ _ _ _ _ _</td>
				<td style="font-size:12px;width:10%; padding-top:10px;">Signature </td>
				<td style="font-size:12px; padding-top:10px;">_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _</td>
			</tr>
		</tbody>
	</table>
	
  </body>
</html>