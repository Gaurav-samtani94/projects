<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
      
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        
        ?>
         <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i
                                            class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    
                </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                <?= form_error(); ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>




                <!-- abhi -->   
              



                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>">Official</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other
                                            Official</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>">Salary</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>">Personal</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>">Contact</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job
                                            History</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link active">Education</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                
                                <form method="post" action="<?= thisurl(); ?>">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_educationlevel"><?= form_error('educationlevel'); ?></span>
                                                <label class="text-muted">Education Level : <span
                                                        id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control show-tick ms select2" name="educationlevel"
                                                    id="educationlevel" data-placeholder="Select" onchange="fetch_degrees()">
                                                    <option
                                                        <?= set_select('educationlevel', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                    if ($EducationLevelRecArr) {
                                                        foreach ($EducationLevelRecArr as $keyy => $recD) {
                                                            ?>
                                                    <option
                                                        <?= set_select('educationlevel', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->educationlevelcode; ?>
                                                    </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course"><?= form_error('course'); ?></span>
                                              
                                                <label class="text-muted">Degree Name: <span id="reqd">*</span></label>
                                                  <span ><a class="fa fa-plus"
                                                    data-toggle="modal" data-target="#educationModel" href="#"></a></span>
                                                <br>
                                                <select  name="course" id="course" onclick="rmvalidationerror(this.id)" class="form-control select2">
<option value=""> -- Select degree --</option>
                                                </select>
                                                <!-- <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="course" id="course"
                                                    value="<?= set_value('course'); ?>" class="form-control"> -->
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_coursetype_id"><?= form_error('coursetype_id'); ?></span>
                                                <label class="text-muted">Course Type : <span id="reqd">*</span></label>
                                                <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control show-tick ms" name="coursetype_id"
                                                    id="coursetype_id" data-placeholder="Select">
                                                    <option
                                                        <?= set_select('coursetype_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                    if ($CourseTypeRecArr) {
                                                        foreach ($CourseTypeRecArr as $keyy => $recD) {
                                                            ?>
                                                    <option
                                                        <?= set_select('coursetype_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->course_name; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_institution_name"><?= form_error('institution_name'); ?></span>
                                                <label class="text-muted">Institution Name : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="institution_name" id="institution_name"
                                                    class="form-control" value="<?= set_value('institution_name'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_board_university"><?= form_error('board_university'); ?></span>
                                                <label class="text-muted">Board / University : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="board_university" id="board_university"
                                                    class="form-control" value="<?= set_value('board_university'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_marks_obtained"><?= form_error('marks_obtained'); ?></span>
                                                <label class="text-muted">Marks Obtained : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('marks_obtained'); ?>"
                                                    name="marks_obtained" id="marks_obtained" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_from_date"><?= form_error('from_date'); ?></span>
                                                <label class="text-muted">From : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input type="text" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" name="from_date" autocomplete="off"
                                                        id="from_date" value="<?= set_value('from_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_to_date"><?= form_error('to_date'); ?></span>
                                                <label class="text-muted">To : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input type="text" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" name="to_date" autocomplete="off"
                                                        id="to_date" value="<?= set_value('to_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_stream"><?= form_error('stream'); ?></span>
                                                <label class="text-muted">Stream : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="stream" id="stream"
                                                    value="<?= set_value('stream'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_stream"><?= form_error('percentage'); ?></span>
                                                <label class="text-muted">Percentage / Grade : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('percentage'); ?>"
                                                    name="percentage" id="percentage" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_spc_location"><?= form_error('spc_location'); ?></span>
                                                <label class="text-muted">Location : <span id="reqd">*</span></label>
                                                <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('spc_location'); ?>"
                                                    name="spc_location" id="spc_location" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_passing_year"><?= form_error('passing_year'); ?></span>
                                                <label class="text-muted">Passing Year : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('spc_location'); ?>"
                                                    name="passing_year" id="passing_year" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_specialization"><?= form_error('specialization'); ?></span>
                                                <label class="text-muted">Specialization Details : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="specialization" id="specialization"
                                                    value="<?= set_value('specialization'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit"
                                                    name="submit" id="submit">
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <div class="col-md-12">
                                <table class="table table-striped table-responsive w-100">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Education Level</th>
                                            <th>Course</th>
                                            <th>Course Type</th>
                                            <th>Institution</th>
                                            <th>Board / University</th>
                                            <th>Marks Obtained</th>

                                            <th>Location</th>
                                            <th>Passing Year</th>
                                            <th>Specialization</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php
                                        if (@$EmplEducationalRecArr) {
                                            foreach ($EmplEducationalRecArr as $kEy => $recD) {
                                                ?>
                                        <tr>
                                            <td><?= $kEy + 1; ?></td>
  <td><?= ($recD->educationlevelcode) ? $recD->educationlevelcode : ""; ?></td>
                                            <td><?= ($recD->degreename) ? $recD->degreename : ""; ?></td>
                                            <td><?= ($recD->course_name) ? $recD->course_name : ""; ?></td>
                                           <td><?= ($recD->institution_name) ? $recD->institution_name : ""; ?></td>
                                            <td><?= ($recD->board_university) ? $recD->board_university : ""; ?>
                                            </td>
                                            <td><?= ($recD->marks_obtained) ? $recD->marks_obtained : ""; ?></td>

                                            <td><?= ($recD->spc_location) ? $recD->spc_location : ""; ?></td>
                                            <td><?=($recD->passing_year) ? $recD->passing_year : ""; ?></td>
                                            <td><?= ($recD->specialization) ? $recD->specialization : ""; ?></td>
                                            <td>
                                            <a class="fa fa-edit"
                                                    data-toggle="modal" data-target="#editeducationModal" href="#" onclick="edit_emp_edu_detail('<?= $recD->id ?>')"></a><br>
                                                <!-- <a href="">
                                                    <i class="fa fa-edit"></i>
                                                </a> &nbsp;&nbsp; -->
                                                <a style="cursor:pointer"
                                                    onclick="delete_educational('<?= $recD->id ?>')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                            }
                                        } else {
                                            ?>
                                        <tr>
                                            <td style="color:red" colspan="13"> Record Not Found. </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <!-- Abbhishek adddegreeModel this  18-10-2022-->
 <div class="modal" id="educationModel" tabindex="-1" role="dialog" aria-labelledby="educationModelLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="educationModelLabel">Add Cource</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?= base_url('add_cource'); ?>" method="post">
               
                <div class="modal-body">
                    <input type="hidden" name="uri_id" value="<?= $this->uri->segment(2);?>">
                                   <div class="row clearfix">
                                        <!-- <div class="col-md-12">
                                                        <label class="email"> Cource Name : </label>
                                                    <input type="text" id="cource_name" name="cource_name" class="form-control" required>
                                        </div> -->
									
                                        <div class="col-md-12">
                                            <label class="email"> Education Level : </label>
                                            <br>
                                            <select id="edulevel" name="edulevel"  class="form-control selectmodal" required>
                                                <option value=""> -- Select Edulevel -- </option>
                                                <?php
                                                if ($edulevel):
                                                    foreach ($edulevel as $rowr) {
                                                        ?>
                                                        <option value="<?= $rowr->id; ?>"> <?= $rowr->educationlevelcode; ?></option>
                                                    <?php } 
                                                endif; ?>
                                            </select>
											
                                        </div>
                                      
                                        <div class="col-md-12">
                                            <br>
                                            <label class="email"> degree Name : </label>
                                            <br>
                                          <input type="text" name="degree_name" id="degree_name" class="form-control">
                                        </div>

                                      

                                        


                                      
                                        
                                    </div>
                               
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Abhoishek  model for add company -->



     <!-- Abbhishek editeducation this  18-10-2022-->
     <div class="modal" id="editeducationModal" tabindex="-1" role="dialog" aria-labelledby="editeducationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editeducationModalLabel">Edit Education</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?= base_url('edit_employe_education'); ?>">
                <div class="modal-body">
              
              
               
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <input type="hidden" id="edit_uri_emp_id" value="<?= $this->uri->segment(2);?>" name="edit_uri_emp_id">
                                         <input type="hidden"id="edit_emp_edu_id" name="edit_emp_edu_id">
                                                <span id="reqd"
                                                    class="error_educationlevel"><?= form_error('educationlevel'); ?></span>
                                                <label class="text-muted">Education Level : <span
                                                        id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control  ms " name="educationlevel" 
                                                    id="edit_educationlevel" data-placeholder="Select" onchange="edit_fetch_degrees()">
                                                    <option
                                                        <?= set_select('educationlevel', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                    if ($EducationLevelRecArr) {
                                                        foreach ($EducationLevelRecArr as $keyy => $recD) {
                                                            ?>
                                                    <option
                                                        <?= set_select('educationlevel', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->educationlevelcode; ?>
                                                    </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_course"><?= form_error('course'); ?></span>
                                              
                                                <label class="text-muted">Degree Name: <span id="reqd">*</span></label>
                                               
                                                <br>
                                                <select  name="course" onclick="rmvalidationerror(this.id)" class="form-control"  id="edit_course">
                                                        <option> -- Select degree --</option>
                                                </select>
                                                <!-- <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="course" id="course"
                                                    value="<?php // set_value('course'); ?>" class="form-control"> -->
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_coursetype_id"><?= form_error('coursetype_id'); ?></span>
                                                <label class="text-muted">Course Type : <span id="reqd">*</span></label>
                                                <br>
                                                <select onclick="rmvalidationerror(this.id)"
                                                    class="form-control show-tick ms " name="coursetype_id"
                                                    id="edit_coursetype_id" data-placeholder="Select">
                                                    <option
                                                        <?= set_select('coursetype_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                    if ($CourseTypeRecArr) {
                                                        foreach ($CourseTypeRecArr as $keyy => $recD) {
                                                            ?>
                                                    <option
                                                        <?= set_select('coursetype_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->course_name; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_institution_name"><?= form_error('institution_name'); ?></span>
                                                <label class="text-muted">Institution Name : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="institution_name" id="edit_institution_name"
                                                    class="form-control" value="<?= set_value('institution_name'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_board_university"><?= form_error('board_university'); ?></span>
                                                <label class="text-muted">Board / University : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="board_university" id="edit_board_university"
                                                    class="form-control" value="<?= set_value('board_university'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_marks_obtained"><?= form_error('marks_obtained'); ?></span>
                                                <label class="text-muted">Marks Obtained : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('marks_obtained'); ?>"
                                                    name="marks_obtained" id="edit_marks_obtained" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_from_date"><?= form_error('from_date'); ?></span>
                                                <label class="text-muted">From : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input type="text" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" name="from_date" autocomplete="off"
                                                        id="edit_from_date" value="<?= set_value('from_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_to_date"><?= form_error('to_date'); ?></span>
                                                <label class="text-muted">To : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input type="text" onclick="rmvalidationerror(this.id)"
                                                        class="form-control" name="to_date" autocomplete="off"
                                                        id="edit_to_date" value="<?= set_value('to_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_stream"><?= form_error('stream'); ?></span>
                                                <label class="text-muted">Stream : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="stream" id="edit_stream"
                                                    value="<?= set_value('stream'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_stream"><?= form_error('percentage'); ?></span>
                                                <label class="text-muted">Percentage / Grade : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('percentage'); ?>"
                                                    name="percentage" id="edit_percentage" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_spc_location"><?= form_error('spc_location'); ?></span>
                                                <label class="text-muted">Location : <span id="reqd">*</span></label>
                                                <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('spc_location'); ?>"
                                                    name="spc_location" id="edit_spc_location" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_passing_year"><?= form_error('passing_year'); ?></span>
                                                <label class="text-muted">Passing Year : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" value="<?= set_value('spc_location'); ?>"
                                                    name="passing_year" id="edit_passing_year" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_specialization"><?= form_error('specialization'); ?></span>
                                                <label class="text-muted">Specialization Details : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                    type="text" name="specialization" id="edit_specialization"
                                                    value="<?= set_value('specialization'); ?>" class="form-control">
                                            </div>
                                        </div>

                                       

                                    </div>
                                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Abhoishek  model for add company -->

    <script>
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }

    function delete_educational(fld_id) {
        if (confirm("Are you sure Delete this?")) {
            window.location = "<?= base_url("delete_educational/"); ?>" + fld_id;
        }
    }
    function edit_fetch_degrees(id)
    {
        var edulevel_id = $('#edit_educationlevel').val();
       var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    //    var degree_name = $("#degree_name").val();
    //    $uri_id = $this->uri->segment(2);
        //   print_r($uri_id);
        //   die();
    //    alert(edulevel_id);
        $.ajax({
                url: "<?=base_url('fetch_cource'); ?>",
                type: "POST",
                data: {
                    edulevel_id: edulevel_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                dataType: 'json',
                success: function(res) {
                    $('#edit_course').html('');
                    $('#edit_course').append("<option value=''>-- Select degree --</option>");
                    $.each(res, function(key,val) {
                      
                        $('#edit_course').append("<option value="+val.id+" ("+val.id+") = "+id+":'Selected':'';>"+val.degreename+"</option>");
                       // $('#Templete_id').html("<option>'"val.letter_templete_name"'</option>")
             // alert(val.letter_templete_name);
                     });
$('#edit_course').val(id);
                  

                }
            });
    }
    function fetch_degrees()
    {
       var edulevel_id = $('#educationlevel').val();
       var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    //    var degree_name = $("#degree_name").val();
    //    $uri_id = $this->uri->segment(2);
        //   print_r($uri_id);
        //   die();
    //    alert(edulevel_id);
        $.ajax({
                url: "<?=base_url('fetch_cource'); ?>",
                type: "POST",
                data: {
                    edulevel_id: edulevel_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                dataType: 'json',
                success: function(res) {
                    $('#course').html('');
                    $.each(res, function(key,val) {
                      
                        $('#course').append("<option value="+val.id+">"+val.degreename+"</option>");
                       // $('#Templete_id').html("<option>'"val.letter_templete_name"'</option>")
             // alert(val.letter_templete_name);
                     });

                  

                }
            });
    }
    function edit_emp_edu_detail(emp_edudetail_id)
    {
        $('#edit_course').val('');
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
    //    var degree_name = $("#degree_name").val();
        $.ajax({
                url: "<?=base_url('fetch_emp_edu_data'); ?>",
                type: "POST",
                data: {
                    emp_edudetail_id: emp_edudetail_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                dataType: 'json',
                success: function(res) {
// alert(res.educationlevel);
$('#edit_emp_edu_id').val(res.id);
                    $('#edit_educationlevel').val(res.educationlevel);
                   var edlevelid = $('#edit_educationlevel').val(res.educationlevel);
                    if(edlevelid.val())
                    {
                       edit_fetch_degrees(res.course);
                       $('#edit_course').val(res.course);
                    }
                     //alert(res.course);
                    $("#edit_course option[value=60]").attr("selected", "selected");
                    $('#edit_course').val(res.course);
                    $('#edit_coursetype_id').val(res.coursetype_id);
                    $('#edit_institution_name').val(res.institution_name);
                    $('#edit_board_university').val(res.board_university);
                    $('#edit_marks_obtained').val(res.marks_obtained);
                    $('#edit_from_date').val(res.from_date);
                    $('#edit_to_date').val(res.to_date);
                    $('#edit_stream').val(res.stream);
                    $('#edit_percentage').val(res.percentage);
                    $('#edit_spc_location').val(res.spc_location);
                    $('#edit_passing_year').val(res.passing_year);
                    $('#edit_specialization').val(res.specialization);
                 
                    // $('#course').html('');
            //         $.each(res, function(key,val) {
                      
            //             // $('#course').append("<option value="+val.id+">"+val.degreename+"</option>");
            //            // $('#Templete_id').html("<option>'"val.letter_templete_name"'</option>")
            //  // alert(val.letter_templete_name);
            //          });

                  

                }
            });
    }
    </script>
   
    <script>
    // jQuery(document).ready(function() {
    //     // console.log("ready!");
    //     alert("redy");
    // });
    </script>


    <?= $this->load->view('admin/includes/footer'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
 <script>
 $(document).ready(function () {
$('.selectmodal').each(function() { 
    $(this).select2({ dropdownParent: $('.add-modal').parent()});
});
 });
</script>
    <style>
    span#reqrd {
        color: red;
    }
    </style>
    