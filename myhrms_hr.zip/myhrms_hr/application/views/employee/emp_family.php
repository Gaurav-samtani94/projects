<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
@$Dependyesorno = array("" => "", "1" => "Yes", "2" => "No");
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                   <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>" >Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>" >Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link active">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_dependent_name"><?= form_error('dependent_name'); ?></span>
                                                <label class="text-muted">Family Member Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="dependent_name" id="dependent_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('dependent_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_dependent_relation"><?= form_error('dependent_select'); ?></span>
                                                <label class="text-muted">Dependent or Not : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="dependent_select" id="dependent_select" data-placeholder="Select" >
                                                    <option <?= set_select('dependent_select', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                    <option <?= set_select('dependent_select', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?> value="1"> Yes </option>
                                                    <option <?= set_select('dependent_select', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?> value="2"> No </option> 
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_dependent_relation"><?= form_error('dependent_relation'); ?></span>
                                                <label class="text-muted">Family Member Relation : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="dependent_relation" id="dependent_relation" data-placeholder="Select" >
                                                    <option <?= set_select('dependent_relation', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                    <option <?= set_select('dependent_relation', "child", (!empty($data) && $data == "child" ? TRUE : FALSE)); ?> value="child"> Child </option>
                                                    <option <?= set_select('dependent_relation', "son", (!empty($data) && $data == "son" ? TRUE : FALSE)); ?> value="son"> Son </option>
                                                    <option <?= set_select('dependent_relation', "daughter", (!empty($data) && $data == "daughter" ? TRUE : FALSE)); ?> value="daughter"> Daughter </option>
                                                    <option <?= set_select('dependent_relation', "sister", (!empty($data) && $data == "sister" ? TRUE : FALSE)); ?> value="sister"> Sister </option>
                                                    <option <?= set_select('dependent_relation', "brother", (!empty($data) && $data == "brother" ? TRUE : FALSE)); ?> value="brother"> Brother </option>
                                                    <option <?= set_select('dependent_relation', "father", (!empty($data) && $data == "father" ? TRUE : FALSE)); ?> value="father"> Father </option>
                                                    <option <?= set_select('dependent_relation', "mother", (!empty($data) && $data == "mother" ? TRUE : FALSE)); ?> value="mother"> Mother </option>
                                                    <option <?= set_select('dependent_relation', "wife", (!empty($data) && $data == "wife" ? TRUE : FALSE)); ?> value="wife"> Wife </option>
                                                    <option <?= set_select('dependent_relation', "husband", (!empty($data) && $data == "husband" ? TRUE : FALSE)); ?> value="husband"> Husband </option>
                                                    <option <?= set_select('dependent_relation', "ex_spouse", (!empty($data) && $data == "ex_spouse" ? TRUE : FALSE)); ?> value="ex_spouse"> Ex Spouse </option>
                                                    <option <?= set_select('dependent_relation', "grand_daughter", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grand_daughter"> Granddaughter </option>
                                                    <option <?= set_select('dependent_relation', "grandfather", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grandfather"> Grandfather </option>
                                                    <option <?= set_select('dependent_relation', "grandmother", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grandmother"> Grandmother </option>
                                                    <option <?= set_select('dependent_relation', "spouse", (!empty($data) && $data == "spouse" ? TRUE : FALSE)); ?> value="spouse"> Spouse </option>
                                                    <option <?= set_select('dependent_relation', "grandson", (!empty($data) && $data == "grandson" ? TRUE : FALSE)); ?> value="grandson"> Grandson </option>

                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_dependent_dob"><?= form_error('dependent_dob'); ?></span>
                                                <label class="text-muted">Date of Birth : <span id="reqd">*</span><br></label>
                                                <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                    <input type="text" class="form-control" name="dependent_dob" autocomplete="off" id="dependent_dob" value="">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_aadhar_no"><?= form_error('aadhar_no'); ?></span>
                                                <label class="text-muted">Aadhar Number : </label> <br>
                                                <input autocomplete="off" type="text" name="aadhar_no" id="aadhar_no" onclick="rmvalidationerror(this.id)" value="<?= set_value('aadhar_no'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">   
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit" name="save" id="save" >
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Name</th>
                                            <th>Dependent or Not</th>
                                            <th>Relation</th>
                                            <th>Date of Birth</th>
                                            <th>Aadhar Number</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$RecFamilyDetailsArr) {
                                            foreach (@$RecFamilyDetailsArr as $kEy => $recD) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= ($recD->dependent_name) ? $recD->dependent_name : ""; ?></td>
                                                    <td><?= ($recD->dependent_select) ? $Dependyesorno[$recD->dependent_select] : ""; ?></td>
                                                    <td><?= ($recD->dependent_relation) ? ucfirst($recD->dependent_relation) : ""; ?></td>
                                                    <td><?= ($recD->dependent_dob) ? date("d-m-Y", strtotime($recD->dependent_dob)) : ""; ?></td>
                                                    <td><?= ($recD->aadhar_no) ? $recD->aadhar_no : ""; ?></td>
                                                    <td>
                                                    <!-- editFamilyModal -->
                                                    <a class="fa fa-edit"
                                                    data-toggle="modal" data-target="#editFamilyModal" href="#" onclick="edit_emp_family_detail('<?= $recD->id ?>')"></a><br>
&nbsp;&nbsp;
                                                        <!-- <a href="">
                                                            <i class="fa fa-edit"></i>
                                                        </a> &nbsp;&nbsp; -->
                                                        <a style="cursor:pointer" onclick="deletefamilydetails('<?= $recD->id ?>')">
                                                            <i class="fa fa-trash"></i>
                                                        </a> 
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                            <tr>
                                                <td style="color:red" colspan="5"> Record Not Found. </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Edit Family By abhishek on 20-10-2022 -->
<div class="modal " id="editFamilyModal" tabindex="-1" role="dialog" aria-labelledby="editFamilyModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editFamilyModalLabel">Edit Family</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                 </button>
                </div>
                <form method="post" action="<?= base_url('edit_family') ?>" >
               
                <div class="modal-body">
                                   <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                 
                                 <input type="hidden" name="emp_id" value="<?= $this->uri->segment(2)?>">
                                   <input type="hidden" name="family_member_id" id="family_member_id">
                                   <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_dependent_name"><?= form_error('dependent_name'); ?></span>
                                                <label class="text-muted">Family Member Name : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="dependent_name" id="edit_dependent_name" onclick="rmvalidationerror(this.id)" value="<?= set_value('dependent_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_dependent_relation"><?= form_error('dependent_select'); ?></span>
                                                <label class="text-muted">Dependent or Not : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms" name="dependent_select" id="edit_dependent_select" data-placeholder="Select" >
                                                    <option <?= set_select('dependent_select', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                    <option <?= set_select('dependent_select', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?> value="1"> Yes </option>
                                                    <option <?= set_select('dependent_select', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?> value="2"> No </option> 
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_dependent_relation"><?= form_error('dependent_relation'); ?></span>
                                                <label class="text-muted">Family Member Relation : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms" name="dependent_relation" id="edit_dependent_relation" data-placeholder="Select" >
                                                    <option <?= set_select('dependent_relation', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                    <option <?= set_select('dependent_relation', "child", (!empty($data) && $data == "child" ? TRUE : FALSE)); ?> value="child"> Child </option>
                                                    <option <?= set_select('dependent_relation', "son", (!empty($data) && $data == "son" ? TRUE : FALSE)); ?> value="son"> Son </option>
                                                    <option <?= set_select('dependent_relation', "daughter", (!empty($data) && $data == "daughter" ? TRUE : FALSE)); ?> value="daughter"> Daughter </option>
                                                    <option <?= set_select('dependent_relation', "sister", (!empty($data) && $data == "sister" ? TRUE : FALSE)); ?> value="sister"> Sister </option>
                                                    <option <?= set_select('dependent_relation', "brother", (!empty($data) && $data == "brother" ? TRUE : FALSE)); ?> value="brother"> Brother </option>
                                                    <option <?= set_select('dependent_relation', "father", (!empty($data) && $data == "father" ? TRUE : FALSE)); ?> value="father"> Father </option>
                                                    <option <?= set_select('dependent_relation', "mother", (!empty($data) && $data == "mother" ? TRUE : FALSE)); ?> value="mother"> Mother </option>
                                                    <option <?= set_select('dependent_relation', "wife", (!empty($data) && $data == "wife" ? TRUE : FALSE)); ?> value="wife"> Wife </option>
                                                    <option <?= set_select('dependent_relation', "husband", (!empty($data) && $data == "husband" ? TRUE : FALSE)); ?> value="husband"> Husband </option>
                                                    <option <?= set_select('dependent_relation', "ex_spouse", (!empty($data) && $data == "ex_spouse" ? TRUE : FALSE)); ?> value="ex_spouse"> Ex Spouse </option>
                                                    <option <?= set_select('dependent_relation', "grand_daughter", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grand_daughter"> Granddaughter </option>
                                                    <option <?= set_select('dependent_relation', "grandfather", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grandfather"> Grandfather </option>
                                                    <option <?= set_select('dependent_relation', "grandmother", (!empty($data) && $data == "3" ? TRUE : FALSE)); ?> value="grandmother"> Grandmother </option>
                                                    <option <?= set_select('dependent_relation', "spouse", (!empty($data) && $data == "spouse" ? TRUE : FALSE)); ?> value="spouse"> Spouse </option>
                                                    <option <?= set_select('dependent_relation', "grandson", (!empty($data) && $data == "grandson" ? TRUE : FALSE)); ?> value="grandson"> Grandson </option>

                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_dependent_dob"><?= form_error('dependent_dob'); ?></span>
                                                <label class="text-muted">Date of Birth : <span id="reqd">*</span><br></label>
                                                <div class="input-group">
                                                <!-- data-date-autoclose="true" data-provide="datepicker" -->
                                                    <input type="date" class="form-control" name="dependent_dob" autocomplete="off" id="edit_dependent_dob" value="">
                                                    <!-- <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group"> 
                                                <span id="reqd" class="error_aadhar_no"><?= form_error('aadhar_no'); ?></span>
                                                <label class="text-muted">Aadhar Number : </label> <br>
                                                <input autocomplete="off" type="text" name="aadhar_no" id="edit_aadhar_no" onclick="rmvalidationerror(this.id)" value="<?= set_value('aadhar_no'); ?>" class="form-control">
                                            </div>
                                        </div>

                                       
                                    </div>
                              

                                     

                                    </div>
                               
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Abhoishek  model for add company -->
    <script>
        function edit_emp_family_detail(family_id)
        {
            
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                url: "<?=base_url('fetch_employee_family'); ?>",
                type: "POST",
                data: {
                    family_id: family_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                // dataType: 'json',
                success: function(res) {
var ress = JSON.parse(res);
$("#family_member_id").val(ress.id);
                   $('#edit_dependent_name').val(ress.dependent_name);
                   $('#edit_dependent_select').val(ress.dependent_select);
                   $('#edit_dependent_relation').val(ress.dependent_relation);
                   $('#edit_dependent_dob').val(ress.dependent_dob);
                   $('#edit_aadhar_no').val(ress.aadhar_no);

                  

                }
            });

        

        }
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
        function deletefamilydetails(fld_id) {
            if (confirm("Are you sure Delete this?")) {
                window.location = "<?= base_url("deletefamilydetails/"); ?>" + fld_id;
            }
        }
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>