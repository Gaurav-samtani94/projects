<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-md-12">
                                            <div class="header">
                                                <h2>PERMANENT ADDRESS </h2>

                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_hono"><?= form_error('perm_hono'); ?></span>
                                                <label class="text-muted">H.No. : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('perm_hono', @$RecEmplContactDetails->perm_hono); ?>" name="perm_hono" id="perm_hono" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_streetaddress"><?= form_error('perm_streetaddress'); ?></span>
                                                <label class="text-muted">Street Address : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('perm_streetaddress', @$RecEmplContactDetails->perm_streetaddress); ?>" name="perm_streetaddress" id="perm_streetaddress" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_area_locality"><?= form_error('perm_area_locality'); ?></span>
                                                <label class="text-muted">Area/ Locality : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('perm_area_locality', @$RecEmplContactDetails->perm_area_locality); ?>" name="perm_area_locality" id="perm_area_locality" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_country"><?= form_error('perm_country'); ?></span>
                                                <label class="text-muted">Country : <span id="reqd">*</span></label> <br>
                                                <select onchange="setpermstate()" onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="perm_country" id="perm_country" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplContactDetails->perm_country == '') ? "selected" : ""; ?> <?= set_select('perm_country', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($countriesRecArr) {
                                                        foreach ($countriesRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplContactDetails->perm_country == $recD->id) ? "selected" : ""; ?> <?= set_select('perm_country', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->country_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_state"><?= form_error('perm_state'); ?></span>
                                                <label class="text-muted"> State : <span id="reqd">*</span></label> <br>
                                                <select onchange="perm_setcitybystateid()" class="form-control show-tick ms select2" name="perm_state" id="perm_state" onclick="rmvalidationerror(this.id)" data-placeholder="Select" >
                                                    <option <?= (set_select('perm_state') == '') ? "selected" : ""; ?>  <?= (@$RecEmplContactDetails->perm_state == '') ? "selected" : ""; ?> <?= set_select('perm_state', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('perm_country')) {
                                                        @$stateArr = GetAllStateBycountryIDGetAllStateBycountryID(set_value('perm_country'));
                                                        if (@$stateArr) {
                                                            foreach (@$stateArr as $reCdd) {
                                                                ?>
                                                                <option <?= set_select('perm_state', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>  value="<?= $reCdd->id; ?>"><?= $reCdd->state_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }

                                                    //For Edit...
                                                    if ($RecEmplContactDetails->perm_country) {
                                                        @$stateArr = GetAllStateBycountryID($RecEmplContactDetails->perm_country);
                                                        if (@$stateArr) {
                                                            foreach (@$stateArr as $reCdd) {
                                                                ?>
                                                                <option <?= (@$RecEmplContactDetails->perm_state == $reCdd->id) ? "selected" : ""; ?> <?= set_select('perm_state', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>  value="<?= $reCdd->id; ?>"><?= $reCdd->state_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_city"><?= form_error('perm_city'); ?></span>
                                                <label class="text-muted">District / City : <span id="reqd">*</span></label> <br>
                                                <select class="form-control show-tick ms select2" name="perm_city" id="perm_city" onclick="rmvalidationerror(this.id)" data-placeholder="Select" >
                                                    <option <?= (@$RecEmplContactDetails->perm_city == '') ? "selected" : ""; ?> <?= set_select('perm_city', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('perm_state')) {
                                                        @$cityArr = GetAllCityByStateID(set_value('perm_state'));
                                                        if (@$cityArr) {
                                                            foreach (@$cityArr as $reCdd) {
                                                                ?>
                                                                <option <?= (@$RecEmplContactDetails->perm_city == $reCdd->city_id) ? "selected" : ""; ?> <?= set_select('perm_city', $reCdd->city_id, (!empty($data) && $data == $reCdd->city_id ? TRUE : FALSE)); ?> value="<?= $reCdd->city_id; ?>"><?= $reCdd->city_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    //For Edit..
                                                    if ($RecEmplContactDetails->perm_state) {
                                                        @$cityArr = GetAllCityByStateID($RecEmplContactDetails->perm_state);
                                                        if (@$cityArr) {
                                                            foreach (@$cityArr as $reCdd) {
                                                                ?>
                                                                <option <?= (@$RecEmplContactDetails->perm_city == $reCdd->city_id) ? "selected" : ""; ?> <?= set_select('perm_city', $reCdd->city_id, (!empty($data) && $data == $reCdd->city_id ? TRUE : FALSE)); ?> value="<?= $reCdd->city_id; ?>"><?= $reCdd->city_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_perm_pincode"><?= form_error('perm_pincode'); ?></span>
                                                <label class="text-muted">Postal/Pin Code : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('perm_pincode', @$RecEmplContactDetails->perm_pincode); ?>" name="perm_pincode" id="perm_pincode" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_personalemail"><?= form_error('personalemail'); ?></span>
                                                <label class="text-muted">Email ID : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('personalemail', @$RecEmplContactDetails->personalemail); ?>" name="personalemail" id="personalemail" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="header">
                                                <h2>CURRENT ADDRESS </h2>
                                                <h2>
                                                    <input cl type="checkbox" onclick="setbothaddsame()" id="pcsameadd"> : If the permanent and current address are the same
                                                    <a href=""><i title="Reset" class="fa fa-refresh"></i></a>
                                                </h2>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_hono"><?= form_error('current_hono'); ?></span>
                                                <label class="text-muted">H.No. : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('current_hono', @$RecEmplContactDetails->current_hono); ?>" name="current_hono" id="current_hono" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_streetaddress"><?= form_error('current_streetaddress'); ?></span>
                                                <label class="text-muted">Street Address : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('current_streetaddress', @$RecEmplContactDetails->current_streetaddress); ?>" name="current_streetaddress"  id="current_streetaddress" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_area_locality"><?= form_error('current_area_locality'); ?></span>
                                                <label class="text-muted">Area/ Locality : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('current_area_locality', @$RecEmplContactDetails->current_area_locality); ?>" name="current_area_locality" id="current_area_locality" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_country"><?= form_error('current_country'); ?></span>
                                                <label class="text-muted">Country : <span id="reqd">*</span></label> <br>
                                                <select onchange="setpermstate_current()" onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="current_country" id="current_country" data-placeholder="Select" >
                                                    <option <?php echo (@$RecEmplContactDetails->current_country == '') ? "selected" : ""; ?> <?= set_select('current_country', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($countriesRecArr) {
                                                        foreach ($countriesRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= (@$RecEmplContactDetails->current_country == $recD->id) ? "selected" : ""; ?> <?= set_select('current_country', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->country_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_state"><?= form_error('current_state'); ?></span>
                                                <label class="text-muted"> State : <span id="reqd">*</span></label> <br>
                                                <select onchange="setpermcity_current()" class="form-control show-tick ms select2" name="current_state" id="current_state" onclick="rmvalidationerror(this.id)" data-placeholder="Select" >
                                                    <option <?= (set_select('perm_state') == '') ? "selected" : ""; ?>  <?= (@$RecEmplContactDetails->perm_state == '') ? "selected" : ""; ?> <?= set_select('perm_state', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('current_country')) {
                                                        @$stateArr = GetAllStateBycountryID(set_value('current_country'));
                                                        if (@$stateArr) {
                                                            foreach (@$stateArr as $reCdd) {
                                                                ?>
                                                                <option <?= set_select('current_state', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>  value="<?= $reCdd->id; ?>"><?= $reCdd->state_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }

                                                    //For Edit...
                                                    if ($RecEmplContactDetails->current_country) {
                                                        @$stateArr = GetAllStateBycountryID($RecEmplContactDetails->current_country);
                                                        if (@$stateArr) {
                                                            foreach (@$stateArr as $reCdd) {
                                                                ?>
                                                                <option <?= (@$RecEmplContactDetails->current_state == $reCdd->id) ? "selected" : ""; ?> <?= set_select('current_state', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>  value="<?= $reCdd->id; ?>"><?= $reCdd->state_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_city"><?= form_error('current_city'); ?></span>
                                                <label class="text-muted">District / City : <span id="reqd">*</span></label> <br>
                                                <select class="form-control show-tick ms select2" name="current_city" id="current_city" onclick="rmvalidationerror(this.id)" data-placeholder="Select" >
                                                    <option <?= (@$RecEmplContactDetails->current_city == '') ? "selected" : ""; ?> <?= set_select('current_city', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('current_state')) {
                                                        @$stateArr = GetAllCityByStateID(set_value('current_state'));
                                                        if (@$stateArr) {
                                                            foreach (@$stateArr as $reCdd) {
                                                                ?>
                                                                <option <?= set_select('current_city', $reCdd->city_id, (!empty($data) && $data == $reCdd->city_id ? TRUE : FALSE)); ?> value="<?= $reCdd->city_id; ?>"><?= $reCdd->city_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    //For Edit..
                                                    if (@$RecEmplContactDetails->current_state) {
                                                        @$cityArr = GetAllCityByStateID($RecEmplContactDetails->current_state);
                                                        if (@$cityArr) {
                                                            foreach (@$cityArr as $reCdd) {
                                                                ?>
                                                                <option <?= (@$RecEmplContactDetails->current_city == $reCdd->city_id) ? "selected" : ""; ?> <?= set_select('current_city', $reCdd->city_id, (!empty($data) && $data == $reCdd->city_id ? TRUE : FALSE)); ?> value="<?= $reCdd->city_id; ?>"><?= $reCdd->city_name; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_pincode"><?= form_error('current_pincode'); ?></span>
                                                <label class="text-muted">Postal/Pin Code : <span id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('current_pincode', @$RecEmplContactDetails->current_pincode); ?>" name="current_pincode" id="current_pincode" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_current_email"><?= form_error('current_email'); ?></span>
                                                <label class="text-muted">Email ID : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('current_email', @$RecEmplContactDetails->current_email); ?>" name="current_email" id="current_email" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="header">
                                                <h2>EMERGENCY DETAILS : </h2>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <span id="reqd" class="error_emergency_name"><?= form_error('emergency_name'); ?></span>
                                                <label class="text-muted">Name : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('emergency_name', @$RecEmplContactDetails->emergency_name); ?>" name="emergency_name" id="emergency_name" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <span id="reqd" class="error_emergency_namerelation"><?= form_error('emergency_namerelation'); ?></span>
                                                <label class="text-muted">Relation : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('emergency_namerelation', @$RecEmplContactDetails->emergency_namerelation); ?>" name="emergency_namerelation" id="emergency_namerelation" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <span id="reqd" class="error_emergency_email"><?= form_error('emergency_email'); ?></span>
                                                <label class="text-muted">Email : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('emergency_email', @$RecEmplContactDetails->emergency_email); ?>" name="emergency_email" id="emergency_email" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <span id="reqd" class="error_emergency_number"><?= form_error('emergency_number'); ?></span>
                                                <label class="text-muted">Cont. Number : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('emergency_number', @$RecEmplContactDetails->emergency_number); ?>" name="emergency_number" id="emergency_number" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <span id="reqd" class="error_emergency_address"><?= form_error('emergency_address'); ?></span>
                                                <label class="text-muted">Full Address : </label> <br>
                                                <input autocomplete="off" type="text" value="<?= set_value('emergency_address', @$RecEmplContactDetails->emergency_address); ?>" name="emergency_address" id="emergency_address" onclick="rmvalidationerror(this.id)" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input autocomplete="off" class="btn btn-primary" type="submit" value="Submit/Update" name="submit" id="submit" >
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }

        //Perm State...
        function setpermstate() {
            var countryID = $('#perm_country').val();
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#perm_state').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#perm_state').trigger("change");

            $('#perm_city').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#perm_city').trigger("change");

            $.ajax({
                url: '<?= base_url('ajax_setstate_bycountryid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, country_id: countryID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#perm_state').append('<option value="' + data['state_id'] + '">' + data['state_name'] + '</option>');
                    });
                }

            });
        }

        //Perm.. City By State ID..
        function perm_setcitybystateid() {
            var stateID = $('#perm_state').val();
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#perm_city').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#perm_city').trigger("change");

            $.ajax({
                url: '<?= base_url('ajax_setcity_bystateid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, state_id: stateID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#perm_city').append('<option value="' + data['city_id'] + '">' + data['city_name'] + '</option>');
                    });
                }

            });
        }

        //Current State..
        function setpermstate_current() {
            var countryID = $('#current_country').val();
            // alert(countryID);
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#current_state').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#current_state').trigger("change");


            $.ajax({
                url: '<?= base_url('ajax_setstate_bycountryid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, country_id: countryID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#current_state').append('<option value="' + data['state_id'] + '">' + data['state_name'] + '</option>');
                    });
                }

            });
        }


        //Current City By State Id..
        function setpermcity_current() {
            var stateID = $('#current_state').val();
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#current_city').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#current_city').trigger("change");

            $.ajax({
                url: '<?= base_url('ajax_setcity_bystateid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, state_id: stateID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#current_city').append('<option value="' + data['city_id'] + '">' + data['city_name'] + '</option>');
                    });
                }
            });
        }
        function setpermstate_current_latest(countryID,state_id) {
            // var countryID = $('#current_country').val();
            // alert(countryID);
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#current_state').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#current_state').trigger("change");


            $.ajax({
                url: '<?= base_url('ajax_setstate_bycountryid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, country_id: countryID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#current_state').append('<option value="' + data['state_id'] + '">' + data['state_name'] + '</option>');
                    });
                    $('#current_state').val(state_id);
                    $('#current_state').trigger("change");
                }

            });
        }
        function setpermcity_current_latest(stateID,city_id) {
            // var stateID = $('#current_state').val();
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            $('#current_city').empty().append('<option selected="selected" value="">-- Select -- </option>');
            $('#current_city').trigger("change");

            $.ajax({
                url: '<?= base_url('ajax_setcity_bystateid') ?>',
                method: 'post',
                data: {[csrfName]: csrfHash, state_id: stateID},
                dataType: 'json',
                success: function (response) {
                    $.each(response, function (index, data) {
                        $('#current_city').append('<option value="' + data['city_id'] + '">' + data['city_name'] + '</option>');
                    });
                    $('#current_city').val(city_id);
                 $('#current_city').trigger("change");
                }
               
            });
        }


        function setbothaddsame() {
            var checkboxV = $("#pcsameadd").val();
            var perm_hono = $("#perm_hono").val();
            var perm_streetaddress = $("#perm_streetaddress").val();
            var perm_area_locality = $("#perm_area_locality").val();
            var perm_country = $("#perm_country").val();
            var perm_state = $("#perm_state").val();
            var perm_city = $("#perm_city").val();
            var perm_pincode = $("#perm_pincode").val();
            var personalemail = $("#personalemail").val();

            if ($("#pcsameadd").prop('checked') == true) {
                $("#current_hono").val(perm_hono);
                $("#current_streetaddress").val(perm_streetaddress);
                $("#current_area_locality").val(perm_area_locality);
                $("#current_country").val(perm_country);
                $('#current_country').trigger("change");
                // setpermstate();
                // perm_setcitybystateid();
            //    var cou_id = $("#current_country").val();
                setpermstate_current_latest(perm_country,perm_state);
                setpermcity_current_latest(perm_state,perm_city);
                // setpermcity_current();
                $("#current_state").val(perm_state);
                // $("#current_city").val(perm_city);
              
                // $('#current_state').trigger("change");
                // $('#current_city').trigger("change");
                $("#current_pincode").val(perm_pincode);
                $("#current_email").val(personalemail);
            }

            if ($("#pcsameadd").prop('checked') == false) {
                $("#current_hono").val('');
                $("#current_streetaddress").val('');
                $("#current_area_locality").val('');
                $("#current_country").val('');
                $("#current_state").val('');
                $("#current_city").val('');
                $('#current_country').trigger("change");
                $('#current_state').trigger("change");
                $('#current_city').trigger("change");
                $("#current_pincode").val('');
                $("#current_email").val('');
            }
        }

    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>
<style>
    span#reqrd {
        color: red;
    }
</style>