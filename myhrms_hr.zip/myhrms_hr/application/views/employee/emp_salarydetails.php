<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                   <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>
                
                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>
                
                
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- Data -->
                            <div class="tab-content">
                                <div class="body"> 
                                    <?php $this->load->view("admin/includes/upper-tab"); ?>
                                    <form method="post" action="<?= thisurl(); ?>" >
                                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <div class="row clearfix">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_currencyid"><?= form_error('currencyid'); ?></span>
                                                    <label class="text-muted">Salary Currency : <span id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="currencyid" id="currencyid" data-placeholder="Select" >
                                                        <option <?php echo (@$RecEmplSalaryDetails->currencyid == "") ? "selected" : ""; ?> <?= set_select('currencyid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if ($CurrencyRecArr) {
                                                            foreach ($CurrencyRecArr as $keyy => $recD) {
                                                                ?>
                                                                <option <?php echo (@$RecEmplSalaryDetails->currencyid == $recD->id) ? "selected" : ""; ?> <?= set_select('currencyid', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->currencyname; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_salarytype"><?= form_error('salarytype'); ?></span>
                                                    <label class="text-muted">Pay Frequency : <span id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="salarytype" id="salarytype" data-placeholder="Select" >
                                                        <option <?php echo (@$RecEmplSalaryDetails->salarytype == '') ? "selected" : ""; ?> <?= set_select('salarytype', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if ($PayFrequencyRecArr) {
                                                            foreach ($PayFrequencyRecArr as $keyy => $recD) {
                                                                ?>
                                                                <option <?php echo (@$RecEmplSalaryDetails->salarytype == $recD->id) ? "selected" : ""; ?> <?= set_select('salarytype', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->freqtype; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_salary"><?= form_error('salary'); ?></span>
                                                    <label class="text-muted">Gross Salary : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('salary', @$RecEmplSalaryDetails->salary); ?>" onclick="rmvalidationerror(this.id)" name="salary" id="salary" class="form-control">
                                                </div>
                                            </div>
											  <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_ctcsalary"><?= form_error('ctcsalary'); ?></span>
                                                    <label class="text-muted">CTC : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('ctcsalary', @$RecEmplSalaryDetails->ctcsalary); ?>" onclick="rmvalidationerror(this.id)" name="ctcsalary" id="ctcsalary" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_bankname"><?= form_error('bankname'); ?></span>
                                                    <label class="text-muted">Bank Name : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('bankname', @$RecEmplSalaryDetails->bankname); ?>" onclick="rmvalidationerror(this.id)" name="bankname" id="bankname" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_accountholder_name"><?= form_error('accountholder_name'); ?></span>
                                                    <label class="text-muted">Account Holder Name : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('accountholder_name', @$RecEmplSalaryDetails->accountholder_name); ?>" onclick="rmvalidationerror(this.id)" name="accountholder_name" id="accountholder_name" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_branchname"><?= form_error('branchname'); ?></span>
                                                    <label class="text-muted">Branch name of Bank : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('branchname', @$RecEmplSalaryDetails->branchname); ?>" onclick="rmvalidationerror(this.id)" name="branchname" id="branchname" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_ifsc_code"><?= form_error('ifsc_code'); ?></span>
                                                    <label class="text-muted">IFSC Code : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('ifsc_code', @$RecEmplSalaryDetails->ifsc_code); ?>" onclick="rmvalidationerror(this.id)" name="ifsc_code" id="ifsc_code" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_pancard_no"><?= form_error('pancard_no'); ?></span>
                                                    <label class="text-muted">PAN Number : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('pancard_no', @$RecEmplSalaryDetails->pancard_no); ?>" onclick="rmvalidationerror(this.id)" name="pancard_no" id="pancard_no" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_accountnumber"><?= form_error('accountnumber'); ?></span>
                                                    <label class="text-muted">Account Number : </label><br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('accountnumber', @$RecEmplSalaryDetails->accountnumber); ?>" onclick="rmvalidationerror(this.id)" name="accountnumber" id="accountnumber" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_appraisalduedate"><?= form_error('appraisalduedate'); ?></span>
                                                    <label class="text-muted">Appraisal Due Date : <span id="reqd">*</span></label> <br>
                                                    <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                        <input type="text" class="form-control" name="appraisalduedate" autocomplete="off" id="appraisalduedate" value="<?= set_value('appraisalduedate', @$RecEmplSalaryDetails->appraisalduedate); ?>">
                                                        <div class="input-group-append">
                                                            <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="form-group">   
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-primary" type="submit" value="Submit / Update" name="submit" id="submit" >
                                                </div>
                                            </div>
                                        </div>
                                    </form> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>
<style>
    span#reqrd {
        color: red;
    }
</style>