<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    .file-list ul{margin-left:0px!important;}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link active" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                               
<!-- code start -->
    <div class ="row">
                <div class ="col-sm-3">
                    <div class="card">
                        <div class="body">
                            <form action="<?=base_url('add_user_document');?>" method="post" id="form_doctrol" enctype="multipart/form-data">
                            <input type="hidden" class="txt_csrfname" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>"><br>   
                            <input type="hidden" name="user_id" value="<?=$this->uri->segment('2'); ?>">
                            <div class="row">
                                <!-- // doc type -->
                                    <div class="col-sm-12">
                                         <button type="button" class="btn btn-three active bg-success" style="float:right" data-toggle="modal" data-target="#myfolder" title="Create New Folder"><i class="icon-plus"></i></button>
                                    </div>
                                    <div class="col-sm-12">
                                        
                                        <div class="form-group">
                                       
                                            <label class="label-control">Document Type:</label>
                                            <select required class="form-control" id="selectdoc_type" onchange="get_document_folder(this.value)">
                                                <option value="">Select Folder</option>
                                               <option value="1"> Education </option>
                                               <option value="2"> Other </option>
                                               <option value="3"> HR </option>
                                            </select>
                                        </div>
                                    </div> 
                                     <!-- // doc type end -->
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="label-control">Document Folder:</label>
                                            <select required class="form-control" id="doc_folder" name="doc_folder">
                                                <option value="">Select Folder</option>
                                                
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="label-control">Document Title:</label>
                                            <input type="text" required placeholder="Document Title*" class="form-control" id="doc_title" name="doc_title">
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="label-control">Document File:</label>
                                            <input type="file" required  class="form-control" id="doc_file" name="doc_file[]" multiple>
                                        </div>
                                    </div>
                                    <!-- <div class="col-sm-12 docs_share">
                                        <div class="form-group">
                                            <label class="label-control"><i class="icon-settings"></i> Share Setting:</label>
                                            <select required class="form-control" name="doc_privacy" id="doc_privacy">
                                                <option value="">-Select Privacy-</option>
                                                <option value="1" selected><i class="icon-ban"></i> All Persons</option>
                                                <option value="2"><i class="icon-users"></i> Some Persons</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group" id="docs_share">
                                            <label class="label-control"><i class="icon-users"></i> Some Persons:</label>
                                            <select class="form-control show-tick ms select2" multiple data-placeholder="Select Person" name="doc_share[]" id="doc_share2">
                                                <?php //if(@$doc_user){ foreach($doc_user as $doc_userrow){ ?>
                                                    <option value="<?php //=@$doc_userrow['user_id'];?>"><?php //=@$doc_userrow['userfullname'];?></option>
                                                <?php //} } ?>
                                            </select> 
                                        </div>
                                    </div>  -->
                                    <div class="col-sm-12">
                                        <div class="form-group text-center">
                                            <input type="reset" class="btn btn-sm" id="doc_reset" value="Reset">
                                            <input type="submit" class="btn btn-one btn-sm" id="doc_save" value="Save">
                                        </div>
                                    </div>  
                                </div>
                            </form>
                        </div>
                    </div>            
                </div>
			<div class="col-sm-9">
                <div class="card">
                    <div class="body">
                        <div class="row"> 
                            <div class="col-lg-12">
                                <ul class="ml-0 file-tree file-list">
                                    <li class="folder-root">
                                        <a href="#">Education Document</a>
                                        <ul>
                                            <?php 
                                                if(@$generaldoc_list){ 
                                                    foreach($generaldoc_list as $doc_row){ 
                                                if($doc_row->doc_privacy == '1'){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 

                                                    // $login_id = $this->session->userdata('loginid');
                                                        $edu_folder =  $login_id.'/Education_folder/';
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/' .$edu_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?=MYHRMSHOSTNAME.'uploads/All_employee_document/'.$edu_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } ?>
                                            <?php 
                                                if(@$doc_list){ 
                                                    // $login_id = $this->session->userdata('loginid');
                                                    $edu_folder =  $login_id.'/Education_folder/';
                                                    foreach($doc_list as $doc_row){ 
                                                        if($doc_row->doc_privacy == '2')
                                                        {
                                                            $doc_share_arr = explode(',', $doc_row->doc_share);
                                                            // $login_id = $this->session->userdata('loginid');
                                                            if(in_array($login_id, $doc_share_arr)){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/' .$edu_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?= MYHRMSHOSTNAME.'uploads/All_employee_document/'.$edu_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } } ?>
                                        </ul>
                                    </li>
                                    <li class="folder-root">
                                        <a href="#">Other Document</a>
                                        <ul>
                                            <?php 
                                            // $login_id = $this->session->userdata('loginid');
                                            $other_folder =  $login_id.'/Other/';
                                                if(@$compinfo_list){ foreach($compinfo_list as $doc_row){ 
                                                if($doc_row->doc_privacy == '1'){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/' .$other_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?=MYHRMSHOSTNAME.'uploads/All_employee_document/'.$other_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } ?>
                                            <?php 
                                                if(@$doc_list){ foreach($doc_list as $doc_row){ 
                                                if($doc_row->doc_privacy == '2'){
                                                $doc_share_arr = explode(',', $doc_row->doc_share);
                                                // $login_id = $this->session->userdata('loginid');
                                                if(in_array($login_id, $doc_share_arr)){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/'.$other_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?=MYHRMSHOSTNAME.'uploads/All_employee_document/'.$other_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } } ?>
                                        </ul>
                                    </li>
                                       <!-- HR DOcument -->
                                    <li class="folder-root">
                                        <a href="#">HR Document</a>
                                        <ul>
                                            <?php 
                                            // $login_id = $this->session->userdata('loginid');
                                            $other_folder =  $login_id.'/Hr_Folder/';
                                                if(@$hr_list){ foreach($hr_list as $doc_row){ 
                                                if($doc_row->doc_privacy == '1'){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/' .$other_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?=MYHRMSHOSTNAME.'uploads/All_employee_document/'.$other_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } ?>
                                            <?php 
                                                if(@$doc_list){ foreach($doc_list as $doc_row){ 
                                                if($doc_row->doc_privacy == '2'){
                                                $doc_share_arr = explode(',', $doc_row->doc_share);
                                                //$login_id = $this->session->userdata('loginid');
                                                if(in_array($login_id, $doc_share_arr)){
                                            ?>
                                            <li class=""><a href="#"><?=@$doc_row->folder_name; ?></a> 
                                                <ul style="overflow: scroll;">
                                                    <?php 
                                                        $explode_file = explode(",", @$doc_row->group_file);
                                                        for($i=0; $i<count($explode_file); $i++){
                                                        if(file_exists('../myhrms/uploads/All_employee_document/'.$other_folder. @$doc_row->folder_name . '/'.@$explode_file[$i])) { 
                                                    ?>
                                                        <li><a href="<?=MYHRMSHOSTNAME.'uploads/All_employee_document/'.$other_folder.@$doc_row->folder_name.'/'.@$explode_file[$i]; ?>" download><?=@$explode_file[$i]; ?></a></li>
                                                    <?php } } ?>
                                                </ul>
                                            </li>
                                            <?php } } } } ?>
                                        </ul>
                                    </li>
                                    <!-- end code for hr documement -->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
    
            </div>
   
</div>
    <!--- code durgesh add new folder (27-07-2022)----------------->
    <div class="modal fade w-25" id="myfolder" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
            <form action="<?=base_url('adddocfolder');?>" method="post" id="form_doc_folder" class="w-100">
            <input type="hidden" class="txt_csrfname" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>"><br>     
          
            <div class="modal-content w-100">
                    <div class="modal-header">
                        <h5 class="modal-title">Create New Folder</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                        <div class="col-sm-12">
                                <!-- <div class="form-group">
                                    <label class="label-control"><i class="icon-plus"></i>  Other Type:</label>
                                    <select name="doc_type" id="" class="form-control select2">
                                        <option value="">-- Select Type--</option>
                                        <?php 
                                      //  foreach($getOtherDocType as $key=>$val)
                                        {
                                        ?>
                                        <option value="<?php //=$val->id?>"><?php //= $val->doc_name?></option>
                                        <?php 
                                        }
                                        ?>
                                    </select>
                                    </div>
                            </div>  -->
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <input type="hidden" name="user_id" value="<?= $this->uri->segment(2);?>">
                                    <label class="label-control"><i class="icon-plus"></i>  Create a new folder:</label>
                                    <input type="text" required placeholder="Create New Folder Name*" class="form-control" name="add_folder" id="add_folder">
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="modal-footer">
                        
                        <input type="reset" class="btn btn-secondary btn-sm" id="folder_reset" value="Reset">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-one btn-sm" id="folder_save" value="Create Folder">
                </div>
                </div>
            </form>
        </div>
    </div>
        <!-- end -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- </div>
    </div> -->
<script>
      function get_document_folder(doc_type)
        {
            $.ajax({
                url: "<?=base_url('fetch_document'); ?>",
                type: "POST",
                data: {
                    'user_id': "<?= $this->uri->segment(2)?>",
                    'doc_type': doc_type,
                    // [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                dataType: 'json',
                success: function(res) {
                    $('#doc_folder').html('');
                    $('#doc_folder').append("<option> Select Folder Name </option>");
                    $.each(res, function(key,val) {
                            $('#doc_folder').append("<option value="+val.fld_id+">"+val.folder_name+"</option>");
                            // $('#Templete_id').html("<option>'"val.letter_templete_name"'</option>")
                            // alert(val.letter_templete_name);
                     });
                }
            });
            // alert(doc_type);
        }
</script>

    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $(".file-tree").filetree();
        });
      
    </script>

    <?php $this->load->view('admin/includes/footer_new'); ?>
    <!-- <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script> -->
    

</body>
<style>
    span#reqrd {
        color: red;
    }
</style>