<?PHP
// error_reporting(0);
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>

td{
	color: #000 important;
	 border: 1px solid black;
	  border-top: 1px solid black !important;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <style>
                    body {
                        background-image: url("http://localhost/myhrms_hr/public/test-01.jpg");
                        background-size: 80%;
                        background-attachment: fixed;
                        background-position: center;

                        /* background-color: #cccccc; */
                    }
                </style>


                <div class="container">

                        <form action="<?= base_url('requestmail'); ?>" method="post">
                    <table class="table table-border" style="width:100%">
                            <tbody>
                                <?php

                                foreach ($todaybirthday as $row => $vs) {

                                ?>
                                    <tr>
                                        <td>
                                            <?= $vs['userfullname']; ?>
                                        </td>
                                        <td>
                                            <?= $vs['position_name']; ?>
                                        </td>
                                        <td>
                                            <?= $vs['department_name']; ?>
                                        </td>
                                        <td>
                                            <?= $vs['contactnumber']; ?>
                                        </td>
                                        <td>
                                            <?= $vs['dob']; ?>
                                        </td>
                                    </tr>

                                <?php


                                }
                                ?>
								</tbody>
                    </table>
                                <button type="submit" name="submit" class="btn btn-one">submit</button>
                        </form>
                </div>

</body>




<?php
$this->load->view('admin/includes/footer');

?>