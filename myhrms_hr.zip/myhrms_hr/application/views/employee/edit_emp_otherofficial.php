<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$attenTypeArr = AttendanceTypeArr();
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>">Official</a></li>
                                    <li class="nav-item"><a class="nav-link active">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>">Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>">Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>">Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="body">
                                    <?php $this->load->view("admin/includes/upper-tab"); ?>
                                    <form method="post" action="<?= thisurl(); ?>">
                                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <div class="row clearfix">

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_sub_department"><?= form_error('sub_department'); ?></span>
                                                    <label class="text-muted">Sub Department : </label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="sub_department" id="sub_department" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->sub_department == '') ? "selected" : ""; ?> <?= set_select('sub_department', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$SubDepartmentRecArr) {
                                                            foreach ($SubDepartmentRecArr as $kEy => $rOws) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->sub_department == $rOws->id) ? "selected" : ""; ?> <?= set_select('sub_department', $rOws->id, (!empty($data) && $data == $rOws->id ? TRUE : FALSE)); ?> value="<?= $rOws->id; ?>"><?= $rOws->subdepartment; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Sub Department 2 : </label> <br>
                                                    <select class="form-control show-tick ms select2" name="sub_department_two" id="sub_department_two" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->sub_dept_second == '') ? "selected" : ""; ?> <?= set_select('sub_department_two', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$SubDepartmentRec2) {
                                                            foreach (@$SubDepartmentRec2 as $kEy => $rOws) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->sub_dept_second == $rOws->fld_id) ? "selected" : ""; ?> <?= set_select('sub_department_two', $rOws->fld_id, (!empty($data) && $data == $rOws->fld_id ? TRUE : FALSE)); ?> value="<?= $rOws->fld_id; ?>"><?= $rOws->sub_deptname; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Sub Department 3 : </label> <br>
                                                    <select class="form-control show-tick ms select2" name="sub_department_three" id="sub_department_three" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->sub_dept_third == '') ? "selected" : ""; ?> <?= set_select('sub_department_two', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$SubDepartmentRec3) {
                                                            foreach (@$SubDepartmentRec3 as $kEy => $rOws) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->sub_dept_third == $rOws->fld_id) ? "selected" : ""; ?> <?= set_select('sub_department_two', $rOws->fld_id, (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value="<?= $rOws->fld_id; ?>"><?= $rOws->sub_deptname; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_reviewing_officer_ro"><?= form_error('reviewing_officer_ro'); ?></span>
                                                    <label class="text-muted">Reviewing Officer (RO) : <span id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="reviewing_officer_ro" id="reviewing_officer_ro" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->reviewing_officer_ro == '') ? "selected" : ""; ?> <?= set_select('reviewing_officer_ro', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$RO_managerNewListArr) {
                                                            foreach (@$RO_managerNewListArr as $ROkey => $ROrow) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->reviewing_officer_ro == $ROrow->user_id) ? "selected" : ""; ?> <?= set_select('reviewing_officer_ro', $ROrow->user_id, (!empty($data) && $data == $ROrow->user_id ? TRUE : FALSE)); ?> value="<?= $ROrow->user_id; ?>"><?= $ROrow->userfullname . " [" . $ROrow->employeeId . "]"; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_ofc_locationid"><?= form_error('ofc_locationid'); ?></span>
                                                    <label class="text-muted">Company Location : <span id="reqd">*</span> </label> <br>
                                                    <select class="form-control show-tick ms select2" name="ofc_locationid" id="ofc_locationid" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->company_location == '') ? "selected" : ""; ?> <?= set_select('ofc_locationid', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$ofclocationRecArr) {
                                                            foreach (@$ofclocationRecArr as $kEy => $rOws) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->company_location == $rOws->id) ? "selected" : ""; ?> <?= set_select('ofc_locationid', $rOws->id, (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value="<?= $rOws->id; ?>"><?= $rOws->city_name; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_nodays_probation_period"><?= form_error('nodays_probation_period'); ?></span>
                                                    <label class="text-muted">No. of Days (Probation Period) : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('nodays_probation_period', @$OtherOfcRecDataArr->probation_period_no); ?>" onclick="rmvalidationerror(this.id)" name="nodays_probation_period" id="nodays_probation_period" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_sub_department"><?= form_error('notice_period_days'); ?></span>
                                                    <label class="text-muted">Notice Period in Days : <span id="reqd">*</span></label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('notice_period_days', @$OtherOfcRecDataArr->noticeperiod); ?>" onclick="rmvalidationerror(this.id)" name="notice_period_days" id="notice_period_days" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_thumb_code"><?= form_error('thumb_code'); ?></span>
                                                    <label class="text-muted">Thumb Code : </label> <br>
                                                    <select class="form-control show-tick ms select2" onclick="rmvalidationerror(this.id)" name="thumb_code" id="thumb_code" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->thumbcode == '') ? "selected" : ""; ?> <?= set_select('thumb_code', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$allActiveThumb) {
                                                            foreach (@$allActiveThumb as $Rows) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->thumbcode == $Rows->EmployeeID) ? "selected" : ""; ?> <?= set_select('thumb_code', $Rows->EmployeeID, (!empty($data) && $data == $Rows->EmployeeID ? TRUE : FALSE)); ?> value="<?= $Rows->EmployeeID; ?>"> <?= " (" . $Rows->EmployeeID . ") " . $Rows->EmployeeName; ?> </option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Payroll Code : </label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('payroll_code', @$OtherOfcRecDataArr->payrollcode); ?>" onclick="rmvalidationerror(this.id)" name="payroll_code" id="payroll_code" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_billablenonbillable"><?= form_error('billablenonbillable'); ?></span>
                                                    <label class="text-muted"> Billable/Non-Billable : <span id="reqd">*</span></label> <br>
                                                    <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="billablenonbillable" id="billablenonbillable" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->billable_non_billable == '') ? "selected" : ""; ?> <?= set_select('billablenonbillable', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select-- </option>
                                                        <option <?= (@$OtherOfcRecDataArr->billable_non_billable == '1') ? "selected" : ""; ?> <?= set_select('billablenonbillable', "1", (!empty($data) && $data == "1" ? TRUE : FALSE)); ?> value="1"> Billable </option>
                                                        <option <?= (@$OtherOfcRecDataArr->billable_non_billable == '2') ? "selected" : ""; ?> <?= set_select('billablenonbillable', "2", (!empty($data) && $data == "2" ? TRUE : FALSE)); ?> value="2"> Non-Billable </option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_attendance_type"><?= form_error('attendance_type'); ?></span>
                                                    <label class="text-muted">Attendance Type : <span id="reqd">*</span></label> <br>
                                                    <select class="form-control show-tick ms select2" onclick="rmvalidationerror(this.id)" name="attendance_type" id="attendance_type" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->atten_punch == '') ? "selected" : ""; ?> <?= set_select('attendance_type', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$attenTypeArr) {
                                                            foreach (@$attenTypeArr as $kEY => $rows) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->atten_punch == $kEY) ? "selected" : ""; ?> <?= set_select('attendance_type', $kEY, (!empty($data) && $data == $kEY ? TRUE : FALSE)); ?> value="<?= $kEY; ?>"><?= $rows; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label class="text-muted">Attendance Machine ID : </label> <br>
                                                    <input autocomplete="off" type="text" value="<?= set_value('attend_machineid', @$OtherOfcRecDataArr->machine_id); ?>" onclick="rmvalidationerror(this.id)" name="attend_machineid" id="attend_machineid" class="form-control">
                                                </div>
                                            </div>
                                            <?php $user_id = $this->uri->segment(2);
                                            if ($user_id) {
                                                $mode = modeofentry($user_id);
                                                if ($mode == 'Dummy') {
                                            ?>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <span id="reqd" class="error_floor_number"><?= form_error('floor_number'); ?></span>
                                                            <label class="text-muted">Related Employe: </label><br>

                                                            <Select name="related_with" class="form-control">
                                                                <option value="">-- Select Employee -- </option>
                                                                <?php $activeemploye = activeemploye();
                                                                foreach ($activeemploye as $key => $value) {
                                                                ?>
                                                                    <option <?= $OtherOfcRecDataArr->related_with == $value->id ? 'Selected' : ''; ?> value="<?= $value->id ?>"><?= $value->userfullname . "" . $value->employeeId
                                                                                                                                                                                ?></option>
                                                                <?php
                                                                } ?>


                                                            </Select>
                                                        </div>
                                                    </div>
                                            <?php
                                                }
                                            }
                                            ?>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <span id="reqd" class="error_floor_number"><?= form_error('floor_number'); ?></span>
                                                    <label class="text-muted">Sitting on Floor : </label><br>
                                                    <select class="form-control show-tick ms select2" onclick="rmvalidationerror(this.id)" name="floor_number" id="floor_number" data-placeholder="Select">
                                                        <option <?= (@$OtherOfcRecDataArr->floor_number == '') ? "selected" : ""; ?> <?= set_select('floor_number', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                        <?php
                                                        if (@$FloorRecArr) {
                                                            foreach (@$FloorRecArr as $kEY => $rows) {
                                                        ?>
                                                                <option <?= (@$OtherOfcRecDataArr->floor_number == $kEY) ? "selected" : ""; ?> <?= set_select('floor_number', $kEY, (!empty($data) && $data == $kEY ? TRUE : FALSE)); ?> value="<?= $kEY; ?>"><?= $rows; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input class="btn btn-primary" type="submit" value="Submit" name="" id="">
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function rmvalidationerror(returnarrg) {
                $('.error_' + returnarrg).html("");
            }
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<style>
    span#reqrd {
        color: red;
    }
</style>