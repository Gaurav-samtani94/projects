<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i class="fa fa-users"></i> Employee List </a> 
                                </li> 
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>" >Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other Official</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>" >Salary</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Personal</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>" >Contact</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a></li>
                                    <li class="nav-item"><a class="nav-link active">Job History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_experience/" . $RecEmplDetails->id); ?>">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                <label class="text-muted">Business Unit : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="business_unit" id="business_unit" onchange="setAllDeptByBunit()" data-placeholder="Select" >
                                                    <option <?= set_select('business_unit', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($BunitsRecArr) {
                                                        foreach ($BunitsRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= set_select('business_unit', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_department"><?= form_error('department'); ?></span>
                                                <label class="text-muted">Department : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="department" id="department" data-placeholder="Select" >
                                                    <option <?= set_select('department', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('business_unit')) {
                                                        @$deptArr = GetAllDepartmentByBUnit(set_value('business_unit'));
                                                        if (@$deptArr) {
                                                            foreach (@$deptArr as $reCdd) {
                                                                ?>
                                                                <option <?= set_select('department', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?> value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_job_titlegroup"><?= form_error('job_titlegroup'); ?></span>
                                                <label class="text-muted">Job Title/Group : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="job_titlegroup" id="job_titlegroup" onchange="setDesignationByJobTitID()" data-placeholder="Select" >
                                                    <option <?= set_select('job_titlegroup', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($JobGroupRecArr) {
                                                        foreach ($JobGroupRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= set_select('job_titlegroup', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_designation"><?= form_error('designation'); ?></span>
                                                <label class="text-muted">Designation : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="designation" id="designation" data-placeholder="Select" >
                                                    <option <?= set_select('designation', '', (!empty($data) && $data == '' ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if (set_value('designation')) {
                                                        @$allDesignationArr = GetAllDesignationByJtitID(set_value('job_titlegroup'));
                                                        if (@$allDesignationArr) {
                                                            foreach (@$allDesignationArr as $desRow) {
                                                                ?>
                                                                <option <?= set_select('designation', $desRow->id, (!empty($data) && $data == $desRow->id ? TRUE : FALSE)); ?> value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?></option>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_vendor"><?= form_error('vendor'); ?></span>
                                                <label class="text-muted">Company : <span id="reqd">*</span></label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="vendor" id="vendor" data-placeholder="Select" >
                                                    <option <?= set_select('vendor', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($CompanyRecArr) {
                                                        foreach ($CompanyRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= set_select('vendor', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->company_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_start_date"><?= form_error('start_date'); ?></span>
                                                <label class="text-muted">From : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)" type="text" class="form-control" name="start_date" autocomplete="off" id="start_date" value="<?= set_value('start_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_end_date"><?= form_error('end_date'); ?></span>
                                                <label class="text-muted">To : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true" data-provide="datepicker">
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)" type="text" class="form-control" name="end_date" autocomplete="off" id="end_date" value="<?= set_value('end_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_project_id"><?= form_error('project_id'); ?></span>
                                                <label class="text-muted">Project : </label> <br>
                                                <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms select2" name="project_id" id="project_id" data-placeholder="Select" >
                                                    <option <?= set_select('project_id', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    if ($ProjectsRecArr) {
                                                        foreach ($ProjectsRecArr as $keyy => $recD) {
                                                            ?>
                                                            <option <?= set_select('project_id', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->project_name; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">   
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit" name="extension_number" id="extension_number" >
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>


                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Business Unit</th>
                                            <th>Department</th>
                                            <th>Job Title</th>
                                            <th>Designation</th>
                                            <th>Company</th>
                                            <th>From</th>
                                            <th>To</th>
                                            <th>Action</th>
                                            <th>Template</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$jobhistoryRecArr) {
                                            foreach (@$jobhistoryRecArr as $kEy => $recD) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= ($recD->unitname) ? $recD->unitname : ""; ?></td>
                                                    <td><?= ($recD->deptname) ? $recD->deptname : ""; ?></td>
                                                    <td><?= ($recD->jobtitlename) ? $recD->jobtitlename : ""; ?></td>
                                                    <td><?= ($recD->positionname) ? $recD->positionname : ""; ?></td>
                                                    <td><?= ($recD->company_name) ? $recD->company_name : ""; ?></td>
                                                    <td><?= ($recD->start_date) ? date("d-m-Y", strtotime($recD->start_date)) : ""; ?></td>
                                                    <td><?= ($recD->end_date) ? date("d-m-Y", strtotime($recD->end_date)) : ""; ?></td>
                                                    <td>
                                                        <a href="javascript:void(0)" onclick="editjob('<?= $recD->id ?>')">
                                                    <i class="fa fa-edit" data-toggle="modal"
                                                        data-target="#jobEditModal"></i>
                                                </a> &nbsp;&nbsp;
                                                        <a style="cursor:pointer" onclick="deletejobhistory('<?= $recD->id ?>')">
                                                            <i class="fa fa-trash"></i>
                                                        </a> 
                                                    </td>
                                                    <!-- // -->
                                                    <?php if ($recD && $recD->pdf_lock == 0): ?>
                                            <!-- PDF is locked -->
                                            <td>
                                                <a href="<?=HOSTNAME.'uploads/job_history_pdf_files/'.$recD->tem_pdf; ?>"
                                                    title="Joining Letter" target="_blank">
                                                    <i class="fa fa-download"></i>
                                                </a> &nbsp;&nbsp;<span style="color:red">Locked</span>
                                            </td>
                                            <?php else: ?>
                                            <!-- PDF is unlocked -->
                                            <td>
                                                <a href="<?= base_url('joiningletter/'.$recD->id.'/'.$jobempId); ?>"
                                                    title="Joining Letter">
                                                    <i class="fa fa-eye"></i>
                                                </a> &nbsp;&nbsp;<span style="color:green">Unlocked</span>
                                            </td>
                                            <?php endif; ?>

                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                            <tr>
                                                <td style="color:red" colspan="9"> Record Not Found. </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		 <div class="container">
        <!-- The Modal -->
        <div class="modal" id="jobEditModal">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h6 class="modal-title">Job History</h6>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <form action="<?= base_url('employee/Employee_controller/jobhistoryUpdate')?>" method="POST">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <div class="row clearfix">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="reqd"
                                            class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                        <label class="text-muted">Business Unit : <span id="reqd">*</span></label> <br>
                                        <select class="form-control" name="editbusiness_unit" id="editbusiness_unit"
                                            onchange="AllDeptByBunit()">
                                            <option value="">--All--</option>
                                            <?php
                                                    if ($BunitsRecArr) {
                                                        foreach ($BunitsRecArr as $keyy => $recD) {
                                                            ?>
                                            <option value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                            <?php
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="reqd" class="error_department"><?= form_error('department'); ?></span>
                                        <label class="text-muted">Department : <span id="reqd">*</span></label>
                                        <br>
                                        <select class="form-control" name="editdepartment" id="editdepartment">
                                            <?php
                                                    if (set_value('editbusiness_unit')) {
                                                        @$deptArr = GetAllDepartmentByBUnit(set_value('editbusiness_unit'));
                                                        if (@$deptArr) {
                                                            foreach (@$deptArr as $reCdd) {
                                                                ?>
                                            <option
                                                <?= set_select('editdepartment', $reCdd->id, (!empty($data) && $data == $reCdd->id ? TRUE : FALSE)); ?>
                                                value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                            <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="reqd"
                                            class="error_job_titlegroup"><?= form_error('job_titlegroup'); ?></span>
                                        <label class="text-muted">Job Title/Group : <span id="reqd">*</span></label>
                                        <br>
                                        <select class="form-control" name="jobtitlegroup" id="jobtitlegroup"
                                            onchange="DesignationByJobTitID()">
                                            <option>--All--</option>
                                            <?php
                                                    if ($JobGroupRecArr) {
                                                        foreach ($JobGroupRecArr as $keyy => $recD) {
                                                            ?>
                                            <option value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?></option>
                                            <?php
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="text-muted">Designation : <span id="reqd">*</span></label>
                                        <br>
                                        <select class="form-control" name="editdesignation" id="editdesignation">
                                            <?php
                                                    if (set_value('editdesignation')) {
                                                        @$allDesignationArr = GetAllDesignationByJtitID(set_value('jobtitlegroup'));
                                                        if (@$allDesignationArr) {
                                                            foreach (@$allDesignationArr as $desRow) {
                                                                ?>
                                            <option value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?>
                                            </option>
                                            <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="reqd" class="error_vendor"><?= form_error('vendor'); ?></span>
                                        <label class="text-muted">Company : <span id="reqd">*</span></label>
                                        <br>
                                        <select class="form-control" name="editvendor" id="editvendor">
                                            <option value=""> -- Select -- </option>
                                            <?php
                                                    if ($CompanyRecArr) {
                                                        foreach ($CompanyRecArr as $keyy => $recD) {
                                                            ?>
                                            <option value="<?= $recD->id; ?>"><?= $recD->company_name; ?></option>
                                            <?php
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">

                                        <label>From : </label>
                                        <div class="input-group ">
                                            <input type="date" class="form-control" name="editstart_date"
                                                id="editstart_date">

                                        </div>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>To : </label> <br>
                                        <input type="date" class="form-control" name="editend_date" id="editend_date"
                                            value="<?= set_value('editend_date'); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="reqd" class="error_project_id"><?= form_error('project_id'); ?></span>
                                        <label class="text-muted">Project : </label> <br>
                                        <select class="form-control" name="editproject_id" id="editproject_id">
                                            <option value=""> -- Select -- </option>
                                            <?php
                                                    if ($ProjectsRecArr) {
                                                        foreach ($ProjectsRecArr as $keyy => $recD) {
                                                            ?>
                                            <option value="<?= $recD->id; ?>"><?= $recD->project_name; ?></option>
                                            <?php
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <input type="hidden" name="jobempId" id="jobempId" value="<?=$jobempId;?>">
                                        <input type="hidden" name="fId" id="fId" value="">
                                        <label class="text-muted"> &nbsp; </label> <br>
                                        <input class="btn btn-primary" type="submit" value="Submit"
                                            name="extension_number" id="extension_number">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>
                                                            function setAllDeptByBunit() {
                                                                var bunitID = $("#business_unit").val();
                                                                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>', csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                                                
                                                               
                                                                $('#department').val('');
                                                                $('#department').trigger("change");
                                                                
                                                                if (bunitID) {
                                                                    $.ajax({
                                                                        type: 'POST',
                                                                        url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                                                                        data: {[csrfName]: csrfHash, 'bunitid': bunitID},
                                                                        success: function (response) {
                                                                            var data = jQuery.parseJSON(response);
                                                                            if (data) {
                                                                                $.each(data, function (index, val) {
                                                                                    $('#department').append('<option value="' + val.id + '">' + val.deptname + '</option>');
                                                                                });
                                                                            }
                                                                        },

                                                                    });
                                                                }
                                                            }


                                                            function setDesignationByJobTitID() {
                                                                var jobtitleID = $('#job_titlegroup').val();
                                                                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>', csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                                                                
                                                               
                                                                $('#designation').val('');
                                                                $('#designation').trigger("change");
                                                                
                                                                if (jobtitleID) {
                                                                    $.ajax({
                                                                        type: 'POST',
                                                                        url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                                                                        data: {[csrfName]: csrfHash, 'jtitleid': jobtitleID},
                                                                        success: function (response) {
                                                                            var data = jQuery.parseJSON(response);
                                                                            if (data) {
                                                                                $.each(data, function (index, val) {
                                                                                    $('#designation').append('<option value="' + val.id + '">' + val.positionname + ' </option>');
                                                                                });
                                                                            }
                                                                        },

                                                                    });
                                                                }
                                                            }

        </script>
        <script>
            function rmvalidationerror(returnarrg) {
                $('.error_' + returnarrg).html("");
            }

            function deletejobhistory(fld_id) {
                if (confirm("Are you sure Delete this?")) {
                    window.location = "<?= base_url("delete_jobhistory/"); ?>" + fld_id;
                }
            }

        </script>
		 <!-- 20-10-2022 vivek -->
    <script>
    function editjob(fld_id) {
        $.ajax({
            type: 'POST',
            dataType: "text",
            url: "<?= base_url('employee/Employee_controller/Get_Single_Job_Record_By_Ajax'); ?>",
            data: {
                'editId': fld_id
            },
            method: 'POST',
            dataType: 'json',
            success: function(response) {

                $('#editbusiness_unit').val(response.businessunit)
                $('#editdepartment').val(response.department)
                $('#jobtitlegroup').val(response.jobtitleid)
                $('#editdesignation').val(response.positionheld)
                $('#editvendor').val(response.vendor)
                $('#editstart_date').val(response.start_date)
                $('#editend_date').val(response.end_date)
                $('#editproject_id').val(response.project_id)
                $('#fId').val(response.id);
                AllDeptByBunit(response.department);
                DesignationByJobTitID(response.positionheld);
            }
        });
    }
    </script>
    <script>
    function AllDeptByBunit(department) {
        var bunitID = $("#editbusiness_unit").val();
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';


        // $('#editdepartment').val('');
        // $('#editdepartment').trigger("change");
        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    // Remove options 
                    $('#editdepartment').find('option').not(':first').remove();
                    $('#editdepartment').find('option').not(':first').remove();

                    $('#editdepartment').append('<option value="">--Select State--</option>');
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#editdepartment').append('<option value="' + val.id + '">' + val
                                .deptname + '</option>');
                        });
                    }
                    $('#editdepartment').val(department);
                },

            });
        }
    }

    function DesignationByJobTitID(positionheld) {
        var jobtitleID = $('#jobtitlegroup').val();
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        if (jobtitleID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'jtitleid': jobtitleID
                },
                success: function(response) {
                    // Remove options 
                    $('#editdesignation').find('option').not(':first').remove();
                    // $('#sel_state').find('option').not(':first').remove();

                    $('#editdesignation').append('<option value="">--Select State--</option>');
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#editdesignation').append('<option value="' + val.id + '">' + val
                                .positionname + ' </option>');
                        });
                    }
                    $('#editdesignation').val(positionheld)
                },

            });
        }
    }
    </script>
		
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<style>
    span#reqrd {  color: red; }
</style>