<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> Employee Details Management</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('emp_list'); ?>" class="btn btn-sm btn-success btn-filter"><i
                                            class="fa fa-users"></i> Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("employee_edit/" . $RecEmplDetails->id); ?>">Official</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_otherofficial/" . $RecEmplDetails->id); ?>">Other
                                            Official</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_salarydetails/" . $RecEmplDetails->id); ?>">Salary</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_personaldetails/" . $RecEmplDetails->id); ?>">Personal</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_contact/" . $RecEmplDetails->id); ?>">Contact</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_skills/" . $RecEmplDetails->id); ?>">Skills</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_jobhistory/" . $RecEmplDetails->id); ?>">Job
                                            History</a></li>
                                    <li class="nav-item"><a class="nav-link active">Experience</a></li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_educationdetails/" . $RecEmplDetails->id); ?>">Education</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_trainingcertification/" . $RecEmplDetails->id); ?>">Training</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_insurance/" . $RecEmplDetails->id); ?>">Insurance</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_family/" . $RecEmplDetails->id); ?>">Family</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("edit_emp_accountsection/" . $RecEmplDetails->id); ?>">Account</a>
                                    </li>
                                    <li class="nav-item"><a class="nav-link"
                                            href="<?= base_url("emp_document/" . $RecEmplDetails->id); ?>">Document</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Data -->
                            <div class="tab-content">
                                <?php $this->load->view("admin/includes/upper-tab"); ?>
                                <form method="post" action="<?= thisurl(); ?>">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_comp_name"><?= form_error('comp_name'); ?></span>
                                                <label class="text-muted">Company Name : <span
                                                        id="reqd">*</span></label> <a class="btn btn-warning fa fa-plus"
                                                    title="Add Company" data-toggle="modal"
                                                    data-target="#addCompnyNameByHrms"
                                                    href="javascript:void(0)"></a><br>
                                                <!-- <input autocomplete="off" type="text" name="comp_name" id="comp_name"
                                                    onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_name'); ?>" class="form-control"> -->
                                                <select class="form-control show-tick ms select2" name="comp_name"  onchange="getcompany_detail()"
                                                    id="comp_name" onclick="rmvalidationerror(this.id)"
                                                    data-placeholder="Select">
                                                    <option
                                                        <?= set_select('is_ceg_exper', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                     if($comanyList){
                                                        foreach($comanyList as $rOws)
                                                        {
                                                            ?>
                                                    <option value="<?=$rOws->fld_id;?>">
                                                        <?=$rOws->company_name;?></option>
                                                    <?php 
                                                    }
                                                }
                                                    ?>


                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_comp_website"><?= form_error('comp_website'); ?></span>
                                                <label class="text-muted">Company Website : </label> <br>
                                                <input autocomplete="off" type="text" name="comp_website"
                                                    id="comp_website_add" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_website'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_comp_location"><?= form_error('comp_location'); ?></span>
                                                <label class="text-muted">Company Location : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="comp_location"
                                                    id="comp_location" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_location'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_designation"><?= form_error('designation'); ?></span>
                                                <label class="text-muted">Designation : <span id="reqd">*</span></label>
                                                <br>
                                                <input autocomplete="off" type="text" name="designation"
                                                    id="designation" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('designation'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_from_date"><?= form_error('from_date'); ?></span>
                                                <label class="text-muted">From : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input onclick="rmvalidationerror(this.id)" type="text"
                                                        class="form-control" name="from_date" autocomplete="off"
                                                        id="from_date" value="<?= set_value('from_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_to_date"><?= form_error('to_date'); ?></span>
                                                <label class="text-muted">To : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        type="text" class="form-control" name="to_date" id="to_date"
                                                        value="<?= set_value('to_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reason_for_leaving"><?= form_error('reason_for_leaving'); ?></span>
                                                <label class="text-muted">Reason for Leaving : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="reason_for_leaving"
                                                    id="reason_for_leaving" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reason_for_leaving'); ?>"
                                                    class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_name"><?= form_error('reference_name'); ?></span>
                                                <label class="text-muted">Referrer Name : 
												
														</label> <br>
                                                <input autocomplete="off" type="text" name="reference_name"
                                                    id="reference_name" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_contact"><?= form_error('reference_contact'); ?></span>
                                                <label class="text-muted">Referrer Contact : </label> <br>
                                                <input autocomplete="off" type="text" name="reference_contact"
                                                    id="reference_contact" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_contact'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_email"><?= form_error('reference_email'); ?></span>
                                                <label class="text-muted">Referrer Email : </label> <br>
                                                <input autocomplete="off" type="text" name="reference_email"
                                                    id="reference_email" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_email'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_last_salary_drawn"><?= form_error('last_salary_drawn'); ?></span>
                                                <label class="text-muted">Last salary Drawn : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="last_salary_drawn"
                                                    id="last_salary_drawn" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('last_salary_drawn'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_is_ceg_exper"><?= form_error('is_ceg_exper'); ?></span>
                                                <label class="text-muted">CEG Experiance ? <span
                                                        id="reqd">*</span></label> <br>
                                                <select class="form-control show-tick ms select2" name="is_ceg_exper"
                                                    id="is_ceg_exper" onclick="rmvalidationerror(this.id)"
                                                    data-placeholder="Select">
                                                    <option
                                                        <?= set_select('is_ceg_exper', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <option
                                                        <?= set_select('is_ceg_exper', "1", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value="1"> Yes </option>
                                                    <option
                                                        <?= set_select('is_ceg_exper', "2", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value="2"> No </option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit"
                                                    name="extension_number" id="extension_number">
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>

                            <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Comp. Name</th>
                                            <th>Comp. Website</th>

                                            <th>Designation</th>
                                            <th>From-To</th>

                                            <th>Referrer Name </th>
                                            <th>Referrer Contact </th>
                                            <th>Action </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (@$EmplExperienceRecArr) {
                                            foreach ($EmplExperienceRecArr as $kEy => $recD) {
                                                ?>
                                        <tr>
                                            <td><?= $kEy + 1; ?></td>
                                            <td><?= (@$recD->company_name) ? @$recD->company_name : ""; ?></td>
                                            <td><?= (@$recD->comp_website) ? @$recD->comp_website : ""; ?></td>
                                            <td><?= (@$recD->designation) ? @$recD->designation : ""; ?></td>
                                            <td><?= (@$recD->from_date) ? date("d-m-Y", strtotime($recD->from_date)) : ""; ?>
                                                <br>-
                                                <?= (@$recD->to_date) ? date("d-m-Y", strtotime($recD->to_date)) : ""; ?>
                                            </td>
                                            <td><?= (@$recD->reference_name) ? @$recD->reference_name : ""; ?></td>
                                            <td><?= (@$recD->reference_contact) ? @$recD->reference_contact : ""; ?>
                                            </td>
                                            <td>
                                                 <a class="fa fa-edit"
                                                    data-toggle="modal" data-target="#experinceModal" href="#" onclick="edit_emp_experince_detail('<?= $recD->id ?>')"></a><br>
&nbsp;&nbsp;
                                                <a style="cursor:pointer" onclick="delexperience('<?= $recD->id ?>')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php
                                            }
                                        } else {
                                            ?>
                                        <tr>
                                            <td style="color:red" colspan="10"> Record Not Found. </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- Abbhishek add this  18-10-2022-->
    <div class="modal" id="addCompnyNameByHrms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Company</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('employee/Employee_controller/add_company_in_main_company')?>"
                        method="POST">
                        <div class="form-group">
                            <label>Name:</label>
                            <input type="text" minlength="8" name="Name" class="form-control"
                                placeholder="Enter Comany Name" required>
                        </div>
                        <div class="form-group">
                            <label>Contact Number:</label>
                            <input type="number" name="number" class="form-control" placeholder="Enter Number" >
                        </div>
                        <div class="form-group">
                            <label>Email Id:</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter Email" >
                        </div>
                        <!-- <div class="form-group">
                            <label>Country:</label>
                            <input type="text" name="country" class="form-control" placeholder="Enter Country" required>
                        </div>
                        <div class="form-group">
                            <label>State:</label>
                            <input type="text" name="state" class="form-control" placeholder="Enter State" required>
                        </div> -->
                        <div class="form-group">
                            <label>Company Wesite:</label>
                            <input type="text" name="website" class="form-control" placeholder="Enter Wesite">
                        </div>
                        <input type="hidden" name="editId" value="<?=$edit_Id ;?>">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-secondary float-right" data-dismiss="modal">Close</button>
                </div>
                </form>
            </div>
        </div>
    </div>
	  <!-- Abbhishek add this  18-10-2022-->
    <div class="modal" id="experinceModal" tabindex="-1" role="dialog" aria-labelledby="experinceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="experinceModalLabel">Edit Experince</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?= base_url('update_experince'); ?>" method="post" class="form-horizontal form-label-left" >
                            
                <div class="modal-body">
                                    <div class="row clearfix">
                                    
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                        value="<?php echo $this->security->get_csrf_hash(); ?>">
                                   <input type="hidden" value="<?= $this->uri->segment(2);?>" name="emp_id">
                                   <input type="hidden" value="<?= $this->uri->segment(2);?>" name="edit_exp_id" id="edit_exp_id">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_comp_name"><?= form_error('comp_name'); ?></span>
                                                <label class="text-muted">Company Name : <span
                                                        id="reqd">*</span></label><br>
                                                <!-- <input autocomplete="off" type="text" name="comp_name" id="comp_name"
                                                    onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_name'); ?>" class="form-control"> -->
                                                <select class="form-control show-tick ms" name="comp_name"
                                                    id="edit_comp_name" onclick="rmvalidationerror(this.id)"
                                                    data-placeholder="Select">
                                                    <option
                                                        <?= set_select('is_ceg_exper', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                     if($comanyList){
                                                        foreach($comanyList as $rOws)
                                                        {
                                                            ?>
                                                    <option value="<?=$rOws->fld_id;?>">
                                                        <?=$rOws->company_name;?></option>
                                                    <?php 
                                                    }
                                                }
                                                    ?>


                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
											
                                                <span id="reqd"
                                                    class="error_comp_website"><?= form_error('comp_website'); ?></span>
                                                <label class="text-muted">Company Website : </label> <br>
                                                <input autocomplete="off" type="text" name="comp_website"
                                                    id="edit_comp_website" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_website'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_comp_location"><?= form_error('comp_location'); ?></span>
                                                <label class="text-muted">Company Location : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="comp_location"
                                                    id="edit_comp_location" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('comp_location'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_designation"><?= form_error('designation'); ?></span>
                                                <label class="text-muted">Designation : <span id="reqd">*</span></label>
                                                <br>
                                                <input autocomplete="off" type="text" name="designation"
                                                    id="edit_designation" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('designation'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_from_date"><?= form_error('from_date'); ?></span>
                                                <label class="text-muted">From : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input onclick="rmvalidationerror(this.id)" type="text"
                                                        class="form-control" name="from_date" autocomplete="off"
                                                        id="edit_from_date" value="<?= set_value('from_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_to_date"><?= form_error('to_date'); ?></span>
                                                <label class="text-muted">To : <span id="reqd">*</span></label> <br>
                                                <div class="input-group date" data-date-autoclose="true"
                                                    data-provide="datepicker">
                                                    <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                                        type="text" class="form-control" name="to_date" id="edit_to_date"
                                                        value="<?= set_value('to_date'); ?>">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-outline-secondary" type="button"><i
                                                                class="fa fa-calendar"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reason_for_leaving"><?= form_error('reason_for_leaving'); ?></span>
                                                <label class="text-muted">Reason for Leaving : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="reason_for_leaving"
                                                    id="edit_reason_for_leaving" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reason_for_leaving'); ?>"
                                                    class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_name"><?= form_error('reference_name'); ?></span>
                                                <label class="text-muted">Referrer Name : </label> <br>
                                                <input autocomplete="off" type="text" name="reference_name"
                                                    id="edit_reference_name" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_name'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_contact"><?= form_error('reference_contact'); ?></span>
                                                <label class="text-muted">Referrer Contact : </label> <br>
                                                <input autocomplete="off" type="text" name="reference_contact"
                                                    id="edit_reference_contact" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_contact'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_reference_email"><?= form_error('reference_email'); ?></span>
                                                <label class="text-muted">Referrer Email : </label> <br>
                                                <input autocomplete="off" type="text" name="reference_email"
                                                    id="edit_reference_email" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('reference_email'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_last_salary_drawn"><?= form_error('last_salary_drawn'); ?></span>
                                                <label class="text-muted">Last salary Drawn : <span
                                                        id="reqd">*</span></label> <br>
                                                <input autocomplete="off" type="text" name="last_salary_drawn"
                                                    id="edit_last_salary_drawn" onclick="rmvalidationerror(this.id)"
                                                    value="<?= set_value('last_salary_drawn'); ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd"
                                                    class="error_is_ceg_exper"><?= form_error('is_ceg_exper'); ?></span>
                                                <label class="text-muted">CEG Experiance ? <span
                                                        id="reqd">*</span></label> <br>
                                                <select class="form-control show-tick ms" name="is_ceg_exper"
                                                    id="edit_is_ceg_exper" onclick="rmvalidationerror(this.id)"
                                                    data-placeholder="Select">
                                                    <option
                                                        <?= set_select('is_ceg_exper', "", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value=""> -- Select -- </option>
                                                    <option
                                                        <?= set_select('is_ceg_exper', "1", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value="1"> Yes </option>
                                                    <option
                                                        <?= set_select('is_ceg_exper', "0", (!empty($data) && $data == "" ? TRUE : FALSE)); ?>
                                                        value="0"> No </option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-2">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input class="btn btn-primary" type="submit" value="Submit"
                                                    name="extension_number" id="extension_number">
                                            </div>
                                        </div> -->

                                    </div>
                                
                                        
                               
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                                            
                </form>
            </div>
        </div>
    </div>
    <!-- Abhoishek  model for add company -->
    <!-- Abhoishek  model for add company -->
    <script>

        function edit_emp_experince_detail(experince_id)
        {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                url: "<?=base_url('fetch_employee_experince'); ?>",
                type: "POST",
                data: {
                    experince_id: experince_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                // dataType: 'json',
                success: function(ress) {
                    var res = JSON.parse(ress);
                    // alert(a.course_name);
                    $("#edit_exp_id").val(res.id);
                    $("#edit_comp_name").val(res.comp_name);
                    $('#edit_comp_website').val(res.comp_website);
                    $('#edit_comp_location').val(res.comp_location);
                    $('#edit_designation').val(res.designation);
                    
                    $('#edit_from_date').val(res.from_date);
                    $('#edit_to_date').val(res.to_date);
                    $('#edit_reason_for_leaving').val(res.reason_for_leaving);
                    $('#edit_reference_name').val(res.reference_name);
                    $('#edit_reference_contact').val(res.reference_contact);
                    $('#edit_reference_email').val(res.reference_email);


              
                    $('#edit_last_salary_drawn').val(res.last_salary_drawn);
                    $('#edit_is_ceg_exper').val(res.is_ceg_exper);
                  

         

                  

                }
            });
        }
		  function getcompany_detail()
        {
           var company_id = $('#comp_name').val();
           var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                url: "<?=base_url('get_company_detail'); ?>",
                type: "POST",
                data: {
                    company_id: company_id,
                    [csrfName]: csrfHash,
                    // letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                // dataType: 'json',
                success: function(ress) {
                    var res = JSON.parse(ress);
$("#comp_website_add").val(res.company_website);
                    // alert(a.course_name);
                    // $("#edit_exp_id").val(res.id);
                    // $("#edit_comp_name").val(res.comp_name);
                    // $('#edit_comp_website').val(res.comp_website);
                    // $('#edit_comp_location').val(res.comp_location);
                    // $('#edit_designation').val(res.designation);
                    
                    // $('#edit_from_date').val(res.from_date);
                    // $('#edit_to_date').val(res.to_date);
                    // $('#edit_reason_for_leaving').val(res.reason_for_leaving);
                    // $('#edit_reference_name').val(res.reference_name);
                    // $('#edit_reference_contact').val(res.reference_contact);
                    // $('#edit_reference_email').val(res.reference_email);


              
                    // $('#edit_last_salary_drawn').val(res.last_salary_drawn);
                    // $('#edit_is_ceg_exper').val(res.is_ceg_exper);
                  

         

                  

                }
            });

        }
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }

    function delexperience(fld_id) {
        if (confirm("Are you sure Delete this?")) {
            window.location = "<?= base_url("delete_experience/"); ?>" + fld_id;
        }
    }
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>
<style>
span#reqrd {
    color: red;
}
</style>