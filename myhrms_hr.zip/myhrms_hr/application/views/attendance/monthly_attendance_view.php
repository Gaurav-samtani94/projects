<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
ul,
#myUL {
    list-style-type: none;
}

#myUL {
    margin: 0;
    padding: 0;
}

.caret {
    cursor: pointer;
    -webkit-user-select: none;
    /* Safari 3.1+ */
    -moz-user-select: none;
    /* Firefox 2+ */
    -ms-user-select: none;
    /* IE 10+ */
    user-select: none;
}

.caret::before {
    content: "\25B6";
    color: black;
    display: inline-block;
    margin-right: 6px;
}

.nested {
    display: none;
}

.active {
    display: block;
}
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <form method="post" action="<?= base_url("monthly_attendance"); ?>">
                                    <!-- <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                         value="<?php echo $this->security->get_csrf_hash(); ?>"> -->
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email">Business Unit : </label>

                                                <select name="businessunit" id="businessunit" class="form-control">
                                                    <option value=""> -- Select Business Unit-- </option>
                                                    <?php
                                                    if ($UnitNameArr) {
                                                        foreach ($UnitNameArr as $keyy => $list) {
                                                            ?>
                                                    <option value="<?= $list->id; ?>"><?= $list->unitname; ?>
                                                    </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email"> Employee Name: </label>
                                                <select class="form-control show-tick ms select2" name="user_id"
                                                    id="user_id" data-placeholder="Select">
                                                    <option value=""> -- Select Employee-- </option>
                                                    <?php
                                                    if ($userrecArr) {
                                                        foreach ($userrecArr as $keyy => $recD) {
                                                            ?>
                                                    <option <?= (@$userid == $recD->user_id) ? "Selected" : ""; ?>
                                                        value="<?= $recD->user_id; ?>"><?= $recD->userfullname; ?>
                                                    </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6">
                                            <div class="form-group">
                                                <label class="email"> Department: </label>
                                                <select class="form-control show-tick ms select2" name="departmentids"
                                                    id="departmentids" data-placeholder="Select">
                                                    <option value=""> -- Select -- </option>
                                                    <?php
                                                    $all_Activedepartment = get_departments();
                                                    if ($all_Activedepartment) {
                                                        foreach ($all_Activedepartment as $keyy => $recD) {
                                                            ?>
                                                    <option <?= (@$dpt_id == $recD->id) ? "Selected" : ""; ?>
                                                        value="<?= $recD->id; ?>"><?= $recD->deptname; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <label class="email"> Year : </label>
                                            <select class="form-control mb-3" name="attendance_year"
                                                id="attendance_year">
                                                <option <?= (@$atten_year == "2019") ? "Selected" : ""; ?> value="2019">
                                                    2019 </option>
                                                <option <?= (@$atten_year == "2020") ? "Selected" : ""; ?> value="2020">
                                                    2020 </option>
                                                <option <?= (@$atten_year == "2021") ? "Selected" : ""; ?> value="2021">
                                                    2021 </option>
                                                <option <?= (@$atten_year == "2022") ? "Selected" : ""; ?> value="2022">
                                                    2022 </option>
                                                <option <?= (@$atten_year == "2023") ? "Selected" : ""; ?> value="2023">
                                                    2023 </option>
                                                <option <?= (@$atten_year == "2024") ? "Selected" : ""; ?> value="2024">
                                                    2024 </option>
                                                <option <?= (@$atten_year == "2025") ? "Selected" : ""; ?> value="2025">
                                                    2025 </option>
                                                <option <?= (@$atten_year == "2026") ? "Selected" : ""; ?> value="2026">
                                                    2026</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <label class="email"> Month : </label>
                                            <select class="form-control mb-3" name="attendance_month"
                                                id="attendance_month">
                                                <option <?= (@$atten_month == "01") ? "Selected" : ""; ?> value="01">
                                                    January </option>
                                                <option <?= (@$atten_month == "02") ? "Selected" : ""; ?> value="02">
                                                    February </option>
                                                <option <?= (@$atten_month == "03") ? "Selected" : ""; ?> value="03">
                                                    March </option>
                                                <option <?= (@$atten_month == "04") ? "Selected" : ""; ?> value="04">
                                                    April </option>
                                                <option <?= (@$atten_month == "05") ? "Selected" : ""; ?> value="05">
                                                    May </option>
                                                <option <?= (@$atten_month == "06") ? "Selected" : ""; ?> value="06">
                                                    June </option>
                                                <option <?= (@$atten_month == "07") ? "Selected" : ""; ?> value="07">
                                                    July </option>
                                                <option <?= (@$atten_month == "08") ? "Selected" : ""; ?> value="08">
                                                    August </option>
                                                <option <?= (@$atten_month == "09") ? "Selected" : ""; ?> value="09">
                                                    September </option>
                                                <option <?= (@$atten_month == "10") ? "Selected" : ""; ?> value="10">
                                                    October </option>
                                                <option <?= (@$atten_month == "11") ? "Selected" : ""; ?> value="11">
                                                    November </option>
                                                <option <?= (@$atten_month == "12") ? "Selected" : ""; ?> value="12">
                                                    December </option>
                                            </select>

                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <div class="mb-3 mt-3 pt-2 mt-xs-2 pt-xs-0 mb-xs-0">
                                                <button type="submit" id="btn-filter" class="btn btn-success"> Filter
                                                </button>
                                                <!-- <button type="reset" id="btn-reset" class="btn btn-success"> Reset
                                                </button> -->
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="attendance_table" class="table table-striped display nowrap table-bordered table-hover"
                                        cellspacing="0" width="100%">
                                        <thead class="month_chage">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>EMPCode</th>
                                                <th>EMPName</th>
                                                <th>Payroll ID</th>
                                                <th>B.Unit</th>
                                                <th>Department</th>
                                                <th>Position</th>
                                                <th>JobTitle</th>
                                                <th>Location</th>
                                                <th>Machine ID</th>
                                                <th>Shift In Time</th>
                                                <th>Shift Out Time</th>
                                                <?php if($dateRangeArr){ foreach($dateRangeArr as $date){ $Dispdate = date("d", strtotime($date));?>
                                                <th><?= $Dispdate; ?></th>
                                                <?php } } ?>
                                                <th>Total LQL</th>
                                                <th>Total LHD</th>
                                                <th>Total QL</th>
                                                <th>Total HD</th>
                                                <th>Total L</th>
                                                <th>Total HDL</th>
                                                <th>Total SL</th>
                                                <th>Total WO</th>
                                                <th>Total WFH</th>
                                                <th>Total H</th>
                                                <th>Total RH</th>
                                                <th>Total T</th>
                                                <th>Total P</th>
                                                <th>Total A</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($attendance):
                                            $AttColorCodeArr = array(
                                                "WO" => "<span style='color:#3B71CA'>Wo</span>",
                                                "L" => "<span style='color:#54B4D'>L</span>",
                                                "HDL" => "<span style='color:#54B4D3'>HDL</span>",
                                                "SL" => "<span style='color:#54B4D3'>SL</span>",
                                                "T" => "<span style='color:#54B4D3'>T</span>",
                                                "H" => "<span style='color:#54B4D3'>H</span>",
                                                "A" => "<span style='color:#DC4C64'>A</span>",
                                                "LQL" => "<span style='color:#DC4C64'>LQL</span>",
                                                "LHD" => "<span style='color:#DC4C64'>LHD</span>",
                                                "MP" => "<span style='color:#E4A11B'>MP</span>",
                                                "HD" => "<span style='color:#E4A11B'>HD</span>",
                                                "RH" => "<span style='color:#E4A11B'>RH</span>",
                                                "P" => "<span style='color:#14A44D'>P</span>",
                                                "QL" => "<span style='color:#14A44D'>QL</span>",
                                                "WFH" => "<span style='color:#14A44D'>WFH</span>",
                                            );     
                                            foreach($attendance as $keys=>$roWs):
                                                $status=array($roWs->d_01,$roWs->d_02,$roWs->d_03,$roWs->d_04,$roWs->d_05,$roWs->d_06,$roWs->d_07,$roWs->d_08,$roWs->d_09,$roWs->d_10,$roWs->d_11,$roWs->d_12,$roWs->d_13,$roWs->d_14,$roWs->d_15,$roWs->d_16,$roWs->d_17,$roWs->d_18,$roWs->d_19,$roWs->d_20,$roWs->d_21,$roWs->d_22,$roWs->d_23,$roWs->d_24,$roWs->d_25,$roWs->d_26,$roWs->d_27,$roWs->d_28,$roWs->d_29,$roWs->d_30,$roWs->d_31);
                                                $count_status=array_count_values($status);
                                                ?>
                                            <tr>
                                                <td><?=$keys++;?></td>
                                                <td><?=$roWs->employeeId;?></td>
                                                <td><?=$roWs->userfullname;?></td>
                                                <td><?=$roWs->payrollcode;?></td>
                                                <td><?=$roWs->businessunit_name;?></td>
                                                <td><?=$roWs->department_name;?></td>
                                                <td><?=$roWs->position_name;?></td>
                                                <td><?=$roWs->jobtitle_name;?></td>
                                                <td><?=$roWs->city_name;?></td>
                                                <td><?=$roWs->machine_id;?></td>
                                                <td><?=$roWs->S_in_time;?></td>
                                                <td><?=$roWs->S_out_time;?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_01];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_02];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_03];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_04];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_05];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_06];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_07];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_08];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_09];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_10];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_11];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_12];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_13];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_14];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_15];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_16];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_17];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_18];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_19];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_20];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_21];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_22];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_23];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_24];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_25];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_26];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_27];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_28];?></td>
                                                <?php if($month_last_date == '31'):?>
                                                <td><?=$AttColorCodeArr[$roWs->d_29];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_30];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_31];?></td>
                                                <?php endif; if($month_last_date == '30'):?>
                                                <td><?=$AttColorCodeArr[$roWs->d_29];?></td>
                                                <td><?=$AttColorCodeArr[$roWs->d_30];?></td>
                                                <?php endif; if($month_last_date == '29'):?>
                                                <td><?=$AttColorCodeArr[$roWs->d_29];?></td>
                                                <?php endif; ?>
                                                <td><?=$count_status[LQL];?></td>
                                                <td><?=$count_status[LHD];?></td>
                                                <td><?=$count_status[QL];?></td>
                                                <td><?=$count_status[HD];?></td>
                                                <td><?=$count_status[L];?></td>
                                                <td><?=$count_status[HDL];?></td>
                                                <td><?=$count_status[SL];?></td>
                                                <td><?=$count_status[WO];?></td>
                                                <td><?=$count_status[WFH];?></td>
                                                <td><?=$count_status[H];?></td>
                                                <td><?=$count_status[RH];?></td>
                                                <td><?=$count_status[T];?></td>
                                                <td><?=$count_status[P];?></td>
                                                <td><?=$count_status[A]; ?></td>
                                            </tr>
                                            <?php endforeach; endif;?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
</body>
<script>
var attendance_table;
$(document).ready(function() {
    attendance_table = $('#attendance_table').DataTable({
        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: [
                'copy',
                'excel',
                'csv',
                'pdf',
                'print'
            ],
            exportOptions: {
                modifier: {
                    page: 'current'
                }
            }
        }],
        //Set column definition initialisation properties.
        "columnDefs": [{
            "targets": [0], //first column / numbering column
            "orderable": false, //set not orderable
        }, ],
        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
});
</script>
<?php $this->load->view('admin/includes/footer'); ?>