 <?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
 <style>
ul,
#myUL {
    list-style-type: none;
}

#myUL {
    margin: 0;
    padding: 0;
}

.caret {
    cursor: pointer;
    -webkit-user-select: none;
    /* Safari 3.1+ */
    -moz-user-select: none;
    /* Firefox 2+ */
    -ms-user-select: none;
    /* IE 10+ */
    user-select: none;
}

.caret::before {
    content: "\25B6";
    color: black;
    display: inline-block;
    margin-right: 6px;
}

.nested {
    display: none;
}

.active {
    display: block;
}
 </style>

 <body class="theme-cyan">
     <div id="wrapper">
         <?php
        $this->load->view('admin/includes/sidebar');
        ?>
         <div id="main-content">
             <div class="container-fluid">
                 <div class="block-header stepper">
                     <div class="row">
                         <div class="col-lg-8 col-md-8 col-sm-12">
                             <ul class="breadcrumb">
                                 <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                 </li>
                                 <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                 <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                             </ul>
                         </div>
                     </div>
                 </div>
                 <div class="row clearfix">
                     <div class="col-lg-12">
                         <div class="card">
                             <div class="header">
                                 <form method="post" action="<?= base_url("attendance"); ?>">
                                     <!-- <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                         value="<?php echo $this->security->get_csrf_hash(); ?>"> -->
                                     <div class="row clearfix">
                                         <div class="col-lg-4 col-md-6">
                                             <label class="email"> Year : </label>
                                             <select class="form-control mb-3" name="attendance_year"
                                                 id="attendance_year">
                                                 <option <?= (@$atten_year == "2019") ? "Selected" : ""; ?>
                                                     value="2019"> 2019 </option>
                                                 <option <?= (@$atten_year == "2020") ? "Selected" : ""; ?>
                                                     value="2020"> 2020 </option>
                                                 <option <?= (@$atten_year == "2021") ? "Selected" : ""; ?>
                                                     value="2021"> 2021 </option>
                                                 <option <?= (@$atten_year == "2022") ? "Selected" : ""; ?>
                                                     value="2022"> 2022 </option>
                                                 <option <?= (@$atten_year == "2023") ? "Selected" : ""; ?>
                                                     value="2023"> 2023 </option>
                                                 <option <?= (@$atten_year == "2024") ? "Selected" : ""; ?>
                                                     value="2024"> 2024 </option>
                                                 <option <?= (@$atten_year == "2025") ? "Selected" : ""; ?>
                                                     value="2025"> 2025 </option>
                                                 <option <?= (@$atten_year == "2026") ? "Selected" : ""; ?>
                                                     value="2026"> 2026</option>
                                             </select>
                                         </div>
                                         <div class="col-lg-4 col-md-6">
                                             <label class="email"> Month : </label>
                                             <select class="form-control mb-3" name="attendance_month"
                                                 id="attendance_month" onchange="this.form.submit()">
                                                 <option <?= (@$atten_month == "01") ? "Selected" : ""; ?> value="01">
                                                     January </option>
                                                 <option <?= (@$atten_month == "02") ? "Selected" : ""; ?> value="02">
                                                     February </option>
                                                 <option <?= (@$atten_month == "03") ? "Selected" : ""; ?> value="03">
                                                     March </option>
                                                 <option <?= (@$atten_month == "04") ? "Selected" : ""; ?> value="04">
                                                     April </option>
                                                 <option <?= (@$atten_month == "05") ? "Selected" : ""; ?> value="05">
                                                     May </option>
                                                 <option <?= (@$atten_month == "06") ? "Selected" : ""; ?> value="06">
                                                     June </option>
                                                 <option <?= (@$atten_month == "07") ? "Selected" : ""; ?> value="07">
                                                     July </option>
                                                 <option <?= (@$atten_month == "08") ? "Selected" : ""; ?> value="08">
                                                     August </option>
                                                 <option <?= (@$atten_month == "09") ? "Selected" : ""; ?> value="09">
                                                     September </option>
                                                 <option <?= (@$atten_month == "10") ? "Selected" : ""; ?> value="10">
                                                     October </option>
                                                 <option <?= (@$atten_month == "11") ? "Selected" : ""; ?> value="11">
                                                     November </option>
                                                 <option <?= (@$atten_month == "12") ? "Selected" : ""; ?> value="12">
                                                     December </option>
                                             </select>

                                         </div>
                                     </div>
                                 </form>
                                 <form id="form-filter">
                                 <div class="row clearfix">
                                     
                                         <div class="col-lg-3 col-md-6">
                                             <div class="form-group">
                                                 <label class="email">Business Unit : </label>

                                                 <select name="businessunit" id="businessunit" class="form-control">
                                                     <option value=""> -- Select Business Unit-- </option>
                                                     <?php
                                                    if ($UnitNameArr) {
                                                        foreach ($UnitNameArr as $keyy => $list) {
                                                            ?>
                                                     <option value="<?= $list->id; ?>"><?= $list->unitname; ?>
                                                     </option>
                                                     <?php
                                                        }
                                                    }
                                                    ?>
                                                 </select>
                                             </div>
                                         </div>
                                         <div class="col-lg-3 col-md-6">
                                             <div class="form-group">
                                                 <label class="email"> Employee Name: </label>
                                                 <select class="form-control show-tick ms select2" name="user_id"
                                                     id="user_id" data-placeholder="Select">
                                                     <option value=""> -- Select Employee-- </option>
                                                     <?php
                                                    if ($userrecArr) {
                                                        foreach ($userrecArr as $keyy => $recD) {
                                                            ?>
                                                     <option <?= (@$userid == $recD->user_id) ? "Selected" : ""; ?>
                                                         value="<?= $recD->user_id; ?>"><?= $recD->userfullname; ?>
                                                     </option>
                                                     <?php
                                                        }
                                                    }
                                                    ?>
                                                 </select>
                                             </div>
                                         </div>

                                         <div class="col-lg-3 col-md-6">
                                             <div class="form-group">
                                                 <label class="email"> Department: </label>
                                                 <select class="form-control show-tick ms select2" name="departmentids"
                                                     id="departmentids" data-placeholder="Select">
                                                     <option value=""> -- Select -- </option>
                                                     <?php
                                                    $all_Activedepartment = get_departments();
                                                    if ($all_Activedepartment) {
                                                        foreach ($all_Activedepartment as $keyy => $recD) {
                                                            ?>
                                                     <option <?= (@$dpt_id == $recD->id) ? "Selected" : ""; ?>
                                                         value="<?= $recD->id; ?>"><?= $recD->deptname; ?></option>
                                                     <?php
                                                        }
                                                    }
                                                    ?>
                                                 </select>
                                             </div>
                                         </div>
                                         <div class="col-lg-3 col-md-6">
                                             <div class="mb-3 mt-3 pt-2 mt-xs-2 pt-xs-0 mb-xs-0">
                                                 <button type="submit" id="btn-filter" class="btn btn-one"> Filter
                                                 </button>
                                                 <button type="reset" id="btn-reset" class="btn btn-success"> Reset
                                                 </button>
                                             </div>
                                         </div>
                                 </div>
                                 </form>
                             </div>
                             <div class="body">
                                 <div class="table-responsive">
                                     <table id="attendance_table"
                                         class="table table-striped display nowrap table-bordered table-hover"
                                         cellspacing="0" width="100%">
                                         <thead class="month_chage">
                                             <tr>
                                                 <th>Sr. No</th>
                                                 <th>EMPCode</th>
                                                 <th>EMPName</th>
                                                 <th>Payroll ID</th>
                                                 <th>B.Unit</th>
                                                 <th>Department</th>
                                                 <th>Position</th>
                                                 <th>JobTitle</th>
                                                 <th>Location</th>
                                                 <th>Machine ID</th>
                                                 <th>Shift In Time</th>
                                                 <th>Shift Out Time</th>
                                                 <?php if($dateRangeArr){ foreach($dateRangeArr as $date){ $Dispdate = date("d", strtotime($date));?>
                                                 <th><?= $Dispdate; ?></th>
                                                 <?php } } ?>
                                                 <th>Total LQL</th>
                                                 <th>Total LHD</th>
                                                 <th>Total QL</th>
                                                 <th>Total HD</th>
                                                 <th>Total L</th>
                                                 <th>Total HDL</th>
                                                 <th>Total SL</th>
                                                 <th>Total WO</th>
                                                 <th>Total WFH</th>
                                                 <th>Total H</th>
                                                 <th>Total RH</th>
                                                 <th>Total T</th>
                                                 <th>Total P</th>
                                                 <th>Total A</th>
                                             </tr>
                                         </thead>
                                     </table>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     </div>
     <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

 </body>

 <script>
$(document).on('change', '.month_select', function(event) { //button filter event click
    event.preventDefault();
    var month = $('#attendance_month').val();
    var year = $('#attendance_year').val();


    $.ajax({
        type: 'POST',
        url: '<?php echo base_url('attendance/Attendance_Controller/month_list_By_ajax'); ?>',
        dataType: "json",
        data: {
            month: month,
            year: year
        },
        success: function(val) {
            var datas =
                '<tr><th>Sr. No</th><th>EMPCode</th><th>EMPName</th><th>Payroll ID</th><th>B.Unit</th><th>Department</th><th>Position</th><th>JobTitle</th><th>Location</th><th>Machine ID</th><th>Shift In Time</th><th>Shift Out Time</th>';
            for (var i = 1; i <= val; i++) {
                datas = datas + '<th>' + i + '</th>';
                // $(city).append('<option id=' + data[i].sysid + ' value=' + data[i].city_name + '>' +
                //     data[i].city_name + '</option>');

            }
            datas = datas +
                '<th>Total LQL</th><th>Total LHD</th><th>Total QL</th><th>Total HD</th><th>Total L</th><th>Total HDL</th><th>Total SL</th><th>Total WO</th><th>Total WFH</th><th>Total H</th><th>Total RH</th><th>Total T</th><th>Total P</th><th>Total A</th></tr>';
            $('.month_chage').html(datas);

        }

    });
});
// function theadhandler(){ //button filter event click
//     alert('see');
//     var month = $('#attendance_month').val();
//     var year = $('#attendance_year').val();
//     $.ajax({
//         type: 'POST',
//         url: '<?php echo base_url('attendance/Attendance_Controller/month_list_By_ajax'); ?>',
//         dataType: "json",
//         data: {
//             month: month,
//             year: year
//         },
//         success: function(data) {
//             var city = ('#thead_ajax');
//             $(thead).empty();
//             $(thead).append('<tr><th>Sr. No</th><th>EMPCode</th><th>EMPName</th><th>Payroll ID</th><th>B.Unit</th><th>Department</th><th>Position</th><th>JobTitle</th><th>Location</th><th>Machine ID</th><th>Shift In Time</th><th>Shift Out Time</th><th>'+

//             for (var i = 1; i <=data; i++) {
//                 i;
//                 // $(city).append('<option id=' + data[i].sysid + ' value=' + data[i].city_name + '>' +
//                 //     data[i].city_name + '</option>');

//             }
//             +'</th> <th>Total LQL</th><th>Total LHD</th><th>Total QL</th><th>Total HD</th><th>Total L</th><th>Total HDL</th><th>Total SL</th><th>Total WO</th><th>Total WFH</th><th>Total H</th><th>Total RH</th><th>Total T</th><th>Total P</th><th>Total A</th></tr>');
//         }

//     });
// };
$("#form-filter").on("submit", function(event) {
    event.preventDefault();

});
 </script>
 <script>
var attendance_table;
// var titleArray = [];
// var parsedJson;
// var j;
// var mTitles;
$(document).ready(function() {

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    attendance_table = $('#attendance_table').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            "url": "<?php echo base_url('attendance/Attendance_Controller/attendance_list_By_ajax'); ?>",
            "type": "POST",
            "data": function(data) {
                data.businessunit = $('#businessunit').val();
                data.user_id = $('#user_id').val();
                data.departmentids = $('#departmentids').val();
                data.attendance_month = $('#attendance_month').val();
                data.attendance_year = $('#attendance_year').val();
            },

        },
        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: [
                'copy',
                'excel',
                'csv',
                'pdf',
                'print'
            ]
        }],
        //Set column definition initialisation properties.
        "columnDefs": [{
            "targets": [0], //first column / numbering column
            "orderable": false, //set not orderable
        }, ],
        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
    $('#btn-filter').click(function() { //button filter event click
        attendance_table.ajax.reload(); //just reload table
    });
    $('#btn-reset').click(function() { //button reset event click
        $('#form-filter')[0].reset();
        attendance_table.ajax.reload(); //just reload table
    });
});
 </script>
 <script type="text/javascript">
var table;
$(document).ready(function() {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    table = $('#table').DataTable({
        "processing": true,
        "serverSide": true,
        "pageLength": -1,
        "order": [],
        "scrollY": '60vh',
        "scrollX": true,
        "ajax": {
            "url": "<?php echo base_url('attendance_report/Attendance_controller/ajax_list'); ?>",
            "type": "POST",
            "data": function(data) {
                data.atten_report = $('#repmonth').val();
                data.atten_jobtitle = $('#repyear').val();
            },
            data: {
                [csrfName]: csrfHash
            },

        },
        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: [
                'copy',
                'excel',
                'csv',
                'pdf',
                'print'
            ]
        }],
        //Set column definition initialisation properties.
        "columnDefs": [{
            "targets": [0], //first column / numbering column
            "orderable": false, //set not orderable
        }, ],
        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
    $('#btn-filter').click(function() { //button filter event click
        table.ajax.reload(); //just reload table
    });
    $('#btn-reset').click(function() { //button reset event click
        $('#form-filter')[0].reset();
        table.ajax.reload(); //just reload table
    });
});

var table1;
$(document).ready(function() {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    //datatables
    table1 = $('#table1').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "scrollY": '60vh',
        "scrollX": true,
        "ajax": {
            "url": "<?php echo base_url('ajax_attendance_report_leave_list') ?>",
            "type": "POST",
            "data": function(data) {
                data.atten_report = $('#atten_report').val();
                data.atten_jobtitle = $('#atten_jobtitle').val();
                data.atten_busintitle = $('#atten_busintitle').val();
            },
            data: {
                [csrfName]: csrfHash
            },

        },

        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
        }],

        "columnDefs": [{
            "targets": [0],
            "orderable": false
        }],

        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
    // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
    // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
    $('#btn-filter').click(function() { //button filter event click
        table1.ajax.reload(); //just reload table
    });
    $('#btn-reset').click(function() { //button reset event click
        $('#form-filter')[0].reset();
        table1.ajax.reload(); //just reload table
    });
});

var table2;
$(document).ready(function() {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    //datatables
    table2 = $('#table2').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            "url": "<?php echo base_url('ajax_attendance_report_tour_list') ?>",
            "type": "POST",
            "data": function(data) {
                data.atten_report = $('#atten_report').val();
                data.atten_jobtitle = $('#atten_jobtitle').val();
                data.atten_busintitle = $('#atten_busintitle').val();
            },
            data: {
                [csrfName]: csrfHash
            },

        },

        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
        }],
        "columnDefs": [{
            "targets": [0],
            "orderable": false
        }],
        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
    // var colvis2 = new $.fn.dataTable.ColVis(table2); //initial colvis
    // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
    $('#btn-filter').click(function() { //button filter event click
        table2.ajax.reload(); //just reload table
    });
    $('#btn-reset').click(function() { //button reset event click
        $('#form-filter')[0].reset();
        table2.ajax.reload(); //just reload table
    });
});

var table3;
$(document).ready(function() {
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    //datatables
    table3 = $('#table3').DataTable({
        "processing": true,
        "serverSide": true,
        "pageLength": -1,
        "order": [],
        "scrollY": '60vh',
        "scrollX": true,
        "ajax": {
            "url": "<?php echo base_url('attendance_report/attendancereport/ajax_attendance_report_list_all') ?>",
            "type": "POST",
            "data": function(data) {
                data.atten_report = $('#atten_report').val();
                data.atten_jobtitle = $('#atten_jobtitle').val();
                data.atten_busintitle = $('#atten_busintitle').val();
            },
            data: {
                [csrfName]: csrfHash
            },
        },

        "dom": 'lBfrtip',
        "buttons": [{
            extend: 'collection',
            text: 'Export',
            buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
        }],

        "columnDefs": [{
            "targets": [0],
            "orderable": false
        }],

        "aLengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
    });
    // var colvis2 = new $.fn.dataTable.ColVis(table3); //initial colvis
    // $('#colvis2').html(colvis2.button()); //add colvis button to div with id="colvis"
    $('#btn-filter').click(function() { //button filter event click
        table3.ajax.reload(); //just reload table
    });
    $('#btn-reset').click(function() { //button reset event click
        $('#form-filter')[0].reset();
        table3.ajax.reload(); //just reload table
    });
});
 </script>
 <?php $this->load->view('admin/includes/footer'); ?>