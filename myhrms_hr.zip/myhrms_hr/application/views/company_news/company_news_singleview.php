<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<style>
.main_view {
    border: 1px solid #bfbfbf;
    overflow: hidden;
    font-family: 'Roboto Regular', sans-serif;
    font-size: 14px;
    margin-bottom: 10px;
}
.main_view_child:nth-child(odd) {
    background: #f9f9f9;
}

.main_view_child {
    position: relative;
    clear: both;
    overflow: hidden;
}
.width_20_left {
    width: 20%;
    float: left;
    -webkit-box-sizing: border-box;
    -ms-box-sizing: border-box;
    box-sizing: border-box;
    padding: 10px 10px;
    text-align: left;
}
.width_80_right {
    width: 80%;
    float: left;
    border-left: 1px solid #e5e5e5;
    -webkit-box-sizing: border-box;
    -ms-box-sizing: border-box;
    box-sizing: border-box;
    padding: 10px 10px;
    text-align: left;
    word-wrap: break-word;
}
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
						 <!--<div class="col-lg-5 col-md-4 col-sm-12"> 
							<a href="<?= base_url('news_list');?>" class="btn btn-primary" style="float:right; margin-top:25px;">Back<<</a>
						 </div>-->
                    </div>
                </div>
				<?php //print_r($singleRecNews);
					$file_name = ($singleRecNews->doc_file) ? $singleRecNews->doc_file : "";
					$file_path = ($singleRecNews->doc_file) ? COMPANY_NEWS.$singleRecNews->doc_file : "";
				?>	
                <div class="row clearfix">
                    <div class="col-lg-12">
                        
                        <div class="card">
						
                            <div class="body">
							<a href="<?= base_url('news_list');?>" class="btn btn-one mb-2">Back<<</a>
								<div class="main_view">
									
									<div class="main_view_child">
										<div class="width_20_left">Title</div>
										<div class="width_80_right"><?= $singleRecNews->title; ?></div>
									</div>
									
									<div class="main_view_child">
										<div class="width_20_left">Category</div>
										<div class="width_80_right"><?= $singleRecNews->news_category_title; ?></div>
									</div>
									
									
									<div class="main_view_child">
										<div class="width_20_left">Description</div>
										<div class="width_80_right">
											<textarea id="description" name="description" class="form-control"  disabled><?= $singleRecNews->description; ?></textarea>
										</div>
									</div>
									
									<div class="main_view_child">
										<div class="width_20_left">Attachments</div>
										<div class="width_80_right">
										<?php if($file_name==""){?>
											No Attachment
										<?php } else{ ?>
										<a target='_blank' href='<?= $file_path;?>'><?= $file_name?></a>
										<?php } ?>
										</div>
									</div>
									
									<div class="main_view_child">
										<div class="width_20_left">Posted Date</div>
										<div class="width_80_right"><?= $singleRecNews->created; ?></div>
									</div>
								</div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script>
			CKEDITOR.replace( 'description', {
				toolbar: [
					[ 'Cut', 'Copy', 'Paste', 'PasteText', '-', 'Undo', 'Redo' ,'-', 'Image','Table','-','Link','Smiley','TextColor','BGColor','NumberedList','BulletedList'],			
					'/',																					
					[ 'Bold', 'Italic','Underline','Strike','HorizontalRule', 'Format', 'Font', 'FontSize'] ,
				]
			});
		</script>
        <?php $this->load->view('admin/includes/footer'); ?>
</body>
                                                         