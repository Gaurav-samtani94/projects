<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
  .table tbody tr td, .table tbody th td {
    white-space: pre-wrap !important;}
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                           <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> User Profile</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
						
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="">
                                <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (validation_errors()): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= validation_errors(); ?>
                                    </div>
                                <?php endif; ?>
                        </div>

                        <div class="card">
                            <div class="body">
							
								<a class="btn btn-one mb-1" style="color:white" data-toggle="modal" data-target="#myModal" href="javascript:void(0);">Add News</a>
								
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable w-100">
										<thead>
											<tr>
												<th>S.No.</th>
												<th>Title</th>
												<th>Category</th>
												<th >Attachment</th>
												<th>Expiry Date</th>
												<th width="110px">Action</th>
											</tr>
										</thead>
										<tbody>
										 <?php 
										 if ($GetAllCompanyNews) {
                                            foreach ($GetAllCompanyNews as $kEy => $dataRow) {
												$file_name = ($dataRow->doc_file) ? $dataRow->doc_file : "";
												$file_path = ($dataRow->doc_file) ? COMPANY_NEWS.$dataRow->doc_file : "--";
												?>
												<tr>
													<td ><?= $kEy + 1; ?></td>
													<td ><?= ($dataRow->title) ? $dataRow->title : ""; ?></td>
													<td ><?= ($dataRow->news_category) ? $dataRow->news_category : ""; ?></td>
													<td ><a target='_blank' href='<?= $file_path;?>'><?= $file_name?></a></td>
													<td ><?= ($dataRow->Expiry_date) ? date('d-m-Y',strtotime($dataRow->Expiry_date)) : ""; ?></td>
													<td width="110px"><a title="View" class="btn" href="javascript:void(0);"  onclick="NewsView('<?= $dataRow->id; ?>')"><i class="fa fa-eye"></i></a><a class="btn" href="javascript:void(0);" onclick="seteditupdatedata(<?= $dataRow->id ?>)" data-toggle="modal" data-target="#myModal2"><i class="fa fa-edit"></i></a><a title="Delete" class="btn" href="javascript:void(0);"  onclick="NewsDelete('<?= $dataRow->id; ?>')"><i class="fa fa-trash"></i></a>
													 </td>
												</tr>												
											<?php }
										}?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<th>S.No.</th>
												<th width="20%">Title</th>
												<th width="20%">Category</th>
												<th width="20%">Attachment</th>
												<th width="30%">Expiry Date</th>
												<th>Action</th>
											</tr>
										</tfoot> 
										<tbody>  
										</tbody>
									</table>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
				
		<div class="container">
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog modal-lg" style="margin-top:100px;">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<h5> Add</h5>
							<button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
						</div>
						<div class="modal-body">
							<form method="post" action="<?= base_url('news_add'); ?>" name="frmmNews" id="frmmNews" enctype="multipart/form-data">
                                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
								<div class="row">
									<?php $get_news_category = get_news_category();
										  //print_r($get_news_category); ?>
									<div class="form-group col-md-6">
										<label class="email">Category: </label>
										<select class="form-control" name="news_category" id="news_category" required>
											<option value=""> -- Select -- </option>
											<?php 
											if ($get_news_category) {
												foreach ($get_news_category as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->news_category; ?></option>
													<?php
												}
											}
											?>
                                        </select>
									</div>
									<div class="form-group col-md-6">
										<label class="email">Title: </label>
										<input type="text" class="form-control" name="title" id="title" required>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-12">
										<label class="email">Description: </label>
										<textarea cols="10" rows="10" name="description" id="description" required class="form-control"></textarea>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-6">
										<label class="email">Expiry Date: </label>
										<input type="date" class="form-control" name="expiry_date" id="expiry_date" required>
									</div>
									<div class="form-group  col-md-6">
										<label class="email">Attachment: </label>
										<input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="doc_file" id="doc_file">
									</div>
								</div>
								<div class="row">
									<div class="form-group  col-md-6">
										<label class="email"> </label>
										<b>Show in Headline : </b> &nbsp;
										<input type="checkbox" id="show_in_headline" name="show_in_headline"  style="zoom:1.3;" >
									</div>
									<div class="form-group  col-md-6">
										<label class="email"> </label>
										<b>Mark Important : </b> &nbsp;
										<input type="checkbox" id="mark_important" name="mark_important"  style="zoom:1.3;" >
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-12">
										<center><input type="submit" class="btn btn-primary" value="Submit"></center>
									</div>
								</div>
							</form>
						</div>

					</div>
				</div>
			</div>
		</div>
		
		
		
		<div class="container">
			<div class="modal fade" id="myModal2" role="dialog">
				<div class="modal-dialog modal-lg" style="margin-top:100px;">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<h5>Edit</h5>
							<button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
						</div>
						<div class="modal-body">
							<form method="post" action="<?= base_url('news_update'); ?>" name="frmmNewsupdate" id="frmmNewsupdate" enctype="multipart/form-data">
                                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
								<div class="row">
									<?php $get_news_category = get_news_category();
										  //print_r($get_news_category); ?>
									<div class="form-group col-md-6">
										<label class="email">Category: </label>
										<select class="form-control" name="edit_news_category" id="edit_news_category" required>
											<option value=""> -- Select -- </option>
											<?php 
											if ($get_news_category) {
												foreach ($get_news_category as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->news_category; ?></option>
													<?php
												}
											}
											?>
                                        </select>
									</div>
									<div class="form-group col-md-6">
										<label class="email">Title: </label>
										<input type="text" class="form-control" name="edit_title" id="edit_title" required>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-12">
										<label class="email">Description: </label>
										<textarea cols="10" rows="10" name="edit_description" id="edit_description" required class="form-control"></textarea>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-6">
										<label class="email">Expiry Date: </label>
										<input type="date" class="form-control" name="edit_expiry_date" id="edit_expiry_date" required>
									</div>
									<div class="form-group  col-md-6">
										<label class="email">Attachment: </label>
										<input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="edit_doc_file" id="edit_doc_file">
									</div>
								</div>
								
								<div class="row">
									<div class="form-group  col-md-6">
										<label class="email"> </label>
										<b>Show in Headline : </b> &nbsp;
										<input type="checkbox" id="edit_show_in_headline" name="edit_show_in_headline"  style="zoom:1.3;" >
									</div>
									<div class="form-group  col-md-6">
										<label class="email"> </label>
										<b>Mark Important : </b> &nbsp;
										<input type="checkbox" id="edit_mark_important" name="edit_mark_important"  style="zoom:1.3;" >
									</div>
								</div>
								<div class="row">
									<div class="form-group col-md-12">
										<input type="hidden" id="upnews_id" name="news_id">
										<center><input type="submit" class="btn btn-primary" value="Update"></center>
									</div>
								</div>
							</form>
						</div>

					</div>
				</div>
			</div>
		</div>
		
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script type="text/javascript">
			var timeout = 1000; // in miliseconds (3*1000)
			$('.alert').delay(timeout).fadeOut(3000);
			
			function NewsDelete(news_id){
				//alert(news_id);
				 if (confirm("Are You sure Delete this ? ")){
				  window.location = "<?= base_url('news_delete/'); ?>" + news_id;
				}	
			}
			
			function seteditupdatedata(news_id){
                         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
				//alert("dsgsdg");
				$.ajax({
				url: '<?= base_url("ajax_getsinglenews_id"); ?>',
				data: ({	[csrfName]: csrfHash,
					news_id: news_id
}),
				type: 'post',
				success: function (data) {
					console.log(data);
					var arr = $.parseJSON(data);
					console.log(arr);
					$("#edit_title").val(arr.title);
					//$("#edit_description").val(arr.description);
					$("#old_file").val(arr.doc_file);
					$("#edit_expiry_date").val(arr.Expiry_date);
					$("#upnews_id").val(news_id);
					$('#edit_news_category').val(arr.news_category);
					CKEDITOR.instances['edit_description'].setData(arr.description);
					
					if(arr.show_headline=="1"){
						$('#edit_show_in_headline').prop('checked', true);
					}else{
						$('#edit_show_in_headline').prop('checked', false);
					}
					if(arr.mark_important_new=="1"){
						$('#edit_mark_important').prop('checked', true);
					}else{
						$('#edit_mark_important').prop('checked', false);
					}
					
				}
                                //data:{[csrfName]: csrfHash}, 
			});
			}
			
			function NewsView(news_id){
				//alert(news_id);
				window.location = "<?= base_url('news_view/'); ?>" + news_id;	
			}
			CKEDITOR.replace( 'description', {
				toolbar: [
					[ 'Cut', 'Copy', 'Paste', 'PasteText', '-', 'Undo', 'Redo' ,'-', 'Image','Table','-','Link','Smiley','TextColor','BGColor','NumberedList','BulletedList'],			
					'/',																					
					[ 'Bold', 'Italic','Underline','Strike','HorizontalRule', 'Format', 'Font', 'FontSize'] ,
				]
			});
			
			CKEDITOR.replace( 'edit_description', {
				toolbar: [
					[ 'Cut', 'Copy', 'Paste', 'PasteText', '-', 'Undo', 'Redo' ,'-', 'Image','Table','-','Link','Smiley','TextColor','BGColor','NumberedList','BulletedList'],			
					'/',																					
					[ 'Bold', 'Italic','Underline','Strike','HorizontalRule', 'Format', 'Font', 'FontSize'] ,
				]
			});
    </script>
        <?php $this->load->view('admin/includes/footer'); ?>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
    </div>
</body>
                                                         