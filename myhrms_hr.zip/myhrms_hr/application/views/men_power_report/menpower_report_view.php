<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Men Power </h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
									<form method="post" action="<?= base_url('gradewise_menpower_report'); ?>" id="visitingcard_form">
                                                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>From Date</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" name="from_date" class="form-control date" value="<?= @$from_date;?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6">
                                                        <b>To Date</b>
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><i class="icon-calendar"></i></span>
                                                            </div>
                                                            <input type="date" name="to_date" class="form-control date" value="<?= @$to_date;?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-3 col-md-6">
                                                        <div class="mt-sm-3">
                                                            <input type="submit"  id="" value="Filter" name="filter" class="btn btn-one">
                                                        
                                                            <input type="reset"  id="" value="Reset" name="submit" class="btn btn-success">
                                                        </div>
                                                    </div>
													
													
                                                </div>
											
                                        <!--</div> -->                         
                                        
										</form>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
				
                    <tr>
                        <th>Sr.No.</th>
						<th>Grade</th>
						<th>Opening Bal</th>
						<th>Joined</th>
						<th>Left</th>
						<th>Closing Bal</th>
                    </tr>
                </thead>
				<tbody>
				<?php 
				if (@$_REQUEST['filter']){
					$st_date = $_REQUEST['from_date'];
					$end_date = $_REQUEST['to_date'];
					$list = array("8" => "A","9" => "B", "10" => "C", "11" => "D", "12" => "E", "13" => "F");
				$data = array();
				$no = 0;
				$recData = array();
				$colTotal1 = 0;
				$colTotal2 = 0;
				$colTotal3 = 0;
				$colTotal4 = 0;
				foreach ($list as $kkeY => $rOws) {
					
					$no++;
					$left = countmenpower($kkeY,$st_date,$end_date);
					$join = countmenpower_joined($kkeY,$st_date,$end_date);
					$open_bal = countmenpower_open_bal($kkeY,$st_date,$end_date);
					// $close_bal = countmenpower_close_bal($kkeY);
					$cls = $open_bal-$left+$join; 
					// $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
					?>
				<tr style="">
					<td><?= $no ; ?></td>
					<td><?= $rOws ; ?></td>
					<td><?= $open_bal ; ?></td>
					<td><?= $join ; ?></td>
					<td><?= $left ; ?></td>
					<td><?= $cls ; ?></td>
					
					 </tr>
				<?php }
				
				}
				else {
				$list = array("8" => "A","9" => "B", "10" => "C", "11" => "D", "12" => "E", "13" => "F");
				$data = array();
				$no = 0;
				$recData = array();
				$colTotal1 = 0;
				$colTotal2 = 0;
				$colTotal3 = 0;
				$colTotal4 = 0;
				$st_date= date("Y-n-j", strtotime("first day of previous month"));
				$end_date= date("Y-n-j", strtotime("last day of previous month"));
				foreach ($list as $kkeY => $rOws) {
					$no++;
					$left = countmenpower($kkeY,$st_date,$end_date);
					$join = countmenpower_joined($kkeY,$st_date,$end_date);
					$open_bal = countmenpower_open_bal($kkeY,$st_date,$end_date);
					// $close_bal = countmenpower_close_bal($kkeY,$st_date,$end_date);
					$cls = $open_bal-$left+$join; 
					// $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
					?>
				<tr style="">
					<td><?= $no ; ?></td>
					<td><?= $rOws ; ?></td>
					<td><?= $open_bal ; ?></td>
					<td><?= $join ; ?></td>
					<td><?= $left ; ?></td>
					<td><?= $cls ; ?></td>
					
					 </tr>
				<?php } }
				?>
				</tbody>
                <tfoot class="d-none">
                    <tr>
                        <th>Sr.No.</th>
						<th>Grade</th>
						<th>Opening Bal</th>
						<th>Joined</th>
						<th>Left</th>
						<th>Closing Bal</th>
                    </tr>
                </tfoot>
                <tbody>
                </tbody>
            </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
	
</body>
<script type="text/javascript">
    var table;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';


        // var compid = $('#companynames').val();
        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [], //Initial no order.
			"scrollY":'10vh',
             "scrollX": true,
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url('ajax_menpower_report_data') ?>",
                "type": "POST",
                "data": function (data) {
                    data.start_dates = $('#start_dates').val();
                    data.end_dates = $('#end_dates').val();
                },
                        data:{[csrfName]: csrfHash}, 


            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
</script>