<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//$statusArr = array("0"=>"A","1"=>"","2"=>"","3"=>"","4"=>);
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                           <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if (validation_errors()): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= validation_errors(); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <table id="table" class="table table-bordered table-striped table-hover display w-100">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Project Code List </th>
                                            <th>Project Status</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>

                                    <tfoot class="d-none">
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Project Code List </th>
                                            <th>Project Status</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        <script>
		 var table;
    $(document).ready(function () {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        // var compid = $('#companynames').val();
        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
			"scrollY":'62vh',
             "scrollX": true,
            "ajax": {
                "url": "<?php echo base_url('Active_project_controller/ajax_all_active_projects') ?>",
                "type": "POST",
                "data": function (data) {
                    // data.start_dates = $('#start_dates').val();
                    // data.end_dates = $('#end_dates').val();
                    data.<?php echo $this->security->get_csrf_token_name(); ?> = '<?php echo $this->security->get_csrf_hash(); ?>';
                },
                        // data:{[csrfName]: csrfHash}, 

            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
	
	
            // var table;
            // $(document).ready(function () {
                // var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                // table = $('#table').DataTable({
                    // "processing": true,
                    // "serverSide": true,
                    // "pageLength": -1,
                    // "order": [],
                    // "ajax": {
                        // "url": "<?php echo base_url('Active_project_controller/getAllPRojects') ?>",
                        // "type": "GET",
                    // },

                    // "dom": 'lBfrtip',
                    // "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}
                    // ],

                    // "columnDefs": [{"targets": [0], "orderable": false}],

                    // "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                // });
            // });
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>

    </div>
</body>