<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//$statusArr = array("0"=>"A","1"=>"","2"=>"","3"=>"","4"=>);
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if (validation_errors()): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= validation_errors(); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form method="post" action="<?= base_url('ShiftTime_emp_Controller/shiftTimings'); ?>" id="form-filter">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-6">
                                            <div class="mb-3">
                                                <b>Business Unit</b>
                                                <select name="bussUnit" class="form-control show-tick ms search-select" data-placeholder="Select">
                                                    <option value="" selected="selected"> Select Business </option>
                                                    <?php
                                                    $all_businessunit = get_businessunits();
                                                    if ($all_businessunit):
                                                        foreach ($all_businessunit as $unitrow) {
                                                            ?>
                                                            <option value="<?= $unitrow->id; ?>"><?= $unitrow->unitname; ?></option>
                                                            <?php
                                                        }
                                                    endif;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <div class="mb-3">
                                                <b>Departments</b>
                                                <select name="dept" class="form-control show-tick ms search-select" id="department" onchange="setSubdptByDpt()" data-placeholder="Select">
                                                    <option value="" selected="selected"> Select Department </option>
                                                    <?php
                                                    $all_Activedepartment = get_departments();
                                                    if ($all_Activedepartment):
                                                        foreach ($all_Activedepartment as $deprow) {
                                                            ?>
                                                            <option value="<?= $deprow->id; ?>"><?= $deprow->deptname; ?></option>
                                                            <?php
                                                        }
                                                    endif;
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <!--<div class="col-lg-3 col-md-6">
                                            <div class="mb-3">
                                                <b>Sub Departments</b>
                                                <select class="form-control show-tick ms search-select" id="subdpt" data-placeholder="Select">
                                                    <option value="" selected="selected"> Select Sub Department </option>
                                                </select>
                                            </div>
                                        </div>-->
                                        <div class="col-lg-3 col-md-6">
                                            <div class="mb-3">
                                                <b>Employees</b>
                                                <select name="employees" class="form-control" id="employee" data-placeholder="Select">
                                                    <option value=""> -- Selectn Employees -- </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <b>Shift in-time</b>
                                            <div class="input-group mb-3">
                                                <select name="shift_in_time" class="form-control show-tick ms search-select" data-placeholder="Select">
                                                    <option value=""> -- Select in Time -- </option>
                                                    <option value="08:00"> 8:00 AM</option>
                                                    <option value="08:15"> 8:15 AM</option>
                                                    <option value="08:30"> 8:30 AM</option>
                                                    <option value="08:45"> 8:45 AM</option>
                                                    <option value="09:00"> 09:00 AM</option>
                                                    <option value="09:15"> 09:15 AM</option>
                                                    <option value="09:30"> 09:30 AM</option>
                                                    <option value="09:45"> 09:45 AM</option>
                                                    <option value="10:00"> 10:00 AM</option>
                                                    <option value="10:15"> 10:15 AM</option>
                                                    <option value="10:30"> 10:30 AM</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-6">
                                            <b>Shift Out-time</b>
                                            <div class="input-group mb-3">
                                                <select name="shift_out_time" class="form-control show-tick ms search-select" data-placeholder="Select">
                                                    <option value=""> -- Select out Time -- </option>
                                                    <option value="05:00"> 05:00 PM</option>
                                                    <option value="05:15"> 05:15 PM</option>
                                                    <option value="05:30"> 05:30 PM</option>
                                                    <option value="05:45"> 05:45 PM</option>
                                                    <option value="06:00"> 06:00 PM</option>
                                                    <option value="06:15"> 06:15 PM</option>
                                                    <option value="06:30"> 06:30 PM</option>
                                                    <option value="06:45"> 06:45 PM</option>
                                                    <option value="07:00"> 07:00 PM</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-md-6">
                                            <div class="mb-3 mt-3 pt-2 mt-xs-0 pt-xs-0 mb-xs-0">
                                                <input type="submit" id="" class="btn btn-round btn-one" value="Update">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <hr>
                                <div class="table-responsive">
                                <table class="table table-striped display nowrap table-bordered table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Name </th>
                                            <th>Department</th>
                                            <th>Job Title</th>
                                            <th>Shift In Time</th>
                                            <th>Shift Out Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($AllRecArr) {
                                            foreach ($AllRecArr as $kEy => $dataRow) {
                                                ?>
                                                <tr>
                                                    <td><?= $kEy + 1; ?></td>
                                                    <td><?= ($dataRow->userfullname) ? $dataRow->userfullname : ""; ?></td>
                                                    <td><?= ($dataRow->department_name) ? $dataRow->department_name : ""; ?></td>
                                                    <td><?= ($dataRow->jobtitle_name) ? $dataRow->jobtitle_name : ""; ?></td>
                                                    <td><?= ($dataRow->shift_in_time) ? $dataRow->shift_in_time : "Not Updated"; ?></td>
                                                    <td><?= ($dataRow->shift_out_time) ? $dataRow->shift_out_time : "Not Updated"; ?></td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            ?>
                                            <tr>
                                                <td style="color:red" colspan="6"> Record Not Found. </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
<!-- 
                                    <tfoot>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Name </th>
                                            <th>Department</th>
                                            <th>Job Title</th>
                                            <th>Shift In Time</th>
                                            <th>Shift Out Time</th>
                                        </tr>
                                    </tfoot> -->
                                </table>
                            </div>

                        </div>


                        <!--<div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Project </th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Location</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                        <?php
                        if ($AppliedTourRecArr) {
                            foreach ($AppliedTourRecArr as $kEy => $dataRow) {
                                ?>
                                                                                            <tr style="<?= ($dataRow->approved_bylmanager == 2) ? "color:#bd2727" : ""; ?>">
                                                                                                <td><?= $kEy + 1; ?></td>
                                                                                                <td><?= ($dataRow->project_name) ? $dataRow->project_name : ""; ?></td>
                                                                                                <td><?= ($dataRow->start_date) ? date("d-m-Y", strtotime($dataRow->start_date)) : ""; ?></td>
                                                                                                <td><?= ($dataRow->end_date) ? date("d-m-Y", strtotime($dataRow->end_date)) : ""; ?></td>
                                                                                                <td><?= ($dataRow->tour_location) ? $dataRow->tour_location : ""; ?></td>
                                                                                                <td><?= ($dataRow->description) ? $dataRow->description : ""; ?></td>
                                                                                                <td><?= ($dataRow->approved_bypmanager) ? $dataRow->approved_bypmanager : ""; ?></td>
                                                                                                <td><i class="fa fa-eye"></i></td>
                                                                                            </tr>
                                <?php
                            }
                        } else {
                            ?>
                                                                    <tr>
                                                                        <td style="color:red" colspan="8"> Record Not Found. </td>
                                                                    </tr>
                        <?php } ?>
                                        </tbody>

                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Project </th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th>Location</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
        <script>
            function setSubdptByDpt() {
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>', csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                //alert('testing')
                var dptid = $('#department').val();
                $('#employee').empty('');
                $.ajax({
                    url: "<?= base_url('ShiftTime_emp_Controller/ajax_emp_getbydept'); ?>",
                    type: "post",
                    dataType: 'json',
                    "scrollY":'60vh',
            "scrollX": true,
                    data: {[csrfName]: csrfHash, department: dptid},
                    success: function (response) {
                        $('#employee').val();
                        $('#employee').append('<option value="77777"> -- All -- </option>')
                        $.each(response, function (index, data) {
                            $('#employee').append('<option value="' + data['user_id'] + '">' + data['userfullname'] + '</option>')
                        });
                    }

                });
            }
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>

    </div>
</body>