<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
	<div id="wrapper">
		<?php $this->load->view('admin/includes/sidebar'); ?>
		<div id="main-content">
			<div class="container-fluid">
				<div class="block-header stepper">
					<div class="row">
						<div class="col-lg-5 col-md-8 col-sm-12">
							<!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Financial Statement</h2>-->
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
								<li class="breadcrumb-item">Home</li>
								<li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
							</ul>
						</div>

					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<?php if ($this->session->flashdata('success_msg')) : ?>
								<div class="alert alert-success alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if ($this->session->flashdata('error_msg')) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if (validation_errors()) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= validation_errors(); ?>
								</div>
							<?php endif; ?>
						</div>



						<div class="card">
							<div class="body">

								<div class="row">
									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">Financial Year : </label> <br>
											<?= ($FinancialYearDetailsArr->slot_name) ? $FinancialYearDetailsArr->slot_name : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">Start Date : </label> <br>
											<?= ($FinancialYearDetailsArr->start_date) ? date("d-m-Y", strtotime($FinancialYearDetailsArr->start_date)) : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">End Date : </label> <br>
											<?= ($FinancialYearDetailsArr->end_date) ? date("d-m-Y", strtotime($FinancialYearDetailsArr->end_date)) : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email"> &nbsp; </label> <br>
											<a href="<?= base_url("financial_statement"); ?>">
												<< Back </a>
										</div>
									</div>

								</div>
							</div>
						</div>


						<div class="card">
							<div class="body">
								<div class="table-responsive" style="margin-top:20px;">
									<table class="table table-bordered table-striped table-hover dataTable js-exportable">
										<thead>
											<tr>
												<th>S.No.</th>
												<th>Office / Branch </th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody>
											<?php
											if ($OfcLocationRecordArr) {
												foreach ($OfcLocationRecordArr as $kEy => $dataRow) { ?>
													<tr>
														<td width="5%"><?= $kEy + 1; ?></td>
														<td width="20%"><?= $dataRow->ofc_loc_name; ?></td>
														<td width="20%"> Active </td>
														<td width="20%">
															<a href="<?= base_url("financial_statement_hr_entry/" . $FinancialYearDetailsArr->fld_id . "/" . $dataRow->fld_id); ?>">
																<i class="fa fa-edit"></i>
															</a>
														</td>
													</tr>
											<?php }
											} ?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<th>S.No.</th>
												<th>Office / Branch </th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</tfoot>
										<tbody>
										</tbody>
									</table>
								</div>
							</div>
						</div>


					</div>
				</div>
			</div>


			<?php $this->load->view('admin/includes/footer'); ?>
		</div>
</body>