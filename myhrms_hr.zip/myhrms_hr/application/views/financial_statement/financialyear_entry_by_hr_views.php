<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
	<div id="wrapper">
		<?php $this->load->view('admin/includes/sidebar'); ?>
		<div id="main-content">
			<div class="container-fluid">
				<div class="block-header stepper">
					<div class="row">
						<div class="col-lg-5 col-md-8 col-sm-12">
							<!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Financial Statement</h2>-->
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
								<li class="breadcrumb-item">Home</li>
								<li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
							</ul>
						</div>

					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<?php if ($this->session->flashdata('success_msg')) : ?>
								<div class="alert alert-success alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if ($this->session->flashdata('error_msg')) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if (validation_errors()) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= validation_errors(); ?>
								</div>
							<?php endif; ?>
						</div>



						<div class="card">
							<div class="body">

								<div class="row">
									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">Financial Year : </label> <br>
											<?= ($FinancialYearDetailsArr->slot_name) ? $FinancialYearDetailsArr->slot_name : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">Start Date : </label> <br>
											<?= ($FinancialYearDetailsArr->start_date) ? date("d-m-Y", strtotime($FinancialYearDetailsArr->start_date)) : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email">End Date : </label> <br>
											<?= ($FinancialYearDetailsArr->end_date) ? date("d-m-Y", strtotime($FinancialYearDetailsArr->end_date)) : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email"> Office Location : </label> <br>
											<?= ($OfcLocationRecordArr->ofc_loc_name) ? $OfcLocationRecordArr->ofc_loc_name : ''; ?>
										</div>
									</div>

									<div class="col-sm-2">
										<div class="form-group">
											<label for="email"> &nbsp; </label> <br>
											<a href="<?= base_url("financial_statement_entry/" . $FinancialYearDetailsArr->fld_id); ?>">
												<< Back </a>
										</div>
									</div>

								</div>
							</div>
						</div>


						




							


								<?php if ($AllCategoryDetailsArr) {
									foreach ($AllCategoryDetailsArr as $kEy => $rowC) {
								?>

										<form method="post" action="<?= base_url("financial_entrybyhr_save_upd"); ?>">
										<div class="card">
										<div class="body">
										<div class="table-responsive">
											<table class="table table-striped display">
												<thead>
													<tr>
														<th style="color:white; text-align:center" colspan="15"> <?= $rowC->categ_name; ?> </th>
													</tr>
													<tr>
														<th width="2%">Sr.No</th>
														<th width="9%"> Details</th>
														<th width="7%">Input-<?= date("m-Y", strtotime($FinancialYearDetailsArr->start_date)); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +1 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +2 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +3 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +4 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +5 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +6 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +7 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +8 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +9 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +10 month")); ?></th>
														<th width="7%">Input-<?= date("m-Y", strtotime("$FinancialYearDetailsArr->start_date +11 month")); ?></th>
														<th width="5%">Total</th>
													</tr>
												</thead>
												<tbody>
													<?php

													// $tot_AllSum_04 = 0;
													// $tot_AllSum_05 = 0;
													// $tot_AllSum_06 = 0;
													// $tot_AllSum_07 = 0;
													// $tot_AllSum_08 = 0;
													// $tot_AllSum_09 = 0;
													// $tot_AllSum_10 = 0;
													// $tot_AllSum_11 = 0;
													// $tot_AllSum_12 = 0;
													// $tot_AllSum_01 = 0;
													// $tot_AllSum_02 = 0;
													// $tot_AllSum_03 = 0;
													// $tot_AllSum_01_12 = 0;


													if ($AllDetailsMasterArr) {
														foreach ($AllDetailsMasterArr as $key => $rOws) {

															$ExistRecordArr = $ExistsExpensEntryRecArr[$rowC->category_id][$rOws->fld_id];

													?>
															<tr>
																<td><?= $key + 1; ?></td>
																<td width="20px" class="ellipsis" title="<?= $rOws->details_name; ?>">
																	<?php
																	//echo truncate($rOws->details_name, 27);
																	echo $rOws->details_name;
																	?>
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_04']) ? $ExistRecordArr['curr_04'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_05']) ? $ExistRecordArr['curr_05'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_06']) ? $ExistRecordArr['curr_06'] : '';  ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_07']) ? $ExistRecordArr['curr_07'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_08']) ? $ExistRecordArr['curr_08'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_09']) ? $ExistRecordArr['curr_09'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_10']) ? $ExistRecordArr['curr_10'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_11']) ? $ExistRecordArr['curr_11'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_12']) ? $ExistRecordArr['curr_12'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_01']) ? $ExistRecordArr['curr_01'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_02']) ? $ExistRecordArr['curr_02'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td>
																	<input type="number" class="form-control" value="<?= ($ExistRecordArr['curr_03']) ? $ExistRecordArr['curr_03'] : ''; ?>" name="curr_<?= $rOws->fld_id; ?>[]">
																</td>
																<td><?= number_format($ExistRecordArr['sumAmount'], 0); ?></td>
															</tr>

															<input type="hidden" name="categ_idact[]" value="<?= $rOws->fld_id; ?>">
														<?php
															//$tot_AllSum_04 += $ExistRecordArr['curr_04'];
															//	$tot_AllSum_05 += $ExistRecordArr['curr_05'];
															//$tot_AllSum_06 += $ExistRecordArr['curr_06'];
															//$tot_AllSum_07 += $ExistRecordArr['curr_07'];
															//$tot_AllSum_08 += $ExistRecordArr['curr_08'];
															//$tot_AllSum_09 += $ExistRecordArr['curr_09'];
															//$tot_AllSum_10 += $ExistRecordArr['curr_10'];
															//$tot_AllSum_11 += $ExistRecordArr['curr_11'];
															//$tot_AllSum_12 += $ExistRecordArr['curr_12'];

															//$tot_AllSum_01 += $ExistRecordArr['curr_01'];
															//$tot_AllSum_02 += $ExistRecordArr['curr_02'];
															//$tot_AllSum_03 += $ExistRecordArr['curr_03'];

															//$tot_AllSum_01_12 += $ExistRecordArr['sumAmount'];
														} ?>

														<tr>
															<th colspan="2"> Total :</th>

															<th> <?= number_format($tot_AllSum_04, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_05, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_06, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_07, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_08, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_09, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_10, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_11, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_12, 0); ?> </th>

															<th> <?= number_format($tot_AllSum_01, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_02, 0); ?> </th>
															<th> <?= number_format($tot_AllSum_03, 0); ?> </th>

															<th> <?= number_format($tot_AllSum_01_12, 0); ?> </th>
														</tr>


														<tr>
															<td colspan="15">
																<input type="hidden" name="fin_slotid" value="<?= $FinancialYearDetailsArr->fld_id; ?>">
																<input type="hidden" name="type_id" value="<?= $rowC->category_id; ?>">
																<input type="hidden" name="ofc_location_id" value="<?= $OfcLocationRecordArr->fld_id; ?>">
																<input type="submit" class="btn btn-one" name="go_submit" value="Add/Update">
															</td>
														</tr>

													<?php } ?>
												</tbody>
											</table>
										</div>
										</div>
										</div>
										</form>

								<?php }
								} ?>

							
						


					</div>
				</div>
			</div>


			<?php $this->load->view('admin/includes/footer'); ?>
		</div>
</body>

<style>
	.ellipsis {
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	input[type="number"] {
		width: 120px;
	}
</style>

<?php
function truncate($str, $max)
{
	$str = trim($str);
	if (strlen($str) > $max) {
		$s_pos = strpos($str, ' ');
		$cut = $s_pos === false || $s_pos > $max;
		$str = wordwrap($str, $max, ';;', $cut);
		$str = explode(';;', $str);
		$str = $str[0] . '...';
	}
	return $str;
}
?>