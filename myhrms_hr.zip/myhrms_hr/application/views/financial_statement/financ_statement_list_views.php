<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
	<div id="wrapper">
		<?php $this->load->view('admin/includes/sidebar'); ?>
		<div id="main-content">
			<div class="container-fluid">
				<div class="block-header stepper">
					<div class="row">
						<div class="col-lg-5 col-md-8 col-sm-12">
							<!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Financial Statement</h2>-->
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
								<li class="breadcrumb-item">Home</li>
								<li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
							</ul>
						</div>

					</div>
				</div>

				<div class="row">
					<div class="col-lg-12">
						<div class="card">
							<?php if ($this->session->flashdata('success_msg')) : ?>
								<div class="alert alert-success alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if ($this->session->flashdata('error_msg')) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
								</div>
							<?php endif; ?>
							<?php if (validation_errors()) : ?>
								<div class="alert alert-danger alert-dismissable">
									<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
									<strong>Error ! </strong> <?= validation_errors(); ?>
								</div>
							<?php endif; ?>
						</div>

						<div class="card">
							<div class="body">
								<div class="table-responsive" >
									<table class="table table-bordered table-striped table-hover dataTable js-exportable">
										<thead>
											<tr>
												<th>S.No.</th>
												<th>Financial Year</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody>
											<?php
											if ($Financ_statementArr) {
												foreach ($Financ_statementArr as $kEy => $dataRow) { ?>
													<tr>
														<td width="5%"><?= $kEy + 1; ?></td>
														<td width="20%"><?= $dataRow->slot_name; ?></td>
														<td width="20%"><?= date("d-m-Y", strtotime($dataRow->start_date)); ?></td>
														<td width="20%"><?= date("d-m-Y", strtotime($dataRow->end_date)); ?></td>
														<td width="20%">
															<a href="<?= base_url("financial_statement_entry/" . $dataRow->fld_id); ?>">
																<i class="fa fa-edit"></i>
															</a>
														</td>
													</tr>
											<?php }
											} ?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<th>S.No.</th>
												<th>Financial Year</th>
												<th>Start Date</th>
												<th>End Date</th>
												<th>Action</th>
											</tr>
										</tfoot>
										<tbody>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


			<?php $this->load->view('admin/includes/footer'); ?>
		</div>
</body>