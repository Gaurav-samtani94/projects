<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Manage Sub-admin</h3> <a href="<?PHP echo base_url(); ?>subadmin-list" class="btn btn-primary pull-right">View All Sub-admin</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <!-- form start -->

                    <?PHP echo form_open_multipart($this->uri->uri_string(), array('class' => 'form-horizontal')) ?>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="First Name" value="<?php echo set_value('f_name'); ?>" name="f_name">
                            <span class="error_msg"><?PHP echo form_error('f_name'); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Last Name</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="Last Name" value="<?php echo set_value('l_name'); ?>" name="l_name">
                            <span class="error_msg"><?PHP echo form_error('l_name'); ?></span>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" placeholder="Email" name="email" value="<?php echo set_value('email'); ?>" id="vendor_email">
                            <span class="error_msg"><?PHP echo form_error('email'); ?></span>
                        </div>
                        <label><div class="col-md-12" id="user-availability" style="margin-top: 4px;">
                            </div></label>
                    </div>

                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">User Role</label>
                        <div class="col-sm-6">
                            <select name="userrole" id="inputEmail3" class="form-control" >
                                <option value="">---Select--</option>
                                <option <?= (set_value('userrole')=='2') ? 'Selected' : '' ?> value="2">National</option>
                                <option <?= (set_value('userrole')=='3') ? 'Selected' : '' ?> value="3">State</option>
                                <option <?= (set_value('userrole')=='4') ? 'Selected' : '' ?> value="4">City</option>
                                <option <?= (set_value('userrole')=='5') ? 'Selected' : '' ?> value="5">Local</option>
                            </select>

                            <span class="error_msg"><?PHP echo form_error('userrole'); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                        <div class="col-sm-6">
                            <input type="password" class="form-control" id="inputEmail3" placeholder="Password" value="<?php echo set_value('password'); ?>" name="password">
                            <span class="error_msg"><?PHP echo form_error('password'); ?></span>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Access</label>
                        <div class="col-sm-6">
                            <ul class="list-unstyled">
                                <li><input type="checkbox" name="access[]" value="manage_subadmin">Manage Subadmin</li>
                                <li><input type="checkbox" name="access[]" value="manage_user">Manage User</li>
                                <li><input type="checkbox" name="access[]" value="manage_package">Manage Package</li>
                                <li><input type="checkbox" name="access[]" value="manage_cms">Manage CMS</li>
                                <li><input type="checkbox" name="access[]" value="bitgo_control">Bitgo Control</li>
                                <li><input type="checkbox" name="access[]" value="manage_site_setting">Site Setting</li>


                            </ul>
                            <span class="error_msg"><?PHP echo form_error('access'); ?></span>
                        </div>
                    </div>

                    <!-- /.box-body -->
                    <div class="box-footer">
                        <div class="col-md-4">
                            <button type="submit" class="btn-lg btn-success pull-right" name="subadmin__submit" id="subadmin_account">Save</button>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <?PHP echo form_close(); ?>
                </div>
                <!-- ./box-body -->
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?PHP $this->load->view("back_end/includes/footer"); ?>