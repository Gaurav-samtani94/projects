<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<!-- Main content -->
<section class="content">

    <?php if ($this->session->flashdata('successmsg')) { ?>
        <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
            <strong>Success!</strong> <?= $this->session->flashdata('successmsg'); ?>
        </div>
    <?php } ?>

    <?php if ($this->session->flashdata('errormsg')) { ?>
        <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
            <strong>Bug!</strong> <?= $this->session->flashdata('errormsg') ?>
        </div>
    <?php } ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Manage Project</h3> <a href="" class="btn btn-primary pull-right">View All Project</a>
                </div>

                <!-- /.box-header -->
                <div class="box-body">
                    <!-- form start -->

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box ">
                            <span class="info-box-icon bg-red ">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="<?= base_url('back_end/project_account/edit/' . $projdetailsArr['id']); ?>">
                                <div class="info-box-content">
                                    <span class="info-box-number"> Basic Details </span>
                                    <small> Update Cotract Value and Enter OutSourced Task & it's Details </small>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box activeclass">
                            <span class="info-box-icon bg-red">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="<?= base_url('back_end/project_account/billreceipt/' . $projdetailsArr['id']); ?>">
                                <div class="info-box-content">  
                                    <span class="info-box-number"> Client Accounts </span>
                                    <small>Enter Amount Received By Client against Bill</small>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-red">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="<?= base_url('back_end/project_account/acdeptoutsourcedact/' . $projdetailsArr['id']); ?>">
                                <div class="info-box-content">
                                    <span class="info-box-number"> Outsourced Task Accounts </span>
                                    <small>Enter Amount Paid/Bill Received By OutSource Firm</small>
                                </div>
                            </a>
                        </div>
                    </div> 
                </div>



                <!-- ./box-body -->
                <!-- /.box-footer -->
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Project Name : </span>
                        <strong><?= $projdetailsArr['project_name']; ?></strong>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Original Contract Value :  </span>
                        <strong><?= ($orgcontactval) ? number_format($orgcontactval, 2) : '0.00'; ?></strong>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Revised Contract Value: </span>
                        <strong><?= ($lastrevcont_val) ? number_format($lastrevcont_val, 2) : ''; ?></strong>
                    </div>
                </div>
            </div>


            <?= form_open_multipart(base_url('back_end/project_account/insert_billreceipt'), array('class' => '')) ?>
            <div class="container box-body" style="background:white; width: 100%">  
                <div class="col-sm-2">
                    <div class="form-group">
                        <label for="email">Bill No.:</label>
                        <input type="text" required="" name="bill_no" class="form-control" id="bill_no">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <label for="email"> Bill Amount:</label>
                        <input type="number" required="" name="bill_amount" class="form-control" id="bill_amount">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <label for="email"> Bill Date:</label>
                        <input type="text" required="" name="billamnt_date" class="form-control" id="billamnt_date">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <label for="email">Amount Recieved:</label>
                        <input type="number" required="" name="amnt_recieved" class="form-control" id="amnt_recieved">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <label for="email">Amount Recieved Date:</label>
                        <input type="text" required="" name="amntrec_date" class="form-control" id="amntrec_date">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group">
                        <br>
                        <input type="hidden" name="base_project" value="<?= $projdetailsArr['id'] ?>">
                        <input type="hidden" name="orgcons_value" value="<?= $orgcontactval ?>">
                        <input type="hidden" name="rev_const_value" value="<?= $lastrevcont_val ?>">
                        <input type="submit" class="btn btn-primary" >
                    </div>
                </div>       
            </div>
            <?= form_close(); ?>

            <div class = "col-md-12 box">
                <br>
                <div class = "well">
                    <table class = "table table-bordered" border = '1' >
                        <thead>
                            <tr>
                                <th>sr. no </th>
                                <th>Bill No</th>
                                <th>Bill Date</th>
                                <th>Bill Amount </th>
                                <th>Amount Rcv Date</th>
                                <th>Amount Recieved </th>
                                <th>Balance </th>
                                <th>Action </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $srno = 0;
                            if ($allrecbillArr) {
                                foreach ($allrecbillArr as $recrow):
                                    ?>
                                    <tr>
                                        <td align="center"><?= $srno = $srno + 1; ?></td>
                                        <td><?= $recrow['bill_no']; ?></td>
                                        <td><?= date("d-m-Y", strtotime($recrow['billamnt_date'])); ?></td>
                                        <td><?= number_format($recrow['bill_amount'], 2); ?></td>
                                        <td><?= date("d-m-Y", strtotime($recrow['amntrec_date'])); ?></td>
                                        <td><?= number_format($recrow['amnt_recieved'], 2); ?></td>
                                        <td><?= number_format($recrow['remaining_amount'], 2); ?></td>
                                        <td align="center">
                                            <button  title="Edit/Update" onclick="updpopupfunc('<?= $recrow['id']; ?>')" data-toggle="modal" data-target="#myModal">
                                                <i class="fa fa-edit"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php
                                endforeach;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <br>

    <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?PHP $this->load->view("back_end/includes/footer"); ?>
<style>
    .activeclass{border: solid green 1px;
                 background-color:rgba(0, 115, 62, 0.05);}
    </style>
    <script>
        $(function () {
            $("#amntrec_date,#billamnt_date,#billamnt_dateu,#amntrec_dateu").datepicker({
                dateFormat: 'dd-mm-yy',
                changeYear: true
            });
        });
        //Edit / Update With Popup..
        function updpopupfunc(updid) {
            //Ajax For Set Value in Text Field..
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                url: "<?= base_url('back_end/project_account/ajaxgetbillamntdetail_byid'); ?>",
                type: "POST", data: {'<?= $this->security->get_csrf_token_name(); ?>': '<?= $this->security->get_csrf_hash(); ?>', 'projid': updid},
                success: function (yourJsonString) {
                    var obj = JSON.parse(yourJsonString);
                    $("#udp_bill_no").val(obj['bill_no']);
                    $("#upd_bill_amount").val(obj['bill_amount']);
                    $("#billamnt_dateu").val(obj['billamnt_date']);
                    $("#udp_amnt_recieved").val(obj['amnt_recieved']);
                    $("#amntrec_dateu").val(obj['amntrec_date']);
                    $("#editid").val(obj['id']);
                    $("#base_project").val(obj['base_project']);
                }
                data:{[csrfName]: csrfHash}, 
            });
        }
    </script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- Modal -->


    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->

        <?= form_open_multipart(base_url('back_end/project_account/updatepopup_billreceipt'), array('class' => '')) ?>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Bill Details </h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="email">Bill No.:</label>
                    <input type="text" required="" name="bill_no" class="form-control" id="udp_bill_no">
                </div>
                <div class="form-group">
                    <label for="email"> Bill Amount:</label>
                    <input type="text" required="" name="bill_amount" class="form-control" id="upd_bill_amount">
                </div>
                <div class="form-group">
                    <label for="email"> Bill Date:</label>
                    <input type="text" required="" name="billamnt_date" class="form-control" id="billamnt_dateu">
                </div>
                <div class="form-group">
                    <label for="email">Amount Recieved:</label>
                    <input type="text" required="" name="amnt_recieved" class="form-control" id="udp_amnt_recieved">
                </div>
                <div class="form-group">
                    <label for="email">Amount Recieved Date:</label>
                    <input type="text" required="" name="amntrec_date" class="form-control" id="amntrec_dateu">
                </div>
                <div class="form-group">
                    <input type="hidden" name="editid" id="editid">
                    <input type="hidden" name="base_project" id="base_project">
                    <input type="submit" class="btn btn-primary pull-right" value="Update">
                </div>
            </div>
            <div class="modal-footer">
                <br>
            </div>
        </div>
        <?= form_close(); ?>


    </div>
</div>

