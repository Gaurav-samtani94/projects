<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<!-- Main content -->
<section class="content">
     <?php if ($this->session->flashdata('successmsg')): ?>
            <div class="alert alert-info alert-dismissible fade in">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Success ! </strong> <?php echo $this->session->flashdata('successmsg'); ?>
            </div>
        <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title"> Atm CSV Sigle Date Attendance Entry </h3>
                </div>

                <div class="box-body">
                    <?PHP echo form_open_multipart("atm_sigle_dateattendance_save", array('class' => 'form-horizontal')) ?>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Upload Atm File</label>
                        <div class="col-sm-6">
                            <input type="file" required class="form-control" id="atmfile" placeholder="Atm File Csv" name="atmfile">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Date</label>
                        <div class="col-sm-6">
                            <input type="date" required class="form-control" id="entry_date"  value="" name="entry_date">
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="col-md-4">
                            <button type="submit" class="btn-lg btn-success pull-right" name="subadmin__submit" id="subadmin_account">Save</button>
                        </div>
                    </div>
                    <?PHP echo form_close(); ?>
                </div>

            </div>
        </div> 
    </div>
</section>


</div>
<!-- /.content-wrapper -->
<?PHP $this->load->view("back_end/includes/footer"); ?>