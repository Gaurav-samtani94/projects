
<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<!-- Main content -->
<section class="content">


    <?php if ($this->session->flashdata('successmsg')) { ?>
        <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
            <strong>Success!</strong> <?= $this->session->flashdata('successmsg'); ?>
        </div>
    <?php } ?>

    <?php if ($this->session->flashdata('errormsg')) { ?>
        <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
            <strong>Bug!</strong> <?= $this->session->flashdata('errormsg') ?>
        </div>
    <?php } ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Manage Project</h3> <a href="" class="btn btn-primary pull-right">View All Project</a>
                </div>



                <!-- /.box-header -->
                <div class="box-body">
                    <!-- form start -->

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box activeclass">
                            <span class="info-box-icon bg-red ">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="">
                                <div class="info-box-content">
                                    <span class="info-box-number"> Basic Details </span>
                                    <small> Update Cotract Value and Enter OutSourced Task & it's Details </small>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-red">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="<?= base_url('back_end/project_account/billreceipt/' . $projdetailsArr['id']); ?>">
                                <div class="info-box-content">  
                                    <span class="info-box-number"> Client Accounts </span>
                                    <small>Enter Amount Received By Client against Bill</small>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="info-box">
                            <span class="info-box-icon bg-red">
                                <i class="fa fa-step-forward"></i>
                            </span>
                            <a href="<?= base_url('back_end/project_account/acdeptoutsourcedact/' . $projdetailsArr['id']); ?>">
                                <div class="info-box-content">
                                    <span class="info-box-number"> Outsourced Task Accounts </span>
                                    <small>Enter Amount Paid/Bill Received By OutSource Firm</small>
                                </div>
                            </a>
                        </div>
                    </div> 
                </div>



                <!-- ./box-body -->
                <!-- /.box-footer -->
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Project Name : </span>
                        <strong><?= $projdetailsArr['project_name']; ?></strong>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Original Contract Value :  </span>
                        <strong><?= ($orgcontactval) ? number_format($orgcontactval, 2) : '0.00'; ?></strong>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="well">
                    <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                        <span class="info-box-number"> Revised Contract Value: </span>
                        <strong><?= ($lastrevcont_val) ? number_format($lastrevcont_val, 2) : ''; ?></strong>
                    </div>
                </div>
            </div>


            <div class="col-md-12 col-sm-6 col-xs-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="well">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Contract Value: </th>
                                        <th>Last Revised Contract Value: </th>
                                        <th>New Revised Contract Value</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?= form_open_multipart(base_url('back_end/project_account/savebillablereviewmaster'), array('class' => 'form-horizontal')) ?>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="contractval" class="form-control" value="<?= ($orgcontactval) ? $orgcontactval : '0'; ?>" id="contractval">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" readonly="" name="lstfalse" value="<?= ($lastrevcont_val) ? $lastrevcont_val : ''; ?>" class="form-control" >
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" name="newrevconval" class="form-control" id="newrevconval">
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <input type="hidden" name="acprojid" id="acprojid" value="<?= $projdetailsArr['id']; ?>" >
                                                <input type="submit" class="btn btn-primary pull-right" value="Update">
                                            </div>
                                        </td>
                                    </tr>
                                    <?PHP echo form_close(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="well">
                    <table class="table table-bordered" border='1' >
                        <thead>
                            <tr>
                                <th>sr. no </th>
                                <th>Types of Task</th>
                                <th>Estimated Cost</th>
                                <th>Outsourced To</th>
                                <th>Date</th>
                                <th>Payble Amount </th>
                                <th>Action </th>
                            </tr>
                        </thead>
                        <tbody>

                            <?= form_open_multipart(base_url('back_end/project_account/insertoutsource/' . $projdetailsArr['id']), array('class' => 'form-horizontal')) ?>
                            <tr>
                                <td></td>
                                <td>
                                    <div class="form-group">
                                        <input type="text" required="" name="outs_task" class="form-control" id="outs_task">
                                    </div>
                                </td>

                                <td>
                                    <div class="form-group">
                                        <input type="text" required name="outs_estimatedcost" class="form-control" id="outs_estimatedcost">
                                    </div>
                                </td>

                                <td>
                                    <div class="form-group">
                                        <input type="text" required name="firm_name" class="form-control" id="firm_name">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <input type="text" name="date" class="form-control" id="date">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <input type="text" required name="outs_contractvalue" class="form-control" id="outs_contractvalue">
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group"> 
                                        <input type="submit" class="btn btn-primary pull-right" value="Add">
                                    </div>
                                </td>
                            </tr>

                            <?php
                            echo form_close();
                            $srno = 0;
                            if ($outsourceArr) {
                                foreach ($outsourceArr as $recrow):
                                    ?>
                                    <tr>
                                        <td align="center"><?= $srno = $srno + 1; ?></td>
                                        <td><?= $recrow['outs_task'] ?></td>
                                        <td><?= $recrow['outs_estimatedcost'] ?></td>
                                        <td><?= $recrow['firm_name'] ?></td>
                                        <td><?= date("d-m-Y", strtotime($recrow['date'])); ?></td>
                                        <td><?= $recrow['outs_contractvalue'] ?></td>
                                        <td align="center">
                                            <button onclick="updpopupfunc('<?= $recrow['id'] ?>')" data-toggle="modal" data-target="#myModal">
                                                <i class="fa fa-edit"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php
                                endforeach;
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.box -->
        </div>


    </div>

    <br>


    <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?PHP $this->load->view("back_end/includes/footer"); ?>

<style>
    .activeclass{border: solid green 1px;
                 background-color:rgba(0, 115, 62, 0.05);}
    </style>
    <script>
        $(function () {
            $("#date,#upd_date").datepicker({dateFormat: 'dd-mm-yy'});
        });

        //Edit / Update With Popup..
        function updpopupfunc(updid) {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            //Ajax For Set Value in Text Field..
            $.ajax({
                url: "<?= base_url('back_end/project_account/ajaxgetoutsourcdetail_byid'); ?>",
                type: "POST", data: {'<?= $this->security->get_csrf_token_name(); ?>': '<?= $this->security->get_csrf_hash(); ?>', 'projid': updid},
                success: function (yourJsonString) {
                    var obj = JSON.parse(yourJsonString);
                    //alert(''+obj['outs_task']);
                    $("#upd_outs_task").val(obj['outs_task']);
                    $("#upd_outs_estimatedcost").val(obj['outs_estimatedcost']);
                    $("#upd_firm_name").val(obj['firm_name']);
                    $("#upd_date").val(obj['date']);
                    $("#upd_outs_contractvalue").val(obj['outs_contractvalue']);

                    $("#upd_projid").val(obj['outs_projid']);
                    $("#outsid").val(updid);
                }
                data:{[csrfName]: csrfHash}, 
            });
        }
    </script>


    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <?= form_open_multipart(base_url('back_end/project_account/updateoutsour'), array('class' => '')) ?>
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Outsource Activities </h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Types of Task</label>
                    <input type="text" required="" name="outs_task" class="form-control" id="upd_outs_task">
                </div>
                <div class="form-group">
                    <label>Estimated Cost</label>
                    <input type="text" required name="outs_estimatedcost" class="form-control" id="upd_outs_estimatedcost">
                </div>
                <div class="form-group">
                    <label>Outsourced To</label>
                    <input type="text" required name="firm_name" class="form-control" id="upd_firm_name">
                </div>
                <div class="form-group">
                    <label>Date</label>
                    <input type="text" name="date" class="form-control" id="upd_date">
                </div>
                <div class="form-group">
                    <label>Payble Amount</label>
                    <input type="text" required name="outs_contractvalue" class="form-control" id="upd_outs_contractvalue">
                </div>
                <div class="form-group">
                    <input type="hidden" name="outsid" id="outsid">
                    <input type="hidden" name="projid" id="upd_projid">

                    <input type="submit" class="btn btn-primary pull-right" value="Update">
                </div>
            </div>

            <div class="modal-footer">
                <br>
            </div>
        </div>
        <?= form_close(); ?>

    </div>
</div>

</div>
