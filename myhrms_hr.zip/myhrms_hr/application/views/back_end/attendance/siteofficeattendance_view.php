<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/jquery.dataTables.min.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/dataTables.colVis.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/buttons.dataTables.min.css' ?>" rel="stylesheet">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/multi-select/0.9.12/css/multi-select.css">-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.css">

<div>
    <section class="content" style="height:auto;">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title" >Custom Filter : </h3>
                <?php // echo '<pre>'; 	$ShowAllPolicy1 = ShowAllPolicy(); print_r($ShowAllPolicy1); ?>
            </div>
            <div class="panel-body">
                <form id="form-filter" class="form-horizontal">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="well">
                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                <span>Project</span>
                                <?php if ($project): ?>
                                    <select required name="project" id="project" class="form-control">
                                        <option value=""> -- Select -- </option>
                                        <?php
                                        foreach ($project as $val) {
                                            ?>
                                            <option value="<?= $val->id; ?>"> <?= $val->project_name; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="well">
                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                <span>Month</span>
                                <select required name="repmonth" id="repmonth" class="form-control">
                                    <option value=""> -- Select -- </option>
                                    <?php for ($i = 1; $i < 13; $i++): ?>
                                        <option value="<?= $i; ?>"><?= $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="well">
                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                <span>Year</span>
                                <select required name="repyear" id="repyear" class="form-control">
                                    <option value=""> -- Select -- </option>
                                    <?php for ($yi = 2018; $yi <= date('Y'); $yi++): ?>
                                        <option value="<?= $yi; ?>"><?= $yi; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-8">
                            <button type="button" id="btn-filter" class="btn btn-primary"> Filter </button>
                            <button type="button" id="btn-reset" class="btn btn-default">Reset</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>


        <div class="panel panel-default" style="overflow-x: scroll;">

            <div class="row">
                <div class="col-md-12">
                    <div id="colvis"></div>
                </div>
            </div>
            <table id="table" class="display" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>Sr. No</th>
                        <th>EMP Name</th>
                        <th>Position</th>
                        <th>1</th>
                        <th>2</th>
                        <th>3</th>
                        <th>4</th>
                        <th>5</th>
                        <th>6</th>
                        <th>7</th>
                        <th>8</th>
                        <th>9</th>
                        <th>10</th>
                        <th>11</th>
                        <th>12</th>
                        <th>13</th>
                        <th>14</th>
                        <th>15</th>
                        <th>16</th>
                        <th>17</th>
                        <th>18</th>
                        <th>19</th>
                        <th>20</th>
                        <th>21</th>
                        <th>22</th>
                        <th>23</th>
                        <th>24</th>
                        <th>25</th>
                        <th>26</th>
                        <th>27</th>
                        <th>28</th>
                        <th>29</th>
                        <th>30</th>
                        <th>31</th>

                    </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Sr. No</th>
                        <th>EMP Name</th>
                        <th>Position</th>
                        <th>1</th>
                        <th>2</th>
                        <th>3</th>
                        <th>4</th>
                        <th>5</th>
                        <th>6</th>
                        <th>7</th>
                        <th>8</th>
                        <th>9</th>
                        <th>10</th>
                        <th>11</th>
                        <th>12</th>
                        <th>13</th>
                        <th>14</th>
                        <th>15</th>
                        <th>16</th>
                        <th>17</th>
                        <th>18</th>
                        <th>19</th>
                        <th>20</th>
                        <th>21</th>
                        <th>22</th>
                        <th>23</th>
                        <th>24</th>
                        <th>25</th>
                        <th>26</th>
                        <th>27</th>
                        <th>28</th>
                        <th>29</th>
                        <th>30</th>
                        <th>31</th>
                    </tr>
                </tfoot>

            </table>

        </div>


    </section>
</div>
<?PHP $this->load->view("back_end/includes/footer"); ?>
<!--<script src="<?= HOSTNAME . 'assets/back_end/jquery/jquery-2.2.3.min.js'; ?>"></script>-->
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
<!--<script src="<?= HOSTNAME . 'assets/back_end/bootstrap/js/bootstrap.min.js'; ?>"></script>-->
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://demos.sanwebcorner.com/select-box-with-search-option-using-jquery/choosen.js"></script>


<style>
    #table_length{margin-left:20px;}
    #table_filter{margin-right:2%;}
    .selectpicker  {background-color: #ffff;}
</style>
<script type="text/javascript">
    var table;

    $(document).ready(function () {
          var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.

            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo site_url('back_end/attendance_controller/siteofficeajax_list') ?>",
                "type": "POST",
                "data": function (data) {
                    data.project = $('#project').val();
                    data.repmonth = $('#repmonth').val();
                    data.repyear = $('#repyear').val();
                    data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                    console.log(data);
                },
                        data:{[csrfName]: csrfHash}, 


                //"data": {'<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>','employeeId' : $('#employeeId').val()},
            },
            "dom": 'lBfrtip',
            "buttons": [
                {
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],

        });

        var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });

    });


</script>
</body>
</html>