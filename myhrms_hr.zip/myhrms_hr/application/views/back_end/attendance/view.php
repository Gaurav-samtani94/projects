<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');

// echo "<pre>";
//print_r($singleproject);
?>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-11">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Project Review</h3>
                    <a href="<?= base_url(); ?>project-account" class="btn btn-primary pull-right">View All Projects</a>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <!--Project View Section start -->
                    <div class="container">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Project Name :</th>
                                    <td> <?= $singleproject['project_name']; ?> </td>
                                    <th>Client Name :</th>
                                    <td> <?= $singleproject['client_name']; ?>  </td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Description : </th>
                                    <td> <?= $singleproject['description']; ?> </td>
                                    <th>Currency :</th>
                                    <td> <?= $singleproject['currencyname']; ?> </td>
                                </tr>

                                <tr>
                                    <th>Contract Value :</th>
                                    <td><?= $singleproject['orgContractVal']; ?></td>
                                    <th>Revised Contract Value :</th>
                                    <td> 0.00 </td>
                                </tr>

                                <tr>
                                    <th>Manpower+Overhead Expenses :</th>
                                    <td> <?= ($singleproject['overhead'] * 2); ?> </td>
                                    <th>Outsourced Expenses :</th>
                                    <td> <?= ($singleproject['outsourced_expenses']) ? $singleproject['outsourced_expenses'] : '0.00'; ?> </td>
                                </tr>

                                <tr>
                                    <th>Total Expenses :</th>
                                    <td><?= ($singleproject['outsourced_expenses'] + ($singleproject['overhead'] * 2)); ?> </td>
                                    <th>Project Status :</th>

                                    <td>
                                        <div id="progressbar">
                                            <div>
                                                <?php
                                                $totV1 = ($singleproject['overhead'] * 2) / $singleproject['orgContractVal'];
                                                $totallv = ($totV1 * 100);
                                                echo number_format((float) $totallv, 2, '.', '');
                                                ?>
                                            </div>
                                        </div>

                                        <small>Physical</small>
                                        <div id="progressbar">
                                            <div>1 % </div>
                                        </div>
                                    </td>

                                </tr>

                                <tr>
                                    <th>Billed to Client :</th>
                                    <td> <?= $singleproject['billed_to_client']; ?> </td>
                                    <th>Amount Received :</th>
                                    <td><?= $singleproject['amountrecieve']; ?>  &nbsp;&nbsp;&nbsp;&nbsp; 
                                        <span style="margin-left:25%;">Due : (<span style="color:red;"> <?php
                                                $remainAmnt = ($singleproject['billed_to_client'] - $singleproject['amountrecieve']);
                                                echo number_format($remainAmnt, 2);
                                                ?>
                                            </span>)  </td>
                                </tr>

                                <tr>
                                    <th>Bill Received (OSW) :</th>
                                    <td> 0.00 </td>
                                    <th>Amount Paid :</th>
                                    <td> 0.00 </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                </div>
                <!-- ./box-body -->
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->


        <?php
//         echo "<pre>";
//         print_r($rows_all_bill);
//         die;
        ?>



        <div class="col-md-11">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Record History</h3>

                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <!--Project View Section start -->
                    <div class="content">
                        <input class="form-control" id="myInput" type="text" placeholder="Search..">
                        <br>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Srn.</th>
                                    <th>Bill Date</th>
                                    <th>Bill No.</th>
                                    <th>Bill From (Contractor)/ To (Client)</th>
                                    <th>Status	Amount</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>

                            <tbody id="myTable">
                                <?php
                                $srn = 0;
                                if ($rows_all_bill):
                                    foreach ($rows_all_bill as $kkey => $recRowval) {
                                        ?>

                                        <tr>
                                            <td><?= $srn = $srn + 1; ?></td>
                                            <td><?= $recRowval['billamnt_date']; ?></td>
                                            <td><?= $recRowval['bill_no']; ?></td>
                                            <td><?= $recRowval['billamnt_date']; ?></td>
                                            <td><?= ($recRowval['amnt_recieved'] > 0) ? 'Recieved' : 'Receivable'; ?></td>
                                            <td><?= ($recRowval['amnt_recieved'] > 0) ? $recRowval['amnt_recieved'] : $recRowval['bill_amount']; ?></td>
                                        </tr>
                                    <?php } endif; ?>       
                            </tbody>

                        </table>
                    </div>
                </div>
                <!-- ./box-body -->
                <!-- /.box-footer -->
            </div>
            <!-- /.box -->
        </div>

    </div>
    <!-- /.row -->
</section>



<style>
    #progressbar {
        background-color: #ffffff;
        border: 1px #ccc solid;
        border-radius: 13px; /* (height of inner div) / 2 + padding */
        padding: 3px;
    }

    #progressbar > div {
        background-color: orange;
        width: 40%; /* Adjust with JavaScript */
        height: 20px;
        border-radius: 10px;
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    $(document).ready(function () {
        $("#myInput").on("keyup", function () {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").each(function () {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>

<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?PHP $this->load->view("back_end/includes/footer"); ?>