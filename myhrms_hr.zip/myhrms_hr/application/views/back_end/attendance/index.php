<?PHP $this->config->set_item('csrf_protection', FALSE); ?>
<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<link href="<?= HOSTNAME .'assets/pagination/datatables/css/jquery.dataTables.min.css'; ?>" rel="stylesheet">
<!-- Main content -->
<div>
    <section class="content">

        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title pull-left">Project Review </h3>
                        <a href="<?PHP echo base_url(); ?>add-subadmin" class="btn btn-primary pull-right">Add Sub-admin</a>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="table" class="table-bordered table-stripped table-hover" cellspacing="0" width="100%">
                            <thead>
<!--                                <tr><td>Sno.</td><td>Name</td><td>Email</td><td>Created</td><td>Status</td><td>Action</td></tr>-->

                                <tr>
                                    <td>Sr.No.</td>
                                    <td>Project Name</td>
                                    <td>Project Type</td>
                                    <td>Client Name</td>
                                    <td>Contract Value</td>
                                    <td>Status</td>
                                    <td>Due from Client</td>
                                    <td>OSW Due Payment</td>
                                    <td>Action</td>
                                </tr>

                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                    <!-- ./box-body -->
                    <!-- /.box-footer -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
</div>
</div>

<?PHP $this->load->view("back_end/includes/footer"); ?>
<script>
    function delete_subadmin(id)
    {
        if (id)
        {
            var con = confirm("Are You Sure To Delete The Subadmin Account?")
            if (con == true)
            {
                window.location.href = "<?PHP echo site_url('delete-subadmin'); ?>/" + id;
            }
        }
    }
</script>
<script src="<?= HOSTNAME .'assets/pagination/datatables/js/jquery.dataTables.min.js'; ?>"></script>
<script type="text/javascript">
    var table;

    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';


        table = $('#table').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
            language: {
                searchPlaceholder: "Search records"
            },
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo site_url('project-ajax-list') ?>",
                "type": "POST",
                "data": function (data) {
                    data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                },
                       
              data:{[csrfName]: csrfHash}, 

            },
            //Set column definition initialisation properties.
            "columnDefs": [
                {
                    "targets": [-1, -2], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],

        });

    });
</script>
