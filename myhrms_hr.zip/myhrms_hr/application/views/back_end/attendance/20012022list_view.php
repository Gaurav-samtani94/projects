<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
if (@$reportmonth == '') {
    @$reportmonth = date('n');
}
if (@$reportyear == '') {
    @$reportyear = date('Y');
}
if (@$reportbunit == '') {
    @$reportbunit = '1';
}
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="header">
                                <?= form_open_multipart(base_url('attendanceReportMonthly'), array('class' => '')) ?>
                                <!--<div class="card-header" id="headingOne">-->
                                <div class="row clearfix">
                                    <div class="col-lg-3 col-md-6">
                                        <b>Business Unit :</b>
                                        <select required name="businessunit" class="form-control">
                                            <option value="1"> CEG </option>
                                            <option value="2"> CEG TH </option>
                                            <option value="3"> CEG Project </option>
                                        </select>
                                    </div>
                                    <!--<div class="col-lg-3 col-md-6">
<div class="form-group">
                                                    <label class="email"> Department: </label> 
                                                    <select name="department" class="form-control">
                                                            <option value=""> Select </option>
                                                    </select>
                                            </div>
</div>-->

                                    <div class="col-lg-3 col-md-6">
                                        <label class="email"> Month : </label>
                                        <select required name="repmonth" class="form-control">
                                            <?php for ($i = 1; $i < 13; $i++): ?>
                                                <option <?= (@$reportmonth == $i) ? "selected" : ''; ?> value="<?= $i; ?>"><?= $i; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                    <div class="col-lg-3 col-md-6">
                                        <label class="email"> Year : </label>
                                        <select required name="repyear" class="form-control">

                                            <?php for ($yi = 2016; $yi <= date('Y'); $yi++): ?>
                                                <option <?= (@$reportyear == $yi) ? "selected" : ''; ?> value="<?= $yi; ?>"><?= $yi; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>



                                    <div class="col-lg-1 col-md-6">
                                        <div class="mb-2">
                                            <b></b>
                                            <input type="submit" name="filterrep" class="btn btn-primary" value="Filter">
                                        </div>
                                    </div>
                                    <div class="col-lg-1 col-md-6">
                                        <div class="mb-2">
                                            <b></b>
                                            <button type="button" id="btn-reset" class="btn btn-primary btn-block"> Reset </button>
                                        </div>
                                    </div>



                                </div>
                                <!--</div> -->                               

                                <?PHP echo form_close(); ?>


                            </div>
                            <div class="body">
                                <?php if ((@$reportmonth) and ( @$reportyear) and ( @$reportbunit)): ?>
                                    <div class="table-responsive">
                                        <table id="table" class="table table-striped display" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>EMP Name</th>
                                                    <th>Position</th>
                                                    <th>Department </th>
    <!--                            <th>No of HD </th>-->
                                                    <th>1</th>
                                                    <th>2</th>
                                                    <th>3</th>
                                                    <th>4</th>
                                                    <th>5</th>
                                                    <th>6</th>
                                                    <th>7</th>
                                                    <th>8</th>
                                                    <th>9</th>
                                                    <th>10</th>
                                                    <th>11</th>
                                                    <th>12</th>
                                                    <th>13</th>
                                                    <th>14</th>
                                                    <th>15</th>
                                                    <th>16</th>
                                                    <th>17</th>
                                                    <th>18</th>
                                                    <th>19</th>
                                                    <th>20</th>
                                                    <th>21</th>
                                                    <th>22</th>
                                                    <th>23</th>
                                                    <th>24</th>
                                                    <th>25</th>
                                                    <th>26</th>
                                                    <th>27</th>
                                                    <th>28</th>
                                                    <th>29</th>
                                                    <th>30</th>
                                                    <th>31</th>
                                                </tr> 
                                            </thead>
                                            <tbody>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>Sr. No</th>
                                                    <th>EMP Name</th>
                                                    <th>Position</th>
                                                    <th>Department </th>
                                                    <th>1</th>
                                                    <th>2</th>
                                                    <th>3</th>
                                                    <th>4</th>
                                                    <th>5</th>
                                                    <th>6</th>
                                                    <th>7</th>
                                                    <th>8</th>
                                                    <th>9</th>
                                                    <th>10</th>
                                                    <th>11</th>
                                                    <th>12</th>
                                                    <th>13</th>
                                                    <th>14</th>
                                                    <th>15</th>
                                                    <th>16</th>
                                                    <th>17</th>
                                                    <th>18</th>
                                                    <th>19</th>
                                                    <th>20</th>
                                                    <th>21</th>
                                                    <th>22</th>
                                                    <th>23</th>
                                                    <th>24</th>
                                                    <th>25</th>
                                                    <th>26</th>
                                                    <th>27</th>
                                                    <th>28</th>
                                                    <th>29</th>
                                                    <th>30</th>
                                                    <th>31</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

</body>
<script type="text/javascript">
    var table;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "dom": 'lBfrtip',
            "order": [],
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url('ajax_lists'); ?>",
                "type": "POST",
                data: {'<?= $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'repyear': '<?= $reportyear ?>', 'repmonth': '<?= $reportmonth ?>', 'reportbunit': '<?= $reportbunit; ?>'},
            },
            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}],
            //Set column definition initialisation properties.
            "columnDefs": [{"targets": [0],
                    "orderable": false,
                },
            ],

            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1

        });
        var colvis = new $.fn.dataTable.ColVis(table);
        $('#colvis').html(colvis.button());
        $('#btn-filter').click(function () {
            table.ajax.reload();
        });
        $('#btn-reset').click(function () {
            $('#form-filter')[0].reset();
            table.ajax.reload();
        });
    });


    // oTable = $('#table').DataTable();   //pay attention to capital D, which is mandatory to retrieve "api" datatables' object, as @Lionel said
    $('#myInputTextField').keyup(function () {
        table.search($(this).val()).draw();
        table.fnFilter($(this).val());
        var i = $(this).attr('data-column');  // getting column index
        var v = $(this).val();  // getting search input value
        table.columns(i).search(v).draw();
    });
</script>

<style>
    .panel {
        margin-bottom: 20px;
        background-color: #fff;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        width: 99%;
        overflow-x: auto;
        white-space: nowrap;
    }
</style>
<?php $this->load->view('admin/includes/footer'); ?>

