<?PHP
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');

if (@$reportmonth == '') {
    @$reportmonth = date('m');
}
if (@$reportyear == '') {
    @$reportyear = date('Y');
}
?>
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/jquery.dataTables.min.css'; ?>" rel="stylesheet">
<link href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/colvis/1.1.2/css/dataTables.colVis.css" rel="stylesheet">
<div>
    <section class="content" style="min-height:700px">
        <div class="panel panel-default">
            <div class="panel-body">
                <?= form_open_multipart(base_url('back_end/attendance_controller/index'), array('class' => '')) ?>
                <div class="row">
                    <div class="col-sm-2">
                        <div class="form-group">
                            <label class="email">Business Unit : </label> 
                            <select required name="businessunit" class="form-control">
                                <option value="1"> CEG </option>
                                <option value="2"> CEG TH </option>
                                <option value="3"> CEG Project </option>
                            </select>
                        </div> 
                    </div>
                    <div class="col-sm-2">
                        <div class="form-group">
                            <label class="email"> Department: </label> 
                            <select name="department" class="form-control">
                                <option value=""> Select </option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-2"> 
                        <label class="email"> Month : </label>
                        <select required name="repmonth" class="form-control">
                            <?php for ($i = 1; $i < 13; $i++): ?>
                                <option <?= (@$reportmonth == $i) ? "selected" : ''; ?> value="<?= $i; ?>"><?= $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-sm-2">
                        <label class="email"> Year : </label>
                        <select required name="repyear" class="form-control">

                            <?php for ($yi = 2016; $yi <= date('Y'); $yi++): ?>
                                <option <?= (@$reportyear == $yi) ? "selected" : ''; ?> value="<?= $yi; ?>"><?= $yi; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-sm-2"><br>
                        <input type="submit" name="filterrep" class="btn btn-primary" value="Filter">
                    </div>
                </div>
                <?PHP echo form_close(); ?>
            </div>
        </div>



        <?php if ((@$reportmonth) and ( @$reportyear) and ( @$reportbunit)): ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title" >Attendance Report  : </h3>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div id="colvis"></div>
                    </div>
                </div>

                <table id="table" class="display" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Sr. No</th>
                            <th>EMP Name</th>
                            <th>Position</th>
                            <th>Department </th>
    <!--                            <th>No of HD </th>-->
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>7</th>
                            <th>8</th>
                            <th>9</th>
                            <th>10</th>
                            <th>11</th>
                            <th>12</th>
                            <th>13</th>
                            <th>14</th>
                            <th>15</th>
                            <th>16</th>
                            <th>17</th>
                            <th>18</th>
                            <th>19</th>
                            <th>20</th>
                            <th>21</th>
                            <th>22</th>
                            <th>23</th>
                            <th>24</th>
                            <th>25</th>
                            <th>26</th>
                            <th>27</th>
                            <th>28</th>
                            <th>29</th>
                            <th>30</th>
                            <th>31</th>

                        </tr>
                    </thead>


                    <tbody>
                    </tbody>

                    <tfoot>
                        <tr>
                            <th>Sr. No</th>
                            <th>EMP Name</th>
                            <th>Position</th>
                            <th>Department </th>
    <!--                            <th>Late No HD </th>-->
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                            <th>5</th>
                            <th>6</th>
                            <th>7</th>
                            <th>8</th>
                            <th>9</th>
                            <th>10</th>
                            <th>11</th>
                            <th>12</th>
                            <th>13</th>
                            <th>14</th>
                            <th>15</th>
                            <th>16</th>
                            <th>17</th>
                            <th>18</th>
                            <th>19</th>
                            <th>20</th>
                            <th>21</th>
                            <th>22</th>
                            <th>23</th>
                            <th>24</th>
                            <th>25</th>
                            <th>26</th>
                            <th>27</th>
                            <th>28</th>
                            <th>29</th>
                            <th>30</th>
                            <th>31</th>
                        </tr>
                    </tfoot>
                </table>
        </section>
    <?php endif; ?>
</div>

<?PHP $this->load->view("back_end/includes/footer"); ?>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/colvis/1.1.2/js/dataTables.colVis.js"></script>
<script src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js"></script>

<style>
    /* #table_length{margin-left:20px;}
    #table_filter{margin-right:2%;} */
</style>

<script type="text/javascript">
    var table;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "dom": 'lBfrtip',
            "order": [],
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?= site_url('back_end/attendance_controller/ajax_list') ?>",
                "type": "POST",
                data: {'<?= $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'repyear': '<?= $reportyear ?>', 'repmonth': '<?= $reportmonth ?>', 'reportbunit': '<?= $reportbunit; ?>'},
            },
            "buttons": [{extend: 'collection', text: 'Export', buttons: ['copy', 'excel', 'csv', 'pdf', 'print']}],
            //Set column definition initialisation properties.
            "columnDefs": [{"targets": [0],
                    "orderable": false,
                },
            ],

            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1

        });
        var colvis = new $.fn.dataTable.ColVis(table);
        $('#colvis').html(colvis.button());
        $('#btn-filter').click(function () {
            table.ajax.reload();
        });
        $('#btn-reset').click(function () {
            $('#form-filter')[0].reset();
            table.ajax.reload();
        });
    });


    // oTable = $('#table').DataTable();   //pay attention to capital D, which is mandatory to retrieve "api" datatables' object, as @Lionel said
    $('#myInputTextField').keyup(function () {
        table.search($(this).val()).draw();
        table.fnFilter($(this).val());
        var i = $(this).attr('data-column');  // getting column index
        var v = $(this).val();  // getting search input value
        table.columns(i).search(v).draw();
    });
</script>

<style>
    .panel {
        margin-bottom: 20px;
        background-color: #fff;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        width: 99%;
        overflow-x: auto;
        white-space: nowrap;
    }
</style>

</body>
</html>