<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Educational  Qualification Report</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <form id="form-filter"> 
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Business Unit :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="businessunit_name" class="form-control"> 
                                                            <option value="">All Business Unit</option>
                                                            <?php foreach ($form_businessunit as $unit) { ?>
                                                                <option value="<?= $unit->id; ?>"><?= $unit->unitname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Company Name :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="company_name" class="form-control custom-select"> 
                                                            <option value="">-Select Company-</option>
                                                            <?php foreach ($companyname as $company) { ?>
                                                                <option value="<?= $company->company_id; ?>"><?= $company->company_name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Department :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="department_name" class="form-control custom-select"> 
                                                            <option value="">-Select Department-</option>
                                                            <?php foreach ($departmentname as $dept) { ?>
                                                                <option value="<?= $dept->id; ?>"><?= $dept->deptname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Designation :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="designation_name" class="form-control custom-select"> 
                                                            <option value="">-Select Designation-</option>
                                                            <?php foreach ($position as $designation) { ?>
                                                                <option value="<?= $designation->id; ?>"><?= $designation->positionname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Employee ID :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" id="employeeId" class="form-control" />
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Employee Name :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" id="userfullname" class="form-control" />
                                                    </div>
                                                </div>

                                                <div class="col-lg-2 col-md-6">
                                                    <b>Location/Project Name :</b>
                                                    <div class="input-group mb-2">
                                                        <?php $proj = get_all_active_project(); ?>
                                                        <select id="project_name" class="form-control custom-select"> 
                                                            <option value="">-Select Project-</option>
                                                            <?php foreach ($proj as $rrrow) { ?>
                                                                <option value="<?= $rrrow->id; ?>"><?= $rrrow->project_name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>


                                                <div class="col-lg-1 col-md-6">
                                                    <div class="mb-2">
                                                        <b></b>
                                                        <button type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>  
                                                    </div>
                                                </div>
                                                <div class="col-lg-1 col-md-6">

                                                    <div class="mb-2">
                                                        <b></b>
                                                        <button type="reset" id="btn-reset" class="btn btn-primary btn-block"> Reset </button>   
                                                    </div>
                                                </div>


                                            </div>
                                            <!--</div> -->          
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">

                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <!--<th>Early Relieving</th>-->
                                                <!--<th>Late Relieving</th>-->
                                                <th>Notice Period</th>
                                                <th>Last Working</th>
                                                <th>IO Status</th>
                                                <th>RO Status</th>
                                                <!--<th>Actual Working</th>-->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <!--<th>Early Relieving</th>-->
                                                <!--<th>Late Relieving</th>-->
                                                <th>Notice Period</th>
                                                <th>Last Working</th>
                                                <th>IO Status</th>
                                                <th>RO Status</th>
                                                <!--<th>Actual Working</th>-->
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>


                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>



        <?php $this->load->view('admin/includes/footer'); ?>
    </div>


    <script type="text/javascript">
        var table;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#exit_type').on('change', function () {
                if ($('#exit_type').val() == 'exit') {
                    $('#first_table').css("display", "block");
                    $('#second_table').css("display", "none");
                    table = $('#table').DataTable({
                        "processing": true, //Feature control the processing indicator.
                        "serverSide": true, //Feature control DataTables' server-side processing mode.
                        "order": [],
                        "ajax": {
                            "url": "<?= base_url('ajax_seperation_list') ?>",
                            "type": "POST",
                            "data": function (data) {
                                data.businessunit_name = $('#businessunit_name').val();
                                data.company_name = $('#company_name').val();
                                data.userfullname = $('#userfullname').val();
                                data.employeeId = $('#employeeId').val();
                                data.designation_name = $('#designation_name').val();
                                data.department_name = $('#department_name').val();
                                data.project_name = $('#project_name').val();
                                data.status_type = $('#status_type').val();

                            },
                                    data:{[csrfName]: csrfHash}, 

                        },
                        "dom": 'lBfrtip',
                        "buttons": [{
                                extend: 'collection',
                                text: 'Export',
                                buttons: [
                                    'copy',
                                    'excel',
                                    'csv',
                                    'pdf',
                                    'print'
                                ]
                            }
                        ],
                        //Set column definition initialisation properties.
                        "columnDefs": [{
                                "targets": [0], //first column / numbering column
                                "orderable": false, //set not orderable
                            },
                        ],
                        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    });
                    var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                    $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                    $('#btn-filter').click(function () { //button filter event click
                        table.ajax.reload();  //just reload table
                    });
                    $('#btn-reset').click(function () { //button reset event click
                        $('#form-filter')[0].reset();
                        table.ajax.reload();  //just reload table
                    });
                }
            });
        });
    </script>
    <script>
        var table_all;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            //  $('#exit_type').on('change', function(){
            //  if($('#exit_type').val() == 'all'){
            //  $('#first_table').css("display","none");
            //   $('#second_table').css("display","block");
            table_all = $('#table_all').DataTable({
                "processing": true, //Feature control the processing indicator.
                "serverSide": true, //Feature control DataTables' server-side processing mode.
                "order": [],
                "ajax": {
                    "url": "<?= base_url('seperation/Seperation_Controller/ajax_seperation_all_list') ?>",
                    "type": "POST",
                    "data": function (data) {
                        data.businessunit_name = $('#businessunit_name').val();
                        data.company_name = $('#company_name').val();
                        data.userfullname = $('#userfullname').val();
                        data.employeeId = $('#employeeId').val();
                        data.designation_name = $('#designation_name').val();
                        data.department_name = $('#department_name').val();
                        data.project_name = $('#project_name').val();
                        data.status_type = $('#status_type').val();

                    },
                            data:{[csrfName]: csrfHash}, 

                },
                "dom": 'lBfrtip',
                "buttons": [{
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [{
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });
            // var colvis = new $.fn.dataTable.ColVis(table_all); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table_all.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table_all.ajax.reload();  //just reload table
            });
            //  }
            // });
        });
    </script>
    <script>
        $('#resignation').hide();
        $('#resignation-left').hide();
        $('#severance').hide();
        $('#demobilization').hide();
        $('#type_seperation').on('change', function () {
            var val = $(this).val();
            if (val == '') {
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            } else if (val == '1') {
                $('#resignation').show();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_severance_first').hide();
            } else if (val == '2') {
                $('#resignation-left').show();
                $('#resignation').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            } else if (val == '3') {
                $('#severance').show();
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
            } else if (val == '4') {
                $('#demobilization').show();
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            }
        });
    </script>

    <script>
        $('#resignation-first').on('change', function () {
            var resign = $(this).val();
            // alert(resign);
            if (resign == '14')
            {
                $('#other_resignation_first').show();
                $('#other_severance_first').hide();
            } else {
                $('#other_resignation_first').hide();
            }
        });
    </script>

    <script>
        $('#severance-first').on('change', function () {
            var severance = $(this).val();
            if (severance == '20')
            {
                $('#other_severance_first').show();
                $('#other_resignation_first').hide();
            } else {
                $('#other_severance_first').hide();
            }
        });
    </script>

    <script>
        function myFunction(id) {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                type: 'POST',
                url: '<?= base_url('seperation/Seperation_Controller/getDataByid/'); ?>',
                data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'id': id},
                success: function (res) {
                    var result = JSON.parse(res);
                    $('#ids').val(result.user_id);
                    $('#ids').val(result.user_id);
                    if (result.profileimg) {
                        $('.avatar').attr('src', '<?= HOSTNAME; ?>/public/uploads/profile/' + result.profileimg);
                    } else {
                        $('.avatar').attr('src', '<?= HOSTNAME; ?>/assets/img/user.jpg');
                    }
                    $('.user-name').html(result.userfullname);
                    $('.text-muted').html(result.position_name);
                    $('.emp_id').html(result.employeeId);
                    $('.phone').html(result.contactnumber);
                    $('.email').html(result.emailaddress);
                    $('.birthday').html(result.date_of_joining);
                    $('.ro').html(result.reporting_manager_name);
                    $('.dept').html(result.department_name);
                    $('#type_seperation').val(result.type_of_seperation);
                    $('#notice_period').val(result.noticeperiod);
                    $('#relieving_date').val(result.relieving_date);
                },
                    data:{[csrfName]: csrfHash}, 
            });

        }
    </script>
    <script>
        /********************calculate last working day according to notice period and default date***/
        $(document).ready(function () {
            $('#type_seperation').on('change', function () {
                var ntpdate = $('#notice_period').val();
                var relievedate = $('#relieving_date').val();
                $.ajax({
                    url: '<?php echo base_url('seperation/Seperation_Controller/getactualdate?rperday='); ?>' + relievedate + '&nperday=' + ntpdate,
                    type: "GET",
                    success: function (resdata) {
                        $('#actual_working_day').val(resdata);
                        $('#last_working_day').val(resdata);
                    }
                });
            });
        });
    </script>
    <script type="text/javascript">
        $(function () {
            $("#project_name,#company_name,#designation_name, #department_name").customselect();
        });
    </script>
    <script>
        $('#early_relieving').datepicker({format: 'mm/dd/yyyy'});
        $('#late_relieving').datepicker({format: 'mm/dd/yyyy'});
        $('#last_working_day').datepicker({format: 'mm/dd/yyyy'});
        $('#actual_working_day').datepicker({format: 'mm/dd/yyyy'});
    </script>
    <style>
        .custom-select{width:auto!important;}
        .custom-select input{width:100%!important;}
    </style>
</body>