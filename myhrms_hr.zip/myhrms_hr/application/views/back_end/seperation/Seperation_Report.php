<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Employee Educational  Qualification Report</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <form id="form-filter"> 
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Business Unit :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="businessunit_name" class="form-control"> 
                                                            <option value="">All Business Unit</option>
                                                            <?php foreach ($form_businessunit as $unit) { ?>
                                                                <option value="<?= $unit->id; ?>"><?= $unit->unitname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Company Name :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="company_name" class="form-control"> 
                                                            <option value="">-Select Company-</option>
                                                            <?php foreach ($companyname as $company) { ?>
                                                                <option value="<?= $company->company_id; ?>"><?= $company->company_name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Department :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="department_name" class="form-control "> 
                                                            <option value="">-Select Department-</option>
                                                            <?php foreach ($departmentname as $dept) { ?>
                                                                <option value="<?= $dept->id; ?>"><?= $dept->deptname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Designation :</b>
                                                    <div class="input-group mb-3">

                                                        <select id="designation_name" class="form-control "> 
                                                            <option value="">-Select Designation-</option>
                                                            <?php foreach ($position as $designation) { ?>
                                                                <option value="<?= $designation->id; ?>"><?= $designation->positionname; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Employee ID :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" id="employeeId" class="form-control" />
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Employee Name :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" id="userfullname" class="form-control" />
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Designation :</b>
                                                    <div class="input-group mb-3">
                                                        <?php $proj = get_all_active_project(); ?>
                                                        <select id="project_name" class="form-control"> 
                                                            <option value="">-Select Project-</option>
                                                            <?php foreach ($proj as $rrrow) { ?>
                                                                <option value="<?= $rrrow->id; ?>"><?= $rrrow->project_name; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Emp Status :</b>
                                                    <div class="input-group mb-3">
                                                        <select id="status_type" name="status_type" class="form-control">
                                                            <option value="">-Select Emp Status-</option>
                                                            <?php foreach ($emp_sta as $rrrow) { ?>
                                                                <option value="<?= $rrrow->id; ?>"><?= $rrrow->employemnt_status; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-lg-1 col-md-6">
                                                    <div class="mb-2">
                                                        <b></b>
                                                        <button type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>  
                                                    </div>
                                                </div>
                                                <div class="col-lg-1 col-md-6">

                                                    <div class="mb-2">
                                                        <b></b>
                                                        <button type="reset" id="btn-reset" class="btn btn-primary btn-block"> Reset </button>   
                                                    </div>
                                                </div>


                                            </div>
                                            <!--</div> -->          
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">

                                <div class="table-responsive" id="first_table" style="display:none;">
                                    <table id="table" class="table table-striped display">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Resign Type</th>
                                                <th>Notice Period</th>
                                                <th>Resign Date</th>
                                                <th>Last Working date</th>
                                                <th>Emp Approval</th>
                                                <th>IO Approval</th>
                                                <th>RO Approval</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Resign Type</th>
                                                <th>Notice Period</th>
                                                <th>Resign Date</th>
                                                <th>Last Working date</th>
                                                <th>Emp Approval</th>
                                                <th>IO Approval</th>
                                                <th>RO Approval</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="table-responsive" id="second_table">
                                    <table id="table_all" class="table table-striped display">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Notice Period</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>Employee Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Notice Period</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>Employee Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>



        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
    <div id="add_seperation" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="modal-content modal-lg">

                <div class="modal-header">
                    <h4 class="modal-title">Add Seperation</h4>
                </div>

                <div class="modal-body">
                    <div class="card-box">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="profile-view">

                                    <div class="profile-img-wrap">
                                        <div class="profile-img">
                                            <a href="#"><img class="avatar" src="" alt=""></a>
                                        </div>
                                    </div>

                                    <div class="profile-basic">
                                        <div class="row">

                                            <div class="col-md-5">
                                                <div class="profile-info-left">
                                                    <h3 class="user-name m-t-0 m-b-0"></h3>                                        
                                                    <small class="text-muted"></small>                                       
                                                    <div class="staff-id">Employee ID :<span class="text emp_id"></span></div>                                       
                                                </div>
                                            </div>

                                            <div class="col-md-7">
                                                <ul class="personal-info" style="list-style: circle;">
                                                    <li>
                                                        <span class="title">Phone:</span>
                                                        <span class="text phone"></span>                                        
                                                    </li>
                                                    <li>
                                                        <span class="title">Email:</span>
                                                        <span class="text email"></span>                                        
                                                    </li>
                                                    <li>
                                                        <span class="title">DOJ:</span>
                                                        <span class="text birthday"></span>                                        
                                                    </li>
                                                    <li>
                                                        <span class="title">RO:</span>
                                                        <span class="text ro"></span>                                        
                                                    </li>
                                                    <li>
                                                        <span class="title">Department:</span>
                                                        <span class="text dept"></span>                                        
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>  

                    <?= form_open(base_url('seperation_add'), array('class' => 'm-b-30', 'id' => 'form_seperation', 'method' => 'post', 'novalidate' => 'novalidate')) ?>
                    <div class="row">

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Type of Seperation<span class="text-danger">*</span></label>
                                <select id="type_seperation" name="type_seperation" autocomplete="off" class="form-control">
                                    <option value="">-Select Seperation-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 0) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4" id="resignation">
                            <div class="form-group">
                                <label class="control-label">Resignation<span class="text-danger">*</span></label>
                                <select id="resignation-first" name="resignation" autocomplete="off" class="form-control">
                                    <option value="">-Select Reason-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 1) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-4" id="other_resignation_first" style="display:none;">  
                            <div class="form-group">
                                <label class="control-label">For Other resignation <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="other_resignation" id="other_resignation" class="form-control"/>
                            </div>
                        </div>    

                        <div class="col-sm-4" id="resignation-left">
                            <div class="form-group">
                                <label class="control-label">Resignation and Left<span class="text-danger">*</span></label>
                                <select name="resignation-left" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason Left-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 2) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>     

                        <div id="demobilization" class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Demobilization<span class="text-danger">*</span></label>
                                <select name="demobilization" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason demobilization-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 4) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div> 

                        <div class="col-sm-4" id="severance">
                            <div class="form-group">
                                <label class="control-label">Severance<span class="text-danger">*</span></label>
                                <select id="severance-first" name="severance" class="form-control" autocomplete="off">
                                    <option value="">-Select Reason severance-</option>
                                    <?php foreach ($resignation as $resign) { ?>
                                        <?php if (($resign->parent_id) == 3) { ?>
                                            <option value="<?= $resign->id; ?>"><?= $resign->seperation_name; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>     

                        <div class="col-sm-4" id="other_severance_first"  style="display:none;">  
                            <div class="form-group">
                                <label class="control-label">For Other severance <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="other_severance" id="other_severance" class="form-control"/>
                            </div>
                        </div>    

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Desired for Early Relieving  <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input  type="text" name="early_relieving" id="early_relieving" class="form-control"/></div>
                            </div>
                        </div>

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Desired for Late Relieving  <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="text" name="late_relieving" id="late_relieving" class="form-control"/></div>
                            </div>
                        </div>

                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Notice Period <span class="text-danger">*</span></label>
                                <input autocomplete="off" type="text" name="notice_period" id="notice_period" value="" class="form-control" readonly/>
                            </div>
                        </div>


                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Last Working date as per notice period <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="text" name="last_working_day" id="last_working_day" value="" class="form-control" readonly/></div>
                            </div>
                        </div>


                        <div class="col-sm-4">  
                            <div class="form-group">
                                <label class="control-label">Actual Last Working Date <span class="text-danger">*</span></label>
                                <div class="cal-icon"><input type="text" name="actual_working_day" id="actual_working_day" value="" class="form-control"/></div>
                            </div>
                        </div>

                    </div>     

                    <div class="row">
                        <div class="m-t-20 text-center">
                            <input type="hidden" value="" name="emp_id" id="ids">
                            <input type="hidden" value="" name="relieving_date" id="relieving_date">
                            <input type="submit" required class="btn btn-primary" value="submit">
                        </div>
                    </div>

                    <?= form_close(); ?>    
                </div>
            </div>


        </div>
    </div>

    <script type="text/javascript">
        var table;
        $(document).ready(function () {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#exit_type').on('change', function () {
                if ($('#exit_type').val() == 'exit') {
                    $('#first_table').css("display", "block");
                    $('#second_table').css("display", "none");
                    table = $('#table').DataTable({
                        "processing": true, //Feature control the processing indicator.
                        "serverSide": true, //Feature control DataTables' server-side processing mode.
                        "order": [],
                        "ajax": {
                            "url": "<?= base_url('ajax_seperation_list') ?>",
                            "type": "POST",
                            "data": function (data) {
                                data.businessunit_name = $('#businessunit_name').val();
                                data.company_name = $('#company_name').val();
                                data.userfullname = $('#userfullname').val();
                                data.employeeId = $('#employeeId').val();
                                data.designation_name = $('#designation_name').val();
                                data.department_name = $('#department_name').val();
                                data.project_name = $('#project_name').val();
                                data.status_type = $('#status_type').val();

                            },
                                    data:{[csrfName]: csrfHash}, 

                        },
                        "dom": 'lBfrtip',
                        "buttons": [{
                                extend: 'collection',
                                text: 'Export',
                                buttons: [
                                    'copy',
                                    'excel',
                                    'csv',
                                    'pdf',
                                    'print'
                                ]
                            }
                        ],
                        //Set column definition initialisation properties.
                        "columnDefs": [{
                                "targets": [0], //first column / numbering column
                                "orderable": false, //set not orderable
                            },
                        ],
                        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    });
                    var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                    $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                    $('#btn-filter').click(function () { //button filter event click
                        table.ajax.reload();  //just reload table
                    });
                    $('#btn-reset').click(function () { //button reset event click
                        $('#form-filter')[0].reset();
                        table.ajax.reload();  //just reload table
                    });
                }
            });
        });
    </script>
    <script>
        var table_all;
        $(document).ready(function () {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            //  $('#exit_type').on('change', function(){
            //  if($('#exit_type').val() == 'all'){
            //  $('#first_table').css("display","none");
            //   $('#second_table').css("display","block");
            table_all = $('#table_all').DataTable({
                "processing": true, //Feature control the processing indicator.
                "serverSide": true, //Feature control DataTables' server-side processing mode.
                "order": [],
                "ajax": {
                    "url": "<?= base_url('seperation/Seperation_Controller/ajax_seperation_all_list') ?>",
                    "type": "POST",
                    "data": function (data) {
                        data.businessunit_name = $('#businessunit_name').val();
                        data.company_name = $('#company_name').val();
                        data.userfullname = $('#userfullname').val();
                        data.employeeId = $('#employeeId').val();
                        data.designation_name = $('#designation_name').val();
                        data.department_name = $('#department_name').val();
                        data.project_name = $('#project_name').val();
                        data.status_type = $('#status_type').val();

                    },
                            data:{[csrfName]: csrfHash}, 

                },
                "dom": 'lBfrtip',
                "buttons": [{
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [{
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });
            // var colvis = new $.fn.dataTable.ColVis(table_all); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table_all.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table_all.ajax.reload();  //just reload table
            });
            //  }
            // });
        });
    </script>
    <script>
        $('#resignation').hide();
        $('#resignation-left').hide();
        $('#severance').hide();
        $('#demobilization').hide();
        $('#type_seperation').on('change', function () {
            var val = $(this).val();
            if (val == '') {
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            } else if (val == '1') {
                $('#resignation').show();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_severance_first').hide();
            } else if (val == '2') {
                $('#resignation-left').show();
                $('#resignation').hide();
                $('#severance').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            } else if (val == '3') {
                $('#severance').show();
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#demobilization').hide();
                $('#other_resignation_first').hide();
            } else if (val == '4') {
                $('#demobilization').show();
                $('#resignation').hide();
                $('#resignation-left').hide();
                $('#severance').hide();
                $('#other_resignation_first').hide();
                $('#other_severance_first').hide();
            }
        });
    </script>

    <script>
        $('#resignation-first').on('change', function () {
            var resign = $(this).val();
            // alert(resign);
            if (resign == '14')
            {
                $('#other_resignation_first').show();
                $('#other_severance_first').hide();
            } else {
                $('#other_resignation_first').hide();
            }
        });
    </script>

    <script>
        $('#severance-first').on('change', function () {
            var severance = $(this).val();
            if (severance == '20')
            {
                $('#other_severance_first').show();
                $('#other_resignation_first').hide();
            } else {
                $('#other_severance_first').hide();
            }
        });
    </script>

    <script>
        function myFunction(id) {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            $.ajax({
                type: 'POST',
                url: '<?= base_url('seperation/Seperation_Controller/getDataByid/'); ?>',
                data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'id': id},
                success: function (res) {
                    var result = JSON.parse(res);
                    $('#ids').val(result.user_id);
                    $('#ids').val(result.user_id);
                    if (result.profileimg) {
                        $('.avatar').attr('src', '<?= HOSTNAME; ?>/public/uploads/profile/' + result.profileimg);
                    } else {
                        $('.avatar').attr('src', '<?= HOSTNAME; ?>/assets/img/user.jpg');
                    }
                    $('.user-name').html(result.userfullname);
                    $('.text-muted').html(result.position_name);
                    $('.emp_id').html(result.employeeId);
                    $('.phone').html(result.contactnumber);
                    $('.email').html(result.emailaddress);
                    $('.birthday').html(result.date_of_joining);
                    $('.ro').html(result.reporting_manager_name);
                    $('.dept').html(result.department_name);
                    $('#type_seperation').val(result.type_of_seperation);
                    $('#notice_period').val(result.noticeperiod);
                    $('#relieving_date').val(result.relieving_date);
                },
                    data:{[csrfName]: csrfHash}, 
            });

        }
    </script>
    <script>
        /********************calculate last working day according to notice period and default date***/
        $(document).ready(function () {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            $('#type_seperation').on('change', function () {
                var ntpdate = $('#notice_period').val();
                var relievedate = $('#relieving_date').val();
                $.ajax({
                    url: '<?php echo base_url('seperation/Seperation_Controller/getactualdate?rperday='); ?>' + relievedate + '&nperday=' + ntpdate,
                    type: "GET",
                    success: function (resdata) {
                        $('#actual_working_day').val(resdata);
                        $('#last_working_day').val(resdata);
                    }
                });
            });
        });
    </script>
    <script type="text/javascript">
        $(function () {
            $("#project_name,#company_name,#designation_name, #department_name").customselect();
        });
    </script>
    <script>
        $('#early_relieving').datepicker({format: 'mm/dd/yyyy'});
        $('#late_relieving').datepicker({format: 'mm/dd/yyyy'});
        $('#last_working_day').datepicker({format: 'mm/dd/yyyy'});
        $('#actual_working_day').datepicker({format: 'mm/dd/yyyy'});
    </script>

</body>