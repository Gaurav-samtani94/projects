<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
$this->load->view('back_end/includes/head');
$this->load->view('back_end/includes/header');
$this->load->view('back_end/includes/sidebar');
?>
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/dataTables.colVis.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/back_end/datatables/css/buttons.dataTables.min.css' ?>" rel="stylesheet">
<div class="page-wrapper">
    <div class="content container-fluid">

        <div class="row">
            <div class="col-xs-12">
                <h4 class="page-title">View Exit Procedures As IO</h4>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="row">
                <div class="col-xs-12">
                    <?php if ($this->session->flashdata('success')): ?>
                        <div class="alert alert-info alert-dismissible fade in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success ! </strong> <?php echo $this->session->flashdata('success'); ?>
                        </div>
                    <?php endif; ?> 
                    <?php if ($this->session->flashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade in">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error ! </strong> <?php echo $this->session->flashdata('error'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="panel-body">   
                <div class="row">
                    <div class="col-md-12">
                        <div id="colvis"></div>
                    </div>
                </div>	   
                <div class="table-responsive">
                    <table id="table" class="table table-striped display">
                        <thead>
                            <tr>
                                <th>S No.</th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Designation</th>
                                <th>Department</th>
                                <th>Resign Type</th>
                                <th>Notice Period</th>
                                <th>Resign Date</th>
                                <th>Last Working date</th>
                                <th>Emp Approval</th>
                                <th>HR Approval</th>
                                <th>RO Approval</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>S No.</th>
                                <th>Employee ID</th>
                                <th>Employee Name</th>
                                <th>Designation</th>
                                <th>Department</th>
                                <th>Resign Type</th>
                                <th>Notice Period</th>
                                <th>Resign Date</th>
                                <th>Last Working date</th>
                                <th>Emp Approval</th>
                                <th>HR Approval</th>
                                <th>RO Approval</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>       
    </div>
</div>


<div id="add_ro_initaiate_status" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">

            <div class="modal-header">
                <h4 class="modal-title">Exit Procedure Io Details</h4>
            </div>

            <div class="modal-body">
                <div class="card-box">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">

                                <div class="profile-img-wrap">
                                    <div class="profile-img">
                                        <a href="#"><img class="avatar" src="" alt=""></a>
                                    </div>
                                </div>

                                <div class="profile-basic">
                                    <div class="row">

                                        <div class="col-md-5">
                                            <div class="profile-info-left">
                                                <h3 class="user-name m-t-0 m-b-0"></h3>                                        
                                                <small class="text-muted"></small>                                       
                                                <div class="staff-id">Employee ID :<span class="text emp_id"></span></div>                                       
                                            </div>
                                        </div>

                                        <div class="col-md-7">
                                            <ul class="personal-info" style="list-style: circle;">
                                                <li>
                                                    <span class="title">Phone:</span>
                                                    <span class="text phone"></span>                                        
                                                </li>
                                                <li>
                                                    <span class="title">Email:</span>
                                                    <span class="text email"></span>                                        
                                                </li>
                                                <li>
                                                    <span class="title">DOJ:</span>
                                                    <span class="text birthday"></span>                                        
                                                </li>
                                                <li>
                                                    <span class="title">RO:</span>
                                                    <span class="text ro"></span>                                        
                                                </li>
                                                <li>
                                                    <span class="title">Department:</span>
                                                    <span class="text dept"></span>                                        
                                                </li>
                                            </ul>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <?= form_open(base_url('update_io_check_status'), array('class' => 'm-b-30', 'method' => 'post')); ?>
                <div class="row">

                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="control-label">Approval<span class="text-danger">*</span></label>
                            <select id="io_approval" name="io_approval" class="form-control" required="required">
                                <option value="">Select Approval</option>
                                <option value="Pending">Pending</option>
                                <option value="Approved">Recommendation</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="control-label">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control summernote" name="io_of_comment" id="io_of_comment" required="required" row="4" col="10"/></textarea>
                        </div>
                    </div>    

                </div>

                <div class="row">
                    <div class="m-t-20 text-center">
                        <input type="hidden" id="ids" name="id" value="">
                        <button id="btn-add-ro-approval" class="btn btn-primary">Submit</button>
                    </div>
                </div>

                <?= form_close(); ?>  
            </div>
        </div>


    </div>
</div>

<?php $this->load->view('back_end/includes/footer'); ?>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>

<style>
    #table_length{margin-left:20px;}
    #table_filter{margin-right:2%;}
</style>

<script type="text/javascript">
    var table;
    $(document).ready(function () {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        table = $('#table').DataTable({
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [],
            "ajax": {
                "url": "<?= site_url('ajax_exit_process_as_ro_list') ?>",
                "type": "POST",
                "data": function (data) {

                },
                data:{[csrfName]: csrfHash}, 
            },
            "dom": 'lBfrtip',
            "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }
            ],
            //Set column definition initialisation properties.
            "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                },
            ],
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        });
        var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
        $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
        $('#btn-filter').click(function () { //button filter event click
            table.ajax.reload();  //just reload table
        });
        $('#btn-reset').click(function () { //button reset event click
            $('#form-filter')[0].reset();
            table.ajax.reload();  //just reload table
        });
    });
</script>
<script>
    function myFunction(id) {
         var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        $.ajax({
            type: 'POST',
            url: '<?= base_url('seperation/Exitprocedures_Controller/getioDataByid/'); ?>',
            data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'id': id},
            success: function (res) {
                var result = JSON.parse(res);
                $('#ids').val(result.employee_id);
               if(result.profileimg){
                $('.avatar').attr('src', '<?= HOSTNAME;?>/public/uploads/profile/'+result.profileimg);
               }
               else{
                 $('.avatar').attr('src', '<?= HOSTNAME;?>/assets/img/user.jpg');  
               }
                $('.user-name').html(result.userfullname);
                $('.text-muted').html(result.position_name);
                $('.emp_id').html(result.employeeId);
                $('.phone').html(result.contactnumber);
                $('.email').html(result.emailaddress);
                $('.birthday').html(result.date_of_joining);
                $('.ro').html(result.reporting_manager_name);
                $('.dept').html(result.department_name);
                $('#io_approval').val(result.l1_status);
                $("#io_of_comment").summernote("code", result.l1_comments);
            },
                data:{[csrfName]: csrfHash}, 
        });

    }
</script>
<script>
    $(document).ready(function () {
        $('.summernote').summernote({
            height: 200, // set editor height
            minHeight: null, // set minimum height of editor
            maxHeight: null, // set maximum height of editor
            focus: false                 // set focus to editable area after initializing summernote
        });
    });
</script>
</body>
</html>