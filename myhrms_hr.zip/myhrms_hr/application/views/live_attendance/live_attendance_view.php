<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <!--<div class="table-responsive">
                                    <table id="table1" class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Device Name</th>
                                                <th>Location</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>In Time</th>
                                                <th>Verify Method</th>
                                                <th>Floor</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($liveAttenDetailArr) {
                                                foreach ($liveAttenDetailArr as $kEy => $data) {
													$time = date('H:i:s A',strtotime($data->LogDate));?>
                                                    <tr style="">
                                                        <td><?= $kEy + 1; ?></td>
                                                        <td><?= ($data->DevicesName) ? $data->DevicesName : ""; ?></td>
                                                        <td><?= ($data->DeviceLocation) ? $data->DeviceLocation : ""; ?></td>
                                                        <td><?= ($data->employeeId) ? $data->employeeId : ""; ?></td>
                                                        <td><?= ($data->userfullname) ? $data->userfullname : ""; ?></td>
                                                        <td><?= ($time) ? $time : ""; ?></td>
                                                        <td><?= ($data->C5) ? $data->C5 : ""; ?></td>
                                                        <td><?= ($data->floor_number) ? $data->floor_number."th" : ""; ?></td>
                                                    <?php
											}
											}

											else {  ?>
                                                <tr>
                                                    <td style="color:red;text-align:center;" colspan="9"> Record Not Found. (Connect Live DB) </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>

                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Device Name</th>
                                                <th>Location</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>In Time</th>
                                                <th>Verify Method</th>
                                                <th>Floor</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>-->

                                <div class="table-responsive table-dataTables_length">
                                    <table id="live_attendance_table"
                                        class="table table-striped display nowrap table-bordered table-hover"
                                        cellspacing="0" width="100%">
                                        <thead>

                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Device Name</th>
                                                <th>Location</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>In Time</th>
                                                <th>Verify Method</th>
                                                <th>Floor</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>

    <script type="text/javascript">
    var live_attendance_table;
    $(document).ready(function() {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

        // var compid = $('#companynames').val();
        live_attendance_table = $('#live_attendance_table').DataTable({
            "processing": true,
            "serverSide": true,
            "scrollY": '60vh',
            "scrollX": true,
            "order": [], //Initial no order.
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url('ajax_live_attendance_report_list') ?>",
                "type": "POST",
                "data": function(data) {
                    // data.start_dates = $('#start_dates').val();
                    // data.end_dates = $('#end_dates').val();
                },
                data: {
                    [csrfName]: csrfHash
                },

            },
            "dom": 'lBfrtip',
            "buttons": [{
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ]
            }],
            //Set column definition initialisation properties.
            "columnDefs": [{
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            }, ],
            "aLengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
        });
        $('#btn-filter').click(function() { //button filter event click
            live_attendance_table.ajax.reload(); //just reload table
        });
        $('#btn-reset').click(function() { //button reset event click
            $('#form-filter')[0].reset();
            live_attendance_table.ajax.reload(); //just reload table
        });
    });
    setInterval(function() {
        live_attendance_table.ajax.reload();
    }, 9000);
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>