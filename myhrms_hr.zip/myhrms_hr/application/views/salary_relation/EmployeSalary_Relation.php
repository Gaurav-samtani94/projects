<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
    .table tbody tr td,
    .table tbody th td {
        word-wrap: break-word;
        white-space: normal !important;
    }
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php if ($this->session->flashdata('successmsg')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success!</strong> <?= $this->session->flashdata('successmsg'); ?>
                    </div>
                <?php } ?>

                <?php if ($this->session->flashdata('errormsg')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Error !</strong> <?= $this->session->flashdata('errormsg'); ?>
                    </div>
                <?php } ?>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="row">


                                </div>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <?php //echo 'hi'; 
                    ?>
                    <div class="col-lg-12">
                        <div class="card">

                            <div class="body">
                                <div class="">
                                    <table id="table" class="table table-bordered table-striped table-hover display">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Employe Name</th>
                                                <th>Relation</th>
                                                <!-- <th>Salary ID</th>
                                                <th>salary historyID</th>
                                                <th>appraisal datemmyy</th>
                                                <th>empctc</th>
                                                <th>grosssalary</th>
                                                <th>basicsalary</th>
                                                <th>empepf</th>
                                                <th>loyaltybonus</th>
                                                <th>emp hra</th>
                                                <th>emp esi</th>
                                                <th>projectcomp bonus</th>
                                                <th>special allowance</th>
                                                <th>emp gratuity</th>
                                                <th>transportation allowance</th>
                                                <th>emp sal gpai</th>
                                                <th>tele empsal allowance</th>
                                                <th>education allowance</th>
                                                <th>medical allowance</th>
                                                <th>statutory deduct</th>
                                                <th>sal other</th>
                                                <th>leave travel allowance</th>
                                                <th>food expenses</th>
                                                <th>fuel expenses</th>
                                                <th>vehicle agreement</th>
                                                <th>driver wagers</th>
                                                <th>empctcp1</th>
                                                <th>empctcp2</th>
                                                <th>project allowance</th>
                                                <th>bonus adv</th>
                                                <th>salsec other</th>
                                                <th>grosssal mediclaim</th>
                                                <th>grosssal other</th>
                                                <th>pcb employer</th>
                                                <th>createdby</th>
                                                <th>modifiedby</th>
                                                <th>createddate</th>
                                                <th>modifieddate</th>
                                                <th>isactive</th>
                                                <th>rating grade</th>
                                                <th>increment amnt</th> -->
                                            </tr>
                                        </thead>

                                        <tbody>

                                        </tbody>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Employe Name</th>
                                                <th>Relation</th>
                                                <!-- <th>Salary ID</th>
                                                <th>salary historyID</th>
                                                <th>appraisal datemmyy</th>
                                                <th>empctc</th>
                                                <th>grosssalary</th>
                                                <th>basicsalary</th>
                                                <th>empepf</th>
                                                <th>loyaltybonus</th>
                                                <th>emp hra</th>
                                                <th>emp esi</th>
                                                <th>projectcomp bonus</th>
                                                <th>special allowance</th>
                                                <th>emp gratuity</th>
                                                <th>transportation allowance</th>
                                                <th>emp sal gpai</th>
                                                <th>tele empsal allowance</th>
                                                <th>education allowance</th>
                                                <th>medical allowance</th>
                                                <th>statutory deduct</th>
                                                <th>sal other</th>
                                                <th>leave travel allowance</th>
                                                <th>food expenses</th>
                                                <th>fuel expenses</th>
                                                <th>vehicle agreement</th>
                                                <th>driver wagers</th>
                                                <th>empctcp1</th>
                                                <th>empctcp2</th>
                                                <th>project allowance</th>
                                                <th>bonus adv</th>
                                                <th>salsec other</th>
                                                <th>grosssal mediclaim</th>
                                                <th>grosssal other</th>
                                                <th>pcb employer</th>
                                                <th>createdby</th>
                                                <th>modifiedby</th>
                                                <th>createddate</th>
                                                <th>modifieddate</th>
                                                <th>isactive</th>
                                                <th>rating grade</th>
                                                <th>increment amnt</th> -->
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>

    </div>
    </div>
    </div>

    <!--================= Modal End ====================-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Relation Detail</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table id="" class="table">
                        <tr>
                            <th>S.no</th>
                            <th>Employe name</th>
                            <th>Employe Id</th>
                        </tr>
                        <tbody id="employedetails">

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        var table;
        $(document).ready(function() {
            //datatables
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "pageLength": -1,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_salary_relation'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        // data.start_date = $('#start_date').val();
                        // data.end_date = $('#end_date').val();
                        data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";

                    },
                },

                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                }],

                "columnDefs": [{
                    "searchable": true,
                    "targets": [0],
                    "orderable": false
                }],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            $('#btn-filter').click(function() {
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#start_date').val('')
                $('#end_date').val('')
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });

        function getallemployess(user_id) {
            $.ajax({
                url: "<?= base_url('EmployeRelationdetail'); ?>",
                type: "POST",
                data: {

                    user_id: user_id
                },
                dataType: 'json',
                success: function(response) {
                    $('#employedetails').html('');
                    // var dat = response.employe;
                    var i = 1;
                    $.each(response.employe, function(key, val) {
                        $('#employedetails').append("<tr><td>" + i++ + "</td><td>" + val.userfullname + "</td><td>" + val.employeeId + "</td></tr>");
                    });
                    $('#exampleModal').modal('show');
                }
            });

        }

        // function update_main_salary_details(fld_id) {
        //     alert(fld_id)
        //     $.ajax({
        //         url: "<?php // base_url('update_temp_to_real_sal_details?fld_id='); 
                            ?>" + fld_id,
        //         type: "POST",
        //         dataType: 'json',
        //         success: function(response) {
        //             alert(response)
        //             // table.ajax.reload();
        //             // $('#msg_' + emplid).show();
        //             // $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
        //         }
        //     });
        // }

        // function delete_temp_salary_details(fld_id) {
        //     alert(fld_id)
        //     // alert(atm_id+"__"+machine_id+"__"+floor_id+"__"+extension_number_)
        //     $.ajax({
        //         url: "<?php // base_url('delete_temp_salary?fld_id='); 
                            ?>" + fld_id,
        //         type: "GET",
        //         dataType: 'json',
        //         success: function(response) {
        //             alert(response)
        //             table.ajax.reload();
        //             // $('#msg_' + emplid).show();
        //             // $('#msg_' + emplid).html('Updated! Record successfully').fadeOut("slow");
        //         }
        //     });
        // }
    </script>
</body>
<?php $this->load->view('admin/includes/footer_updateSal'); ?>

<script>

</script>
<!-- Modal -->