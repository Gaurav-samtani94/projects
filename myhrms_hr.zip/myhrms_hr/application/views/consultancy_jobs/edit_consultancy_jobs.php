<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?php //base_url('emp_list'); 
                                                ?>" class="">
                                        <i class="fa fa-tasks"></i> Consultancy Company Job List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <form method="post" action="<?= base_url('edit_consultancy_jobs/' . $getCompRec->id); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <!-- Start Professional -->
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="company_name">Company Name : <span style="color:red;">*</span></label>
                                                <input type="text" name="company_name" id="company_name" class="form-control" onclick="rmvalidationerror(this.id)" value="<?= set_value('company_name', $getCompRec->company_name) ?>">
                                                <span id="reqd" class="error_company_name"><?= form_error('company_name'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="location">Location : <span style="color:red;"></span></label>
                                                <input type="text" name="location" id="location" class="form-control" onclick="rmvalidationerror(this.id)" value="<?= set_value('location', $getCompRec->location) ?>">
                                                <!-- <span id="reqd" class="error_company_location_id"><?= form_error('location'); ?></span> -->
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="country_id">Country : <span style="color:red;"></span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="country_id" id="country_id" onchange="getstate()" class="form-control select2">
                                                    <option <?= set_select('country', "", (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Country -- </option>
                                                    <?php
                                                    $country = getcountry();
                                                    foreach ($country as $key => $value) {
                                                        $selected = ($value->id == $getCompRec->country_id) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $value->id; ?>" <?= $selected ?>> <?= $value->country_name; ?> </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="state_id">State : <span style="color:red;"></span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="state_id" id="state_id" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php if (!empty($getState)) {
                                                        foreach ($getState as $sta) {
                                                            $selected = ($sta['id'] == $getCompRec->state_id) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $sta['id'] ?>" <?= $selected ?>><?= $sta['state_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="city_id">City : <span style="color:red;"></span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="city_id" id="city_id" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php if (!empty($getCity)) {
                                                        foreach ($getCity as $cit) {
                                                            $selected = ($cit['id'] == $getCompRec->city_id) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $sta['id'] ?>" <?= $selected ?>><?= $cit['city_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <input class="btn btn-one" type="submit" value="Submit" name="submit" id="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        CKEDITOR.replace('description');
        //Validation Error Removed..
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }

        function gtetemplete() {
            var lettertype = $('#lettertype').val();
            $.ajax({
                url: "<?= base_url('get_letter_templete'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                },
                dataType: 'json',
                success: function(res) {
                    $('#Templete_id').html('');
                    $('#Templete_id').trigger("change");
                    $('#Templete_id').append("<option>Select Template</option>");
                    if (res) {
                        $.each(res, function(key, val) {
                            $('#Templete_id').append("<option value=" + val.id + ">" + val.letter_templete_name + "</option>");
                        });
                    } else {
                        $('#Templete_id').append("<option>Select Template</option>");
                    }
                }
            });
        }
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>