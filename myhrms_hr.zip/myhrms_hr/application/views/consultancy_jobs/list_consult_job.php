<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Monthly Tour Management</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <a href="<?=base_url('add_consultancy_jobs')?>" class="btn btn-primary">Add Company</a>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Company Name</th>
                                                <th>Location</th>
                                                <th>Country</th>
                                                <th>State</th>
                                                <!-- <th>City</th> -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Company Name</th>
                                                <th>Location</th>
                                                <th>Country</th>
                                                <th>State</th>
                                                <!-- <th>City</th> -->
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    </div>


    <script type="text/javascript">
        var table;
        $(document).ready(function() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            //  var compid = $('#companynames').val();
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_consultancy_jobs'); ?>",
                    "type": "POST",
                    "data": function(data) {

                        data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                table.ajax.reload();
            });
            $('#btn-reset').click(function() {
                $('#form-filter')[0].reset();
                table.ajax.reload();
            });
        });
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>