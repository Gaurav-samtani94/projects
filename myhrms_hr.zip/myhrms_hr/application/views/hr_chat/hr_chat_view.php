<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$loginUserRec = GetBasicRecLoginUser();
$userpic = GetChatUserPic($from_user_id);
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Financial Statement</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <?php if ($this->session->flashdata('success_msg')) : ?>
                            <div class="alert alert-success alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                            </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error_msg')) : ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                            </div>
                            <?php endif; ?>
                            <?php if (validation_errors()) : ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Error ! </strong> <?= validation_errors(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <!-- inbox body -->
                        <div class="row clearfix">
                            <div class="col-lg-12">
                                <div class="card chat-app">
                                    <div id="plist" class="people-list">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="icon-magnifier"></i></span>
                                            </div>
                                            <input type="text" class="form-control" placeholder="Search...">
                                        </div>
                                        <ul class="list-unstyled chat-list mt-2 mb-0">
                                            <li class="clearfix">
                                                <?php if ($loginUserRec->profileimg) { ?>
                                                <img src="<?= EMPLPROFILE . $loginUserRec->profileimg; ?>"
                                                    class="rounded-circle user-photo" alt=""
                                                    style="height:55px; width:55px">
                                                <?php } else {
                                                     ?>
                                                <img src="<?= EMPLPROFILE; ?>candidate-profile_pic.jpg"
                                                    class="rounded-circle user-photo" alt=""
                                                    style="height:55px; width:55px">
                                                <?php } ?>
                                                <div class="about">
                                                    <div class="name"><?=$username->userfullname;?></div>
                                                    <div class="status"> <i class="fa fa-circle online"></i> online
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="chat">
                                        <div class="chat-header clearfix">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <?php if ($userpic->profileimg) { ?>
                                                    <img src="<?= EMPLPROFILE . $userpic->profileimg; ?>"
                                                        class="rounded-circle user-photo" alt=""
                                                        style="height:55px; width:55px">
                                                    <?php } else {
                                                     ?>
                                                    <img src="<?= EMPLPROFILE; ?>candidate-profile_pic.jpg"
                                                        class="rounded-circle user-photo" alt=""
                                                        style="height:55px; width:55px">
                                                    <?php } ?>
                                                    <div class="chat-about">
                                                        <h6 class="m-b-0"><?=$msgbyusername->userfullname;?></h6>
                                                        <!-- <div class="status"> <i class="fa fa-circle online"></i> online
                                                        </div> -->
                                                    </div>
                                                </div>
                                                <!-- <div class="col-lg-6 hidden-sm text-right">
                                            <a href="javascript:void(0);" class="btn btn-outline-secondary"><i
                                                    class="icon-camera"></i></a>
                                            <a href="javascript:void(0);" class="btn btn-outline-primary"><i
                                                    class="icon-camcorder"></i></a>
                                            <a href="javascript:void(0);" class="btn btn-outline-info"><i
                                                    class="icon-settings"></i></a>
                                            <a href="javascript:void(0);" class="btn btn-outline-warning"><i
                                                    class="icon-question"></i></a>
                                        </div> -->
                                            </div>
                                        </div>

                                        <div class="chat-history">
                                            <ul class="m-b-0" id="ulhid_msg">
                                                <?php
                                        foreach($messagebyid as $rOws){
                                            if($rOws->from_user_id==$from_user_id AND $rOws->to_user_id=='1'){
                                             ?>

                                                <li class="clearfix">
                                                    <div class="message-data text-right">
                                                        <span
                                                            class="message-data-time"><?=date('d-m-Y h:i:s A', strtotime($rOws->created_date));?></span>
                                                        <?php if ($userpic->profileimg) { ?>
                                                        <img src="<?= EMPLPROFILE . $userpic->profileimg; ?>"
                                                            class="rounded-circle user-photo" alt=""
                                                            style="height:55px; width:55px">
                                                        <?php } else {
                                                     ?>
                                                        <img src="<?= EMPLPROFILE; ?>candidate-profile_pic.jpg"
                                                            class="rounded-circle user-photo" alt=""
                                                            style="height:55px; width:55px">
                                                        <?php } ?>
                                                    </div>
                                                    <div class="message other-message float-right">
                                                        <b class=" float-left"><?=($rOws->subject) ? "$rOws->subject ,": '';?>
                                                        </b>
                                                        </br>
                                                        <?=$rOws->chat_message?>
                                                        <?php
                                            if($rOws->docs_file){
                                            ?>
                                                        <div class="message-data text-right">
                                                            <a href="<?='/myhrms/uploads/file/'.$rOws->docs_file;?>"
                                                                class="btn btn-success btn-sm" download>File
                                                                Download &nbsp;&nbsp;<i class="fa fa-download"></i></a>
                                                        </div>
                                                        <?php
                                            }
                                            ?>
                                                    </div>
                                                </li>
                                                <?php
                                        }else{
                                        ?>
                                                <li class="clearfix">
                                                    <div class="message-data">
                                                        <?php if ($loginUserRec->profileimg) { ?>
                                                        <img src="<?= EMPLPROFILE . $loginUserRec->profileimg; ?>"
                                                            class="rounded-circle user-photo" alt=""
                                                            style="height:55px; width:55px">
                                                        <?php } else {
                                                     ?>
                                                        <img src="<?= EMPLPROFILE; ?>candidate-profile_pic.jpg"
                                                            class="rounded-circle user-photo" alt=""
                                                            style="height:55px; width:55px">
                                                        <?php } ?>
                                                        <b><?=$rOws->userfullname;?></b>
                                                        <span class="message-data-time"
                                                            id="datetime">-&nbsp;<?=date('d-m-Y h:i:s A', strtotime($rOws->created_date));?></span>
                                                    </div>
                                                    <div class="message my-message">
                                                        <?=$rOws->chat_message;?>
                                                    </div>
                                                </li>
                                                <?php
                                        }
                                    }
                                        ?>
                                            </ul>

                                        </div>

                                        <div class="chat-message clearfix">
                                            <div class="input-group mb-0">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"
                                                        onclick="replaypopup('<?=$from_user_id?>')">
                                                        <i class="icon-paper-plane"></i>
                                                    </span>
                                                </div>

                                                <input type="text" class="form-control" id="replaymsg" value=""
                                                    name="replaymsg" placeholder="Enter text here...">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>





                    </div>
                </div>
            </div>
            <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
            <script>
            function replaypopup(valfield) {
                // alert("Hello! I am an alert box!!");
                var replaymsg = $('#replaymsg').val();
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                    csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                $.ajax({
                    type: 'POST',
                    dataType: "text",
                    url: "<?= base_url('Hr_Chat_Controller/ajax_get_byid'); ?>",
                    data: {
                        'replayid': valfield,
                        replaymsg: replaymsg,
                        [csrfName]: csrfHash
                    },
                    dataType: 'json',
                    success: function(response) {

                        $("#ulhid_msg").html('');
                        $.each(response, function(index, data) {
                            if (data.from_user_id == <?=$from_user_id?> && data.to_user_id == '1') {
                                $("#ulhid_msg").append(
                                    '<li class="clearfix"> <div class="message-data text-right"><span class="message-data-time" >' +
                                    data.created_date +
                                    '</span><img src="<?= EMPLPROFILE . $userpic->profileimg;?>" class="rounded-circle user-photo" alt=""></div><div class="message other-message float-right">' +
                                    data.chat_message + '</div></li>'
                                );
                            } else {
                                $("#ulhid_msg").append(
                                    '<li class="clearfix"> <div class="message-data"><img src="<?= EMPLPROFILE . $loginUserRec->profileimg; ?>" class="rounded-circle user-photo" alt=""><b>' +
                                    data.userfullname +
                                    '</b><span class="message-data-time" >' +
                                    data.created_date +
                                    '</span></div><div class="message other-message">' +
                                    data
                                    .chat_message + '</div></li>'
                                );

                            }
                        });
                        $('#replaymsg').val('');
                    }
                });
            }
            </script>

            <?php $this->load->view('admin/includes/footer'); ?>
        </div>
</body>