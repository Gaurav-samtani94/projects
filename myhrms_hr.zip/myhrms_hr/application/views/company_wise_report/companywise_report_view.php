<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper ">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Yearly Men Power Report.</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <form method="post" action="<?= base_url('com_wise_opn_cls_report'); ?>" id="visitingcard_form">
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Select Company</b>
                                                    <div class="input-group">
                                                        <select name="company_name" id="company_name" class="select floating form-control">
                                                            <option value="" selected="selected">Select Company</option>
                                                            <?php
                                                            $all_company = get_companyname();
                                                            if ($all_company):
                                                                foreach ($all_company as $companyrow) {
                                                                    ?>
                                                                    <option <?= (@$com_name == $companyrow->id) ? "Selected" : "" ?> value="<?= $companyrow->id; ?>"><?= $companyrow->company_name; ?></option>
                                                                    <?php
                                                                }
                                                            endif;
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>


                                                <div class="col-lg-3 col-md-6">
                                                    <div class="mt-sm-3">
                                                        <input type="submit"  id="" value="Filter" name="filter" class="btn btn-one">
                                                  
                                                        <input type="reset"  id="" value="Reset" name="submit" class="btn btn-success">
                                                    </div>
                                                </div>


                                            </div>
                                           
                                            <!--</div> -->                         

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>

                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Grade</th>
                                                <th>Opening Bal</th>
                                                <th>Joined</th>
                                                <th>Left</th>
                                                <th>Closing Bal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if (@$_REQUEST['filter']) {

                                                // echo $com_name; die;
                                                $list = array("1" => "Jan", "2" => "Feb", "3" => "Mar", "4" => "Apr", "5" => "May", "6" => "June", "7" => "July", "8" => "Aug", "9" => "Sept", "10" => "Oct", "11" => "Nov", "12" => "Dec");
                                                $data = array();
                                                $no = 0;
                                                $recData = array();
                                                $colTotal1 = 0;
                                                $colTotal2 = 0;
                                                $colTotal3 = 0;
                                                $colTotal4 = 0;
                                                // echo date(date('Y-01-01')); 
                                                // echo date(date('Y-m-d'));
                                                $pre_val = 0;
                                                foreach ($list as $kkeY => $rOws) {
                                                    $com_name = $_REQUEST['company_name'];
                                                    //$unit_name = $_REQUEST['unit_name'];
                                                    $no++;
                                                    $st_date = date('Y-' . $no . '-01');
                                                    $a_date = date('Y-' . $no . '-01');
                                                    $end_date = date("Y-m-t", strtotime($a_date));
                                                    $left = countcom_report($st_date, $end_date, $com_name);
                                                    $join = countcom_report_joined($st_date, $end_date, $com_name);
                                                    $open_bal = countcom_report_open_bal($st_date, $com_name);
                                                    // $close_bal = countcom_report_close_bal($end_date);
                                                    // $opn_join = countcom_report_joined_opn($st_date,$end_date);



                                                    if ($no == 1):
                                                        $cls = $open_bal - $left + $join;
                                                    else:
                                                        $cls = $opn - $left + $join;
                                                    endif;

                                                    // $cls = $open_bal-$left+$join; 
                                                    // $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
                                                    ?>
                                                    <tr style="">
                                                        <td><?= $no; ?></td>
                                                        <td><?= $rOws; ?></td>
                                                        <?php if ($no == 1): ?>
                                                            <td><?= $open_bal; ?></td>
                                                        <?php else: ?>
                                                            <td><?= $opn; ?></td>
                                                        <?php endif; ?>
                                                        <td><?= $join; ?></td>
                                                        <td><?= $left; ?></td>
                                                        <td><?= $cls; ?></td>

                                                    </tr>
                                                    <?php
                                                    $pre_val = $left;
                                                    $opn = $cls;
                                                }
                                            }
                                            else {
                                                $list = array("1" => "jan", "2" => "Feb", "3" => "Mar", "4" => "Apr", "5" => "May", "6" => "June", "7" => "July", "8" => "Aug", "9" => "Sept", "10" => "Oct", "11" => "Nov", "12" => "Dec");
                                                $data = array();
                                                $no = 0;
                                                $recData = array();
                                                $colTotal1 = 0;
                                                $colTotal2 = 0;
                                                $colTotal3 = 0;
                                                $colTotal4 = 0;
                                                // echo date(date('Y-01-01')); 
                                                // echo date(date('Y-m-d'));
                                                $pre_val = 0;
                                                foreach ($list as $kkeY => $rOws) {

                                                    $no++;
                                                    $com_name = '';
                                                    $st_date = date('Y-' . $no . '-01');
                                                    $a_date = date('Y-' . $no . '-01');
                                                    $end_date = date("Y-m-t", strtotime($a_date));
                                                    $left = countcom_report($st_date, $end_date, $com_name);
                                                    $join = countcom_report_joined($st_date, $end_date, $com_name);
                                                    $open_bal = countcom_report_open_bal($st_date, $com_name);
                                                    // $close_bal = countcom_report_close_bal($end_date);
                                                    // $opn_join = countcom_report_joined_opn($st_date,$end_date);



                                                    if ($no == 1):
                                                        $cls = $open_bal - $left + $join;
                                                    else:
                                                        $cls = $opn - $left + $join;
                                                    endif;

                                                    // $cls = $open_bal-$left+$join; 
                                                    // $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
                                                    ?>
                                                    <tr style="">
                                                        <td><?= $no; ?></td>
                                                        <td><?= $rOws; ?></td>
        <?php if ($no == 1): ?>
                                                            <td><?= $open_bal; ?></td>
                                                        <?php else: ?>
                                                            <td><?= $opn; ?></td>
                                                        <?php endif; ?>
                                                        <td><?= $join; ?></td>
                                                        <td><?= $left; ?></td>
                                                        <td><?= $cls; ?></td>

                                                    </tr>
        <?php
        $pre_val = $left;
        $opn = $cls;
    }
}
?>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Grade</th>
                                                <th>Opening Bal</th>
                                                <th>Joined</th>
                                                <th>Left</th>
                                                <th>Closing Bal</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>

</body>
