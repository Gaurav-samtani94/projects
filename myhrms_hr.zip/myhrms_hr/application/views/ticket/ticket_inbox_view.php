<?php

use Mpdf\Tag\H1;

$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <?php if ($this->session->flashdata('success_msg')) : ?>
                            <div class="alert alert-success alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                            </div>
                            <?php endif; ?>
                            <?php if ($this->session->flashdata('error_msg')) : ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                            </div>
                            <?php endif; ?>
                            <?php if (validation_errors()) : ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                <strong>Error ! </strong> <?= validation_errors(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <!-- inbox body -->


                        <div class="row clearfix">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="mail-inbox">
                                        <div class="mail-right">
                                            <div class="header d-flex align-center">
                                                <h2> Inbox </h2>
                                            </div>
                                            
                                            <div class="mail-action clearfix">
                                                <div class="pull-left">
                                                    <div class="fancy-checkbox d-inline-block">
                                                        <label>
                                                            <input class="select-all" type="checkbox" name="checkbox"
                                                                <?=count($allInboxCategory) > 1 ? "checked" : "" ;?>>
                                                            <span></span>
                                                        </label>
                                                    </div>

                                                    <?php
                                                        foreach($allInboxCategory as $rOws){ ?>
                                                            <div class="btn-group">
                                                                <?php
                                                                if(count($allInboxCategory) > 1){ ?>
                                                                    <a href="<?= base_url('category/'.$rOws->fld_id)?>"
                                                                        class="btn btn-outline-secondary btn-sm hidden-sm"><?=$rOws->c_name?>
                                                                    </a>
                                                                <?php }
                                                                if(count($allInboxCategory) < 2){ ?>
                                                                    <a href="javascript:void(0);"
                                                                        class="btn btn-outline-secondary btn-sm hidden-sm"><?=$rOws->c_name?>
                                                                    </a>
                                                                    <a href="<?= base_url('inbox')?>"
                                                                        class="btn btn-outline-secondary btn-sm hidden-sm">Refresh
                                                                    </a>
                                                                <?php } ?>
                                                            </div>
                                                    <?php } ?>
                                                    
                                                </div>
                                               
                                            </div>
                                            

                                            <div class="mail-list">
                                                <ul class="list-unstyled">
                                                    <?php
                                                    if($allinboxmessage){
                                                    foreach($allinboxmessage as $rOws){
                                                        $uid=$rOws->entry_by;
                                                         $dept=GetDepartmentBYId($uid);
                                                         $rowCount=GetStatusCountBYId($uid);
                                                    ?>
                                                    <li class="clearfix">
                                                        <div class="mail-detail-left">
                                                            <label class="fancy-checkbox">
                                                               
                                                                <span></span>
                                                            </label>
                                                            <a href="javascript:void(0);"
                                                                class="<?=$rOws->tick_status==1 ? 'mail-star active' : 'mail-star';?>"><i
                                                                    class="fa fa-star"></i></a>
                                                        </div>
                                                        <div class="mail-detail-right">
                                                            <h6 class="sub"><a
                                                                    href="<?= base_url('tickethistroy/').$rOws->entry_by;?>"
                                                                    class="mail-detail-expand"><?=$dept->userfullname;?></a>
                                                                <span
                                                                    class="badge badge-default mb-0"><?=($dept->department_name) ? '-'.$dept->department_name : "";?></span>
                                                            </h6>
                                                            <h6 class="dep"><span
                                                                    class="m-r-10">[Sub]</span><?=$rOws->subject;?>.
                                                            </h6>
                                                            <h6 class="dep"><span class="m-r-10">[Ticket No.]</span><?=$rOws->ticket_no;?>.</h6>
                                                            <h6 class="dep"><span class="m-r-10">[Category]</span><?=$rOws->c_name;?>.</h6>
                                                            <h6 class="dep"><span class="m-r-10">[Current Status]</span><?=( $rOws->tick_status==1 ) ? "Open" : ( $rOws->tick_status==2  ? "In Progress" :" Closed" );?>.</h6>
                                                                <span class="time"><?=date('d-M-Y', strtotime($rOws->entry_date));?></span>
                                                        </div>
                                                    </li>

                                                    <?php } } else { ?>
                                                        <h5 style="color: red;">Record Not found</h5>
                                                    <?php }  ?>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $this->load->view('admin/includes/footer'); ?>
        </div>
</body>