<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$csrf = array(
    'name' => $this->security->get_csrf_token_name(),
    'hash' => $this->security->get_csrf_hash()
 );
  $defaultLink = EMPLPROFILE. 'candidate-profile_pic.jpg';
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content" class="taskboard">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url('inbox'); ?>"><i
                                            class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong id="statusMsg">Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>
                <div class="row clearfix">

                    <div class="col-lg-12 col-md-12">
                        <div class="card ">
                            <div class="card-body">

                                <div class="card-text">
                                    <img src="<?= $defaultLink ? $defaultLink : $defaultLink;?>" alt="Media"
                                        class="rounded-circle" />&nbsp;&nbsp;&nbsp;&nbsp;
                                    <?=$ticketbyid[0]->userfullname;?>-[<?=$ticketbyid[0]->employeeId;?>]&nbsp;&nbsp;&nbsp;&nbsp;
                                    Department:- [<?=$ticketbyid[0]->department_name;?>]
                                    <a href="<?= base_url('inbox');?>">
                                        <button type="button" class="btn btn-outline-info float-right">
                                            << Back </button>
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="row clearfix">

                    <div class="col-lg-4 col-md-12">
                        <div class="card planned_task">
                            <div class="header">
                                <h2>Open</h2>
                                <!-- <ul class="header-dropdown">
                                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#addcontact"><i
                                                class="icon-plus"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="body taskboard">
                                <div class="dd" data-plugin="nestable">
                                    <ol class="dd-list">
                                        <li class="dd-item" data-id="1">
                                            <?php
                                            foreach($ticketbyid as $rOws){
                                                 if($rOws->tick_status == '1'){
                                            ?>
                                            <div class="dd-handle">#<?=$rOws->ticket_no;?></div>
                                            <div class="dd-content p-15">
                                                <b>category:</b><?=$rOws->c_name;?></br>
                                                <b>Sub:</b><?=$rOws->subject;?>
                                                <p><?=$rOws->message;?></p>
                                                <hr>
                                                <div class="action">
                                                    <b>Date:</b>
                                                    <?=date('d-M-Y', strtotime($rOws->entry_date));?>
                                                    <button type="
                                                        button" class="btn btn-sm btn-outline-secondary float-right"
                                                        title=" Move Status In Progress"
                                                        onclick="movepopup('<?=$rOws->fld_id;?>')">
                                                        <i class="fa fa-check-circle"
                                                            style="font-size:30px;color:#FFCE4B"></i>
                                                    </button>
                                                    <input type="hidden" name="entryby" value="<?=$rOws->tick_status;?>"
                                                        id="entryby">
                                                    <!-- <button type="button"
                                                        class="btn btn-outline-light"><?=date('d-M', strtotime($rOws->entry_date));?></button> -->
                                                </div>
                                            </div>
                                            <?php
                                            }
                                        }?>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=" col-lg-4 col-md-12">
                        <div class="card progress_task">
                            <div class="header">
                                <h2>In progress</h2>
                            </div>
                            <div class="body taskboard">
                                <div class="dd" data-plugin="nestable">
                                    <ol class="dd-list">
                                        <li class="dd-item" data-id="1">
                                            <?php
                                            foreach($ticketbyid as $rOws){
                                                 if($rOws->tick_status == '2'){
                                            ?>
                                            <div class="dd-handle">
                                                #<?=$rOws->ticket_no;?></div>
                                            <div class="dd-content p-15">
                                                <b>category:</b><?=$rOws->c_name;?></br>
                                                <b>Sub:</b><?=$rOws->subject;?>
                                                <p><?=$rOws->message;?></p>
                                                <hr>
                                                <div class="action">
                                                    <b>Date:</b>
                                                    <?=date('d-M-Y', strtotime($rOws->entry_date));?>
                                                    <!-- <button type="button" class="btn btn-sm btn-outline-secondary"
                                                            title="Edit" onclick="editpopup('<?=$rOws->fld_id; ?>')">
                                                            <a href="javascript:void(0);" data-toggle="modal"
                                                                data-target="#editinprogressstatus"><i
                                                                    class="icon-note"></i></a>
                                                        </button> -->
                                                    <input type="hidden" name="statusid"
                                                        value="<?=$rOws->tick_status;?>" id="statusid">
                                                    <button type="button"
                                                        class="btn btn-sm btn-outline-secondary float-right"
                                                        title=" Move Status In Progress"
                                                        onclick="moveinprogress('<?=$rOws->fld_id;?>')"><i
                                                            class="fa fa-check-circle"
                                                            style="font-size:30px;color:#86c541"></i>
                                                    </button>
                                                    <button type="button"
                                                        class="btn btn-sm btn-outline-secondary float-right"
                                                        title="Comment" onclick="editpopup('<?=$rOws->fld_id; ?>')">
                                                        <a href="javascript:void(0);" data-toggle="modal"
                                                            data-target="#comment">
                                                            <i class="icon-bubbles"></i></a></button>
                                                    <button type="button"
                                                        class="btn btn-sm btn-outline-secondary float-right"
                                                        title="reply">
                                                        <a href="<?= base_url('replyhistroy/').$rOws->fld_id;?>"><i
                                                                class="fa fa-reply"></i></a>
                                                    </button>
                                                    <!-- <button type="button" data-type="confirm"
                                                        class="btn btn-sm btn-outline-danger float-right js-sweetalert"
                                                        title="Delete"><i class="icon-trash"></i></button> -->


                                                </div>
                                            </div>
                                            <?php
                                            }
                                        }?>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="card completed_task">
                            <div class="header">
                                <h2>Completed</h2>
                                <!-- <ul class="header-dropdown">
                                    <li><a href="javascript:void(0);" data-toggle="modal" data-target="#addcontact"><i
                                                class="icon-plus"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="body taskboard">
                                <div class="dd" data-plugin="nestable">
                                    <ol class="dd-list">
                                        <li class="dd-item" data-id="1">
                                            <?php
                                            foreach($ticketbyid as $rOws){
                                                if($rOws->tick_status == '3'){
                                            ?>
                                            <div class="dd-handle">#<?=$rOws->ticket_no;?>
                                            </div>
                                            <div class="dd-content p-15">
                                                <b>category:</b><?=$rOws->c_name;?></br>
                                                <b>Sub:</b><?=$rOws->subject;?>
                                                <p><?=$rOws->message;?></p>
                                                <!-- <hr> -->
                                                <!-- <div class="action">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                                        title="Edit"><i class="icon-note"></i></button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                                        title="Time"><i class="icon-clock"></i></button>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                                        title="Comment"><i class="icon-bubbles"></i></button>
                                                    <button type="button" data-type="confirm"
                                                        class="btn btn-sm btn-outline-danger float-right js-sweetalert"
                                                        title="Delete"><i class="icon-trash"></i></button>
                                                </div> -->
                                            </div>
                                            <?php
                                            }
                                        }?>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="modal fade" id="addcontact" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="title" id="defaultModalLabel">Add New Task</h6>
                        </div>
                        <div class="modal-body">
                            <div class="row clearfix">
                                <div class="col-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Task no.">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Job title">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea type="number" class="form-control"
                                            placeholder="Description"></textarea>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <select class="form-control show-tick m-b-10">
                                        <option>Select Team</option>
                                        <option>John Smith</option>
                                        <option>Hossein Shams</option>
                                        <option>Maryam Amiri</option>
                                        <option>Tim Hank</option>
                                        <option>Gary Camara</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label>Range</label>
                                    <div class="input-daterange input-group" data-provide="datepicker">
                                        <input type="text" class="form-control" name="start">
                                        <span class="input-group-addon"> to </span>
                                        <input type="text" class="form-control" name="end">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary">Add</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                        </div>
                    </div>
                </div>
            </div>
            <script>
            function movepopup(valfield) {
                var stausid = $('#entryby').val();
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                    csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                $.ajax({
                    type: 'POST',
                    dataType: "text",
                    url: "<?= base_url('Ticket_Raised_Controller/ajax_get_byid'); ?>",
                    data: {
                        [csrfName]: csrfHash,
                        'editId': valfield,
                        'statusId': stausid
                    },
                    dataType: 'json',
                    success: function(response) {
                        var statusMsg = 'ticket Move in In Progress.';
                        $('#statusMsg').html(statusMsg);
                        location.reload();

                    }
                });
            }
            </script>
            <script>
            function moveinprogress(valfield) {
                var stausid = $('#statusid').val();
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                    csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                $.ajax({
                    type: 'POST',
                    dataType: "text",
                    url: "<?= base_url('Ticket_Raised_Controller/moveajax_get_byid'); ?>",
                    data: {
                        [csrfName]: csrfHash,
                        'editId': valfield,
                        'statusId': stausid
                    },
                    dataType: 'json',
                    success: function(response) {
                        var statusMsg = 'ticket Move in In Progress.';
                        $('#statusMsg').html(statusMsg);
                        location.reload();

                    }
                });
            }
            </script>

        </div>
    </div>
    <!-- Comment Task -->
    <div class="modal fade" id="comment" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?= base_url('Ticket_Raised_Controller/usercomment');?>" method="POST">
                    <input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" />
                    <div class="modal-header">
                        <h6 class="title" id="defaultModalLabel">Replay Message</h6>
                    </div>
                    <div class="modal-body">
                        <div class="row clearfix">
                            <div class="col-12">
                                <div class="form-group">
                                    <textarea type="text" name="description" class="form-control"
                                        placeholder="Description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="updateid" id="commentopenid" value="">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
    function editpopup(valfield) {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        $.ajax({
            type: 'POST',
            dataType: "text",
            url: "<?= base_url('Ticket_Raised_Controller/ajax_get_bycommentid'); ?>",
            data: {
                [csrfName]: csrfHash,
                'editId': valfield
            },
            dataType: 'json',
            success: function(response) {
                $('#commentopenid').val(response);
                // $('#statusinprogressid').val(response);
                // $('#editstatus').modal({
                //     backdrop: 'static',
                //     keyboard: true,
                //     show: true
                // });
            }

        });
    }
    </script>
</body>
<?php $this->load->view('admin/includes/footer'); ?>