<?php
date_default_timezone_set('Asia/Kolkata');
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
 $csrf = array(
    'name' => $this->security->get_csrf_token_name(),
    'hash' => $this->security->get_csrf_hash()
 );
 //$loginUserRec = GetBasicRecLoginUser();
 $picid=$parentMessage->entry_by;
$userpic = GetChatUserPic($picid);
//$loginRec = GetBasicRecUser();

  //$loginimglink = EMPLPROFILE . $loginUserRec->profileimg;
   $userimglink = EMPLPROFILE . $userpic->profileimg;
 $defaultLink = EMPLPROFILE. 'candidate-profile_pic.jpg';
 $hours=time_elapsed_string($parentMessage->entry_date);
?>

<style>
.card {
    position: relative;
    display: flex;
    padding: 20px;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid #d2d2dc;
    border-radius: 11px;
    -webkit-box-shadow: 0px 0px 5px 0px rgb(249, 249, 250);
    -moz-box-shadow: 0px 0px 5px 0px rgba(212, 182, 212, 1);
    box-shadow: 0px 0px 5px 0px rgb(161, 163, 164)
}

.media img {

    width: 60px;
    height: 60px;
}


.reply a {

    text-decoration: none;
}
</style>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content" class="taskboard">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url('inbox'); ?>"><i
                                            class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="card">
                        <div class="card-text">
                            <a href="<?= base_url('inbox');?>">
                                <button type="button" class="btn btn-outline-info">
                                    << Back</button>
                            </a>
                        </div>

                    </div>

                    <div class=" card">
                        <div class="row">
                            <div class="col-md-12">

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="media">

                                            <img src="<?= $userimglink ? $userimglink : $defaultLink;?>"
                                                alt="Bootstrap Media Preview" class="rounded-circle" />
                                            <div class="media-body">
                                                <div class="row">
                                                    <div class="col-8 d-flex">
                                                        <h5><?= $parentMessage->userfullname; ?></h5>
                                                        <span>-
                                                            <?= $hours;?><span>
                                                    </div>

                                                    <div class="col-4">

                                                        <div class="pull-right reply">

                                                            <a href="javascript:void(0);" data-toggle="modal"
                                                                data-target="#comment"><span><i class="fa fa-reply"></i>
                                                                    reply</span></a>


                                                        </div>

                                                    </div>
                                                </div>

                                                <?= $parentMessage->message; ?>
                                                <?php
                                              if($parentMessage->docs_file)
                                              {
                                                ?>
                                                <a href="<?=TICKETDOWNLOAD.$parentMessage->docs_file;?>"
                                                    class="btn btn-success btn-sm" download>File
                                                    Download &nbsp;&nbsp;<i class="fa fa-download"></i></a>
                                                <?php
                                              }
                                                    foreach($childMessage as $rOws){
                                                      $userPicId=$rOws->entry_by;
                                                    $childPicId = GetChildUserPic($userPicId);
                                                      $childimglink = EMPLPROFILE . $childPicId->profileimg;
                                                       $hours=time_elapsed_string($rOws->entry_date);
                                                    ?>
                                                <div class="media mt-4">

                                                    <a class="pr-3" href="#"><img class="rounded-circle"
                                                            alt="Bootstrap Media Another Preview"
                                                            src="<?= $childimglink ? $childimglink : $defaultLink;?>" /></a>
                                                    <div class="media-body">

                                                        <div class="row">
                                                            <div class="col-12 d-flex">
                                                                <h5><?= $rOws->userfullname; ?></h5>
                                                                <span>- <?= $hours; ?> </span>

                                                            </div>


                                                        </div>

                                                        <?= $rOws->message; ?>
                                                        <?php
                                                          if($rOws->docs_file)
                                              {
                                                ?>
                                                        <a href="<?=TICKETDOWNLOAD.$rOws->docs_file;?>"
                                                            class="btn btn-success btn-sm" download> &nbsp;&nbsp;<i
                                                                class="fa fa-download"></i></a>
                                                        <?php
                                              }?>
                                                    </div>

                                                </div>
                                                <?php
                                                    }
                                                    ?>
                                            </div>
                                        </div>






                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>






            </div>
        </div>
    </div>
    <div class="modal fade" id="comment" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="<?= base_url('Ticket_Raised_Controller/usercomment');?>" method="POST"
                    enctype="multipart/form-data">
                    <input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" />
                    <div class="modal-header">
                        <h6 class="title" id="defaultModalLabel">Replay Message</h6>
                    </div>
                    <div class="modal-body">
                        <div class="row clearfix">
                            <div class="col-12">
                                <div class="form-group">
                                    <textarea required name="description" class="form-control"
                                        placeholder="Description"></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <!-- <input type="file" name="image" class="form-control"> -->
                                    <input type="file" name="image" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="updateid" value="<?=$parentMessage->fld_id;?>">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<?php
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

?>

<?php $this->load->view('admin/includes/footer'); ?>