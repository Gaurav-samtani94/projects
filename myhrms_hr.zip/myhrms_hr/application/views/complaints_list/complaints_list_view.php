<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
							<i class="fa fa-arrow-left"></i></a>Complaints List</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive" >
									<!--<h4>Complaint List </h4>-->
                                    <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
										<thead>
											<tr>
												<th>S.No.</th>
												<th>Complaint Category</th>
												<th>Complaint Title</th>
												<th>Description</th>
												<th>Date</th>
												<th>Complaint Ticket No.</th>
												<th>Complaint Ticket Status</th>
												<th>Complaint By</th>
											</tr>
										</thead>
										<tbody>
										 <?php 
										 //print_r($complaints_lists);
										 
										 if ($complaints_lists) {
											$kEy="1";
                                            foreach ($complaints_lists as $dataRow) { 
												date_default_timezone_set("Asia/Kolkata");
												$curr_date =  date("Y-m-d h:m:s");
												$hours= round((strtotime($curr_date) - strtotime($dataRow->entry_date))/(60*60));
												?>
												<tr>
													<td width="5%"><?=  $kEy; ?></td>
													<td width="15%"><?= ($dataRow->complaint_category) ? $dataRow->complaint_category : ""; ?></td>
													<td width="15%"><?= ($dataRow->complaint_title) ? $dataRow->complaint_title : ""; ?></td>
													<td width="20%" style="white-space: normal;"><?= ($dataRow->complaint_desc) ? $dataRow->complaint_desc : ""; ?>
													</td>
													<td width="10%"><?= ($dataRow->complaint_date) ? date('d-m-Y',strtotime($dataRow->complaint_date)) : ""; ?></td>
													<td width="20%"><?= ($dataRow->ticket_id) ? $dataRow->ticket_id : ""; ?></td>
													<td width="15%">
													<?php 
													if($dataRow->ticket_status=="0" && $hours<3){
														echo "Open";
													}
													else if($dataRow->ticket_status=="2"){
														echo "In Progress";
													}else if($dataRow->ticket_status=="3"){
														echo "Closed";
													}else if($hours>3){
														echo "In Queue";
													} ?></td>
													<td width="20%"><?= ($dataRow->entryby) ? get_ro_details_by_Id($dataRow->entryby) : ""; ?>
													</td>
												</tr>												
											<?php $kEy++; }
										}?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<th>S.No.</th>
												<th>Complaint Category</th>
												<th>Complaint Title</th>
												<th>Description</th>
												<th>Date</th>
												<th>Complaint Ticket No.</th>
												<th>Complaint Ticket Status</th>
												<th>Complaint By</th>
											</tr>
										</tfoot> 
										<tbody>  
										</tbody>
									</table>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
                                                         