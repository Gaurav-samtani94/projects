<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- <a href="<?= base_url('add_employee') ?>" class="btn btn-primary">Add Employee Type</a> -->
                <a href="javascript:void(0)" class="btn btn-primary" data-toggle="modal" data-target="#addQualiModal">Add Qualification</a>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addQualiModal" tabindex="-1" aria-labelledby="addQualiModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addQualiModalLabel">Add Employee Type</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="addEmployeeForm">
                            <div class="form-group">
                                <label for="Qualiname">Qualification Name</label>
                                <input type="text" class="form-control" id="Qualiname" name="educationlevelcode">
                                <span class="error_name text-danger"></span> <!-- Error message placeholder -->
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="submitQualificationForm()">Submit</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Employee Type Modal -->
        <div class="modal fade" id="editQualificationModal" tabindex="-1" aria-labelledby="editQualificationModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editQualificationModalLabel">Edit Employee Type</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Error Message Container -->
                        <div id="editForm-errors" class="alert alert-danger" role="alert" style="display:none;"></div>

                        <!-- Form for editing employee type -->
                        <form id="editQualificationForm">
                            <input type="hidden" id="editQualificationId" name="qualification_id">
                            <div class="form-group">
                                <label for="editQualificationName">Qualification Name</label>
                                <input type="text" class="form-control" id="editQualificationName" name="educationlevelcode">
                                <span class="error_edit_name text-danger"></span>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="submitEditEmployeeForm()">Update</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    </div>
    <script type="text/javascript">
        var table;
        $(document).ready(function() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_qualification_list'); ?>",
                    "type": "POST",
                    "data": function(data) {

                        data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                "columnDefs": [{
                    "targets": [0],
                    "orderable": false,
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            $('#btn-filter').click(function() {
                table.ajax.reload();
            });
            $('#btn-reset').click(function() {
                $('#form-filter')[0].reset();
                table.ajax.reload();
            });
        });
    </script>
    <script>
        function submitQualificationForm() {
            var formData = {
                name: $('#Qualiname').val()
            };

            $.ajax({
                type: 'POST',
                url: '<?= base_url('add_qualification') ?>',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        $('#addQualiModal').modal('hide');
                        location.reload();
                    } else if (response.status === 'error') {
                        if (response.errors && response.errors.name) { 
                            $('.error_name').text(response.errors.name); // Display error message
                        } else {
                            $('.error_name').text(''); // Clear error message if no specific error
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }

        $(document).ready(function() {
            // Hide error message span initially
            $('.error_name').text('');
            $('.error_edit_name').text('');
        });

        // Edit Case Code //

        $(document).on('click', '.edit-qualification', function(e) {
            e.preventDefault();
            var qulId = $(this).data('quli-id');

            // AJAX call to fetch employee type data
            $.ajax({
                type: 'GET',
                url: '<?= base_url('EmployeeType/Qualification/get_qualification_data') ?>/' + qulId,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        $('#editQualificationId').val(response.data.id);
                        $('#editQualificationName').val(response.data.educationlevelcode);
                    } else {
                        error_edit_name
                        console.error('Failed to fetch employee data');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        // Function to submit edit form via AJAX
        function submitEditEmployeeForm() {
            var formData = {
                qualification_id: $('#editQualificationId').val(),
                name: $('#editQualificationName').val()
            };

            $.ajax({
                type: 'POST',
                url: '<?= base_url('EmployeeType/Qualification/update_employee') ?>',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        $('#editQualificationModal').modal('hide');
                        location.reload();
                    } else if (response.status === 'error') {
                        if (response.errors && response.errors.name) { 
                            $('.error_edit_name').text(response.errors.name); // Display error message
                        } else {
                            $('.error_edit_name').text(''); // Clear error message if no specific error
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }

        $(document).ready(function() {
            // Hide error message div initially
            $('#editForm-errors').hide();
        });
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>