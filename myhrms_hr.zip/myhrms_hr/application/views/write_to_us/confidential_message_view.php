<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
 .morecontent span {
    display: none;
}
.morelink {
    display: block;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
							<i class="fa fa-arrow-left"></i></a>Confidential Message</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                
							<div class="table-responsive" >
                                    <table class="table table-bordered table-hover js-basic-example dataTable table-custom w-100">
										<thead>
											<tr>
												<th>S.No.</th>
												<th>Title</th>
												<th>Description</th>
												<th>Date</th>
												<th>Message By</th>
											</tr>
										</thead>
										<tbody>
										 <?php 
										 if ($confidential_message_list) {
                                            foreach ($confidential_message_list as $dataRow) { ?>
												<tr>
													<td ><?=  $kEy+1; ?></td>
													<td ><?= ($dataRow->title) ? $dataRow->title : ""; ?></td>
													<td style="white-space: normal;"><?= ($dataRow->description) ? $dataRow->description : ""; ?></td>
													<td ><?= ($dataRow->add_date) ? date('d-m-Y',strtotime($dataRow->add_date)) : ""; ?></td>
													<td ><?= ($dataRow->entryby) ? get_ro_details_by_Id($dataRow->entryby) : ""; ?></td>
												</tr>												
											<?php $kEy++; }
										}?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<th>S.No.</th>
												<th>Title</th>
												<th>Description</th>
												<th>Date</th>
												<th>Message By</th>
											</tr>
										</tfoot> 
										<tbody>  
										</tbody>
									</table>
                                </div>
							</div>
							</div>
							
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
                                                         