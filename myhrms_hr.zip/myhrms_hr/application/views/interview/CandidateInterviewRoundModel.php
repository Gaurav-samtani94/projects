<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CandidateInterviewRoundModel extends CI_Model
{
    public $jobs_table = 'job_interview_round as a';
    public $column_order = ['a.interview_id', 'a.round', 'a.round_status', 'a.direct_selected'];
    public $column_search = ['a.interview_id', 'a.round', 'a.round_status', 'a.direct_selected'];

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query($interview_id)
    {
        $logined_id = $this->session->userdata('loginid');
        $this->db->select('a.*');
        $this->db->from($this->jobs_table);
        $this->db->join("main_users as u", "u.id = a.interviewers_id", "LEFT");
        $this->db->where('a.interview_id', $interview_id);
        $this->db->where('a.interviewers_id', $logined_id);
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) {
                    $this->db->group_end();
                }
            }
            ++$i;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } elseif (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables($interview_id)
    {
        $this->_get_datatables_query($interview_id);
        if ($_POST['length'] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        $query = $this->db->get();

        return $query->result();
    }

    public function count_filtered($interview_id)
    {
        $this->_get_datatables_query($interview_id);
        $query = $this->db->get();

        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->jobs_table);

        return $this->db->count_all_results();
    }

    public function get_competency_data($roundId, $competency_id)
    {
        $this->db->where('interview_round_id', $roundId);
        $this->db->where('competency_id', $competency_id);
        $query = $this->db->get('competencies_job');;
        return $query->row_array();
    }

    public function save_competencies($data)
    {
        $this->db->insert_batch('competencies_job', $data);
    }

    public function update_round_status($round_id, $data)
    {
        $this->db->where('id', $round_id);
        $this->db->update('job_interview_round', $data);
    }
    public function get_round_status($roundId)
    {
        $this->db->select('round_status');
        $this->db->from('job_interview_round');
        $this->db->where('id', $roundId);
        $query = $this->db->get();

        return $query->row()->round_status;
    }
    public function get_competency_data_by_round($round_id)
    {
        $this->db->where('interview_round_id', $round_id);
        $query = $this->db->get('competencies_job');
        return $query->result_array();
    }
    public function update_competency_data($round_id, $competency_id, $data)
    {
        $this->db->where('interview_round_id', $round_id);
        $this->db->where('competency_id', $competency_id);
        $this->db->update('competencies_job', $data);
    }
    public function calculateTotalMarks($round_id)
    {
        $this->db->select_sum('marks');
        $this->db->where('interview_round_id', $round_id);
        $query = $this->db->get('competencies_job');
        $result = $query->row();
        return $result->marks;
    }

    public function updateTotalMarks($round_id, $totalMarks)
    {
        $this->db->where('id', $round_id);
        $this->db->update('job_interview_round', ['marks' => $totalMarks]);
    }
    public function updateRoundDetails($round_id, $data)
    {
        $this->db->where('id', $round_id);
        $this->db->update('job_interview_round', $data);
    }
    public function update_selected_status($round_id, $data)
    {
        $this->db->where('id', $round_id);
        $this->db->update('job_interview_round', $data);
    }
    public function getRoundDetails($round_id)
    {
        $this->db->where('id', $round_id);
        $query = $this->db->get('job_interview_round');
        return $query->row_array();
    }
}
