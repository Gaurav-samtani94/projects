<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//$statusArr = TourStatusRec();
?>
<style>
textarea {
  resize: none;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
							<!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Policies</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?> 
                               
                                <div id="collapseOne" >
                                    <div class="body">
                                        <form action="<?= base_url('policy_insert'); ?>" id="basic-form" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <div class="row clearfix">
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Name : </label>
                                                        <input type="text" name="policy_name" id="policy_name" autocomplete="off" value="" class="form-control" required>
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Description :</label>
                                                        <textarea  maxlength="200" name="policy_desc" id="policy_desc" required class="form-control" ></textarea>
                                                    </div>
                                                </div>
											
												<?php  $get_businessunits = get_businessunits(); //print_r($get_businessunits); die;?>
												<div class="col-lg-3 col-md-6">
													<div class="form-group">
														<label class="email">Bussiness Unit: </label>
														<select class="form-control" name="business_unit" id="business_unit" required onchange="check_dept_projectIDS()">
                                                            <option value=""> -- Select -- </option>
                                                            <?php 
                                                            if ($get_businessunits) {
                                                                foreach ($get_businessunits as $keyy => $recD) {
                                                                    ?>
                                                                    <option value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
													</div>
												</div>
												
												<div class="col-lg-3 col-md-6">
													<div class="form-group">
														<label class="email">Dept.: </label>
														<select class="form-control " name="dept_id" id="dept_id" required>
                                                            <option>-- Select --</option>
                                                        </select>
													</div>
												</div>
												
												<?php  $get_project_names = get_project_names(); //print_r($get_businessunits); die;?>
                                                <div class="col-lg-3 col-md-6" id="ProjectID_Div" style="display:none;">
                                                    <div class="form-group">
                                                        <label class="text-muted"> Project :</label>
                                                        <select class="form-control show-tick ms select2" 
														name="projectID" id="projectID" data-placeholder="Select" >
                                                            <option value=""> -- Select -- </option>
                                                            <?php
                                                            if ($get_project_names) {
                                                                foreach ($get_project_names as $keyy => $recD) {
                                                                    ?>
                                                                    <option value="<?= $recD->id; ?>"><?= $recD->project_name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
												
                                                <div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Active Date : </label>
														<input  type="date" class="form-control" name="start_date" autocomplete="off" id="start_date"  required>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">InActive Date :</label>
                                                        <input type="date"  class="form-control" name="end_date" autocomplete="off" id="end_date">
                                                    </div>
                                                </div>
												
												
												<?php  $get_location = get_location(); //print_r($get_location); die;?>
                                                <div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Location : </label>
                                                        <select class="form-control" name="location" id="location" required>
                                                            <option value=""> -- Select -- </option>
                                                            <?php
                                                            if ($get_location) {
                                                                foreach ($get_location as $keyy => $recD) {
                                                                    ?>
                                                                    <option <?= set_select('city_name', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->city_name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
												
												<?php  $get_companyname = get_companyname(); //print_r($get_companyname); die;?>
                                                <div class="col-lg-3 col-md-6">
                                                    <div class="form-group">
                                                        <label class="text-muted">Company Name :</label>
                                                        <select class="form-control" name="company_id" id="company_id" required>
                                                            <option value=""> -- Select -- </option>
                                                            <?php
                                                            if ($get_companyname) {
                                                                foreach ($get_companyname as $keyy => $recD) {
                                                                    ?>
                                                                    <option <?= set_select('company_name', $recD->id, (!empty($data) && $data == $recD->id ? TRUE : FALSE)); ?> value="<?= $recD->id; ?>"><?= $recD->company_name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
												
												<div class="col-lg-3 col-md-6">
													<div class="form-group">
														<label class="email">Attachment: </label>
														<input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="policy_doc" id="policy_doc" required>
													</div>
												</div>
												
												
                                                <div class="col-lg-2 col-md-6">
                                                    <div class="mt-sm-3">
                                                        <input type="submit" class="btn btn-one">
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>
			var timeout = 1000; // in miliseconds (3*1000)
			$('.alert').delay(timeout).fadeOut(3000);
		
			function check_dept_projectIDS(){
                             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
				var Bussiness_unit = $("#business_unit").val();
				if(Bussiness_unit!='' && Bussiness_unit=="3"){
					$("#ProjectID_Div").show();
				}else{
					$("#ProjectID_Div").hide();
				}
				$.ajax({
					url: '<?= base_url("Policylist_Controller/get_dept_name_base_unit"); ?>',
					data: ({unit_id: Bussiness_unit}),
					type: 'post',
					success: function (data) {
						console.log(data);
						var response = '';
						var data2 = jQuery.parseJSON(data);
						var $select = $('#dept_id'); 
						$select.find('option').remove();  
						//$select.append('<option value=' '>'-- Select --'</option>');
						$.each(data2,function(i, item) {
							$select.append('<option value=' + item.id + '>' + item.deptname + '</option>');
						});
						$("#dept_id option:first").before($('<option value="" disabled selected >-- Select -- </option>'));
					}
                                        data:{[csrfName]: csrfHash}, 
				});
			}
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>


