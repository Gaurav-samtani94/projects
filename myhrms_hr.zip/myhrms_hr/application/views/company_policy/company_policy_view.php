<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
  .table tbody tr td, .table tbody th td {
    white-space: pre-wrap !important;}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">-->
							<!--<i class="fa fa-arrow-left"></i></a>Policies</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
						 <div class="body">
                                <?php if ($this->session->flashdata('success_msg')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($this->session->flashdata('error_msg')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (validation_errors()): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                        <strong>Error ! </strong> <?= validation_errors(); ?>
                                    </div>
                                <?php endif; ?>
								<?php  //print_r($GetAllPolicys); die; 
								 $get_businessunits = get_businessunits(); //print_r($get_businessunits); die; 
								 if (in_array($loginid, $HrPermUserIdsArr)) { ?>
									<a class="btn btn-one" style="color:white" href="<?= base_url('policy_add');?>">Add Policy</a>
								<?php } ?>
								<p></p>
                                
								<div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
										<thead>
											<tr>
												<?php if (in_array($loginid, $HrPermUserIdsArr)) { ?>
												<th>S.No.</th>
												<th>Policy Name</th>
												<th>Policy Description</th>
												<th>Bussiness Unit</th>
												<th>Department Name</th>
												<th>Project Name</th>
												<th>Company Name</th>
												<th>Location</th>
												<th>Active Date</th>
												<th>InActive  Date</th>
												<th>Attachment</th>
												<th>Action</th> 
												<?php } ?>
												<?php if (!in_array($loginid, $HrPermUserIdsArr)) { ?>
												<th>S.No.</th>
												<th>Policy Name</th>
												<th>Policy Description</th>
												<th>Attachment</th>
												<?php } ?>
											</tr>
										</thead>
										<tbody>
										 <?php 
										 if ($GetAllPolicys) {
                                            foreach ($GetAllPolicys as $kEy => $dataRow) {
												$file_name = ($dataRow->policy_doc) ? $dataRow->policy_doc : "";
												$file_path = ($dataRow->policy_doc) ? COMPANY_POLICY.$dataRow->policy_doc : "";
												?>
												<tr>
													<?php if (in_array($loginid, $HrPermUserIdsArr)) { ?>
													<td><?= $kEy + 1; ?></td>
													<td><?= ($dataRow->policy_name) ? $dataRow->policy_name : ""; ?></td>
													<td width="15%"><?= ($dataRow->policy_desc) ? $dataRow->policy_desc : ""; ?></td>
													
													<td><?= ($dataRow->business_unit) ? get_business_unit_name($dataRow->business_unit) : ""; ?></td>
													
													<td><?= ($dataRow->dept_id) ? get_dept_name($dataRow->dept_id) : ""; ?></td>
													
													<td><?= ($dataRow->projectID) ? get_project_name($dataRow->projectID) : "-"; ?></td>
													
													<td><?= ($dataRow->company_id) ? get_company_name($dataRow->company_id) : ""; ?></td>
													
													<td><?= ($dataRow->location) ? get_location_value($dataRow->location) : ""; ?></td>
													
													<td><?= ($dataRow->start_date) ? date('d-m-Y',strtotime($dataRow->start_date)) : ""; ?></td>
													<td><?= ($dataRow->end_date) ? date('d-m-Y',strtotime($dataRow->end_date)) : ""; ?></td>
													
													<td><a target='_blank' href='<?= $file_path;?>'><?= $file_name?></a></td>
													
													<td width="10%"><a class="btn" href="javascript:void(0);" onclick="seteditupdatedata('<?= $dataRow->id; ?>','<?= $dataRow->projectID;?>')" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit"></i></a><a title="Delete" class="btn" href="javascript:void(0);"  onclick="Policy_Delete('<?= $dataRow->id; ?>')"><i class="fa fa-trash"></i></a></td>
													<?php }?>
													<?php if (!in_array($loginid, $HrPermUserIdsArr)) { ?>
													<td><?= $kEy + 1; ?></td>
													<td><?= ($dataRow->policy_name) ? $dataRow->policy_name : ""; ?></td>
													<td width="15%"><?= ($dataRow->policy_desc) ? $dataRow->policy_desc : ""; ?></td>
													<td><a target='_blank' href='<?= $file_path;?>'><?= $file_name?></a></td>
													<?php } ?>
												</tr>												
											<?php }
										}?>
										</tbody>
										<tfoot class="d-none">
											<tr>
												<?php if (in_array($loginid, $HrPermUserIdsArr)) { ?>
												<th>S.No.</th>
												<th>Policy Name</th>
												<th>Policy Description</th>
												<th>Bussiness Unit</th>
												<th>Department Name</th>
												<th>Project Name</th>
												<th>Company Name</th>
												<th>Location</th>
												<th>Active Date</th>
												<th>InActive  Date</th>
												<th>Attachment</th>
												<th>Action</th> 
												<?php } ?>
												<?php if (!in_array($loginid, $HrPermUserIdsArr)) { ?>
												<th>S.No.</th>
												<th>Policy Name</th>
												<th>Policy Description</th>
												<th>Attachment</th>
												<?php } ?>
											</tr>
										</tfoot> 
										<tbody>  
										</tbody>
									</table>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
					
					
					
			<div class="container">
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog modal-lg" style="margin-top:150px;">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<h5> Edit Policy</h5>
							<button type="button" class="close" style="color:red" data-dismiss="modal"> X </button>
						</div>
						<div class="modal-body">
							<form method="post" action="<?= base_url('policy_update'); ?>" name="frmmNews" id="frmmNews" enctype="multipart/form-data">
							<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">	
                                                            <div class="row">
									<div class="form-group col-md-6">
										<label class="email">Policy Name: </label>
										<input type="text" class="form-control" name="edit_policy_name" id="edit_policy_name" required>
									</div>
									<div class="form-group col-md-6">
										<label class="email">Policy Description: </label>
										<textarea cols="5"  name="edit_policy_desc" id="edit_policy_desc" required class="form-control" style="resize:none;"></textarea>
									</div>
								</div>
								
								
								<?php  
								$get_businessunits = get_businessunits(); //print_r($get_businessunits); die;
								$get_departments = get_departments(); //print_r($get_departments); die;
								$get_project_names = get_project_names(); //print_r($get_businessunits); die;
								$get_location = get_location(); //print_r($get_location); die;
								$get_companyname = get_companyname(); //print_r($get_companyname); die;
								?>
								
								<div class="row">
									<div class="form-group col-md-6">
										<label class="email">Bussiness Unit: </label>
										<select class="form-control" name="edit_business_unit" id="edit_business_unit" required onchange="check_dept_projectIDS()" >
											<option value=""> -- Select -- </option>
											<?php 
											if ($get_businessunits) {
												foreach ($get_businessunits as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
													<?php
												}
											}
											?>
										</select>
									</div>
									
									<div class="col-lg-3 col-md-6" id="dept_id_div">
										<div class="form-group">
											<label class="email">Department Name.: </label>
											<select class="form-control" name="edit_dept_id" id="edit_dept_id" required>
											<option value=""> -- Select -- </option>
											<?php 
											if ($get_departments) {
												foreach ($get_departments as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->deptname; ?></option>
													<?php
												}
											}
											?>
										</select>
										</div>
									</div>
									
									
									
									<!--<div class="col-lg-3 col-md-6">
										<div class="form-group">
											<label class="email">Department Name.: </label>
											<select class="form-control" name="edit_dept_id" id="edit_dept_id" required>
												<option>-- Select --</option>
											</select>
										</div>
									</div>!-->
								</div>
								
								<div class="row">
									
									<div class="form-group col-md-6" id="ProjectID_Div" >
										<label class="text-muted"> Project Name:</label>
										<select class="form-control" name="edit_projectID" id="edit_projectID"  >
											<option value=""> -- Select -- </option>
											<?php if ($get_project_names) {
												foreach ($get_project_names as $keyy => $recD) {?>
													<option value="<?= $recD->id; ?>"><?= $recD->project_name; ?></option>
												<?php }
											}?>
										</select>
									</div>
									<div class="form-group col-md-6">
										<label class="text-muted">Company Name :</label>
										<select class="form-control" name="edit_company_id" id="edit_company_id" required>
											<option value=""> -- Select -- </option>
											<?php
											if ($get_companyname) {
												foreach ($get_companyname as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->company_name; ?></option>
													<?php
												}
											}
											?>
										</select>
									</div>
									
								</div>
										
								<div class="row">
									
									<div class="form-group col-md-6">
										<label class="text-muted">Location : </label>
										<select class="form-control" name="edit_location" id="edit_location" required>
											<option value=""> -- Select -- </option>
											<?php
											if ($get_location) {
												foreach ($get_location as $keyy => $recD) {
													?>
													<option value="<?= $recD->id; ?>"><?= $recD->city_name; ?></option>
													<?php
												}
											}
											?>
										</select>
									</div>
									
									<div class="form-group col-md-6">
										<label class="text-muted">Active Date : </label>
										<input  type="date" class="form-control" name="edit_start_date" autocomplete="off" id="edit_start_date" value="">
									</div>
								</div>
										
								
								<div class="row">
									<div class="form-group col-md-6">
										<label class="text-muted">InActive Date :</label>
										<input type="date"  class="form-control" name="edit_end_date" autocomplete="off" id="edit_end_date">
									</div>
									<div class="form-group  col-md-6">
										<label class="email">Old Attachment: </label>
										<input type="text" class="form-control" name="old_attach" id="old_attach" disabled>
									</div>
								</div>
										
								<div class="row">
									<div class="form-group  col-md-6">
										<label class="email">New Attachment: </label>
										<input type="file" accept=".gif,.jpg,.jpeg,.png,.doc,.docx,.pdf" class="form-control" name="edit_policy_doc" id="edit_policy_doc" required>
									</div>
								</div>		
										
								<div class="row">
									<div class="form-group col-md-12">
										<input type="hidden" id="uppolicy_id" name="uppolicy_id">
										<center><input type="submit" class="btn btn-primary" value="Submit"></center>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
					
                </div>
            </div>
        </div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		
        
    </div>
	
	<script type="text/javascript">
        
		var timeout = 1000; // in miliseconds (3*1000)
		$('.alert').delay(timeout).fadeOut(3000);
		
		function Policy_Delete(policy_id){
			//alert(policy_id);
			 if (confirm("Are You sure Delete this ? ")){
              window.location = "<?= base_url('policy_delete/'); ?>" + policy_id;
            }	
		}
		
		function seteditupdatedata(policy_id,ProjectID){
                 var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
			if(ProjectID=="0"){
				"scrollY":'62vh',
             "scrollX": true,
				$.ajax({
					url: '<?= base_url("ajax_getsinglepolicy_id"); ?>',
					data: ({policy_id: policy_id}),
					type: 'post',
					success: function (data) {
						console.log(data);
						var arr = $.parseJSON(data);
						console.log(arr);
						$("#edit_policy_name").val(arr.policy_name);
						$("#edit_policy_desc").val(arr.policy_desc);
						$('#edit_business_unit').val(arr.business_unit);
						$('#edit_dept_id').val(arr.dept_id);
						$("#ProjectID_Div").hide();
						$('#edit_location').val(arr.location);
						$('#edit_company_id').val(arr.company_id);
						$('#edit_start_date').val(arr.start_date);
						$('#edit_end_date').val(arr.end_date);
						$('#old_attach').val(arr.policy_doc);
						$('#uppolicy_id').val(policy_id);
					}
                                        data:{[csrfName]: csrfHash}, 
				});
			}else{
				$.ajax({
					url: '<?= base_url("ajax_getsinglepolicy_id"); ?>',
					data: ({policy_id: policy_id}),
					type: 'post',
					success: function (data) {
						console.log(data);
						var arr = $.parseJSON(data);
						console.log(arr);
						$("#ProjectID_Div").show();
						$("#edit_policy_name").val(arr.policy_name);
						$("#edit_policy_desc").val(arr.policy_desc);
						$('#edit_business_unit').val(arr.business_unit);
						$('#edit_dept_id').val(arr.dept_id);
						$("#edit_projectID").val(arr.projectID);
						$('#edit_location').val(arr.location);
						$('#edit_company_id').val(arr.company_id);
						$('#edit_start_date').val(arr.start_date);
						$('#edit_end_date').val(arr.end_date);
						$('#old_attach').val(arr.policy_doc);
						$('#uppolicy_id').val(policy_id);
					}
                                        data:{[csrfName]: csrfHash}, 
				});	
			}
		}
    </script>
	
	<script>
			function check_dept_projectIDS(){
                             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
				var Bussiness_unit = $("#edit_business_unit").val();
				if(Bussiness_unit!='' && Bussiness_unit=="3"){
					$("#ProjectID_Div").show();
				}else{
					$("#ProjectID_Div").hide();
				}
				$.ajax({
					url: '<?= base_url("Policylist_Controller/get_dept_name_base_unit"); ?>',
					data: ({unit_id: Bussiness_unit}),
					type: 'post',
					success: function (data) {
						console.log(data);
						var response = '';
						var data2 = jQuery.parseJSON(data);
						var $select = $('#edit_dept_id'); 
						$select.find('option').remove();  
						//$select.append('<option value=' '>'-- Select --'</option>');
						$.each(data2,function(i, item) {
							$select.append('<option value=' + item.id + '>' + item.deptname + '</option>');
						});
						$("#edit_dept_id option:first").before($('<option value="" disabled selected >-- Select -- </option>'));
					}
                                        data:{[csrfName]: csrfHash}, 
				});
			}
        </script>
	<?php $this->load->view('admin/includes/footer'); ?>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jquery.dataTables.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.bootstrap.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.colVis.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/dataTables.buttons.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.flash.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/pdfmake.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/jszip.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/vfs_fonts.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.html5.min.js'; ?>"></script>
		<script src="<?= HOSTNAME . 'assets/back_end/datatables/js/buttons.print.min.js'; ?>"></script>
	
</body>
                                                         