<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
//epd($edit_int);
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?php //base_url('emp_list'); 
                                                ?>" class="">
                                        <i class="fa fa-tasks"></i> Job List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">

                            <form method="POST" action="<?= base_url('edit_job_interview/' . $edit_int['id']); ?>" enctype="multipart/form-data">
                                <div class="body">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="title">Jobs : <span style="color:red;">*</span></label>
                                                <select name="job_id" id="job_id" class="form-control select2">
                                                    <option value="">--select Job</option>
                                                    <?php if (!empty($getJobList)) {
                                                        foreach ($getJobList as $jb) {
                                                            $selected = ($jb['id'] == $edit_int['job_id']) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $jb['id'] ?>" <?= set_select($jb['title']) ?><?= $selected ?>><?= $jb['title'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_job_id"><?= form_error('job_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="title">Interview ID</label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" name="inter_emp_id" id="inter_emp_id" name="inter_emp_id" value="<?= set_value('inter_emp_id', $edit_int['inter_emp_id']) ? set_value('inter_emp_id', $edit_int['inter_emp_id']) : ''; ?>" class="form-control" readonly>
                                                <!-- <span id="reqd" class="error_inter_emp_id"><?= form_error('inter_emp_id'); ?></span> -->
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="types">Types</label><br>
                                                <input type="radio" value="1" name="types" class="type-radio" data-target="consultancy-dropdown" <?php echo set_radio('types', '1', $edit_int['types'] == '1'); ?>> Consultancy<br>
                                                <input type="radio" value="2" name="types" class="type-radio" data-target="reference-dropdown" <?php echo set_radio('types', '2', $edit_int['types'] == '2'); ?>> Reference<br>
                                                <input type="radio" value="3" name="types" class="type-radio" data-target="others-dropdown" <?php echo set_radio('types', '3', $edit_int['types'] == '3'); ?>> Others<br>
                                            </div>
                                        </div>

                                        <!-- Consultancy dropdown -->
                                        <div class="col-md-3">
                                            <div class="form-group" id="consultancy-dropdown" <?php echo set_radio('types', '1', TRUE) ? '' : 'style="display: none;"'; ?>>
                                                <label for="consultancy_company_id">Consultancy Company</label>
                                                <select name="consultancy_company_id" id="consultancy_company_id" class="form-control select2">
                                                    <option value="">--select company--</option>
                                                    <?php foreach ($getCompList as $cmp) {
                                                        $selected = ($cmp['id'] == $edit_int['consultancy_company_id']) ? 'selected' : '';
                                                    ?>
                                                        <option value="<?= $cmp['id'] ?>" <?php echo set_select('consultancy_company_id', $cmp['id']); ?> <?= $selected ?>>
                                                            <?= $cmp['company_name'] ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                                <span class="text-danger"><?php echo form_error('consultancy_company_id'); ?></span>
                                            </div>

                                            <!-- Reference dropdown -->
                                            <div class="form-group" id="reference-dropdown" <?php echo set_radio('types', '2') ? '' : 'style="display: none;"'; ?>>
                                                <label for="reference_id">Reference</label>
                                                <select name="reference_id" id="reference_id" class="form-control select2">
                                                    <option value="">--select reference--</option>
                                                    <?php foreach ($getRefList as $ref) {
                                                        $selected = ($ref['id'] == $edit_int['emp_reference_id']) ? 'selected' : '';
                                                    ?>
                                                        <option value="<?= $ref['id'] ?>" <?php echo set_select('reference_id', $ref['id']); ?><?= $selected ?>>
                                                            <?= $ref['userfullname'] . ' ' . $ref['employeeId'] ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                                <span class="text-danger"><?php echo form_error('reference_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="title">Prefix : <span style="color:red;">*</span></label>
                                                <select name="prefix" id="prefix" class="form-control select2">
                                                    <option value="">--select company--</option>
                                                    <?php if (!empty($getPrefixList)) {
                                                        foreach ($getPrefixList as $pre) {
                                                            $selected = ($pre['id'] == $edit_int['prefix']) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $pre['id'] ?>" <?= $selected ?>><?= $pre['prefix'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_prefix"><?= form_error('prefix'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="first_name">First Name : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="first_name" name="first_name" value="<?= set_value('first_name', $edit_int['first_name']) ? set_value('first_name', $edit_int['first_name']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_first_name"><?= form_error('first_name'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="middle_name">Middle Name :</label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="middle_name" name="middle_name" value="<?= set_value('middle_name', $edit_int['middle_name']) ? set_value('middle_name', $edit_int['middle_name']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_middle_name"><?= form_error('middle_name'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="last_name">Last Name : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="last_name" name="last_name" value="<?= set_value('last_name', $edit_int['last_name']) ? set_value('last_name', $edit_int['last_name']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_last_name"><?= form_error('first_name'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="dob">DOB : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="dob" name="dob" value="<?= set_value('dob', $edit_int['dob']) ? set_value('dob', $edit_int['dob']) : ''; ?>" class="form-control datepicker">
                                                <span id="reqd" class="error_dob"><?= form_error('dob'); ?></span>
                                            </div>
                                        </div>

                                        <!-- <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="userfullname">User Name : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="userfullname" name="userfullname" value="<?= set_value('userfullname') ? set_value('userfullname') : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_userfullname"><?= form_error('userfullname'); ?></span>
                                            </div>
                                        </div> -->

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="contact">Contact : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="number" id="contact" name="contact" value="<?= set_value('contact', $edit_int['contact']) ? set_value('contact', $edit_int['contact']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_contact"><?= form_error('contact'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="email_id">Email : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="email_id" name="email_id" value="<?= set_value('email_id', $edit_int['email_id']) ? set_value('email_id', $edit_int['email_id']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_email_id"><?= form_error('email_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="country_id">Country : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="country_id" id="country_id" onchange="getstate()" class="form-control select2">
                                                    <option <?= set_select('country', "", (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Country -- </option>
                                                    <?php
                                                    $country = getcountry();
                                                    foreach ($country as $key => $value) {
                                                        $selected = ($value->id == $edit_int['country_id']) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $value->id; ?>" <?= $selected ?>> <?= $value->country_name; ?> </option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_country_id"><?= form_error('country_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="state_id">State : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="state_id" id="state_id" onchange="getcity_State()" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php if (!empty($getState)) {
                                                        foreach ($getState as $sta) {
                                                            $selected = ($sta['id'] == $edit_int['state_id']) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $sta['id'] ?>" <?= $selected ?>><?= $sta['state_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_state_id"><?= form_error('state_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="city_id">City : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="city_id" id="city_id" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php if (!empty($getCity)) {
                                                        foreach ($getCity as $cit) {
                                                            $selected = ($cit['id'] == $edit_int['city_id']) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $sta['id'] ?>" <?= $selected ?>><?= $cit['city_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_city_id"><?= form_error('city_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="address">Pincode : <span style="color:red;">*</span></label>
                                                <input type="number" name="pincode" id="pincode" class="form-control" value="<?= set_value('pincode', $edit_int['pincode']) ?>">
                                                <span id="reqd" class="error_pincode"><?= form_error('pincode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="address">Address : <span style="color:red;">*</span></label>
                                                <textarea name="address" id="address" class="form-control"><?= set_value('address', $edit_int['address']) ?></textarea>
                                                <span id="reqd" class="error_address"><?= form_error('address'); ?></span>
                                            </div>
                                        </div>

                                        <?php /*
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="interview_round">Interview Round : <span style="color:red;">*</span></label>
                                                <input type="number" name="interview_round" id="interview_round" class="form-control" value="<?= set_value('interview_round', $edit_int['interview_round']) ?>">
                                                <span id="reqd" class="error_interview_round"><?= form_error('interview_round'); ?></span>
                                            </div>
                                        </div>
                                        */ ?>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="total_exp">Total Experience : <span style="color:red;">*</span></label>
                                                <input type="number" name="total_exp" id="total_exp" class="form-control" value="<?= set_value('total_exp', $edit_int['total_exp']) ?>">
                                                <span id="reqd" class="error_total_exp"><?= form_error('total_exp'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="address">Upload Document : <span style="color:red;"></span></label>
                                                <input type="file" name="cv_document" id="cv_document" class="form-control" accept=".pdf, .doc, .docx">
                                                <span id="reqd" class="error_cv_document"><?= form_error('cv_document'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="qualification">Qualification : <span style="color:red;">*</span></label>
                                                <select id="qualification" name="qualification_id[]" class="form-control select2" multiple>
                                                    <option value="" disabled>-- Select qualification --</option>
                                                    <?php foreach ($getQualification as $qua) : ?>
                                                        <?php
                                                        $expload = explode(',', $edit_int['qualification_id']);
                                                       // $selected = in_array($qua['id'], $expload);
                                                        if(in_array($qua['id'], $expload)){ ?>
                                                            <option value="<?= $qua['id'] ?>" selected><?= $qua['educationlevelcode'] ?></option>
                                                            <?php 
                                                        } else { ?>
                                                            <option value="<?= $qua['id'] ?>" ><?= $qua['educationlevelcode'] ?></option>
                                                            <?php 
                                                        }
                                                        ?>
                                                        
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <span id="reqd" class="error_qualification"><?= form_error('qualification_id[]'); ?></span>
                                        </div>

                                        <div id="qualificationDetails">
                                            <!-- Table for qualification details will be dynamically added here -->
                                            <?php // $qualification_details_table; ?>
                                        </div>

                                        <!-- <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description">Description : <span style="color:red;">*</span></label>
                                                <textarea name="description" id="description" class="form-control"><?= set_value('description') ?></textarea>
                                                <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                            </div>
                                        </div> -->

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <input class="btn btn-one" type="submit" value="Submit" name="submit" id="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize datepicker
            $(".datepicker").datepicker({
                dateFormat: 'yy-mm-dd',
                maxDate: '-18y',
                // maxDate: '0',
                changeMonth: true,
                changeYear: true,
                yearRange: '-100:+0',
                onSelect: function(dateText, inst) {
                    validateAge(dateText);
                }
            });

            // Function to validate age
            function validateAge(selectedDate) {
                var today = new Date();
                var selectedDOB = new Date(selectedDate);
                var age = today.getFullYear() - selectedDOB.getFullYear();
                var m = today.getMonth() - selectedDOB.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < selectedDOB.getDate())) {
                    age--;
                }
                if (age < 18) {
                    toastr.error("You must be at least 18 years old.");
                    $("#dob").val('');
                }
            }

            function rmvalidationerror(id) {
                $("#" + id).siblings(".error_dob").html("");
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            // Initial setup
            $("#consultancy-dropdown").show();
            $("#reference-dropdown").hide();

            // Event handler for radio button change
            $(".type-radio").change(function() {
                var target = $(this).data('target');

                if (target === "others-dropdown") {
                    $("#consultancy-dropdown").hide();
                    $("#reference-dropdown").hide();
                } else if (target === "consultancy-dropdown") {
                    $("#consultancy-dropdown").show();
                    $("#reference-dropdown").hide();
                    // Clear Reference dropdown when switching to Consultancy
                    $("#reference_id").val('').trigger('change'); // Clear and trigger change event
                } else if (target === "reference-dropdown") {
                    $("#consultancy-dropdown").hide();
                    $("#reference-dropdown").show();
                    // Clear Consultancy dropdown when switching to Reference
                    $("#consultancy_company_id").val('').trigger('change'); // Clear and trigger change event
                }
            });
        });

        $(document).ready(function() {
            var selectedType = $('input[name="types"]:checked').val();
            showHideDropdown(selectedType);
        });


        $('input[name="types"]').change(function() {
            var selectedType = $(this).val();
            showHideDropdown(selectedType);
        });


        function showHideDropdown(selectedType) {
            if (selectedType == '1') {
                $('#consultancy-dropdown').show();
                $('#reference-dropdown').hide();
            } else if (selectedType == '2') {
                $('#consultancy-dropdown').hide();
                $('#reference-dropdown').show();
            } else {
                $('#consultancy-dropdown').hide();
                $('#reference-dropdown').hide();
            }
        }

        $(document).ready(function() {
            tableHTML = '';
            function initializeQualificationDetails(selectedOptions, qualificationDetails,type) {
                if (!selectedOptions || selectedOptions.length === 0) {
                    $('#qualificationDetails').empty();
                    return;
                }

                tableHTML = '<table class="table table-bordered"><thead><tr>' +
                    '<th>Qualification</th>' +
                    '<th>Year of Passing</th>' +
                    '<th>% of Marks/Grade</th>' +
                    '<th>Stream/Main Subject</th>' +
                    '<th>School/College/Institution</th>' +
                    '<th>Place</th>' +
                    '<th>Regular / Correspondence</th>' +
                    '</tr></thead><tbody>';

                selectedOptions.forEach(function(optionId) {
                    
                    var qualificationDetail = qualificationDetails.find(function(detail) {
                        return detail.qualification_id == optionId; // Ensure to use == for loose comparison
                    });

                    var qualificationName = $('#qualification option[value="' + optionId + '"]').text();

                    if (qualificationDetail) {
                        var qualification_id = qualificationDetail.qualification_id;
                        var yearOfPassing = qualificationDetail.year_passing;
                        var marksGrade = qualificationDetail.marks_grade;
                        var streamSubject = qualificationDetail.main_subject;
                        var institution = qualificationDetail.institution_name;
                        var place = qualificationDetail.place;
                        var regularCorrespondence = qualificationDetail.education_type;
                       // alert(regularCorrespondence);

                        tableHTML += '<tr>' +
                            '<td><div style="display:none;"><input type="text" name="qualification_details[' + optionId + '][qualification_id]" value="'+qualification_id+'" class="form-control"></div>' + qualificationName + '</td>' +
                            '<td><input type="text" name="qualification_details[' + optionId + '][year_of_passing]" class="form-control" value="' + yearOfPassing + '"></td>' +
                            '<td><input type="text" name="qualification_details[' + optionId + '][marks_grade]" class="form-control" value="' + marksGrade + '"></td>' +
                            '<td><input type="text" name="qualification_details[' + optionId + '][stream_subject]" class="form-control" value="' + streamSubject + '"></td>' +
                            '<td><input type="text" name="qualification_details[' + optionId + '][institution]" class="form-control" value="' + institution + '"></td>' +
                            '<td><input type="text" name="qualification_details[' + optionId + '][place]" class="form-control" value="' + place + '"></td>' +
                            '<td><select id="qualification" name="qualification_details[' + optionId + '][regular_correspondence]" class="form-control"><option value="" disabled>-- Select regular / correspondence --</option><option '+((regularCorrespondence == 'regular')? 'selected':'')+' value="regular">Regular</option><option '+((regularCorrespondence == 'correspondence')? 'selected':'')+' value="correspondence">Correspondence</option></select></td>' +
                            '</tr>';
                    }
                });
                if(type == 'first'){
                    tableHTML += '</tbody></table>';
                }
                $('#qualificationDetails').html(tableHTML);
            }

            var selectedOptions = $('#qualification').val();
            var qualificationDetails = <?= json_encode($qualification_details) ?>;
            initializeQualificationDetails(selectedOptions, qualificationDetails,'first');

            $('#qualification').change(function() {
                var selectedOptions = $(this).val();
                if (!selectedOptions || selectedOptions.length === 0) {
                    $('#qualificationDetails').empty();
                    return;
                }
                tableHTML = '';
                var selectedOptions1 = $('#qualification').val();
                var qualificationDetails1 = <?= json_encode($qualification_details) ?>;
                initializeQualificationDetails(selectedOptions1, qualificationDetails1,'types');
                

                selectedOptions.forEach(function(optionId) {
                    var qualificationIds = [];
                    var ik = 0;
                    var qualificationDetail = qualificationDetails1.find(function(detail) {
                        qualificationIds[ik] = detail.qualification_id;
                        ik++;
                    });
                    if(qualificationIds.includes(optionId)){

                    } else {
                        var qualificationName = $('#qualification option[value="' + optionId + '"]').text();
                        tableHTML += '<tr>' +
                        '<td><div style="display:none;"><input type="text" name="qualification_details[' + optionId + '][qualification_id]" value="'+optionId+'" class="form-control"></div>' + qualificationName + '</td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][year_of_passing]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][marks_grade]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][stream_subject]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][institution]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][place]" class="form-control"></td>' +
                        '<td><select id="qualification" name="qualification_details[' + optionId + '][regular_correspondence]" class="form-control"><option value="" disabled>-- Select regular / correspondence --</option><option value="regular">Regular</option><option value="correspondence">Correspondence</option></select></td>' +
                        '</tr>';
                    }
                    
                });

                tableHTML += '</tbody></table>';
                $('#qualificationDetails').html(tableHTML);
            });
        });


        $(document).ready(function() {
            $('#qualification').select2({
                placeholder: "-- Select qualification --",
                allowClear: true
            });
        });
    </script>

    <!-- <script>
        $(document).ready(function() {
            $('#qualification').change(function() {
                var selectedOptions = $(this).val();
                if (!selectedOptions || selectedOptions.length === 0) {
                    $('#qualificationDetails').empty();
                    return;
                }

                var tableHTML = '<table class="table table-bordered"><thead><tr>' +
                    '<th>Qualification</th>' +
                    '<th>Year of Passing</th>' +
                    '<th>% of Marks/Grade</th>' +
                    '<th>Stream/Main Subject</th>' +
                    '<th>School/College/Institution</th>' +
                    '<th>Place</th>' +
                    '<th>Regular / Correspondence</th>' +
                    '</tr></thead><tbody>';

                selectedOptions.forEach(function(optionId) {
                    var qualificationName = $('#qualification option[value="' + optionId + '"]').text();
                    tableHTML += '<tr>' +
                        '<td>' + qualificationName + '</td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][year_of_passing]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][marks_grade]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][stream_subject]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][institution]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][place]" class="form-control"></td>' +
                        '<td><input type="text" name="qualification_details[' + optionId + '][regular_correspondence]" class="form-control"></td>' +
                        '</tr>';
                });

                tableHTML += '</tbody></table>';
                $('#qualificationDetails').html(tableHTML);
            });
        });
    </script> -->

    <?php $this->load->view('admin/includes/footer'); ?>
</body>