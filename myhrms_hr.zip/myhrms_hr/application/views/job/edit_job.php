<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?php //base_url('emp_list'); 
                                                ?>" class="">
                                        <i class="fa fa-tasks"></i> Job List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">

                            <form method="post" action="<?= base_url('edit_jobs/' . $job_record['id']); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <!-- Start Professional -->
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="title">Title : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="title" name="title" value="<?= set_value('title', $job_record['title']) ? set_value('title', $job_record['title']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_title"><?= form_error('title'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="business_unit_id">Bussines Unit : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="business_unit_id" id="business_unit_id" class="form-control select2">
                                                    <option <?= set_select('business_unit_id', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Unit</option>
                                                    <?php
                                                    $business_unit = get_businessunits();
                                                    foreach ($business_unit as $key => $vall) {
                                                        $selected = ($vall->id == $job_record['business_unit_id']) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('business_unit_id', $vall->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $vall->id; ?>" <?= $selected ?>><?= $vall->unitname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_business_unit_id"><?= form_error('business_unit_id'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="position">Position : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="position" id="position" class="form-control select2">
                                                    <option <?= set_select('position', "", (!empty($data) && $data == '' ? true : false)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    $position = get_all_positions();
                                                    foreach ($position as $key => $val) {
                                                        $selected = ($val->id == $job_record['position']) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('position', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>" <?= $selected ?>> <?= $val->positionname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_position"><?= form_error('position'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="company_id">Company Name : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="company_id" id="company_id" class="form-control select2">
                                                    <option <?= set_select('company_id', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Company --</option>
                                                    <?php
                                                    $companylist = get_companyname();
                                                    foreach ($companylist as $key => $val) {
                                                        $selected = ($val->id == $job_record['company_id']) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('company_id', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>" <?= $selected ?>><?= $val->company_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_company_id"><?= form_error('company_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="company_location_id">Company Location : <span style="color:red;">*</span></label>
                                                <select name="company_location_id" onclick="rmvalidationerror(this.id)" id="company_location_id" class="form-control select2">
                                                    <option <?= set_select('company_location_id', '', (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Location -- </option>
                                                    <?php
                                                    $comp_location = get_compancy_location();
                                                    foreach ($comp_location as $key => $va) {
                                                        $selected = ($va->id == $job_record['company_location_id']) ? 'selected' : '';
                                                    ?>
                                                        <option <?= set_select('company_location_id', $va->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $va->id; ?>" <?= $selected ?>><?= $va->city_name; ?></option>
                                                    <?php
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_company_location_id"><?= form_error('company_location_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="location">location : <span style="color:red;">*</span></label>
                                                <textarea name="location" id="location" onclick="rmvalidationerror(this.id)" class="form-control"><?= set_value('location', $job_record['location']) ? set_value('location', $job_record['location']) : ''; ?></textarea>
                                                <span id="reqd" class="error_address"><?= form_error('location'); ?></span>
                                            </div>
                                        </div>



                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="country_id">Country : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="country_id" id="country_id" onchange="getstate()" class="form-control select2">
                                                    <option value=''> -- Select Country -- </option>
                                                    <?php
                                                    $country = getcountry();
                                                    foreach ($country as $key => $value) {
                                                        $selected = ($value->id == $job_record['country_id']) ? 'selected' : '';
                                                        echo "<option value='{$value->id}' {$selected}> {$value->country_name} </option>";
                                                    }
                                                    ?>
                                                </select>
                                                <span id="reqd" class="error_country_id"><?= form_error('country_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="state_id">State : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="state_id" id="state_id" onchange="getcity_State()" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                </select>
                                                <span id="reqd" class="error_state_id"><?= form_error('state_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="city_id">City : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="city_id" id="city_id" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                </select>
                                                <span id="reqd" class="error_city_id"><?= form_error('city_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_experience">Min Experience : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="min_experience" id="min_experience" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php
                                                    $selectedValue = $job_record['min_experience'];
                                                    for ($i = 0; $i < 15; $i++) {
                                                        $selected = ($i == $selectedValue) ? 'selected' : '';

                                                        if ($i == 0) { ?>
                                                            <option value='<?= $i ?>' <?= $selected ?>> <?= $i ?> </option>
                                                        <?php
                                                        } else { ?>
                                                            <option value='<?= $i ?>' <?= $selected ?>> <?= $i ?> Years </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                                <span id="reqd" class="error_min_experience"><?= form_error('min_experience'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_experience">Max Experience : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="max_experience" id="max_experience" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php
                                                    $selectedValue = $job_record['max_experience'];

                                                    for ($i = 1; $i <= 15; $i++) {
                                                        $selected = ($i == $selectedValue) ? 'selected' : '';
                                                    ?>
                                                        <option value='<?= $i ?>' <?= $selected ?>> <?= $i ?> Years </option>
                                                    <?php
                                                    }
                                                    ?>

                                                </select>
                                                <span id="reqd" class="error_max_experience"><?= form_error('max_experience'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="qualifications">Qualifications : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="qualifications" name="qualifications" value="<?= set_value('qualifications', $job_record['qualifications']) ? set_value('qualifications', $job_record['qualifications']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('qualifications'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="courses">Courses : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="courses" name="courses" value="<?= set_value('courses', $job_record['courses']) ? set_value('courses', $job_record['courses']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('courses'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="skills">Skill : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="skills" name="skills" value="<?= set_value('skills', $job_record['skills']) ? set_value('skills', $job_record['skills']) : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('skills'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="employment_type">Employment Type : <span style="color:red;">*</span></label>
                                                <select name="employment_type" id="employment_type" class="form-control">
                                                    <option value="">--select employment--</option>
                                                    <?php if (!empty($empList)) {
                                                        foreach ($empList as $obj) {
                                                            $selected = ($obj['emp_id'] == $job_record['employment_type']) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?= $obj['emp_id'] ?>" <?= $selected ?>><?= $obj['type_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_employment_type"><?= form_error('employment_type'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="work_mode">Work Mode : <span style="color:red;">*</span></label>
                                                <?php
                                                $selectedValue = $job_record['work_mode'];
                                                ?>
                                                <select name="work_mode" id="work_mode" class="form-control">
                                                    <option value="">--select works--</option>
                                                    <option value="from_office" <?= ($selectedValue == 'from_office') ? 'selected' : ''; ?>>From Office</option>
                                                    <option value="from_home" <?= ($selectedValue == 'from_home') ? 'selected' : ''; ?>>From Home</option>
                                                </select>

                                                <span id="reqd" class="error_work_mode"><?= form_error('work_mode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_annual_salary">Min Annual Salary : <span style="color:red;">*</span></label>
                                                <input type="number" name="min_annual_salary" id="min_annual_salary" class="form-control" value="<?= set_value('min_annual_salary', $job_record['min_annual_salary']) ?>">
                                                <span id="reqd" class="error_min_annual_salary"><?= form_error('min_annual_salary'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="max_annual_salary">Max Annual Salary : <span style="color:red;">*</span></label>
                                                <input type="number" name="max_annual_salary" id="max_annual_salary" class="form-control" value="<?= set_value('max_annual_salary', $job_record['max_annual_salary']) ?>">
                                                <span id="reqd" class="error_max_annual_salary"><?= form_error('max_annual_salary'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="requirement">Requirement : <span style="color:red;">*</span></label>
                                                <input type="text" name="requirement" id="requirement" class="form-control" value="<?= set_value('requirement', $job_record['requirement']) ?>">
                                                <span id="reqd" class="error_requirement"><?= form_error('requirement'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description">Description : <span style="color:red;">*</span></label>
                                                <textarea name="description" id="description" class="form-control"><?= set_value('description', $job_record['description']) ?></textarea>
                                                <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <input class="btn btn-one" type="submit" value="Update" name="submit" id="submit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        CKEDITOR.replace('description');
        //Validation Error Removed..
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }



        function gtetemplete() {
            var lettertype = $('#lettertype').val();
            $.ajax({
                url: "<?= base_url('get_letter_templete'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                },
                dataType: 'json',
                success: function(res) {
                    $('#Templete_id').html('');
                    $('#Templete_id').trigger("change");
                    $('#Templete_id').append("<option>Select Template</option>");
                    if (res) {
                        $.each(res, function(key, val) {
                            $('#Templete_id').append("<option value=" + val.id + ">" + val.letter_templete_name + "</option>");
                        });
                    } else {
                        $('#Templete_id').append("<option>Select Template</option>");
                    }
                }
            });
        }


        // function readURL(input) {
        //     if (input.files && input.files[0]) {
        //         var reader = new FileReader();
        //         reader.onload = function(e) {
        //             $('#blah').removeAttr('src');
        //             $('#blah').attr('src', e.target.result);
        //         }
        //         reader.readAsDataURL(input.files[0]);
        //     }
        // }


        function getstate(selectedStateId = '') {
            var country = $("#country_id").val();

            $('#state_id').html('<option value=""> -- Select -- </option>');
            $('#city_id').html('<option value=""> -- Select -- </option>');

            if (country) {
                $.ajax({
                    url: "<?= base_url('getstate'); ?>",
                    type: "POST",
                    data: {
                        country: country
                    },
                    dataType: 'json',
                    success: function(res) {
                        $.each(res, function(key, val) {
                            var selected = (val.id == selectedStateId) ? 'selected' : '';
                            $('#state_id').append("<option value='" + val.id + "' " + selected + ">" + val.state_name + "</option>");
                        });

                        // Initialize select2 after options are appended
                        $("#state_id").select2({
                            allowClear: true,
                            placeholder: " -- Select -- "
                        });

                        // Trigger the state change to load cities if state is pre-selected
                        if (selectedStateId) {
                            getcity_State(selectedStateId, <?= $job_record['city_id'] ?>);
                        }
                    }
                });
            } else {
                $("#state_id").select2({
                    allowClear: true,
                    placeholder: " -- Select -- "
                });
            }
        }

        function getcity_State(selectedStateId = '', selectedCityId = '') {
            var state = selectedStateId || $("#state_id").val();

            $('#city_id').html('<option value=""> -- Select -- </option>');

            if (state) {
                $.ajax({
                    url: "<?= base_url('getcity'); ?>",
                    type: "POST",
                    data: {
                        state: state
                    },
                    dataType: 'json',
                    success: function(res) {
                        $.each(res, function(key, val) {
                            var selected = (val.id == selectedCityId) ? 'selected' : '';
                            $('#city_id').append("<option value='" + val.id + "' " + selected + ">" + val.city_name + "</option>");
                        });

                        // Initialize select2 after options are appended
                        $("#city_id").select2({
                            allowClear: true,
                            placeholder: " -- Select -- "
                        });
                    }
                });
            } else {
                $("#city_id").select2({
                    allowClear: true,
                    placeholder: " -- Select -- "
                });
            }
        }

        // Call getstate with the pre-selected state ID when the page loads
        $(document).ready(function() {
            var selectedCountryId = <?= $job_record['country_id'] ?>;
            var selectedStateId = <?= $job_record['state_id'] ?>;
            var selectedCityId = <?= $job_record['city_id'] ?>;

            if (selectedCountryId) {
                getstate(selectedStateId);
            }
        });




        // //editbutton 
        // function mgetstate(){
        //    var country = $("#mcountry").val();
        //     $.ajax({
        //         url: "<?php // base_url('getstate'); 
                            ?>",
        //         type: "POST",
        //         data: {
        //             country:country
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#state').html('');
        //             $('#city').html('');

        //             $('#city').append("<option value=''> -- Select City -- </option>");
        //             $('#state').append("<option>Select State</option>");

        //             $('#state').trigger("change");
        //             $('#city').trigger("change");

        //             $.each(res, function(key,val) {
        //                 $('#state').append("<option value="+val.id+">"+val.state_name+"</option>");
        //              });
        //         }
        //     });
        // }

        // function mgetcity_State(){
        //     var state = $("#state").val();
        //     $.ajax({
        //         url: "<?php // base_url('getcity'); 
                            ?>",
        //         type: "POST",
        //         data: {
        //             state:state
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#mcity').html('');
        //             $('#city').trigger("change");
        //             $('#mcity').append("<option>Select City</option>");
        //             $.each(res, function(key,val) {
        //                 $('#mcity').append("<option value="+val.id+">"+val.city_name+"</option>");
        //            }); 
        //         }
        //     });
        // }

        function fetch_positon() {
            var hr_id = $('#hrname').val();
            $.ajax({
                url: "<?= base_url('get_hr_id_position'); ?>",
                type: "POST",
                data: {
                    hr_id: hr_id
                },
                dataType: 'json',
                success: function(res) {
                    $('#hr_position').val(res).change();
                }
            });
        }
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>