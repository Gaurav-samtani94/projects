<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?php //base_url('emp_list'); 
                                                ?>" class="">
                                        <i class="fa fa-tasks"></i> Job List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">

                            <form method="post" action="<?= base_url('add_jobs'); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <!-- Start Professional -->
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="title">Title : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="title" name="title" value="<?= set_value('title') ? set_value('title') : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_title"><?= form_error('title'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="business_unit_id">Bussines Unit : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="business_unit_id" id="business_unit_id" class="form-control select2">
                                                    <option <?= set_select('business_unit_id', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Unit</option>
                                                    <?php
                                                    $business_unit = get_businessunits();
                                                    foreach ($business_unit as $key => $vall) { ?>
                                                        <option <?= set_select('business_unit_id', $vall->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $vall->id; ?>"><?= $vall->unitname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_business_unit_id"><?= form_error('business_unit_id'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="position">Position : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="position" id="position" class="form-control select2">
                                                    <option <?= set_select('position', "", (!empty($data) && $data == '' ? true : false)); ?> value=""> -- Select -- </option>
                                                    <?php
                                                    $position = get_all_positions();
                                                    foreach ($position as $key => $val) { ?>
                                                        <option <?= set_select('position', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_position"><?= form_error('position'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="company_id">Company Name : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="company_id" id="company_id" class="form-control select2">
                                                    <option <?= set_select('company_id', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Company --</option>
                                                    <?php
                                                    $companylist = get_companyname();
                                                    foreach ($companylist as $key => $val) { ?>
                                                        <option <?= set_select('company_id', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>"><?= $val->company_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_company_id"><?= form_error('company_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="company_location_id">Company Location : <span style="color:red;">*</span></label>
                                                <select name="company_location_id" onclick="rmvalidationerror(this.id)" id="company_location_id" class="form-control select2">
                                                    <option <?= set_select('company_location_id', '', (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Location -- </option>
                                                    <?php
                                                    $comp_location = get_compancy_location();
                                                    foreach ($comp_location as $key => $va) { ?>
                                                        <option <?= set_select('company_location_id', $va->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $va->id; ?>"><?= $va->city_name; ?></option>
                                                    <?php
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_company_location_id"><?= form_error('company_location_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="location">location : <span style="color:red;">*</span></label>
                                                <textarea name="location" id="location" onclick="rmvalidationerror(this.id)" class="form-control"><?= set_value('location') ? set_value('location') : ''; ?></textarea>
                                                <span id="reqd" class="error_address"><?= form_error('location'); ?></span>
                                            </div>
                                        </div>



                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="country_id">Country : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="country_id" id="country_id" onchange="getstate()" class="form-control select2">
                                                    <option <?= set_select('country', "", (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Country -- </option>
                                                    <?php
                                                    $country = getcountry();
                                                    foreach ($country as $key => $value) { ?>
                                                        <option <?= set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $value->id; ?>"> <?= $value->country_name; ?> </option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_country_id"><?= form_error('country_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">

                                                <label for="state_id">State : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="state_id" id="state_id" onchange="getcity_State()" class="form-control select2">
                                                    <option value=''> -- Select -- </option>

                                                </select>
                                                <span id="reqd" class="error_state_id"><?= form_error('state_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="city_id">City : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="city_id" id="city_id" class="form-control select2">
                                                    <option value=''> -- Select -- </option>

                                                </select>
                                                <span id="reqd" class="error_city_id"><?= form_error('city_id'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_experience">Min Experience : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="min_experience" id="min_experience" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php
                                                    for ($i = 0; $i < 15; $i++) {
                                                        if ($i == 0) { ?>
                                                            <option value='<?= $i ?>'> <?= $i ?> </option>
                                                        <?php
                                                        } else { ?>
                                                            <option value='<?= $i ?>'> <?= $i ?> Years </option>
                                                        <?php
                                                        }
                                                        ?>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                                <span id="reqd" class="error_min_experience"><?= form_error('min_experience'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_experience">Max Experience : <span style="color:red;">*</span></label>
                                                <select onclick="rmvalidationerror(this.id)" name="max_experience" id="max_experience" class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php
                                                    for ($i = 1; $i <= 15; $i++) {  ?>
                                                        <option value='<?= $i ?>'> <?= $i ?> Years </option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                                <span id="reqd" class="error_max_experience"><?= form_error('max_experience'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="qualifications">Qualifications : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="qualifications" name="qualifications" value="<?= set_value('qualifications') ? set_value('qualifications') : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('qualifications'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="courses">Courses : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="courses" name="courses" value="<?= set_value('courses') ? set_value('courses') : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('courses'); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="skills">Skill : <span style="color:red;">*</span></label>
                                                <input onclick="rmvalidationerror(this.id)" type="text" id="skills" name="skills" value="<?= set_value('skills') ? set_value('skills') : ''; ?>" class="form-control">
                                                <span id="reqd" class="error_qualifications"><?= form_error('skills'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="employment_type">Employment Type : <span style="color:red;">*</span></label>
                                                <select name="employment_type" id="employment_type" class="form-control">
                                                    <option value="">--select employment--</option>
                                                    <?php if (!empty($empList)) {
                                                        foreach ($empList as $obj) { ?>
                                                            <option value="<?= $obj['emp_id'] ?>"><?= $obj['type_name'] ?></option>
                                                    <?php }
                                                    } ?>
                                                </select>
                                                <span id="reqd" class="error_employment_type"><?= form_error('employment_type'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="work_mode">Work Mode : <span style="color:red;">*</span></label>
                                                <select name="work_mode" id="work_mode" class="form-control">
                                                    <option value="">--select works--</option>
                                                    <option value="from_office">From Office</option>
                                                    <option value="from_home">From Home</option>
                                                </select>
                                                <span id="reqd" class="error_work_mode"><?= form_error('work_mode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="min_annual_salary">Min Annual Salary : <span style="color:red;">*</span></label>
                                                <input type="number" name="min_annual_salary" id="min_annual_salary" class="form-control" value="<?=set_value('min_annual_salary')?>">
                                                <span id="reqd" class="error_min_annual_salary"><?= form_error('min_annual_salary'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="max_annual_salary">Max Annual Salary : <span style="color:red;">*</span></label>
                                                <input type="number" name="max_annual_salary" id="max_annual_salary" class="form-control" value="<?=set_value('max_annual_salary')?>">
                                                <span id="reqd" class="error_max_annual_salary"><?= form_error('max_annual_salary'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="requirement">Requirement : <span style="color:red;">*</span></label>
                                                <input type="text" name="requirement" id="requirement" class="form-control" value="<?=set_value('requirement')?>">
                                                <span id="reqd" class="error_requirement"><?= form_error('requirement'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="description">Description : <span style="color:red;">*</span></label>
                                                <textarea name="description" id="description" class="form-control"><?=set_value('description')?></textarea>
                                                <span id="reqd" class="error_description"><?= form_error('description'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                <input class="btn btn-one" type="submit" value="Submit" name="submit" id="submit">
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </form>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        CKEDITOR.replace('description');
        //Validation Error Removed..
        function rmvalidationerror(returnarrg) {
            $('.error_' + returnarrg).html("");
        }



        function gtetemplete() {
            var lettertype = $('#lettertype').val();
            $.ajax({
                url: "<?= base_url('get_letter_templete'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                },
                dataType: 'json',
                success: function(res) {
                    $('#Templete_id').html('');
                    $('#Templete_id').trigger("change");
                    $('#Templete_id').append("<option>Select Template</option>");
                    if (res) {
                        $.each(res, function(key, val) {
                            $('#Templete_id').append("<option value=" + val.id + ">" + val.letter_templete_name + "</option>");
                        });
                    } else {
                        $('#Templete_id').append("<option>Select Template</option>");
                    }
                }
            });
        }


        // function readURL(input) {
        //     if (input.files && input.files[0]) {
        //         var reader = new FileReader();
        //         reader.onload = function(e) {
        //             $('#blah').removeAttr('src');
        //             $('#blah').attr('src', e.target.result);
        //         }
        //         reader.readAsDataURL(input.files[0]);
        //     }
        // }


        function getstate() {
            var country = $("#country_id").val();

            $('#state_id').html('');
            $('#state_id').val('');
            $('#state_id').trigger("change");

            $("#state_id").select2({
                allowClear: true,
                placeholder: " -- "
            });

            $.ajax({
                url: "<?= base_url('getstate'); ?>",
                type: "POST",
                data: {
                    country: country
                },
                dataType: 'json',
                success: function(res) {
                    $('#state_id').append("<option value=''> -- Select State -- </option>");
                    $.each(res, function(key, val) {
                        $('#state_id').append("<option value=" + val.id + ">" + val.state_name + "</option>");
                    });
                }
            });

        }

        function getcity_State() {
            var state = $("#state_id").val();

            $('#city_id').html('');
            $('#city_id').val('');
            $('#city_id').trigger("change");

            $("#city_id").select2({
                allowClear: true,
                placeholder: " -- "
            });

            $.ajax({
                url: "<?= base_url('getcity'); ?>",
                type: "POST",
                data: {
                    state: state
                },
                dataType: 'json',
                success: function(res) {

                    $('#city_id').append("<option value=''> -- Select City -- </option>");

                    $.each(res, function(key, val) {
                        $('#city_id').append("<option value=" + val.id + ">" + val.city_name + "</option>");
                    });
                }
            });
        }

        // //editbutton 
        // function mgetstate(){
        //    var country = $("#mcountry").val();
        //     $.ajax({
        //         url: "<?php // base_url('getstate'); 
                            ?>",
        //         type: "POST",
        //         data: {
        //             country:country
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#state').html('');
        //             $('#city').html('');

        //             $('#city').append("<option value=''> -- Select City -- </option>");
        //             $('#state').append("<option>Select State</option>");

        //             $('#state').trigger("change");
        //             $('#city').trigger("change");

        //             $.each(res, function(key,val) {
        //                 $('#state').append("<option value="+val.id+">"+val.state_name+"</option>");
        //              });
        //         }
        //     });
        // }

        // function mgetcity_State(){
        //     var state = $("#state").val();
        //     $.ajax({
        //         url: "<?php // base_url('getcity'); 
                            ?>",
        //         type: "POST",
        //         data: {
        //             state:state
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#mcity').html('');
        //             $('#city').trigger("change");
        //             $('#mcity').append("<option>Select City</option>");
        //             $.each(res, function(key,val) {
        //                 $('#mcity').append("<option value="+val.id+">"+val.city_name+"</option>");
        //            }); 
        //         }
        //     });
        // }

        function fetch_positon() {
            var hr_id = $('#hrname').val();
            $.ajax({
                url: "<?= base_url('get_hr_id_position'); ?>",
                type: "POST",
                data: {
                    hr_id: hr_id
                },
                dataType: 'json',
                success: function(res) {
                    $('#hr_position').val(res).change();
                }
            });
        }
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>