<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Job Post/ Candidate/ job seeker</th>
                                                <th>Type</th>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Email</th>
                                                <th>Interview Round</th>
                                                <th>Salary</th>
                                                <th>Interview Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Job Post/ Candidate/ job seeker</th>
                                                <th>Type</th>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Email</th>
                                                <th>Interview Round</th>
                                                <th>Salary</th>
                                                <th>Interview Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    </div>
    <div id="manageInterviewRoundsModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="manageInterviewRoundsLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="manageInterviewRoundsLabel">Manage Interview Rounds</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="existingRoundsDiv" class="existing-rounds">
                        <h6>Existing Interview Rounds</h6>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Round</th>
                                    <th>Interviewer Name</th>
                                </tr>
                            </thead>
                            <tbody id="existingRounds">
                                <!-- Existing rounds will be populated here by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                    
                    <form id="interviewForm" method="post">
                        <div class="body">
                            <div class="row clearfix">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="round">Interview Round : <span style="color:red;">*</span></label><br>
                                        <input type="text" class="form-control" name="round" id="round" readonly>
                                        <span class="error_round text-danger"></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marks">Interviewer Name : <span style="color:red;">*</span></label><br>
                                        <select name="interviewers_id" id="interviewers_id" class="form-control select2">
                                            <option value="">-select names--</option>
                                            <?php if (!empty($getEmpList)) {
                                                foreach ($getEmpList as $emp) { ?>
                                                    <option value="<?= $emp['id'] ?>"><?= $emp['userfullname'] . ' ' . $emp['employeeId'] ?></option>
                                            <?php }
                                            } ?>
                                        </select>
                                        <span class="error_interviewers_id text-danger"></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="text-muted"> &nbsp; </label> <br>
                                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                        <input type="hidden" name="interview_id" id="interview_id" value="">
                                        <input class="btn btn-one" type="submit" value="Submit">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                    
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="interviewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Interview Round</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="RoundForm" method="post">
                    <div class="modal-body">
                        <input type="hidden" name="interview_id" id="interview_id" value="">
                        <div class="form-group">
                            <label for="interview_round">Interview Round:</label>
                            <input type="text" maxlength="1" class="form-control" name="interview_round" id="interview_round" required>
                            <span class="error_interview_round text-danger"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="selectionDecisionModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Selection Decision</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="selectionDecisionForm" method="post">
                    <div class="modal-body">
                        <div style="display:none;">
                            <input type="text" name="interview_id" id="selection_interview_id" value="">
                        </div>
                        <div class="form-group">
                            <label for="interviewers_mode">Selection Decision: <span style="color:red;">*</span></label> <br>
                            <input type="radio" name="selection_decision" id="selection_decision_1" value="1"> &nbsp; <label for="selection_decision_1">Not Suitable</label> &nbsp;
                            <input type="radio" name="selection_decision" id="selection_decision_2" value="2"> &nbsp; <label for="selection_decision_2">Reserve in databank</label> &nbsp;
                            <input type="radio" name="selection_decision" id="selection_decision_3" value="3"> &nbsp; <label for="selection_decision_3">Referred to other dept</label> &nbsp;
                            <input type="radio" name="selection_decision" id="selection_decision_4" value="4"> &nbsp; <label for="selection_decision_4">Suitable</label> &nbsp;
                            
                            <span class="error_selection_decision_id text-danger"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary sectiondecisonsubmit">Ok</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        var table;
        $(document).ready(function() {
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('list_interview_cvm_ajax'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                        
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                "columnDefs": [{
                    "targets": [0],
                    "orderable": false,
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            $('#btn-filter').click(function() {
                table.ajax.reload();
            });
            $('#btn-reset').click(function() {
                $('#form-filter')[0].reset();
                table.ajax.reload();
            });
        });

        $(document).ready(function() {
            $('#manageInterviewRoundsModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget); // Button that triggered the modal
                var interviewId = button.data('interview-id'); // Extract info from data-* attributes
                var modal = $(this);

                // Update the modal's hidden input with the interview ID
                modal.find('#interview_id').val(interviewId);
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            function fetchAndShowInterviewRound(interviewId) {
                $.ajax({
                    url: '<?= base_url("fetch_interview_round") ?>',
                    type: 'POST',
                    data: {
                        interview_id: interviewId,
                        <?= $this->security->get_csrf_token_name(); ?>: '<?= $this->security->get_csrf_hash(); ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            if (response.showForm) {
                                $('#interviewForm').show();
                            } else {
                                $('#interviewForm').hide();
                            }

                            if (response.round == 0) {
                                $('#interviewForm').hide();
                            }

                            $('#round').val(response.round);
                            $('#existingRounds').empty();

                            if (response.existing_rounds.length > 0) {
                                $('#existingRoundsDiv').show();
                                response.existing_rounds.forEach(function(round) {
                                    $('#existingRounds').append('<tr><td>' + round.round + '</td><td>' + round.userfullname + '</td></tr>');
                                });
                            } else {
                                $('#existingRoundsDiv').hide();
                            }

                            $('#manageInterviewRoundsModal').modal('show');
                        }
                    },
                    error: function(xhr, status, error) {
                        toastr.error('An error occurred while fetching interview round.');
                    }
                });
            }

            $('#manageInterviewRoundsModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var interviewId = button.data('interview-id');
                $(this).find('#interview_id').val(interviewId);
                fetchAndShowInterviewRound(interviewId);
            });

            $('#interviewForm').submit(function(event) {
                event.preventDefault();
                var form = $(this);

                $.ajax({
                    url: '<?= base_url("add_interview_round") ?>',
                    type: 'POST',
                    data: form.serialize(),
                    dataType: 'json',
                    success: function(response) {
                        $('.text-danger').text('');
                        if (response.success) {
                            // Fetch and show the next interview round
                            fetchAndShowInterviewRound($('#interview_id').val());
                            toastr.success('Interview round saved successfully!');
                        } else {
                            $.each(response.errors, function(key, val) {
                                $('.error_' + key).text(val);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred. Please try again.');
                    }
                });
            });

        });
    </script>

    <script>
        $(document).ready(function() {
            $('#interviewModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var interviewId = button.data('interview-round');
                $(this).find('#interview_id').val(interviewId);
                var interviewRound = button.text();
            });

            $('#RoundForm').on('submit', function(e) {
                e.preventDefault();

                $.ajax({
                    url: '<?= base_url("update_interview_round") ?>',
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 'success') {
                            toastr.success('Interview Round successfully updated!');
                            location.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function() {
                        toastr.error('An error occurred. Please try again.');
                    }
                });
            });
        });

        $(document).on("input", "#interview_round", function() {
            var validValues = ['1', '2', '3'];
            var currentValue = this.value;
            if (!validValues.includes(currentValue)) {
                $(this).val('');
            }
        });

        $(document).on('click','.selectionDecision',function(){
            var selection_interview_id = $(this).data('interview_id');
            
            $('#selection_interview_id').val(selection_interview_id);
            $('#selectionDecisionModel').modal('show');
        });

        $(document).on('click','.sectiondecisonsubmit',function(){
            $.ajax({
                url: '<?= base_url("update_selection_decision") ?>',
                type: 'POST',
                data: $('#selectionDecisionForm').serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status == 'success') {
                        toastr.success(response.message);
                        if(response.url != ''){
                            window.location.href=response.url;
                        } else {
                            location.reload();
                        }
                        
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() {
                    toastr.error('An error occurred. Please try again.');
                }
            });
        });
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>