<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Employeereport_model extends CI_Model {

    var $table = 'main_users as a';
    var $summery_table = 'main_employees_summary as b';
    var $salery_table = 'main_empsalarydetails as c';
    var $leave_table = 'main_employeeleaves as d';
    var $education_table = 'main_empeducationdetails as e';
    var $address_table = 'main_empcommunicationdetails as f';
    var $otherofficial_table = 'emp_otherofficial_data as g';
    var $personalinfo_table = 'main_emppersonaldetails as p';
    var $sal_increment_table = 'main_empsal_increment as h';
	
    var $column_order = array(null, 'a.employeeId', 'g.payrollcode', 'a.userfullname', 'p.father_nm', 'p.dob', 'p.genderid','b.position_name', 'b.department_name', 'g.sub_department', 'e.educationlevel', 'c.salary', 'a.contactnumber', 'a.company_nameid', 'a.emailaddress', 'b.businessunit_name'); //set column field database for datatable orderable
    var $column_search = array('g.payrollcode', 'f.perm_streetaddress', 'p.father_nm', 'b.position_name', 'g.sub_department', 'b.department_name', 'p.dob', 'p.genderid', 'f.current_streetaddress', 'b.businessunit_name', 'e.educationlevel', 'c.salary', 'a.contactnumber', 'a.company_nameid', 'a.userfullname', 'a.emailaddress', 'a.employeeId', 'b.businessunit_name'); //set column field database for datatable searchable 
    var $order = array('id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        if($this->input->post('businessunit_name')) {
            $this->db->where('b.businessunit_id', $this->input->post('businessunit_name'));
        }
        if($this->input->post('company_name')) {
            $this->db->like('g.company_name', $this->input->post('company_name'));
        }
	if($this->input->post('department_id')) {
            $this->db->where('b.department_id', $this->input->post('department_id'));
        }
	if($this->input->post('potion_design_id')) {
            $this->db->where('b.position_id', $this->input->post('potion_design_id'));
        }
        if($this->input->post('userfullname')) {
            $this->db->like('a.userfullname', $this->input->post('userfullname'));
        }
	if($this->input->post('email')) {
            $this->db->like('a.emailaddress', $this->input->post('email'));
        }
        if($this->input->post('contactnumber')) {
            $this->db->where('a.contactnumber', $this->input->post('contactnumber'));
        }
        if($this->input->post('salary')) {
            $this->db->like('c.salary', $this->input->post('salary'));
        }

        $this->db->select('a.*, p.father_nm, p.dob,p.genderid,h.empctc,h.grosssalary, b.selecteddate, b.years_exp,b.date_of_joining, b.businessunit_name,b.position_name,g.company_location, g.sub_department,g.on_project, b.department_name, g.reviewing_officer_ro, g.payrollcode, b.reporting_manager_name,c.salary,d.emp_leave_limit,d.used_leaves,e.educationlevel,f.perm_streetaddress, f.perm_pincode, f.current_streetaddress, f.current_country, f.current_state, f.current_city, f.current_pincode,ct.city_name,st.state_name,co.country_name, ctp.city_name as permcity,stp.state_name as permstate');
        $this->db->from($this->table);
         $this->db->where('a.isactive','1');
        $this->db->join($this->summery_table, 'a.id = b.user_id', 'left');
        $this->db->join($this->salery_table, 'a.id = c.user_id', 'left');
        $this->db->join($this->leave_table, 'a.id = d.user_id', 'left');
        $this->db->join($this->education_table, 'a.id = e.user_id', 'left');
        $this->db->join($this->address_table, 'a.id = f.user_id', 'left');
        $this->db->join($this->otherofficial_table, 'a.id = g.user_id', 'left');
        $this->db->join($this->personalinfo_table, 'a.id = p.user_id', 'left');
        $this->db->join($this->sal_increment_table, 'a.id = h.user_id', 'left');
        $this->db->join("tbl_cities as ct", 'f.current_city = ct.id', 'left');     
        $this->db->join("tbl_states as st", 'f.current_state = st.id', 'left');    
        $this->db->join("tbl_countries as co", 'f.current_country = co.id', 'left');		
        $this->db->join("tbl_cities as ctp", 'f.perm_city = ctp.id', 'left');
        $this->db->join("tbl_states as stp", 'f.perm_state = stp.id', 'left');
        $this->db->order_by("h.id", "desc");
        $this->db->group_by('a.id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    public function get_list_businessunit() {
        $this->db->select('*');
        $this->db->from('main_businessunits');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        $businessunit = array();
        foreach ($result as $row) {
            $businessunit[] = $row->unitname;
        }
        return $businessunit;
    }

    public function get_list_companyname() {
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where('is_active', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_educationcode() {
        $this->db->select('*');
        $this->db->from('main_educationlevelcode');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_bycompanyid($id) {
        $arr = array('id' => $id, 'is_active' => '1');
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where($arr);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result[0]->company_name;
    }

    public function getUsernameByID($id) {
        $arr = array('id' => $id, 'isactive' => '1');
        $this->db->select('*');
        $this->db->from('main_users');
        $this->db->where($arr);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

}
