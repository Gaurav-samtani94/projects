<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_Model extends CI_Model {

    var $table = 'main_employees_summary as a';
    var $column_order = array(null, 'a.employeeId','a.userfullname','a.jobtitle_name');
    var $column_search = array('a.employeeId','a.userfullname','a.jobtitle_name');
    var $order = array('a.user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        if($this->input->post('businessunit')){
            $this->db->where("a.businessunit_id", $this->input->post('businessunit'));
        }
        else{
            $this->db->where("a.businessunit_id",'1');
        }
        if($this->input->post('user_id')){
            $this->db->where("a.user_id", $this->input->post('user_id'));
        }
        if($this->input->post('departmentids')){
            $this->db->where("a.department_id", $this->input->post('departmentids'));
        }
        
        $this->db->select("a.user_id,a.employeeId,a.userfullname,b.payrollcode,a.businessunit_id,a.businessunit_name,a.department_id,a.department_name,a.position_name,a.jobtitle_name,d.city_name,b.machine_id,c.FirstIn,c.LastOut,b.shift_in_time,b.shift_out_time");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_otherofficial_data as b","b.user_id=a.user_id","left");
        $this->db->join("thumb_attendance as c","b.thumbcode=c.EmployeeID","left");
        $this->db->join("tbl_ofclocation as d","d.id=b.company_location","left");
        $this->db->join("main_users as e","e.id=a.user_id","left");
        $this->db->where(array('a.isactive'=>'1'));
        $this->db->where(array('e.isactive'=>'1'));
        // $this->db->where_in('a.user_id',[3220]);
        $this->db->where_not_in('a.user_id',[2,173,175,190]);
        // $this->db->order_by("a.jobtitle_id",'');
        $this->db->group_by('a.user_id');
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from('main_employees_summary');
        $this->db->where(array('main_employees_summary.isactive'=>'1','main_employees_summary.businessunit_id'=>'1'));
        $this->db->group_by('main_employees_summary.user_id');     
        return $this->db->count_all_results();
    }
    public function Get_Monthly_Attendance($to_date,$user_id,$dpt_id,$bus_id){
        $this->db->select("b.employeeId,b.userfullname,c.payrollcode,b.businessunit_name,b.department_name,b.position_name,b.jobtitle_name,d.city_name,c.machine_id,a.*");
        $this->db->from('monthly_attendance_report as a');
        $this->db->join("main_employees_summary as b","b.user_id=a.user_id","left");
        $this->db->join("emp_otherofficial_data as c","a.user_id=c.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.Year'=>date("Y", strtotime($to_date)),'a.Month'=>date("m", strtotime($to_date)),'a.isactive'=>'1'));
        $this->db->where_not_in('b.user_id',[2,173,175,190]);
        if ($user_id != ''):
            $this->db->where('a.user_id',$user_id);
        endif;
        if ($bus_id != ''):
            $this->db->where(array('a.B_unit_id' => $bus_id));
        endif;
        if ($dpt_id != ''):
            $this->db->where(array('a.department_id' => $dpt_id));
        endif;
        $this->db->group_by('a.user_id');
        $query = $this->db->get();
        return $query->result();
    }

}
