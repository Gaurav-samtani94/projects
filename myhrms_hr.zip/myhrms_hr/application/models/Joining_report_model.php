<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Joining_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    //Get Employee Details for joining report ..
    public function joining_details_current_month($from_date = '', $to_date = '') {
		$cur_month = date('Y-m-01');
        $this->db->select('a.userfullname,a.employeeId,a.date_of_joining,a.position_name,a.jobtitle_name,a.department_name,c.subdepartment,d.project_name,e.company_name,c.subdepartment,d.project_name,e.company_name');
        $this->db->from('main_employees_summary as a');
        $this->db->join('emp_otherofficial_data as b', "a.user_id=b.user_id", "LEFT");
        $this->db->join('main_subdepartments as c', "c.id=b.sub_department", "LEFT");
        $this->db->join('tm_projects as d', "d.id=b.on_project", "LEFT");
        $this->db->join('tbl_companyname as e', "e.id=b.company_name", "LEFT");
        $this->db->where(array("a.isactive" => "1"));
		if ($from_date && $to_date) {
            $this->db->where('date_of_joining >=', $from_date);
			$this->db->where('date_of_joining <=', $to_date);
        }
		else {
			$this->db->where("a.date_of_joining>=", $cur_month);
		}
        $RecRows = $this->db->get()->result();
		 // print_r($RecRows); die;
        return ($RecRows) ? $RecRows : null;
    }
	
	//Get Details of applied visiting card..
    public function GetDetailofappliedVisitingCard($userId) {
        $this->db->select('a.*,c.hod,b.sub_department,d.*');
        $this->db->from('hrm_visiting_card as a');
        $this->db->join('emp_otherofficial_data as b', "a.approved_by=b.user_id", "LEFT");
        $this->db->join('main_subdepartments as c', "b.sub_department=c.id", "LEFT");
        $this->db->join('main_employees_summary as d', "d.user_id=a.user_id", "LEFT");
        $this->db->where(array("a.user_id" => $userId,"a.is_active" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
	
	//Get Details of applied visiting card..
    public function GetDetailofappliedVisitingCard1($userId) {
        $this->db->select('a.*,c.hod,b.sub_department,d.*');
        $this->db->from('hrm_visiting_card as a');
        $this->db->join('emp_otherofficial_data as b', "a.approved_by=b.user_id", "LEFT");
        $this->db->join('main_subdepartments as c', "b.sub_department=c.id", "LEFT");
        $this->db->join('main_employees_summary as d', "d.user_id=a.user_id", "LEFT");
        $this->db->where_in("a.approved_by", $userId);
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
	
	//Get Details of applied visiting card..
    public function GetDetailofappliedVisitingCard_for_hr() {
		$status= array('1', '2','3');
        $this->db->select('a.*,c.hod,b.sub_department,d.*');
        $this->db->from('hrm_visiting_card as a');
        $this->db->join('emp_otherofficial_data as b', "a.approved_by=b.user_id", "LEFT");
        $this->db->join('main_subdepartments as c', "b.sub_department=c.id", "LEFT");
        $this->db->join('main_employees_summary as d', "d.user_id=a.user_id", "LEFT");
        $this->db->where(array("a.is_active" => "1"));
		$this->db->where_in('a.status', $status);
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
	
	//Insert All Master
    public function InsertData($recArr, $tablename) {
        if ($recArr && $tablename):
            return $this->db->insert($tablename, $recArr);
        else:
            return false;
        endif;
    }
	
	//Update Record..
    public function update_visitingcard_rqst($table, $Where, $data) {
		if($table && $Where && $data):
			$this->db->where($Where);
			return $this->db->update($table, $data);
		else:
			return false;
		endif;
    }

}

?>