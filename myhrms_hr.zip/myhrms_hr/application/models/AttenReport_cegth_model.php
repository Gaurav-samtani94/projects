<?php

class AttenReport_cegth_model extends CI_Model {

    var $table = 'main_employees_summary as a';
    var $other_table = 'emp_otherofficial_data as b';
    var $daily_table = 'daily_attendance_oct_report as c';
    var $company_location = 'tbl_ofclocation as d';
    var $column_order = array(null,null);
    var $column_search = array(null);
    var $order = array(null); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        if($this->input->post('businessunit_name')) {
            $this->db->where('a.businessunit_id', $this->input->post('businessunit_name'));
        }
        if($this->input->post('dept_name')) {
            $this->db->where('a.department_id', $this->input->post('dept_name'));
        }
       $this->db->select('b.payrollcode,d.city_name,a.userfullname,a.businessunit_name,a.employeeId,a.department_name,a.position_name,a.jobtitle_name,c.machine_id,c.shift_in_time,c.shift_out_time,c.user_id');
        $this->db->from($this->daily_table);
        $this->db->join($this->other_table,'b.user_id=c.user_id','left');
        $this->db->join($this->company_location,'d.id=b.company_location','left');
        $this->db->join($this->table, 'c.user_id=a.user_id','left');
        $this->db->where(array('a.isactive'=>'1','a.businessunit_id' => '2'));
        // $this->db->where_in('a.businessunit_id', ['1','2','3']);
        $this->db->where_not_in('c.user_id', ['2','173','175','190']);
        //$this->db->where_not_in('c.user_id', ['0']);
        $this->db->where('c.user_id IS NOT NULL', null, false);
        $this->db->group_by('c.machine_id');
        $this->db->order_by('a.department_id', 'ASC');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }


   public  function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
        //if ($recArr) {
            return $query->result();
        //}
    }

    public function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows(); 
    }

    public function count_all() {
         $this->db->from($this->daily_table);
         return $this->db->count_all_results();
    }
    
    
    

    public function GetShiftInTime($thumCode, $dateComb){
        $ymD = date("Y-m-d", strtotime($dateComb));
        $table_name = 'devicelogs_3_2021';
        $query = $this->db->query("SELECT TIME_FORMAT(`LogDate`, '%H:%i:%s') as InTime FROM $table_name WHERE (STR_TO_DATE(LogDate, '%Y-%m-%d')='$ymD') AND UserId='$thumCode' AND Direction='in' ORDER BY DeviceLogId ASC LIMIT 1");
        $InTimeOutArr = $query->row();
        return ($InTimeOutArr->InTime) ? $InTimeOutArr->InTime : "";
    }
    
    public function GetShiftOutTime($thumCode, $dateComb){
        $ymD = date("Y-m-d", strtotime($dateComb));
        $table_name = 'devicelogs_3_2021';
        $query = $this->db->query("SELECT TIME_FORMAT(`LogDate`, '%H:%i:%s') as OutTime FROM $table_name WHERE (STR_TO_DATE(LogDate, '%Y-%m-%d')='$ymD') AND UserId='$thumCode' AND Direction='out' ORDER BY DeviceLogId DESC LIMIT 1");
        $InTimeOutArr = $query->row();
        return ($InTimeOutArr->OutTime) ? $InTimeOutArr->OutTime : "";
    }
    
   //Check Is Holiday on a Particular Date..
    public function check_isholidays($actDate) {
        $this->db->select('holidayname');
        $this->db->from('main_holidaydates');
        $this->db->where(array('holidaydate' => $actDate, 'isactive' => '1', 'groupid' => '1'));
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? true : false;
    }

    //All Emp Leave
    public function all_emp_leaves($empId) {
        $this->db->select(array('from_date', 'to_date', 'leavestatus', 'leavetypeid','leaveday'));
        $this->db->from('main_leaverequest_summary');
        $this->db->where(array('user_id' => $empId, 'isactive' => '1'));
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? $recArr : false;
    }
    
   //All Tour
    public function getallTourDates($empid) {
        $this->db->select(array('start_date', 'end_date'));
        $this->db->from('emp_tourapply');
        $this->db->where(array('emp_id' => $empid, 'is_active' => '1'));
        $this->db->where('approved_bypmanager <', '2');
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? $recArr : false;
    }
    
     //Date Range Exist or Not a Particular Date ..
    public function check_in_range($start_date, $end_date, $date_from_user) {
        // Convert to timestamp
        $start_ts = strtotime($start_date);
        $end_ts = strtotime($end_date);
        $user_ts = strtotime($date_from_user);
        return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
    }
}

?>