<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Remark_BC_emplist_Appraisal_model extends CI_Model {

    var $table = 'appr_proj_formdata_bc as b';
    var $column_order = array(null, 'userfullname', 'employeeId');
    var $column_search = array('userfullname', 'employeeId');
    var $order = array('fld_id' => 'ASC'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        $user_id = $this->session->userdata('loginid');
		$this->db->select('b.*,d.user_id,d.userfullname,d.employeeId,d.jobtitle_name');
        $this->db->from($this->table);
        $this->db->join("main_employees_summary as d", "d.user_id=b.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as e", "e.user_id=b.user_id", "LEFT");
        $this->db->join("main_empsalarydetails as f", "f.user_id=b.user_id", "LEFT");
        $this->db->where(array("d.businessunit_id" => '3')); 
		if ($this->input->post('appr_session') and $this->input->post('appr_duedate')) {
			$this->db->where('b.session_appr_year', $this->input->post('appr_session'));

            $showDate = $this->input->post('appr_duedate');
            $monthFull = date("F",strtotime($showDate));
            $this->db->like('f.appraisalduedate', $monthFull, 'both');

			//$this->db->where('f.appraisalduedate', $this->input->post('appr_duedate')); 
        }else{
			$this->db->where('b.session_appr_year', '04-2024');
            $this->db->like('f.appraisalduedate', "April", 'both');
			//$this->db->where('f.appraisalduedate', 'April 2022');
			
		}
        $this->db->group_by('b.user_id');
		
			
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

}