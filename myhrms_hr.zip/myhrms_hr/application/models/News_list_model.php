<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class News_list_model extends CI_Model {
    
	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
	
    public function GetAllCompanyNews() {
        $this->db->select('a.*,b.news_category');
        $this->db->from('main_companynews as a');
		$this->db->join('news_category_master as b', "a.news_category=b.id", "LEFT");
		$this->db->order_by("a.id", "DESC");
		$this->db->where("a.is_active", "1");
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
	
	//Single Tour Details By ID..
    Public function GetSingleNewsDetailsByID($news_id) {
		$this->db->select('a.*,b.news_category as news_category_title');
        $this->db->from('main_companynews as a');
		$this->db->join('news_category_master as b', "a.news_category=b.id", "LEFT");
        $this->db->where("a.id",$news_id);
        $NewsRecord = $this->db->get()->row();
        return ($NewsRecord) ? $NewsRecord : null;
    }
	
	 public function GetAllCompanyNews_title() {
        $this->db->select('title,Expiry_date,doc_file');
        $this->db->from('main_companynews');
		$this->db->where("is_active", "1");
		$this->db->order_by("id", "DESC");
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
	
  
}
