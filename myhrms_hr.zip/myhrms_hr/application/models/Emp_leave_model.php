<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_leave_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    //Get Employee Details for joining report ..
    public function get_employee_leave_data()
    {
        $this->db->select('data.from_date as f_date,data.to_date as t_date,user.businessunit_id as business_id,user.employeeId as emp_id,user.userfullname as username,user.jobtitle_name as title_name,data.leaveday as nofday,data.leavestatus as lstatus,user.businessunit_name as busname');
        $this->db->from('main_leaverequest as data');
        $this->db->join('main_employees_summary as user', 'data.user_id = user.user_id', 'LEFT');
        $data  = $this->db->get()->result();

        return $data;
    }
    public function ActiveEmployeedata()
    {
        $this->db->select('*');
        $this->db->from('main_employees_summary');
        $this->db->where('isactive', 1);
        $data = $this->db->get()->result();
        return $data;
    }
    public function ActiveEmployefloar()
    {
        $today_dateM = date("Y-m-d"); //DeviceLogs_Processed
        // print_r($today_dateM);
        $this->db->select('max(a.LogDate) as log,a.UserId');
        $this->db->from('DeviceLogs_Processed as a');

        $this->db->where('date(a.LogDate)', $today_dateM);

        $this->db->order_by("a.LogDate");
        $this->db->group_by('a.UserId');

        $data  = $this->db->get()->result();
        $result = array();
        foreach ($data as $d) {
            $this->db->select('a.UserId as userids,b.floor_number as flor,a.Direction as Directions,d.jobtitle_id as jobtitid');
            $this->db->from('DeviceLogs_Processed as a');
            $this->db->join('emp_otherofficial_data as b', 'b.user_id=a.UserId', 'LEFT');
            $this->db->join('main_users as d', 'd.id=a.UserId', 'LEFT');
            $this->db->where('a.UserId', $d->UserId);
            $this->db->where('a.LogDate', $d->log);
            // $this->db->where('b.floor_number', $floorid);
            // $this->db->where('d.jobtitle_id', $grade);
            $resu = $this->db->get()->row();
            if ($resu) {
                $result[] = $resu;
            }
        }
        // $rs = count($result);
        // echo "<pre>";
        // print_r($result);
        // die();
        return $result;
        // $this->db->select('reporting_manager.prefix_name as prefx,user.*,b.thumbcode,b.payroll_with_name,b.machine_id');
        // $this->db->from('main_employees_summary as user');
        // $this->db->join("main_employees_summary reporting_manager", "reporting_manager.user_id=user.reporting_manager", "LEFT");
        // $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        // $this->db->where(array("user.isactive" => "1"));
    }
}
