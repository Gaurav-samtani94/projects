<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Live_atten_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
	
	//Get Employee present today...
    public function live_atten_report_ceg_busunit($id) {
		$today = date("Y-m-d"); 
		$this->db->select("c.UserId");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1","a.businessunit_id" => $id));
        $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
    //Get Employee present today...
    public function live_atten_report_ceg($id) {
		$today = date("Y-m-d"); 
		$this->db->select("c.UserId");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1","b.company_location" => $id));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        // $recArr = $this->db->get()->result();
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	//Get Employee present today...
    public function live_atten_report_graph($cid) {
		$today = date("Y-m-d"); 
		$this->db->select("c.LogDate");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1",'b.company_location'=>$cid));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '0';
    }
	

	public function getTotalActiveEmployeeCeg($cId){
		$bid =array('1','2');
		$this->db->select('a.*');
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->where(array('a.isactive' => '1', 'b.company_location' => $cId));
		$this->db->where_in('a.businessunit_id',$bid);
		$this->db->group_by("b.user_id");
        $result = $this->db->get()->num_rows();
		// $resultCount = count($result);
		return isset($result) ? $result : '0';
	}
	
	
	public function getTotalTimeLateEmployeeCeg($user_id){
		$today = date("Y-m-d"); 
		$this->db->select("c.LogDate,b.user_id");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1","b.user_id" => $user_id));
        $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : null;
	}

	public function update_machineId_offical_data(){
		  /*$this->db->select("EmployeeID,EnrollNo");
		  $this->db->from('temp_machine_atten');
		  $dataArr = $this->db->get()->result();
		  // return ($dataArr) ? $dataArr : '0';
		  
		  // $varArrSrt='';
		  // $varArr = array();
		  // $varArr2 = array();
		  // if ($dataArr) {
			foreach ($dataArr as $kkEy => $rEcd) {
				$Where = 'thumbcode='.$rEcd->EmployeeID;
				$data = array(
					'machine_id' => $rEcd->EnrollNo,
				);
				$this->db->where($Where);
				return $this->db->update('emp_otherofficial_data', $data);
				
			}
		  // }
			// print_r($dataArr); die;
		  // $arrList = explode(",", $varArrSrt);
		  // $arrList2 = array_filter($arrList);
		  // $arrList3 = array_unique($arrList2);
		
		  // if (count($arrList3) > 0) {
			// $this->db->select("id,client_name");
			// $this->db->from('cegth_clients');
			// $this->db->where_in('id', $arrList3);
			// $this->db->where('status', '1');
			// $RecordData = $this->db->get()->result();
		   // }
		  // echo $RecordData;
		  */
	}
	public function ActiveEmployeedata()
    {
        $this->db->select("count(user_id)");
        $this->db->from('main_employees_summary');
        $this->db->where('isactive', "1");
		 $this->db->group_by("user_id");
        $data = $this->db->get()->num_rows();
		// epd($data);
        return $data;
    }
	public function InActiveEmployeedata()
    {
        $this->db->select("count(user_id)");
        $this->db->from('main_employees_summary');
        $this->db->where('isactive', "0");
		 $this->db->group_by("user_id");
        $data = $this->db->get()->num_rows();
        return $data;
    }
	 public function get_employee_leave_data()
    {
        $this->db->select("count(data.user_id)");
        $this->db->from('main_leaverequest as data');
        $this->db->join('main_employees_summary as user', 'data.user_id = user.user_id', 'LEFT');
		$this->db->where("data.to_date >=", date("Y-m-d"));
		$this->db->where("data.from_date <=", date("Y-m-d"));  
		$this->db->where("data.isactive", "1"); 
		$this->db->where('user.isactive', "1"); 
		$this->db->group_by("data.user_id");
        $data  = $this->db->get()->num_rows();
		// epd($data);
        return $data;
    }
}

?>