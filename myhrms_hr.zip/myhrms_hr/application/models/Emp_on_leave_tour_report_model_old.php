<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_on_leave_tour_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
	
	public function tour_atten_report_ceg() {
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.start_date,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_tourapply as b","a.user_id=b.emp_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','start_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '0';
    }
	     
	public function leave_atten_report_ceg1() {
		$today = date("Y-m-d"); 
		$this->db->select("b.leaveday,d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.leavestatus,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_leaverequest as b","a.user_id=b.user_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','b.from_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '0';
    }
	
	


}

?>