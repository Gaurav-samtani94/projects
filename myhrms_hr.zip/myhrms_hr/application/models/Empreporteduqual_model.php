<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Empreporteduqual_model extends CI_Model {

    var $table = 'main_users as a';
    var $summery_table = 'main_employees_summary as b';
    var $education_table = 'main_empeducationdetails as e';
    var $otherofficial_table = 'emp_otherofficial_data as g';
    var $educationlevel = 'main_educationlevelcode as v';
    var $column_order = array(null, 'g.payrollcode', 'a.userfullname', 'b.position_name', 'b.department_name', 'g.sub_department', 'e.educationlevel', 'a.contactnumber', 'a.company_id', 'a.emailaddress', 'a.employeeId', 'b.businessunit_name', 'v.educationlevelcode', 'e.institution_name', 'e.coursetype_id', 'e.spc_location', 'e.specialization', 'e.from_date', 'e.percentage');
    var $column_search = array('g.payrollcode', 'b.position_name', 'g.sub_department', 'b.department_name', 'b.businessunit_name', 'e.educationlevel', 'a.contactnumber', 'a.company_id', 'a.userfullname', 'a.emailaddress', 'a.employeeId', 'b.businessunit_name', 'v.educationlevelcode', 'e.institution_name', 'e.coursetype_id', 'e.spc_location', 'e.specialization', 'e.from_date', 'e.percentage');
    var $order = array('a.userfullname' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
		

        $this->db->select('a.*,b.date_of_joining, b.businessunit_name,b.position_name,g.company_location, g.sub_department,g.on_project, b.department_name, g.reviewing_officer_ro, g.payrollcode,b.reporting_manager_name,e.educationlevel,v.educationlevelcode,e.institution_name,e.coursetype_id,e.spc_location,e.specialization,e.from_date,e.percentage');
        $this->db->from($this->table);
        $this->db->where('a.isactive', '1');
        $this->db->join($this->summery_table, 'a.id = b.user_id', 'left');
        $this->db->join($this->education_table, 'a.id = e.user_id', 'left');
        $this->db->join($this->otherofficial_table, 'a.id = g.user_id', 'inner');
        $this->db->join($this->educationlevel, 'e.educationlevel = v.id', 'left');
       // $this->db->or_where('e.isactive', '1');
		//$this->db->like('a.userfullname', 'Abdul Rasheed');
        // $this->db->order_by('b.userfullname', 'ASC');
        // $this->db->limit(1, 0);
		if ($this->input->post('businessunit_name')) {
            $this->db->where('b.businessunit_id', $this->input->post('businessunit_name'));
        }
        if ($this->input->post('company_id')) {
            $this->db->like('a.company_id', $this->input->post('company_id'));
        }
        if ($this->input->post('department_id')) {
            $this->db->where('b.department_id', $this->input->post('department_id'));
        }
        if ($this->input->post('potion_design_id')) {
            $this->db->where('b.position_id', $this->input->post('potion_design_id'));
        }
        if ($this->input->post('from_date') and $this->input->post('to_date')) {
            $fromdate = date("Y-m-d", strtotime($this->input->post('from_date')));
            $todate = date("Y-m-d", strtotime($this->input->post('to_date')));
            $this->db->where('b.date_of_joining >=', $fromdate);
            $this->db->where('b.date_of_joining <=', $todate);
        }
	    if ($this->input->post('userfullname')) {
            $this->db->like('a.userfullname', $this->input->post('userfullname'));
        }
        $this->db->group_by('e.id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
         $this->_get_datatables_query();
         $query = $this->db->get();
         return $query->num_rows();
    }

    public function count_all() {
         $this->db->from($this->table);
        return $this->db->count_all_results();

    }

}
