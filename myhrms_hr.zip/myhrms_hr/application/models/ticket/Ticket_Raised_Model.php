<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ticket_Raised_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
         $this->db1 = $this->load->database('default', TRUE);//sentrifugo
		$this->db2 = $this->load->database('default', TRUE);
		$this->db3 = $this->load->database('accdept_db', TRUE);
    }


    public function GetAllInboxMessage($idArr){
        if($idArr){
         $userId=$this->session->userdata('loginid');
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,$db1.b.c_name");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->join("$db1.tick_ticket_category_master as b","$db1.a.category_id=$db1.b.fld_id", "LEFT");
        $this->db->where("$db1.a.status", "1");
         $this->db->where("$db1.a.parent_id", "0");

        if($this->session->userdata('assign_role')!='1'):
          $this->db->where_in("$db1.a.category_id", $idArr);
        endif;

        // $this->db->ORDER_BY("$db1.a.fld_id", "DESC");
        $this->db->ORDER_BY("$db1.a.entry_date", "DESC");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }

     }
     public function GetAllCategoryWiseInboxMessage($categoryid){
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,$db1.b.c_name");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->join("$db1.tick_ticket_category_master as b","$db1.a.category_id=$db1.b.fld_id", "LEFT");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.category_id", $categoryid);
        $this->db->where("$db1.a.parent_id", "0");
        $this->db->group_by("$db1.a.entry_by");
        $this->db->ORDER_BY("$db1.a.fld_id", "DESC");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
     }
     public function GetAllTicketHistory($ticktId)
     {
         $db1 = $this->db1->database;
         $this->db->select("$db1.a.*,b.userfullname,b.department_name,b.employeeId,$db1.c.c_name");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->join("$db1.main_employees_summary as b", "$db1.b.user_id=$db1.a.entry_by", "left");
         $this->db->join("$db1.tick_ticket_category_master as c", "$db1.a.category_id=$db1.c.fld_id", "left");
        $this->db->where("$db1.a.entry_by", $ticktId);
        $this->db->where("$db1.a.parent_id", '0');
        $this->db->where("$db1.a.status", "1");
         $this->db->order_by("$db1.a.fld_id", "DESC");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }
    public function GetStatusCountBYId($countid)
    {
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.entry_by");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.tick_status", "1");
        $this->db->where("$db1.a.entry_by", $countid);
        $Allrecord=$this->db->get()->num_rows();
        return ($Allrecord) ? $Allrecord : "0";
    }
     public function GetprogressCountBYId($countid)
    {
         $db1 = $this->db1->database;
       $this->db->select("$db1.a.entry_by");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.tick_status", "2");
        $this->db->where("$db1.a.entry_by", $countid);
        $Allrecord=$this->db->get()->num_rows();
        return ($Allrecord) ? $Allrecord : "0";
    }
     public function GetcloseCountBYId($countid)
    {
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.entry_by");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.tick_status", "3");
        $this->db->where("$db1.a.entry_by", $countid);
        $Allrecord=$this->db->get()->num_rows();
        return ($Allrecord) ? $Allrecord : "0";
    }

    public function GetAllInProgressMessage($ticktId)
     {
         $db1 = $this->db1->database;
         $this->db->select("$db1.a.*");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->where("$db1.a.entry_by", $ticktId);
        $this->db->where("$db1.a.parent_id", '0');
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.tick_status", "2");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }
   
     public function GetuserNameById($uid)
  {
     $db1 = $this->db1->database;
    $this->db->select("$db1.a.userfullname");
    $this->db->from("$db1.main_employees_summary as a");
    $this->db->where("$db1.a.user_id", $uid);
    $recordList = $this->db->get()->row();
    return ($recordList) ? $recordList : null;
  }
  public function GetuserById($chat_id)
  {
    $db1 = $this->db1->database;
    $this->db->select("$db1.a.userfullname");
    $this->db->from("$db1.main_employees_summary as a");
    $this->db->where("$db1.a.user_id", $chat_id);
    $recordList = $this->db->get()->row();
    return ($recordList) ? $recordList : null;
  }
    public function GetAllusermessage($userid)
     {
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,$db1.b.userfullname");
        $this->db->from("$db1.hrchat_message as a");
         $this->db->join("$db1.main_employees_summary as b", "$db1.b.user_id=$db1.a.entry_by", "left");
        $this->db->where("$db1.a.from_user_id", $userid);
          $this->db->or_where("$db1.a.to_user_id", $userid);
         $this->db->where("$db1.a.status", "Yes");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }
    public function AllReplyParentMessage($id)
    {

         $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,b.userfullname");
        $this->db->from("$db1.tick_ticket_raise as a");
         $this->db->join("$db1.main_employees_summary as b","$db1.a.entry_by=$db1.b.user_id","left");
        $this->db->where("$db1.a.fld_id", $id);
        $recordList = $this->db->get()->row();
        //epd($recordList);
        return ($recordList) ? $recordList : null;
    }
     public function AllReplyChildMessage($id)
    {

         $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,b.userfullname");
        $this->db->from("$db1.tick_ticket_raise as a");
         $this->db->join("$db1.main_employees_summary as b","$db1.a.entry_by=$db1.b.user_id","left");
        $this->db->where("$db1.a.parent_id", $id);
        $recordList = $this->db->get()->result();
        //epd($recordList);
        return ($recordList) ? $recordList : null;
    }
    public function GetChildUserPic($picid)
    {
        //$id = $this->session->userdata('loginid');
        $this->db->select('user.*,b.thumbcode,b.payroll_with_name');
        $this->db->from('main_employees_summary as user');
        $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->where(array("user.user_id" => $picid, "user.isactive" => "1"));
        $RecSingleRow = $this->db->get()->row();
        //epd($RecSingleRow);
        return ($RecSingleRow) ? $RecSingleRow : null;
    }
    // 20-07-2022 vivek
    public function GetAllInboxCategory($userId){
       // epd($userId);
        if($userId != 1){
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.category_id,$db1.b.c_name,$db1.b.fld_id");
        $this->db->from("$db1.hr_person_assign_to_category as a");
         $this->db->join("$db1.tick_ticket_category_master as b", "$db1.a.category_id=$db1.b.fld_id", "LEFT");
        $this->db->where("$db1.a.hruser_id",$userId);
         $this->db->where("$db1.a.status", "1");
        $Allrecord=$this->db->get()->result();
         return ($Allrecord) ? $Allrecord : "NUll";
        $Allrecord=$this->db->get()->result();
        }else{
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.category_id,$db1.b.c_name,$db1.b.fld_id");
        $this->db->from("$db1.tick_ticket_raise as a");
        $this->db->join("$db1.tick_ticket_category_master as b","$db1.a.category_id=$db1.b.fld_id", "LEFT");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.category_id !=", "0");
        $this->db->group_by("$db1.a.category_id");
        $Allrecord=$this->db->get()->result();
         return ($Allrecord) ? $Allrecord : "NUll";
        }
       
     }
     public function GetAllInboxCategoryId($id){
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.c_name,$db1.a.fld_id");
        $this->db->from("$db1.tick_ticket_category_master as a");
        // $this->db->join("$db1.tick_ticket_category_master as b","$db1.a.category_id=$db1.b.fld_id", "LEFT");
        $this->db->where("$db1.a.status", "1");
        $this->db->where("$db1.a.fld_id",$id);
        $Allrecord=$this->db->get()->result();
         return ($Allrecord) ? $Allrecord : "NUll";
     }
     public function GetAllCategoryId($id=''){
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.category_id");
        $this->db->from("$db1.hr_person_assign_to_category as a");
        $this->db->where("$db1.a.status", "1");
        if($this->session->userdata('assign_role')!='1'):
          $this->db->where("$db1.a.hruser_id",$id);
        endif;
        $Allrecord=$this->db->get()->result();
         return ($Allrecord) ? $Allrecord : "0";

     }
  

}