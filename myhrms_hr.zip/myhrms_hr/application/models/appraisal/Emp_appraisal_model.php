<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_appraisal_model extends CI_Model {

    var $table = 'main_users as a';
    var $summery_table = 'main_employees_summary as b';
    var $column_order = array(null, 'a.userfullname', 'a.firstname');
    var $column_search = array('a.userfullname', 'a.firstname');
    var $order = array('a.userfullname' => 'ASC');

    public function __construct() {
        parent::__construct();
        $this->load->database();
        
        $ApprSessionRecd = GetLastApprSession();
        $this->AppraisalFullMonth = date('F Y',strtotime($ApprSessionRecd->cycle_date));
        $this->AppraisalDate = date('Y-m-d',strtotime($ApprSessionRecd->cycle_date));
    }

    private function _get_datatables_query() {

        $appr_sessionid = $this->input->post('appr_sessionid');

        $this->db->select("d.appraisalduedate,a.userfullname,a.employeeId,b.date_of_joining,b.businessunit_name,b.department_name,b.reporting_manager_name,a.id,c.id as apprsession");
        $this->db->from($this->table);
        $this->db->join($this->summery_table, 'a.id = b.user_id', 'LEFT');
        $this->db->join("appr_mail_appraisal as c", "(a.id = c.emp_id AND c.appraisal_cycle_id=$appr_sessionid)", 'LEFT');
        $this->db->join("main_empsalarydetails as d", "a.id=d.user_id", "LEFT");
        $this->db->like('b.businessunit_id','1');
        

        $this->db->where('a.id!=', '1');
        $this->db->where('a.id!=', '2');
        $this->db->where('a.id!=', '173');
        $this->db->where('a.id!=', '175');
        $this->db->where('a.id!=', '190');
        $this->db->where('a.isactive', '1');
        $this->db->where("(d.appraisalduedate='$this->AppraisalFullMonth')", NULL, FALSE);

        $this->db->order_by('a.id', 'ASC');
        $this->db->group_by('a.id');

        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }

        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    //code by durgesh for get all active project
    public function GetAllproject() {
        $this->db->select('id,project_name');
        $this->db->from('tm_projects');
        $this->db->where('is_active', '1');
        $this->db->order_by('project_name', 'ASC');
        $this->db->group_by('project_name');
        $result = $this->db->get()->result();
        if ($result) {
            return ($result) ? $result : '';
        }
    }

}
