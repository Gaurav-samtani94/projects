<?php

error_reporting(1);
defined('BASEPATH') or exit('No direct script access allowed');

class Todaybirthday_model extends CI_Model
{

    // var $table = 'tm_projects as a';
    // var $column_order = array(null, 'project_name');
    // var $column_search = array('project_name');
    // var $order = array('id' => 'DESC'); // default order 

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function Gettodaybirthday()
    {


        $today_date = date('m-d');
        // epd($today_date);
        // $date = strtotime($recArr[0]['dob']);
        // echo date('m-d', $date);


        $this->db->select('a.user_id,a.dob,b.department_name,b.position_name,b.userfullname,b.contactnumber');
        $this->db->from('main_emppersonaldetails as a');
        $this->db->join('main_employees_summary as b', 'a.user_id = b.user_id', 'left');
        $this->db->where('DATE_FORMAT(a.dob,"%m-%d")', $today_date);

        $this->db->where(array('b.isactive' => 1));
        $this->db->order_by('b.userfullname', "ASC");
        // $this->db->where('approved_bypmanager <', '2');
        $recArr = $this->db->get()->result_array();


        // epd($recArr);
        return ($recArr) ? $recArr : false;
    }
    public function getEmployeeemaildata()
    {


        $today_date = date('m-d');
        $this->db->select('a.user_id,a.dob,b.department_name,b.position_name,b.userfullname,b.contactnumber');
        $this->db->from('main_emppersonaldetails as a');
        $this->db->join('main_employees_summary as b', 'a.user_id = b.user_id', 'left');
        $this->db->where('DATE_FORMAT(a.dob,"%m-%d")', $today_date);
        $this->db->where(array('b.isactive' => 1));
        $this->db->order_by('b.userfullname', "ASC");
        // $this->db->where('approved_bypmanager <', '2');
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? $recArr : false;
    }

    public function getEmployeeemail()
    {
        $this->db->select('a.user_id,a.emailaddress');
        $this->db->from('main_employees_summary as a');
        $this->db->where(array('a.isactive' => 1));
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
}
