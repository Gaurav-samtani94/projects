<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Assissment_model extends CI_Model {

    var $table = 'assessment_assign_fin as a';
    var $column_order = array(null, 'employeeId','userfullname');
    var $column_search = array('employeeId','userfullname');
    var $order = array('a.user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->db3 = $this->load->database('accdept_db', TRUE);

    }

    private function _get_datatables_query() {
        $db3 = $this->db3->database;
        // if($this->input->post('atten_report')){
        //     $ymd = date('Y-m-d', strtotime($this->input->post('atten_report')));
        //     $this->db->where("date_format(STR_TO_DATE(c.FirstIn, '%m/%d/%Y'),'%Y-%m-%d') =",$ymd);
        // }
        // if($this->input->post('atten_jobtitle')){
        //     $this->db->where("a.jobtitle_id", $this->input->post('atten_jobtitle'));
        // }
		
		// if($this->input->post('atten_busintitle')){
        //     $this->db->where("a.businessunit_id", $this->input->post('atten_busintitle'));
        // }
    
        $this->db->select("c.userfullname,c.employeeId,b.assisment_question,d.slot_name");
        $this->db->from("assessment_assign_fin as a");
        $this->db->join("main_users as c","c.id=a.user_id","LEFT");
        $this->db->join("assesment_tbl as b","b.id=a.assissment_id","LEFT");
        $this->db->join("$db3.financial_year_slot as d","d.fld_id=a.financial_year_id","LEFT");
        // $this->db->join("emp_otherofficial_data as b","b.user_id=a.user_id","left");
        // $this->db->join("thumb_attendance as c","b.thumbcode=c.EmployeeID","left");
        // $this->db->join("tbl_ofclocation as d","d.id=b.company_location","left");
        // $this->db->where(array('a.isactive'=>'1'));
        // $this->db->order_by("a.jobtitle_id",'ASC');
        // $this->db->group_by('a.user_id');
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from('main_employees_summary');
        return $this->db->count_all_results();
    }
    public function get_all_employess()
    {
        $this->db->select("b.id,b.userfullname,b.employeeId");
        $this->db->from("main_employees_summary as a");
        $this->db->join("main_users as b","b.id=a.user_id","LEFT");
        $this->db->where("a.isactive",'1');
        $result = $this->db->get()->result();
        return $result?$result:'';
    

    }
    public function get_all_assesment()
    {
        $this->db->select("*");
        $this->db->from("assesment_tbl");
        $this->db->where("is_active",'1');
        $data  = $this->db->get()->result();
        return $data?$data:'';
    }
    public function financial_year_slot()
    {
        $db3 = $this->db3->database;
        $this->db->select("*");
        $this->db->from("$db3.financial_year_slot");
        $this->db->where("status",'1');
        $data  = $this->db->get()->result();
        return $data?$data:'';
    }
    public function assign_assessment_parametter($input)
    {

        // print_R($input);
        // die();
        $ins_array = array("user_id"=>$input['user_id'],"assissment_id"=>$input['assessment_id'],"financial_year_id"=>$input['financial_year']);
        $return =  $this->db->insert("assessment_assign_fin",$ins_array);
        return $return;

    }

}
