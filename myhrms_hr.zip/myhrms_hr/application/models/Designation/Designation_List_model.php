
<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Designation_List_model extends CI_Model
{

    var $table = 'main_positions as a';
    var $column_order = array('a.positionname');
    var $column_search = array('a.positionname');
    var $order = array('a.id' => 'asc'); // default order 

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query()
    {
        // $user_id = $this->session->userdata('loginid');

        $this->db->select('a.*,b.jobtitlename');
        $this->db->from("main_positions as a");
        $this->db->join("main_jobtitles as b", "b.id=a.jobtitleid", "LEFT");
        $this->db->where(array("a.isactive" => '1'));
        // $this->db->group_by('a.emp_id');
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables()
    {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    public function AdddDesignation($position_name, $jobtitle, $description, $createdby)
    {
        $date = date("Y-m-d h:i:s");
        $array = array(
            'positionname' => $position_name,
            'jobtitleid' => $jobtitle,
            'description' => $description,
            'createdby' => $createdby,
            'isactive' => 1,
            'createddate' => $date
        );
        // print_R($array);
        $data = $this->db->insert('main_positions', $array);
        return ($data);
    }
    public function editdesignation($position)
    {
        $this->db->select('*');
        $this->db->from('main_positions');
        $this->db->where('id', $position);
        $data = $this->db->get()->row();
        return $data;
    }
    public function updatedesignation($posid, $posi_name, $jobtitle, $description)
    {
        $date = date("Y-m-d h:i:s");
        $modifiedby = $this->session->userdata('loginid');
        $upArray = array(
            'positionname' => $posi_name,
            'jobtitleid' => $jobtitle,
            'description' => $description,
            'modifiedby' => $modifiedby,
            'modifieddate' => $date
        );
        $this->db->where('id', $posid);
        $return = $this->db->update('main_positions', $upArray);
        return $return;
    }
}
