<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Designation_Model extends CI_Model
{

    var $table = 'accountinfo as a';

    public function __construct()
    {
        parent::__construct();
        $this->db1 = $this->load->database('online', TRUE);
        $this->db2 = $this->load->database('default', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }
    public function index()
    {
    }
}
    //Check Designation Existance..
//     public function checkexist($tableName, $whereArr)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;
//         $this->db->where($whereArr);
//         $num = $this->db->count_all_results($tableName);
//         return ($num) ? $num : null;
//     }

//     public function getallprojaccountinfo()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.accountinfo.project_id,$db2.tm_projects.project_name,$db2.tm_projects.id");
//         $this->db->from("$db1.accountinfo");
//         $this->db->join("$db2.tm_projects", "$db1.accountinfo.project_numberid=$db2.tm_projects.id", "LEFT");
//         $this->db->where(array("$db1.accountinfo.status" => '1'));
//         $this->db->order_by("$db2.tm_projects.project_name", "ASC");
//         $this->db->group_by("$db2.tm_projects.id");
//         $projListArr = $this->db->get()->result();
//         return ($projListArr) ? $projListArr : null;
//     }

//     public function getall_reimbursablelist()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.reimburs_category_master.id,$db3.reimburs_category_master.type");
//         $this->db->from("$db3.reimburs_category_master");
//         $this->db->where(array("$db3.reimburs_category_master.status" => '1'));
//         $this->db->order_by("$db3.reimburs_category_master.type", "ASC");
//         $this->db->group_by("$db3.reimburs_category_master.id");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     //Get All Designation Category Master..
//     public function getall_designationcatlist()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db2->database;

//         $this->db->select("$db1.designationcat_master.k_id,$db1.designationcat_master.ktype_name");
//         $this->db->from("$db1.designationcat_master");
//         $this->db->where(array("$db1.designationcat_master.status" => '1'));
//         $this->db->order_by("$db1.designationcat_master.ktype_name", "ASC");
//         $this->db->group_by("$db1.designationcat_master.k_id");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     //Get All reimbursable on Project..
//     public function getallreimbursableonproject($tsProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.reimburs_category_master.type");
//         $this->db->from("$db3.acc2_reimbursable_assign");
//         $this->db->join("$db3.reimburs_category_master", "$db3.acc2_reimbursable_assign.reim_type_id=$db3.reimburs_category_master.id", "LEFT");
//         $this->db->where(array("$db3.acc2_reimbursable_assign.ts_projid" => $tsProjID, "$db3.acc2_reimbursable_assign.status" => '1'));
//         $recListArr = $this->db->get()->result();
//         $arrRecd = array();
//         if ($recListArr) {
//             foreach ($recListArr as $recList) {
//                 $arrRecd[] = $recList->type;
//             }
//         }
//         return ($arrRecd) ? implode(" ,<br> ", $arrRecd) : null;
//     }

//     //Designation Category String 
//     public function getalldesignationcategonproject($tsProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.designationcat_master.ktype_name");
//         $this->db->from("$db3.acc2_designcateg_assign");
//         $this->db->join("$db1.designationcat_master", "$db3.acc2_designcateg_assign.desigcat_id=$db1.designationcat_master.k_id", "LEFT");
//         $this->db->where(array("$db3.acc2_designcateg_assign.ts_projid" => $tsProjID, "$db3.acc2_designcateg_assign.status" => '1'));
//         $recListArr = $this->db->get()->result();

//         $arrRecd = array();
//         if ($recListArr) {
//             foreach ($recListArr as $recList) {
//                 $arrRecd[] = $recList->ktype_name;
//             }
//         }
//         return ($arrRecd) ? implode(" ,<br> ", $arrRecd) : null;
//     }

//     public function getalldesigncategontsprojid($tsProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db2->database;

//         $this->db->select("$db3.acc2_designcateg_assign.desigcat_id,$db1.designationcat_master.ktype_name");
//         $this->db->from("$db3.acc2_designcateg_assign");
//         $this->db->join("$db1.designationcat_master", "$db3.acc2_designcateg_assign.desigcat_id=$db1.designationcat_master.k_id", "LEFT");
//         $this->db->where(array("$db3.acc2_designcateg_assign.bd_projid" => $tsProjID, "$db3.acc2_designcateg_assign.status" => '1'));
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     //Get Designation Category Name By Id .. 
//     public function getDesignCategNameById($desCategid)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.designationcat_master.ktype_name");
//         $this->db->from("$db1.designationcat_master");
//         $this->db->where(array("$db1.designationcat_master.k_id" => $desCategid, "$db1.designationcat_master.status" => '1'));
//         $recListArr = $this->db->get()->row();
//         return ($recListArr->ktype_name) ? $recListArr->ktype_name : null;
//     }

//     //GetAll DEsignation List By Designation Category
//     public function GetAllDesignListByDesigCategID($desigCategId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.designation_master_requisition.designation_name,$db1.designation_master_requisition.fld_id");
//         $this->db->from("$db1.designation_master_requisition");
//         $this->db->where(array("$db1.designation_master_requisition.cat_id" => $desigCategId, "$db1.designation_master_requisition.is_active" => '1'));
//         $this->db->order_by("$db1.designation_master_requisition.designation_name", "ASC");
//         $this->db->group_by("$db1.designation_master_requisition.designation_name");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     //Company List On A particular Project
//     public function GetAllCompanyonProj($bdProjId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.jv_cegexp.base_comp_id,$db1.jv_cegexp.lead_comp_id,$db1.jv_cegexp.joint_venture,$db1.jv_cegexp.asso_comp");
//         $this->db->from("$db1.jv_cegexp");
//         $this->db->where(array("$db1.jv_cegexp.project_id" => $bdProjId, "$db1.jv_cegexp.status" => '1'));
//         $recListArr = $this->db->get()->row();
//         $base_comp_id = explode(",", $recListArr->base_comp_id);
//         $leadSarr = explode(",", $recListArr->lead_comp_id);
//         $jvarr = explode(",", $recListArr->joint_venture);
//         $asscomparr = explode(",", $recListArr->asso_comp);
//         $CompnArray = array_unique(array_filter(array_merge($leadSarr, $jvarr, $asscomparr, $base_comp_id)));
//         $compnArr = array();
//         if ($CompnArray) {
//             foreach ($CompnArray as $rEcd) :
//                 $compnArr[$rEcd] = $this->getCompanyNameByIdcegExp($rEcd);
//             endforeach;
//         }
//         return ($compnArr) ? $compnArr : ["74" => $this->getCompanyNameByIdcegExp('74')];
//     }

//     //Company Name By Id..
//     public function getCompanyNameByIdcegExp($compID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db1.main_company.company_name");
//         $this->db->FROM("$db1.main_company");
//         $this->db->where(array("$db1.main_company.fld_id" => $compID, "$db1.main_company.status" => "1"));
//         $recdArr = $this->db->get()->row();
//         return ($recdArr) ? $recdArr->company_name : null;
//     }

//     public function GetAccountInfoData($hrmsProjId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;
//         $this->db->SELECT("$db2.tm_projects.project_name,$db1.accountinfo.*");
//         $this->db->FROM("$db1.accountinfo");
//         $this->db->join("$db2.tm_projects", "$db1.accountinfo.project_numberid=$db2.tm_projects.id", "LEFT");
//         $this->db->where(array("$db1.accountinfo.status" => "1", "$db1.accountinfo.project_numberid" => $hrmsProjId));
//         $recdArr = $this->db->get()->row();
//         return ($recdArr) ? $recdArr : null;
//     }

//     public function GetProjectInfobyID($bdProjId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db1.accountinfo.*");
//         $this->db->FROM("$db1.accountinfo");
//         $this->db->where(array("$db1.accountinfo.status" => "1", "$db1.accountinfo.project_id" => $bdProjId));
//         $recdArr = $this->db->get()->row();
//         return ($recdArr) ? $recdArr : null;
//     }

//     public function GetTsProjectID($bdProjId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db1.accountinfo.project_numberid");
//         $this->db->FROM("$db1.accountinfo");
//         $this->db->where(array("$db1.accountinfo.status" => "1", "$db1.accountinfo.project_id" => $bdProjId));
//         $recdArr = $this->db->get()->row();
//         return ($recdArr) ? $recdArr->project_numberid : null;
//     }

//     public function getDesignationTeamDetails($projId, $designatin_categid)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db1.assign_finalteam.rate,$db1.assign_finalteam.empname,$db1.assign_finalteam.proj_positioid_metro,$db1.assign_finalteam.id,$db1.designation_master_requisition.designation_name,$db1.main_company.company_name,$db1.assign_finalteam.maintenance_months,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.employee_type,$db1.assign_finalteam.account_date,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.maintenance_rate,$db1.assign_finalteam.construction_rate,$db1.assign_finalteam.man_months");
//         $this->db->FROM("$db1.assign_finalteam");
//         $this->db->join("$db1.designation_master_requisition", "$db1.assign_finalteam.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//         $this->db->join("$db1.main_company", "$db1.main_company.fld_id=$db1.assign_finalteam.company_id", "LEFT");

//         $this->db->where(array("$db1.assign_finalteam.status" => "1", "$db1.assign_finalteam.project_id" => $projId, "$db1.assign_finalteam.designatin_categid" => $designatin_categid));
//         $recdArr = $this->db->get()->result();
//         return ($recdArr) ? $recdArr : null;
//     }

//     public function getall_hrmsEmplist()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db2.main_users.id,$db2.main_users.userfullname,$db2.main_users.employeeId");
//         $this->db->from("$db2.main_users");
//         $this->db->where(array("$db2.main_users.isactive" => '1'));
//         $this->db->order_by("$db2.main_users.userfullname", "ASC");
//         $this->db->group_by("$db2.main_users.id");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     public function getall_otherEmplist()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.team_req_otheremp.fld_id,$db1.team_req_otheremp.emp_name,$db1.team_req_otheremp.emp_email,$db1.team_req_otheremp.emp_contact");
//         $this->db->from("$db1.team_req_otheremp");
//         $this->db->where(array("$db1.team_req_otheremp.status" => '1'));
//         $this->db->order_by("$db1.team_req_otheremp.emp_name", "ASC");
//         $this->db->group_by("$db1.team_req_otheremp.emp_email");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     public function getAssignFinalSingleRow($rOwId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db1.accountinfo.project_numberid,$db1.assign_finalteam.teamstatus,$db1.assign_finalteam.project_id,$db1.assign_finalteam.designatin_categid,$db1.assign_finalteam.status,$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname,$db1.assign_finalteam.company_id");
//         $this->db->FROM("$db1.assign_finalteam");
//         $this->db->join("$db1.accountinfo", "$db1.assign_finalteam.project_id=$db1.accountinfo.project_id", "LEFT");
//         $this->db->where(array("$db1.assign_finalteam.status" => "1", "$db1.assign_finalteam.id" => $rOwId));
//         $recdArr = $this->db->get()->row();
//         return ($recdArr) ? $recdArr : null;
//     }

//     public function GetAllDesignCategAndTeamByProjID($bdProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.acc2_designcateg_assign.desigcat_id,$db1.designationcat_master.ktype_name");
//         $this->db->from("$db3.acc2_designcateg_assign");
//         $this->db->join("$db1.designationcat_master", "$db3.acc2_designcateg_assign.desigcat_id=$db1.designationcat_master.k_id", "LEFT");
//         $this->db->where(array("$db3.acc2_designcateg_assign.ts_projid" => $bdProjID, "$db3.acc2_designcateg_assign.status" => '1'));
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     public function GetKeyTeamList($projId, $keyID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.assign_finalteam.*,$db1.designation_master_requisition.designation_name,$db2.main_employees_summary.prefix_name,$db2.main_employees_summary.userfullname,$db1.team_req_otheremp.emp_name,$db2.tm_project_employees.is_intermittent");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->join("$db2.main_employees_summary", "$db1.assign_finalteam.empname=$db2.main_employees_summary.user_id", "LEFT");
//         $this->db->join("$db1.team_req_otheremp", "$db1.team_req_otheremp.fld_id=$db1.assign_finalteam.empname", "LEFT");
//         $this->db->join("$db1.designation_master_requisition", "$db1.assign_finalteam.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//         $this->db->join("$db1.accountinfo", "$db1.accountinfo.project_id=$db1.assign_finalteam.project_id", "LEFT");
//         $this->db->join("$db2.tm_project_employees", "$db1.accountinfo.project_numberid=$db2.tm_project_employees.project_id AND $db2.tm_project_employees.emp_id=$db1.assign_finalteam.empname AND $db2.tm_project_employees.is_active='1'", "LEFT");
//         $this->db->where(array("$db1.assign_finalteam.status" => "1", "$db1.assign_finalteam.designatin_categid" => $keyID, "$db1.assign_finalteam.project_id" => $projId));
//         $this->db->group_by("$db1.assign_finalteam.designation_id");
//         $this->db->order_by("$db1.assign_finalteam.srno", "ASC");
//         $recListArr = $this->db->get()->result();

//         $returnResp = array();
//         if ($recListArr) {
//             foreach ($recListArr as $recDr) {
//                 $recDr->repl_reducation_tot_rate = "";
//                 if ($RdRate = $recDr->replacement_reducationrate > 0) {
//                     $recDr->repl_reducation_tot_rate = $recDr->rate - (($recDr->rate * $recDr->replacement_reducationrate) / 100);
//                 }
//                 $returnResp[] = $recDr;
//             }
//         }
//         return ($returnResp) ? $returnResp : null;
//     }

//     public function reimbursable_setproj($projId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.acc2_reimbursable_assign.reim_type_id,$db3.reimburs_category_master.type");
//         $this->db->from("$db3.acc2_reimbursable_assign");
//         $this->db->join("$db3.reimburs_category_master", "$db3.reimburs_category_master.id=$db3.acc2_reimbursable_assign.reim_type_id", "LEFT");
//         $this->db->where(array("$db3.acc2_reimbursable_assign.status" => "1", "$db3.acc2_reimbursable_assign.bd_projid" => $projId));
//         $recListArr = $this->db->get()->result();
//         if ($recListArr) {
//             foreach ($recListArr as $recD) {
//                 $this->db->where(["project_id" => $projId, "type_id" => $recD->reim_type_id, "status" => "1"]);
//                 $Num = $this->db->count_all_results("$db3.reimburs_category_master");
//                 //Insert Rows..
//                 if ($Num < 1) {
//                     $inserRecArr = array(
//                         "project_id" => $projId,
//                         "type_id" => $recD->reim_type_id,
//                         "description" => $recD->type,
//                         "status" => "1",
//                         "createdby" => $this->session->userdata('uid')
//                     );
//                     $this->db->insert("$db3.reimburs_category_master", $inserRecArr);
//                 }
//             }
//         }
//         //Layer 2...
//         $this->db->where(["project_id" => $projId, "status" => "1"]);
//         $RecArr = $this->db->get("$db3.reimburs_category_master")->result();
//         return ($RecArr) ? $RecArr : null;
//     }

//     public function GetReimbursable_Byproj($projId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.acc2_reimbursable_assign.reim_type_id,$db3.reimburs_category_master.type");
//         $this->db->from("$db3.acc2_reimbursable_assign");
//         $this->db->join("$db3.reimburs_category_master", "$db3.reimburs_category_master.id=$db3.acc2_reimbursable_assign.reim_type_id", "LEFT");
//         $this->db->where(array("$db3.acc2_reimbursable_assign.status" => "1", "$db3.acc2_reimbursable_assign.bd_projid" => $projId));
//         $this->db->order_by("$db3.acc2_reimbursable_assign.reim_type_id", "ASC");
//         $recListArr = $this->db->get()->result();
//         return ($recListArr) ? $recListArr : null;
//     }

//     //Invoice Project ..
//     public function invoiceProjectList()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->SELECT("$db2.tm_projects.project_name,$db3.assign_designation_onproj.bd_projid,$db3.assign_designation_onproj.hrms_projid");
//         $this->db->FROM("$db3.assign_designation_onproj");
//         $this->db->Join("$db2.tm_projects", "$db2.tm_projects.id=$db3.assign_designation_onproj.hrms_projid", "LEFT");
//         $this->db->WHERE("$db3.assign_designation_onproj.status", '1');
//         $this->db->group_by("$db3.assign_designation_onproj.bd_projid");
//         $recResults = $this->db->get()->result();
//         return ($recResults) ? $recResults : null;
//     }

//     //Invoice Project ..
//     public function GetAttendRec($bdProjId, $year, $month)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.timeshet_fill.*");
//         $this->db->from("$db1.timeshet_fill");
//         $this->db->where("$db1.timeshet_fill.is_active", '1');
//         $this->db->where(array("$db1.timeshet_fill.project_id" => $bdProjId, "$db1.timeshet_fill.year" => $year, "$db1.timeshet_fill.month" => $month));
//         $recResults = $this->db->get()->result_array();
//         $returnArr = array();
//         if ($recResults) {
//             foreach ($recResults as $recd) {
//                 $returnArr[$recd['designation_id']] = $recd;
//             }
//         }
//         return ($returnArr) ? $returnArr : null;
//     }

//     //Get Supporting Staff or Admin Staff..
//     public function GetStaffRateMMAmnt_Total($bdProjID, $keyID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $maintenance_monthsTot = 0;
//         $maintenance_rateTot = 0;
//         $construction_monthsTot = 0;
//         $construction_rateTot = 0;
//         $MMTot = 0;
//         $RateAmountTot = 0;

//         $this->db->select("$db1.assign_finalteam.id,$db1.assign_finalteam.maintenance_months,$db1.assign_finalteam.maintenance_rate,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.construction_rate,$db1.assign_finalteam.man_months,$db1.assign_finalteam.rate,$db1.assign_finalteam.key_id,$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->where("$db1.assign_finalteam.status", '1');
//         $this->db->where(array("$db1.assign_finalteam.project_id" => $bdProjID, "$db1.assign_finalteam.designatin_categid" => $keyID));
//         $recResults = $this->db->get()->result_array();

//         if ($recResults) {
//             foreach ($recResults as $recd) {
//                 //Maintenance
//                 if ($recd['maintenance_months']) {
//                     $maintenance_monthsTot += $recd['maintenance_months'];
//                 }
//                 if ($recd['maintenance_months'] and $recd['rate']) {
//                     $maintenance_rateTot += ($recd['maintenance_months'] * $recd['rate']);
//                 }
//                 //Construction
//                 if ($recd['construction_months']) {
//                     $construction_monthsTot += $recd['construction_months'];
//                 }
//                 if ($recd['construction_months'] and $recd['rate']) {
//                     $construction_rateTot += ($recd['construction_months'] * $recd['rate']);
//                 }
//                 //Total MM Rate..
//                 if ($recd['man_months']) {
//                     $MMTot += $recd['man_months'];
//                 }
//                 if ($recd['man_months'] and $recd['rate']) {
//                     $RateAmountTot += ($recd['man_months'] * $recd['rate']);
//                 }
//             }
//         }
//         return array("maintenance_monthsTot" => $maintenance_monthsTot, "maintenance_rateTot" => $maintenance_rateTot, "construction_monthsTot" => $construction_monthsTot, "construction_rateTot" => $construction_rateTot, "MMTot" => $MMTot, "RateAmountTot" => $RateAmountTot);
//     }

//     //Get Reimbursable Cumulative up to Previous Bill..
//     public function ReimbursableCumulativePreviousBill($bdprojId, $typerId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $TsProjID = $this->GetTsProjectID($bdprojId);
//         $masterdetail_idArr = $this->getIdsArr($bdprojId, $typerId);
//         $resultArr = 0;
//         if (($TsProjID) and ($masterdetail_idArr)) {
//             $this->db->select("$db1.invoicedetail.id,$db1.acc_othermonthdate.id as othermonthdateID");
//             $this->db->from("$db1.invoicedetail");
//             $this->db->join("$db1.acc_othermonthdate", "$db1.invoicedetail.id=$db1.acc_othermonthdate.invoice_id", "LEFT");
//             $this->db->where("$db1.invoicedetail.project_numberid", $TsProjID);
//             $this->db->order_by("$db1.invoicedetail.invoice_date", "DESC");
//             $this->db->order_by("$db1.acc_othermonthdate.id", "DESC");
//             //acc_othermonthdate
//             $this->db->limit(1, 1);
//             $recRow = $this->db->get()->row();

//             if ($recRow->othermonthdateID and count($masterdetail_idArr) > 0) {
//                 $this->db->select_sum("$db1.acc_othermonthdetail.cumulative_pre_amount");
//                 $this->db->from("$db1.acc_othermonthdetail");
//                 $this->db->where("$db1.acc_othermonthdetail.month_id", $recRow->othermonthdateID);
//                 $this->db->where_in("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_idArr);
//                 $resultArr = $this->db->get()->row();
//             }
//         }
//         return ($resultArr) ? $resultArr->cumulative_pre_amount : "0";
//     }

//     public function getIdsArr($bdprojId, $typerId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recDDArr = array();
//         if ($typerId) {
//             $this->db->select("$db3.reimburs_category_master");
//             $this->db->from("$db3.reimburs_category_master");
//             $this->db->where("$db3.reimburs_category_master.project_id", $bdprojId);
//             $this->db->where("$db3.reimburs_category_master.type_id", $typerId);
//             $recordArr = $this->db->get()->result();
//             if ($recordArr) {
//                 foreach ($recordArr as $RoWWs) {
//                     $recDDArr[] = $RoWWs->id;
//                 }
//             }
//         }
//         return $recDDArr;
//     }

//     //Get Reimbursable Cumulative up to Previous Bill..
//     public function ReimbursableCumulativeCurrentBill($bdprojId, $typerId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $TsProjID = $this->GetTsProjectID($bdprojId);
//         $masterdetail_idArr = $this->getIdsArr($bdprojId, $typerId);
//         $resultArr = 0;
//         if (($TsProjID) and ($masterdetail_idArr)) {
//             $this->db->select("$db1.invoicedetail.id,$db1.acc_othermonthdate.id as othermonthdateID");
//             $this->db->from("$db1.invoicedetail");
//             $this->db->join("$db1.acc_othermonthdate", "$db1.invoicedetail.id=$db1.acc_othermonthdate.invoice_id", "LEFT");
//             $this->db->where("$db1.invoicedetail.project_numberid", $TsProjID);
//             $this->db->order_by("$db1.invoicedetail.invoice_date", "DESC");
//             $this->db->limit(0, 1);
//             $recRow = $this->db->get()->row();

//             if ($recRow->othermonthdateID and count($masterdetail_idArr) > 0) {
//                 $this->db->select_sum("$db1.acc_othermonthdetail.cumulative_pre_amount");
//                 $this->db->from("$db1.acc_othermonthdetail");
//                 $this->db->where("$db1.acc_othermonthdetail.month_id", $recRow->othermonthdateID);
//                 $this->db->where_in("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_idArr);
//                 $resultArr = $this->db->get()->row();
//             }
//         }
//         return ($resultArr) ? $resultArr->cumulative_pre_amount : "0";
//     }

//     //Single Row Holidays Arr...
//     public function getSunHolidaysArr($month, $year, $projID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $sundays = array();
//         $StartDate = $year . "-" . $month . "-" . "01";
//         $EndDate = $year . "-" . $month . "-" . "31";
//         $startDate = new DateTime($StartDate);
//         $endDate = new DateTime($EndDate);
//         while ($startDate <= $endDate) {
//             if ($startDate->format('w') == 0) {
//                 $sundays[] = $startDate->format('d');
//             }
//             $startDate->modify('+1 day');
//         }
//         return ($sundays) ? $sundays : null;
//     }

//     //Get Holidays Recd..
//     public function getHolidaysArr($month, $year, $projID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $HolidaysRecds = $this->db->select('holiday_date')->where(["is_active" => "1", "proj_id" => $projID, "year" => $year, "month" => $month])->get('siteoffice_holiday')->result();
//         if ($HolidaysRecds) {
//             foreach ($HolidaysRecds as $reCdS) :
//                 $Holidays[] = date("d", strtotime($reCdS->holiday_date));
//             endforeach;
//         }
//         return ($Holidays) ? $Holidays : null;
//     }

//     //Get Single Reimbursable Cumulative up to Previous Bill..
//     public function SingleReimbursableCumulativeCurrentBill($bdprojId, $typerId, $masterdetail_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $TsProjID = $this->GetTsProjectID($bdprojId);
//         $resultArr = 0;
//         if ($TsProjID) {
//             $this->db->select("$db1.invoicedetail.id,$db1.acc_othermonthdate.id as othermonthdateID");
//             $this->db->from("$db1.invoicedetail");
//             $this->db->join("$db1.acc_othermonthdate", "$db1.invoicedetail.id=$db1.acc_othermonthdate.invoice_id", "LEFT");
//             $this->db->where("$db1.invoicedetail.project_numberid", $TsProjID);
//             $this->db->order_by("$db1.invoicedetail.invoice_date", "DESC");
//             $this->db->limit(0, 1);
//             $recRow = $this->db->get()->row();
//             if ($recRow->othermonthdateID and $masterdetail_id) {
//                 $this->db->select("$db1.acc_othermonthdetail.cumulative_pre_amount,$db1.acc_othermonthdetail.cumulative_pre_mm,$db1.acc_othermonthdetail.other_mm");
//                 $this->db->from("$db1.acc_othermonthdetail");
//                 $this->db->where("$db1.acc_othermonthdetail.month_id", $recRow->othermonthdateID);
//                 $this->db->where("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_id);
//                 $resultArr = $this->db->get()->row();
//             }
//         }
//         return ($resultArr) ? $resultArr : "0";
//     }

//     //Cumulative up to Previous Bill.. Func Code By 
//     public function GetKeyProf_SubProf_CurrentBillAmnt($Project_id, $invoice_no)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $cumulativeamount = 0;
//         $totalcumulativeamount = 0;

//         if ($Project_id and $invoice_no) {
//             $this->db->select("$db1.invoicesave.cumulativeamount,$db1.invoicesave.totalcumulativeamount");
//             $this->db->from("$db1.invoicesave");
//             $this->db->where("$db1.invoicesave.project_id", $Project_id);
//             $this->db->where("$db1.invoicesave.invoiceno_id", $invoice_no);
//             $this->db->where("($db1.invoicesave.key_id='1' OR $db1.invoicesave.key_id='2')", NULL, FALSE);
//             $recRow = $this->db->get()->result_array();

//             if ($recRow) {
//                 foreach ($recRow as $recd) {
//                     if ($recd['cumulativeamount']) :
//                         $cumulativeamount += $recd['cumulativeamount'];
//                     endif;
//                     if ($recd['totalcumulativeamount']) :
//                         $totalcumulativeamount += $recd['totalcumulativeamount'];
//                     endif;
//                 }
//             }
//         }
//         return array("cumulativeamount" => $cumulativeamount, "totalcumulativeamount" => $totalcumulativeamount);
//     }

//     public function GetTotReimbursableCurrentMM($bdProjID, $reim_type_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $TransportationRecArr = GetReimbursableList($bdProjID, $reim_type_id);
//         $recdToT4 = 0;
//         if ($TransportationRecArr) {
//             foreach ($TransportationRecArr as $Tran_key => $Tran_row) {
//                 $quanty = ($Tran_row->qty > 0) ? $Tran_row->qty : 1;
//                 $unit = ($Tran_row->unit > 0) ? $Tran_row->unit : 1;
//                 $cumulative_pre_amount = 0;
//                 $userRateForCal = 0;
//                 $snglCurrentMMAmount = 0;
//                 $cumulative_pre_amount = SingleReimbursableCumulativeCurrentBill($Tran_row->project_id, $Tran_row->type_id, $Tran_row->id);

//                 if ($Tran_row->maintenance_rate > 0) {
//                     $userRateForCal = $Tran_row->maintenance_rate;
//                 }
//                 if ($Tran_row->construction_rate > 0) {
//                     $userRateForCal = $Tran_row->construction_rate;
//                 }
//                 if (($Tran_row->construction_rate < 1) and ($Tran_row->maintenance_rate < 1)) {
//                     $userRateForCal = $Tran_row->per_month;
//                 }
//                 $snglCurrentMMAmount = ($cumulative_pre_amount->other_mm * $userRateForCal * $quanty * $unit);

//                 if (($bdProjID == "89224") and (($reim_type_id == "3") or ($reim_type_id == "4") or ($reim_type_id == "5"))) {
//                     $snglCurrentMMAmount = (($snglCurrentMMAmount * 75) / 100);
//                 }
//                 $recdToT4 += $snglCurrentMMAmount;
//             }
//         }
//         return ($recdToT4) ? $recdToT4 : "0";
//     }

//     //Function By Asheesh..
//     public function getCurrentMonthAmount($bdProjectId, $invoice_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->load->model("Front_model");
//         $keyProfRecDataArr = GetKeyTeamList($bdProjectId, "1");
//         $AccountInfoDataArr = $this->GetAccountInfoData($bdProjectId);
//         if ($keyProfRecDataArr and $AccountInfoDataArr and $invoice_id) {
//             $invoicedata = $this->Front_model->getaccountdetailforexcel($invoice_id);
//             if ($invoicedata->invoice_date) {
//                 $Invcprev_month = date("d-m-Y", strtotime("$invoicedata->invoice_date -1 month"));
//                 $InvcDateAtten = date('M Y', strtotime($Invcprev_month));
//                 $InvcYearAtten = date('Y', strtotime($Invcprev_month));
//                 $InvcMonthAtten = date('m', strtotime($Invcprev_month));
//             }
//             //No of Days Global Variable Define..
//             if ($invoicedata->no_days == "") {
//                 $GLB_no_days = "30";
//             }
//             if ($invoicedata->no_days) {
//                 $GLB_no_days = $invoicedata->no_days;
//             }
//             //Decimal Place Global..
//             if ($invoicedata->decimal_place == "") {
//                 $GLB_decimal_place = "2";
//             }
//             if ($invoicedata->decimal_place) {
//                 $GLB_decimal_place = $invoicedata->decimal_place;
//             }

//             $keyProfRecDataArr = GetKeyTeamList($invoicedata->project_id, "1");
//             $subProfRecDataArr = GetKeyTeamList($invoicedata->project_id, "2");
//             $AdminSupportingStaffArr = GetKeyTeamList($invoicedata->project_id, "3");

//             if ($keyProfRecDataArr) {
//                 foreach ($keyProfRecDataArr as $rOws) {
//                     if ($rOws->maintenance_rate > 0) {
//                         $userRateForCal = $rOws->maintenance_rate;
//                     }
//                     if ($rOws->construction_rate > 0) {
//                         $userRateForCal = $rOws->construction_rate;
//                     }
//                     if (($rOws->construction_rate < 1) and ($rOws->maintenance_rate < 1)) {
//                         $userRateForCal = $rOws->rate;
//                     }
//                     if ($rOws->key_id == "1") {
//                         if ($rOws->is_intermittent == "1") {
//                             $TotPresentDays_up = getintermittentattd($invoicedata->project_id, $rOws->empname, $rOws->designation_id, $InvcMonthAtten, $InvcYearAtten);
//                             $intermMM = ($TotPresentDays_up->present / $GLB_no_days);
//                             $intermMM2 = number_format($intermMM, $GLB_decimal_place);
//                         }
//                         if ($rOws->is_intermittent != "1") {
//                             $TotPresentDays_up = gettimesheetdetail($invoicedata->project_id, $rOws->designation_id, $rOws->empname, $InvcMonthAtten, $InvcYearAtten);
//                             $intermMM = ($TotPresentDays_up->leave + $TotPresentDays_up->absent);
//                             $intermMM1 = 1 - ($intermMM / $GLB_no_days);
//                             $intermMM2 = number_format($intermMM1, $GLB_decimal_place);
//                         }
//                         $recdToT1 += ($userRateForCal * $intermMM2);
//                     }
//                 }
//             }

//             //Sub Prof...
//             if ($subProfRecDataArr) {
//                 foreach ($subProfRecDataArr as $recD) {
//                     if ($recD->is_intermittent == "1") {
//                         $TotPresentDays_up = getintermittentattd($invoicedata->project_id, $recD->empname, $recD->designation_id, $InvcMonthAtten, $InvcYearAtten);
//                         $intermMM = ($TotPresentDays_up->present / $GLB_no_days);
//                         $intermMM2 = number_format($intermMM, $GLB_decimal_place);
//                     }
//                     if ($rOws->is_intermittent != "1") {
//                         $TotPresentDays_up = gettimesheetdetail($invoicedata->project_id, $recD->designation_id, $recD->empname, $InvcMonthAtten, $InvcYearAtten);
//                         $intermMM = ($TotPresentDays_up->leave + $TotPresentDays_up->absent);
//                         $intermMM1 = 1 - ($intermMM / $GLB_no_days);
//                         $intermMM2 = number_format($intermMM1, $GLB_decimal_place);
//                     }
//                     if ($recD->maintenance_rate > 0) {
//                         $userRateForCal = $recD->maintenance_rate;
//                     }
//                     if ($recD->construction_rate > 0) {
//                         $userRateForCal = $recD->construction_rate;
//                     }
//                     if (($recD->construction_rate < 1) and ($recD->maintenance_rate < 1)) {
//                         $userRateForCal = $recD->rate;
//                     }
//                     $recdToT2 += ($userRateForCal * $intermMM2);
//                 }
//             }

//             //Supporting Staff or Admin Staff...
//             if ($AdminSupportingStaffArr) {
//                 foreach ($AdminSupportingStaffArr as $AdmkEy => $AdmRow) {
//                     if ($AdmRow->is_intermittent == "1") {
//                         $TotPresentDays_up = getintermittentattd($invoicedata->project_id, $AdmRow->empname, $AdmRow->designation_id, $InvcMonthAtten, $InvcYearAtten);
//                         $intermMM = ($TotPresentDays_up->present / $GLB_no_days);
//                         $intermMM2 = number_format($intermMM, $GLB_decimal_place);
//                     }
//                     if ($AdmRow->is_intermittent != "1") {
//                         $TotPresentDays_up = gettimesheetdetail($invoicedata->project_id, $AdmRow->designation_id, $AdmRow->empname, $InvcMonthAtten, $InvcYearAtten);
//                         $intermMM = ($TotPresentDays_up->leave + $TotPresentDays_up->absent);
//                         $intermMM1 = 1 - ($intermMM / $GLB_no_days);
//                         $intermMM2 = number_format($intermMM1, $GLB_decimal_place);
//                     }
//                     if ($AdmRow->maintenance_rate > 0) {
//                         $userRateForCal = $AdmRow->maintenance_rate;
//                     }
//                     if ($AdmRow->construction_rate > 0) {
//                         $userRateForCal = $AdmRow->construction_rate;
//                     }
//                     if (($AdmRow->construction_rate < 1) and ($AdmRow->maintenance_rate < 1)) {
//                         $userRateForCal = $AdmRow->rate;
//                     }
//                     $recdToT3 += ($userRateForCal * $intermMM2);
//                 }
//             }
//         }

//         $returNarr = array("keyProfTota" => round($recdToT1), "subProfTota" => round($recdToT2), "adminstaffProfTota" => round($recdToT3));
//         return ($returNarr) ? $returNarr : null;
//     }

//     //Get getCurrentMonthAmount Reimbursable..
//     public function getCurrentMonthAmountReimbursable($bdProjectId, $invoice_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $invoicedata->project_id = $bdProjectId;
//         //Transportation..
//         $TransportationRecArr = GetReimbursableList($invoicedata->project_id, "1");
//         //Duty Travel to Site (Fixed Costs): Professional and Sub - Professional Staff..
//         $DutyTravelRecArr = GetReimbursableList($invoicedata->project_id, "2");
//         //Office Rent..
//         $OfficeRentRecArr = GetReimbursableList($invoicedata->project_id, "3");
//         //Start Section(6) Office Supplies, Utilities and Communication (Fixed Costs)..
//         $OfficeSupplieRecArr = GetReimbursableList($invoicedata->project_id, "4");
//         // Start (7) Office Furniture and Equipment (Rental) (Fixed Monthly Cost)..
//         $OfcFurnitureRecArr = GetReimbursableList($invoicedata->project_id, "5");
//         //Office Equipment (Rental / Hire)
//         $OfcEquipmentRecArr = GetReimbursableList($invoicedata->project_id, "6");
//         //Reports and Documents..
//         $RepDocsRecArr = GetReimbursableList($invoicedata->project_id, "7");
//         //Survey Equipment with Survey Party and Vehicle etc
//         $SurveyEqpRecArr = GetReimbursableList($invoicedata->project_id, "8");
//         // Road Survey Equipment
//         $RoadSurveyEquipRecArr = GetReimbursableList($invoicedata->project_id, "9");
//         //Contingencies
//         $ContingenciesRecArr = GetReimbursableList($invoicedata->project_id, "10");

//         //(1) Transportation..
//         $userRateForCal = 0;
//         $Transp_Tot = 0;
//         foreach ($TransportationRecArr as $Tran_key => $Tran_row) {
//             $cumulative_pre_amount = SingleReimbursableCumulativeCurrentBill($Tran_row->project_id, $Tran_row->type_id, $Tran_row->id);
//             if ($Tran_row->maintenance_rate > 0) {
//                 $userRateForCal = $Tran_row->maintenance_rate;
//             }
//             if ($Tran_row->construction_rate > 0) {
//                 $userRateForCal = $Tran_row->construction_rate;
//             }
//             if (($Tran_row->construction_rate < 1) and ($Tran_row->maintenance_rate < 1)) {
//                 $userRateForCal = $Tran_row->rate;
//             }
//             $Transp_Tot += ($cumulative_pre_amount->other_mm * $userRateForCal);
//         }
//         //(2) DutyTravelRec
//         $userRateForCal2 = 0;
//         $DutyTravelRec_Tot = 0;
//         foreach ($DutyTravelRecArr as $row2) {
//             $cumulative_pre_amount2 = SingleReimbursableCumulativeCurrentBill($row2->project_id, $row2->type_id, $row2->id);
//             if ($row2->maintenance_rate > 0) {
//                 $userRateForCal2 = $row2->maintenance_rate;
//             }
//             if ($row2->construction_rate > 0) {
//                 $userRateForCal2 = $row2->construction_rate;
//             }
//             if (($row2->construction_rate < 1) and ($row2->maintenance_rate < 1)) {
//                 $userRateForCal2 = $row2->rate;
//             }
//             $DutyTravelRec_Tot += ($cumulative_pre_amount2->other_mm * $userRateForCal2);
//         }
//         //(3) OfficeRentRec
//         $userRateForCal3 = 0;
//         $OfficeRentRec_Tot = 0;
//         foreach ($OfficeRentRecArr as $row3) {
//             $cumulative_pre_amount3 = SingleReimbursableCumulativeCurrentBill($row3->project_id, $row3->type_id, $row3->id);
//             if ($row3->maintenance_rate > 0) {
//                 $userRateForCal3 = $row3->maintenance_rate;
//             }
//             if ($row3->construction_rate > 0) {
//                 $userRateForCal3 = $row3->construction_rate;
//             }
//             if (($row3->construction_rate < 1) and ($row3->maintenance_rate < 1)) {
//                 $userRateForCal3 = $row2->rate;
//             }
//             $OfficeRentRec_Tot += ($cumulative_pre_amount3->other_mm * $userRateForCal3);
//         }
//         //(4) OfficeSupplieRecArr..
//         $userRateForCal4 = 0;
//         $OfficeSupplie_Tot = 0;
//         foreach ($OfficeSupplieRecArr as $row4) {
//             $cumulative_pre_amount4 = SingleReimbursableCumulativeCurrentBill($row4->project_id, $row4->type_id, $row4->id);
//             if ($row4->maintenance_rate > 0) {
//                 $userRateForCal4 = $row4->maintenance_rate;
//             }
//             if ($row4->construction_rate > 0) {
//                 $userRateForCal4 = $row4->construction_rate;
//             }
//             if (($row4->construction_rate < 1) and ($row4->maintenance_rate < 1)) {
//                 $userRateForCal4 = $row4->rate;
//             }
//             $OfficeSupplie_Tot += ($cumulative_pre_amount4->other_mm * $userRateForCal4);
//         }
//         //(5) OfcFurniture
//         $userRateForCal5 = 0;
//         $OfcFurniture_Tot = 0;
//         foreach ($OfcFurnitureRecArr as $row5) {
//             $cumulative_pre_amount5 = SingleReimbursableCumulativeCurrentBill($row5->project_id, $row5->type_id, $row5->id);
//             if ($row5->maintenance_rate > 0) {
//                 $userRateForCal5 = $row5->maintenance_rate;
//             }
//             if ($row5->construction_rate > 0) {
//                 $userRateForCal5 = $row5->construction_rate;
//             }
//             if (($row5->construction_rate < 1) and ($row5->maintenance_rate < 1)) {
//                 $userRateForCal5 = $row5->rate;
//             }
//             $OfcFurniture_Tot += ($cumulative_pre_amount5->other_mm * $userRateForCal5);
//         }
//         //(6) Ofc Equipment Record Array..
//         $userRateForCal6 = 0;
//         $OfcEquipment_Tot = 0;
//         foreach ($OfcEquipmentRecArr as $row6) {
//             $cumulative_pre_amount6 = SingleReimbursableCumulativeCurrentBill($row6->project_id, $row6->type_id, $row6->id);
//             if ($row6->maintenance_rate > 0) {
//                 $userRateForCal6 = $row6->maintenance_rate;
//             }
//             if ($row6->construction_rate > 0) {
//                 $userRateForCal6 = $row6->construction_rate;
//             }
//             if (($row6->construction_rate < 1) and ($row6->maintenance_rate < 1)) {
//                 $userRateForCal6 = $row6->rate;
//             }
//             $OfcEquipment_Tot += ($cumulative_pre_amount6->other_mm * $userRateForCal6);
//         }
//         //(7) RepDocsRecArr..
//         $userRateForCal7 = 0;
//         $RepDocsRec_Tot = 0;
//         foreach ($RepDocsRecArr as $row7) {
//             $cumulative_pre_amount7 = SingleReimbursableCumulativeCurrentBill($row7->project_id, $row7->type_id, $row7->id);
//             if ($row7->maintenance_rate > 0) {
//                 $userRateForCal7 = $row7->maintenance_rate;
//             }
//             if ($row7->construction_rate > 0) {
//                 $userRateForCal7 = $row7->construction_rate;
//             }
//             if (($row7->construction_rate < 1) and ($row7->maintenance_rate < 1)) {
//                 $userRateForCal7 = $row7->rate;
//             }
//             $RepDocsRec_Tot += ($cumulative_pre_amount7->other_mm * $userRateForCal7);
//         }
//         //(8) SurveyEqpRecArr..
//         $userRateForCal8 = 0;
//         $SurveyEqpRec_Tot = 0;
//         foreach ($SurveyEqpRecArr as $row8) {
//             $cumulative_pre_amount8 = SingleReimbursableCumulativeCurrentBill($row8->project_id, $row8->type_id, $row8->id);
//             if ($row8->maintenance_rate > 0) {
//                 $userRateForCal8 = $row8->maintenance_rate;
//             }
//             if ($row8->construction_rate > 0) {
//                 $userRateForCal8 = $row8->construction_rate;
//             }
//             if (($row8->construction_rate < 1) and ($row8->maintenance_rate < 1)) {
//                 $userRateForCal8 = $row8->rate;
//             }
//             $SurveyEqpRec_Tot += ($cumulative_pre_amount8->other_mm * $userRateForCal8);
//         }
//         //(9) RoadSurveyEquip
//         $userRateForCal9 = 0;
//         $RoadSurveyEquip_Tot = 0;
//         foreach ($RoadSurveyEquipRecArr as $row9) {
//             $cumulative_pre_amount9 = SingleReimbursableCumulativeCurrentBill($row9->project_id, $row9->type_id, $row9->id);
//             if ($row9->maintenance_rate > 0) {
//                 $userRateForCal9 = $row9->maintenance_rate;
//             }
//             if ($row9->construction_rate > 0) {
//                 $userRateForCal9 = $row9->construction_rate;
//             }
//             if (($row9->construction_rate < 1) and ($row9->maintenance_rate < 1)) {
//                 $userRateForCal9 = $row9->rate;
//             }
//             $RoadSurveyEquip_Tot += ($cumulative_pre_amount9->other_mm * $userRateForCal9);
//         }
//         //(10) Contingencies Record..
//         $userRateForCal10 = 0;
//         $Contingencies_Tot = 0;
//         foreach ($ContingenciesRecArr as $row10) {
//             $cumulative_pre_amount10 = SingleReimbursableCumulativeCurrentBill($row10->project_id, $row10->type_id, $row10->id);
//             if ($row10->maintenance_rate > 0) {
//                 $userRateForCal10 = $row10->maintenance_rate;
//             }
//             if ($row10->construction_rate > 0) {
//                 $userRateForCal10 = $row10->construction_rate;
//             }
//             if (($row10->construction_rate < 1) and ($row10->maintenance_rate < 1)) {
//                 $userRateForCal10 = $row10->rate;
//             }
//             $Contingencies_Tot += ($cumulative_pre_amount10->other_mm * $userRateForCal10);
//         }
//         return array("transportation" => $Transp_Tot, "DutyTravel" => $DutyTravelRec_Tot, "OfficeRent" => $OfficeRentRec_Tot, "OfficeSupplie" => $OfficeSupplie_Tot, "OfcFurniture" => $OfcFurniture_Tot, "OfcEquipment" => $OfcEquipment_Tot, "ReportDocuments" => $RepDocsRec_Tot, "SurveyEqpRec" => $SurveyEqpRec_Tot, "RoadSurveyEquip" => $RoadSurveyEquip_Tot, "Contingencies" => $Contingencies_Tot);
//     }

//     //Get EOT Single Empl.
//     public function GetEOTRecArr($project_id, $designationID, $emplID)
//     {

//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("eot_mm,eot_rate");
//         $this->db->from("saveeotteam");
//         $this->db->where(["project_id" => $project_id, "designation_id" => $designationID, "emp_id" => $emplID]);
//         $this->db->order_by("eot_id", "DESC");
//         $this->db->group_by("eot_id");
//         $this->db->limit("1");
//         $recRow = $this->db->get()->row();
//         return ($recRow) ? $recRow : null;
//     }

//     public function GetEOTRecReimburRow($project_id, $id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("id");
//         $this->db->from("acceot_date");
//         $this->db->where(["project_id" => $project_id]);
//         $this->db->order_by("id", "DESC");
//         $this->db->limit("1");
//         $recRow = $this->db->get()->row();
//         if ($recRow->id) {
//             $this->db->select("eot_mm,eot_rate");
//             $this->db->from("eot_detail");
//             $this->db->where(["project_id" => $project_id, "masterdetail_id" => $id, "eot_id" => $recRow->id]);
//             $recResult = $this->db->get()->row();
//         }
//         return ($recResult) ? $recResult : null;
//     }

//     //Get Total Reimbursable Value EOT-Total And REVISED CONTRACT VALUE As Per...
//     public function GetToReimbursableEOT_RvContVal($project_id, $typeID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $TransportationRecArr = GetReimbursableList($project_id, $typeID);

//         $TOTSaving_trans = 0;
//         $TOTRv_trans = 0;

//         if ($TransportationRecArr) {
//             foreach ($TransportationRecArr as $Tran_key => $row) {
//                 $EotRate_Tran = 0;
//                 $TransRVamount = 0;

//                 $eotRecdReimb = GetEOTRecReimburRow($project_id, $row->id);
//                 if (($eotRecdReimb) and ($eotRecdReimb->eot_mm)) {
//                     $EotRate_Tran = ($eotRecdReimb->eot_rate) ? $eotRecdReimb->eot_rate : ($row->per_month * $eotRecdReimb->eot_mm);
//                 }
//                 if ($row->qty > 0) {
//                     $TransRVamount = ($row->qty * $row->per_month * $row->no_month) + $EotRate_Tran;
//                 } else {
//                     $TransRVamount = ($row->per_month * $row->no_month) + $EotRate_Tran;
//                 }
//                 //######################################################################
//                 $TOTSaving_trans += $EotRate_Tran;
//                 $TOTRv_trans += $TransRVamount;
//             }
//         }
//         return array("TotEOT" => $TOTSaving_trans, "TotRV" => $TOTRv_trans);
//     }

//     //Cumulative up to Previous Bill.. Func Code By Asheesh
//     public function GetKeyProf_SubProf_CumulativuptoPrevAmnt($Project_id, $invoice_no)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $cumulativeamount = 0;
//         $totalcumulativeamount = 0;

//         if ($Project_id and $invoice_no) {
//             //Key Prof..
//             $recDdata = $this->GetProjDesignEmpIDs($Project_id, "1");
//             if ($recDdata) {
//                 foreach ($recDdata as $rEdRow) {
//                     //$cumulativeamount = 0;
//                     // $totalcumulativeamount = 0;
//                     $RecdCumulativuptoPrev = $this->Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $rEdRow->designation_id, $rEdRow->empname);
//                     if ($RecdCumulativuptoPrev->cumulativeamount) :
//                         $cumulativeamount += $RecdCumulativuptoPrev->cumulativeamount;
//                     endif;
//                     if ($RecdCumulativuptoPrev->totalcumulativeamount) :
//                         $totalcumulativeamount += $RecdCumulativuptoPrev->totalcumulativeamount;
//                     endif;
//                 }
//             }
//             //Sub Prof..
//             $recDdata2 = $this->GetProjDesignEmpIDs($Project_id, "2");
//             if ($recDdata2) {
//                 foreach ($recDdata2 as $rEdRow) {
//                     $RecdCumulativuptoPrev = $this->Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $rEdRow->designation_id, $rEdRow->empname);
//                     if ($RecdCumulativuptoPrev->cumulativeamount) :
//                         $cumulativeamount += $RecdCumulativuptoPrev->cumulativeamount;
//                     endif;
//                     if ($RecdCumulativuptoPrev->totalcumulativeamount) :
//                         $totalcumulativeamount += $RecdCumulativuptoPrev->totalcumulativeamount;
//                     endif;
//                 }
//             }
//         }
//         return array("cumulativeamount" => $cumulativeamount, "totalcumulativeamount" => $totalcumulativeamount);
//     }

//     //Supporting Staff or Admin Staff Cumulative up to Previous Bill.. Func Code By Asheesh
//     public function GetAdminSupportingStaffCumulativAmnt($Project_id, $invoice_no)
//     {

//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $cumulativeamount = 0;
//         $totalcumulativeamount = 0;
//         if ($Project_id and $invoice_no) {
//             $recDdata = $this->GetProjDesignEmpIDs($Project_id, "3");
//             if ($recDdata) {
//                 foreach ($recDdata as $rEdRow) {
//                     $RecdCumulativuptoPrev = $this->Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $rEdRow->designation_id, $rEdRow->empname);
//                     if ($RecdCumulativuptoPrev->cumulativeamount) :
//                         $cumulativeamount += $RecdCumulativuptoPrev->cumulativeamount;
//                     endif;
//                     if ($RecdCumulativuptoPrev->totalcumulativeamount) :
//                         $totalcumulativeamount += $RecdCumulativuptoPrev->totalcumulativeamount;
//                     endif;
//                 }
//             }
//         }
//         return array("cumulativeamount" => $cumulativeamount, "totalcumulativeamount" => $totalcumulativeamount);
//     }

//     public function GetProjDesignEmpIDs($projID, $key)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->where(array("$db1.assign_finalteam.project_id" => $projID, "$db1.assign_finalteam.designatin_categid" => $key, "$db1.assign_finalteam.status" => "1"));
//         $recResult = $this->db->get()->result();
//         return ($recResult) ? $recResult : null;
//     }

//     //Cumulative up to Previous Bill.. Single Employee Wise..
//     public function Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $empDesignationID, $emplID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         if ($Project_id and $invoice_no and $empDesignationID) {
//             $this->db->select("$db1.invoicesave.cumulativeamount,$db1.invoicesave.totalcumulativeamount,$db1.invoicesave.cumulativemm,$db1.invoicesave.totalcumulativemm");
//             $this->db->from("$db1.invoicesave");
//             $this->db->where("$db1.invoicesave.project_id", $Project_id);
//             $this->db->where("$db1.invoicesave.invoiceno_id", $invoice_no);
//             $this->db->where("$db1.invoicesave.designation_id", $empDesignationID);
//             $this->db->where("$db1.invoicesave.emp_id", $emplID);
//             $recRow = $this->db->get()->row();
//         }
//         return ($recRow) ? $recRow : "0";
//     }

//     //Get Key Professional Staff & Sub Professional Staff Total RateAmount.. Code By Asheesh
//     public function GetKeyProf_SubProfStaffTotRateAmnt($bdProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $maintenance_monthsTot = 0;
//         $maintenance_rateTot = 0;
//         $construction_monthsTot = 0;
//         $construction_rateTot = 0;
//         $MMTot = 0;
//         $RateAmountTot = 0;

//         $this->db->select("$db1.assign_finalteam.id,$db1.assign_finalteam.maintenance_months,$db1.assign_finalteam.maintenance_rate,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.construction_rate,$db1.assign_finalteam.man_months,$db1.assign_finalteam.rate,$db1.assign_finalteam.key_id,$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->where("$db1.assign_finalteam.status", '1');
//         $this->db->where(array("$db1.assign_finalteam.project_id" => $bdProjID));
//         $this->db->where("($db1.assign_finalteam.designatin_categid='1' OR $db1.assign_finalteam.designatin_categid='2')", NULL, FALSE);
//         $recResults = $this->db->get()->result_array();

//         if ($recResults) {
//             foreach ($recResults as $recd) {

//                 //Maintenance
//                 if ($recd['maintenance_months']) {
//                     $maintenance_monthsTot += $recd['maintenance_months'];
//                 }
//                 if ($recd['maintenance_months'] and $recd['rate']) {
//                     $maintenance_rateTot += ($recd['maintenance_months'] * $recd['rate']);
//                 }
//                 //Construction
//                 if ($recd['construction_months']) {
//                     $construction_monthsTot += $recd['construction_months'];
//                 }
//                 if ($recd['construction_months'] and $recd['rate']) {
//                     $construction_rateTot += ($recd['construction_months'] * $recd['rate']);
//                 }
//                 //Total MM Rate..
//                 if ($recd['man_months']) {
//                     $MMTot += $recd['man_months'];
//                 }
//                 if ($recd['man_months'] and $recd['rate']) {
//                     $RateAmountTot += ($recd['rate'] * $recd['man_months']);
//                 }
//             }
//         }
//         return array("maintenance_monthsTot" => $maintenance_monthsTot, "maintenance_rateTot" => $maintenance_rateTot, "construction_monthsTot" => $construction_monthsTot, "construction_rateTot" => $construction_rateTot, "MMTot" => $MMTot, "RateAmountTot" => $RateAmountTot);
//     }

//     //Get Project Remuneration Total Amount & MM Details..
//     public function GetRembursableTotAmntDetail_new($bdProjID, $typeID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $maintenance_monthsTot = 0;
//         $maintenance_rateTot = 0;
//         $construction_monthsTot = 0;
//         $construction_rateTot = 0;
//         $MMTot = 0;
//         $RateAmountTot = 0;

//         $this->db->select("$db3.reimburs_category_master.id,$db3.reimburs_category_master.type_id,$db3.reimburs_category_master.unit,$db3.reimburs_category_master.qty,$db3.reimburs_category_master.construction_months,$db3.reimburs_category_master.construction_rate,$db3.reimburs_category_master.maintenance_months,$db3.reimburs_category_master.maintenance_rate,$db3.reimburs_category_master.no_month,$db3.reimburs_category_master.per_month");
//         $this->db->from("$db3.reimburs_category_master");
//         $this->db->where("$db3.reimburs_category_master.status", '1');
//         $this->db->where(array("$db3.reimburs_category_master.project_id" => $bdProjID, "$db3.reimburs_category_master.type_id" => $typeID));
//         $recResults = $this->db->get()->result_array();

//         if ($recResults) {
//             foreach ($recResults as $recd) {
//                 $quanty = ($recd['qty'] > 0) ? $recd['qty'] : 1;
//                 $unit = ($recd['unit'] > 0) ? $recd['unit'] : 1;
//                 //Maintenance
//                 if ($recd['maintenance_months']) {
//                     $maintenance_monthsTot += $recd['maintenance_months'];
//                 }
//                 if ($recd['maintenance_months']) {
//                     $maintenance_rateTot += ($recd['maintenance_months'] * $recd['maintenance_rate'] * $quanty * $unit);
//                 }
//                 //Construction
//                 if ($recd['construction_months']) {
//                     $construction_monthsTot += $recd['construction_months'];
//                 }
//                 if ($recd['construction_months']) {
//                     $construction_rateTot += ($recd['construction_months'] * $recd['construction_rate'] * $quanty * $unit);
//                 }
//                 //Total MM Rate..
//                 if ($recd['no_month']) {
//                     $MMTot += $recd['no_month'];
//                 }
//                 if ($recd['no_month'] and $recd['per_month']) {
//                     if ($recd['qty'] > 0) {
//                         $RateAmountTot += ($recd['qty'] * $recd['no_month'] * $recd['per_month'] * $unit);
//                     } else {
//                         $RateAmountTot += ($recd['no_month'] * $recd['per_month'] * $unit);
//                     }
//                 }
//             }
//         }
//         return array("maintenance_monthsTot" => $maintenance_monthsTot, "maintenance_rateTot" => $maintenance_rateTot, "construction_monthsTot" => $construction_monthsTot, "construction_rateTot" => $construction_rateTot, "MMTot" => $MMTot, "RateAmountTot" => $RateAmountTot);
//     }

//     //Get Single Reimbursable Cumulative up to Previous Bill 26-12-2019 new Function By Asheesh..
//     public function SingleReimbursableCumulativePrev_Bill($bdprojId, $invoiceId, $masterdetail_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.acc_othermonthdate.id as othermonthdateID");
//         $this->db->from("$db1.acc_othermonthdate");
//         $this->db->where("$db1.acc_othermonthdate.project_id", $bdprojId);
//         $this->db->where("$db1.acc_othermonthdate.invoice_id <= ", $invoiceId);
//         $this->db->order_by("$db1.acc_othermonthdate.id", "DESC");
//         $this->db->limit(1, 1);
//         $recRow = $this->db->get()->row();
//         if ($recRow->othermonthdateID and $masterdetail_id) {
//             $this->db->select("$db1.acc_othermonthdetail.cumulative_pre_amount,$db1.acc_othermonthdetail.cumulative_pre_mm,$db1.acc_othermonthdetail.other_mm");
//             $this->db->from("$db1.acc_othermonthdetail");
//             $this->db->where("$db1.acc_othermonthdetail.month_id", $recRow->othermonthdateID);
//             $this->db->where("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_id);
//             $resultArr = $this->db->get()->row();
//         }
//         return ($resultArr) ? $resultArr : "0";
//     }

//     public function SingleReimbursableCumulativeCurrent_Bill($bdprojId, $invoiceId, $masterdetail_id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.acc_othermonthdate.id as othermonthdateID");
//         $this->db->from("$db1.acc_othermonthdate");
//         $this->db->where("$db1.acc_othermonthdate.project_id", $bdprojId);
//         $this->db->where("$db1.acc_othermonthdate.invoice_id <= ", $invoiceId);
//         $this->db->order_by("$db1.acc_othermonthdate.id", "DESC");
//         $this->db->limit(0, 1);
//         $recRow = $this->db->get()->row();
//         if ($recRow->othermonthdateID and $masterdetail_id) {
//             $this->db->select("$db1.acc_othermonthdetail.cumulative_pre_amount,$db1.acc_othermonthdetail.cumulative_pre_mm,$db1.acc_othermonthdetail.other_mm");
//             $this->db->from("$db1.acc_othermonthdetail");
//             $this->db->where("$db1.acc_othermonthdetail.month_id", $recRow->othermonthdateID);
//             $this->db->where("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_id);
//             $resultArr = $this->db->get()->row();
//         }
//         return ($resultArr) ? $resultArr : "0";
//     }

//     //Get Reimbursable Cumulative up to Previous Bill..
//     public function ReimbursableCumulative_PrevBill($bdprojId, $invoiceId, $typerId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $masterdetail_idArr = $this->getIdsArr($bdprojId, $typerId);
//         $resultArr = 0;
//         if (($bdprojId) and ($masterdetail_idArr)) {
//             $this->db->select("$db1.acc_othermonthdate.id as othermonthdateID");
//             $this->db->from("$db1.acc_othermonthdate");
//             $this->db->where("$db1.acc_othermonthdate.project_id", $bdprojId);
//             $this->db->where("$db1.acc_othermonthdate.invoice_id <= ", $invoiceId);
//             $this->db->order_by("$db1.acc_othermonthdate.id", "DESC");
//             $this->db->limit(1, 1);
//             $recRow = $this->db->get()->row();
//             if ($recRow) {
//                 $othermonthdateID = $recRow->othermonthdateID;
//                 $this->db->select_sum("$db1.acc_othermonthdetail.cumulative_pre_amount");
//                 $this->db->from("$db1.acc_othermonthdetail");
//                 $this->db->where("$db1.acc_othermonthdetail.month_id", $othermonthdateID);
//                 $this->db->where_in("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_idArr);
//                 $resultArr = $this->db->get()->row();
//             }
//         }
//         return ($resultArr) ? $resultArr->cumulative_pre_amount : "0";
//     }

//     //Get Reimbursable Cumulative up to Current Bill..
//     public function ReimbursableCumulative_CurrentBill($bdprojId, $invoiceId, $typerId)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $resulrSumAmount = 0;
//         $masterdetail_idArr = $this->getIdsArr($bdprojId, $typerId);

//         if (($bdprojId) and ($masterdetail_idArr)) {
//             $this->db->select("$db1.acc_othermonthdate.id as othermonthdateID");
//             $this->db->from("$db1.acc_othermonthdate");
//             $this->db->where("$db1.acc_othermonthdate.project_id", $bdprojId);
//             $this->db->where("$db1.acc_othermonthdate.invoice_id <= ", $invoiceId);
//             $this->db->order_by("$db1.acc_othermonthdate.id", "DESC");
//             $this->db->limit(0, 1);
//             $recRow = $this->db->get()->row();

//             if ($recRow) {
//                 $othermonthdateID = $recRow->othermonthdateID;
//                 $this->db->select("$db1.acc_othermonthdetail.*,$db1.acc_msterdetail.description,$db1.acc_msterdetail.per_month,$db1.acc_msterdetail.qty");
//                 $this->db->from("$db1.acc_othermonthdetail");
//                 $this->db->join("$db1.acc_msterdetail", "$db1.acc_othermonthdetail.masterdetail_id=$db1.acc_msterdetail.id", "LEFT");
//                 $this->db->where("$db1.acc_othermonthdetail.month_id", $othermonthdateID);
//                 $this->db->where_in("$db1.acc_othermonthdetail.masterdetail_id", $masterdetail_idArr);
//                 $resultArr = $this->db->get()->result();

//                 if ($resultArr) {
//                     foreach ($resultArr as $roWs) {
//                         $snglCurrentMMAmount = 0;
//                         $quanty = ($roWs->qty > 0) ? $roWs->qty : "1";
//                         $snglCurrentMMAmount = ($roWs->other_mm * $roWs->per_month * $quanty);
//                         if ($bdprojId == "89224") {
//                             $snglCurrentMMAmount = (($snglCurrentMMAmount * 75) / 100);
//                         }
//                         $resulrSumAmount += $snglCurrentMMAmount;
//                     }
//                 }
//             }
//         }
//         return ($resulrSumAmount) ? $resulrSumAmount : "0";
//     }

//     //Get Key Professional Staff Total RateAmount.. Code By Asheesh
//     public function GetKeyProf_staffTotRateAmnt($bdProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $maintenance_monthsTot = 0;
//         $maintenance_rateTot = 0;
//         $construction_monthsTot = 0;
//         $construction_rateTot = 0;
//         $MMTot = 0;
//         $RateAmountTot = 0;

//         $this->db->select("$db1.assign_finalteam.id,$db1.assign_finalteam.maintenance_months,$db1.assign_finalteam.maintenance_rate,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.construction_rate,$db1.assign_finalteam.man_months,$db1.assign_finalteam.rate,$db1.assign_finalteam.key_id,$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->where("$db1.assign_finalteam.status", '1');
//         $this->db->where(array("$db1.assign_finalteam.project_id" => $bdProjID));
//         $this->db->where("($db1.assign_finalteam.designatin_categid='1')", NULL, FALSE);
//         $recResults = $this->db->get()->result_array();

//         if ($recResults) {
//             foreach ($recResults as $recd) {

//                 //Maintenance
//                 if ($recd['maintenance_months']) {
//                     $maintenance_monthsTot += $recd['maintenance_months'];
//                 }
//                 if ($recd['maintenance_months'] and $recd['rate']) {
//                     $maintenance_rateTot += ($recd['maintenance_months'] * $recd['rate']);
//                 }
//                 //Construction
//                 if ($recd['construction_months']) {
//                     $construction_monthsTot += $recd['construction_months'];
//                 }
//                 if ($recd['construction_months'] and $recd['rate']) {
//                     $construction_rateTot += ($recd['construction_months'] * $recd['rate']);
//                 }
//                 //Total MM Rate..
//                 if ($recd['man_months']) {
//                     $MMTot += $recd['man_months'];
//                 }
//                 if ($recd['man_months'] and $recd['rate']) {
//                     $RateAmountTot += ($recd['rate'] * $recd['man_months']);
//                 }
//             }
//         }
//         return array("maintenance_monthsTot" => $maintenance_monthsTot, "maintenance_rateTot" => $maintenance_rateTot, "construction_monthsTot" => $construction_monthsTot, "construction_rateTot" => $construction_rateTot, "MMTot" => $MMTot, "RateAmountTot" => $RateAmountTot);
//     }

//     //Get Key Professional Staff Total RateAmount.. Code By Asheesh
//     public function GetSubProf_staffTotRateAmnt($bdProjID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $maintenance_monthsTot = 0;
//         $maintenance_rateTot = 0;
//         $construction_monthsTot = 0;
//         $construction_rateTot = 0;
//         $MMTot = 0;
//         $RateAmountTot = 0;

//         $this->db->select("$db1.assign_finalteam.id,$db1.assign_finalteam.maintenance_months,$db1.assign_finalteam.maintenance_rate,$db1.assign_finalteam.construction_months,$db1.assign_finalteam.construction_rate,$db1.assign_finalteam.man_months,$db1.assign_finalteam.rate,$db1.assign_finalteam.key_id,$db1.assign_finalteam.designation_id,$db1.assign_finalteam.empname");
//         $this->db->from("$db1.assign_finalteam");
//         $this->db->where("$db1.assign_finalteam.status", '1');
//         $this->db->where(array("$db1.assign_finalteam.project_id" => $bdProjID));
//         $this->db->where("($db1.assign_finalteam.designatin_categid='2')", NULL, FALSE);
//         $recResults = $this->db->get()->result_array();

//         if ($recResults) {
//             foreach ($recResults as $recd) {

//                 //Maintenance
//                 if ($recd['maintenance_months']) {
//                     $maintenance_monthsTot += $recd['maintenance_months'];
//                 }
//                 if ($recd['maintenance_months'] and $recd['rate']) {
//                     $maintenance_rateTot += ($recd['maintenance_months'] * $recd['rate']);
//                 }
//                 //Construction
//                 if ($recd['construction_months']) {
//                     $construction_monthsTot += $recd['construction_months'];
//                 }
//                 if ($recd['construction_months'] and $recd['rate']) {
//                     $construction_rateTot += ($recd['construction_months'] * $recd['rate']);
//                 }
//                 //Total MM Rate..
//                 if ($recd['man_months']) {
//                     $MMTot += $recd['man_months'];
//                 }
//                 if ($recd['man_months'] and $recd['rate']) {
//                     $RateAmountTot += ($recd['rate'] * $recd['man_months']);
//                 }
//             }
//         }
//         return array("maintenance_monthsTot" => $maintenance_monthsTot, "maintenance_rateTot" => $maintenance_rateTot, "construction_monthsTot" => $construction_monthsTot, "construction_rateTot" => $construction_rateTot, "MMTot" => $MMTot, "RateAmountTot" => $RateAmountTot);
//     }

//     //Cumulative up to Previous Bill.. Func Code By Asheesh
//     public function GetKeyProf_CumulativuptoPrevAmnt($Project_id, $invoice_no)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;
//         $cumulativeamount = 0;
//         $totalcumulativeamount = 0;

//         if ($Project_id and $invoice_no) {
//             //Key Prof..
//             $recDdata = $this->GetProjDesignEmpIDs($Project_id, "1");
//             if ($recDdata) {
//                 foreach ($recDdata as $rEdRow) {
//                     //$cumulativeamount = 0;
//                     // $totalcumulativeamount = 0;
//                     $RecdCumulativuptoPrev = $this->Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $rEdRow->designation_id, $rEdRow->empname);
//                     if ($RecdCumulativuptoPrev->cumulativeamount) :
//                         $cumulativeamount += $RecdCumulativuptoPrev->cumulativeamount;
//                     endif;
//                     if ($RecdCumulativuptoPrev->totalcumulativeamount) :
//                         $totalcumulativeamount += $RecdCumulativuptoPrev->totalcumulativeamount;
//                     endif;
//                 }
//             }
//         }
//         return array("cumulativeamount" => $cumulativeamount, "totalcumulativeamount" => $totalcumulativeamount);
//     }

//     //Cumulative up to Previous Bill.. Func Code By Asheesh
//     public function GetSubProf_CumulativuptoPrevAmnt($Project_id, $invoice_no)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $cumulativeamount = 0;
//         $totalcumulativeamount = 0;

//         if ($Project_id and $invoice_no) {
//             //Sub Prof..
//             $recDdata2 = $this->GetProjDesignEmpIDs($Project_id, "2");
//             if ($recDdata2) {
//                 foreach ($recDdata2 as $rEdRow) {
//                     $RecdCumulativuptoPrev = $this->Emp_CumulativuptoPrevAmnt($Project_id, $invoice_no, $rEdRow->designation_id, $rEdRow->empname);
//                     if ($RecdCumulativuptoPrev->cumulativeamount) :
//                         $cumulativeamount += $RecdCumulativuptoPrev->cumulativeamount;
//                     endif;
//                     if ($RecdCumulativuptoPrev->totalcumulativeamount) :
//                         $totalcumulativeamount += $RecdCumulativuptoPrev->totalcumulativeamount;
//                     endif;
//                 }
//             }
//         }
//         return array("cumulativeamount" => $cumulativeamount, "totalcumulativeamount" => $totalcumulativeamount);
//     }

//     //New Code 09-05-2020...
//     //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//     //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//     //$$                 NEW Code Asheesh                                                     $$
//     //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//     //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//     //Check Designation Existance..
//     public function check_designationexist($whereArr)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->where($whereArr);
//         $num = $this->db->count_all_results("$db3.assign_designation_onproj");
//         return ($num) ? $num : null;
//     }

//     //Get Project Designation Category..
//     public function GetProjectDesignCategByProjID($hrmsProjid)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.assign_designation_onproj.design_categid,$db1.designationcat_master.ktype_name");
//         $this->db->from("$db3.assign_designation_onproj");
//         $this->db->join("$db1.designationcat_master", "$db1.designationcat_master.k_id=$db3.assign_designation_onproj.design_categid", "LEFT");

//         $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrmsProjid, "$db3.assign_designation_onproj.status" => "1"]);
//         $this->db->group_by("$db3.assign_designation_onproj.design_categid");
//         $this->db->order_by("$db3.assign_designation_onproj.design_categid", "ASC");
//         $respArrRecd = $this->db->get()->result();
//         return ($respArrRecd) ? $respArrRecd : null;
//     }

//     public function GetAllReimburDetailsListArr($bdProjectID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recdArr = $this->GetReimbursable_Byproj($bdProjectID);
//         $respReturnArr = array();
//         if ($recdArr) {
//             foreach ($recdArr as $kEyY => $RecD) {
//                 $this->db->select("$db3.reimbursable_on_project.*,$db1.main_company.company_name");
//                 $this->db->from("$db3.reimbursable_on_project");
//                 $this->db->join("$db1.main_company", "$db3.reimbursable_on_project.assign_comp_id=$db1.main_company.fld_id", "LEFT");
//                 $this->db->where("$db3.reimbursable_on_project.project_id", $bdProjectID);
//                 $this->db->where("$db3.reimbursable_on_project.reimburs_category", $RecD->reim_type_id);
//                 $this->db->where("$db3.reimbursable_on_project.status", "1");
//                 $rec2Arr = $this->db->get()->result();
//                 if ($rec2Arr) {
//                     $respReturnArr[$RecD->reim_type_id] = $rec2Arr;
//                 }
//             }
//         }
//         return ($respReturnArr) ? $respReturnArr : null;
//     }

//     //Get InterMittent Employee List on a Particular Project...
//     public function GetAllIntermittentEmplListArr($projID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db2.tm_project_employees.emp_id,$db2.main_employees_summary.userfullname");
//         $this->db->from("$db2.tm_project_employees");
//         $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db2.tm_project_employees.emp_id", "LEFT");
//         $this->db->where(["$db2.tm_project_employees.project_id" => $projID, "$db2.tm_project_employees.is_intermittent" => "1", "$db2.tm_project_employees.is_active" => "1"]);
//         $this->db->where("($db2.tm_project_employees.emp_id!='409' AND $db2.tm_project_employees.emp_id!='410' AND $db2.tm_project_employees.emp_id!='411')", NULL, FALSE);
//         $this->db->group_by("$db2.tm_project_employees.emp_id");
//         $this->db->order_by("$db2.main_employees_summary.userfullname", "ASC");
//         $recResponArr = $this->db->get()->result();
//         return ($recResponArr) ? $recResponArr : null;
//     }

//     public function GetSingleRowsByID($fldID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.assign_designation_onproj.*");
//         $this->db->from("$db3.assign_designation_onproj");
//         $this->db->where(["$db3.assign_designation_onproj.fld_id" => $fldID, "$db3.assign_designation_onproj.status" => "1"]);
//         $this->db->limit("1");
//         $recResponArr = $this->db->get()->row();
//         return ($recResponArr) ? $recResponArr : null;
//     }

//     //Employee Details By Id..
//     public function GetEmployeeDetailsByID($userID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db2.main_employees_summary.date_of_joining,$db2.main_employees_summary.userfullname");
//         $this->db->from("$db2.main_employees_summary");
//         $this->db->where(["$db2.main_employees_summary.user_id" => $userID, "$db2.main_employees_summary.isactive" => "1"]);
//         $this->db->limit("1");
//         $recResponArr = $this->db->get()->row();
//         return ($recResponArr) ? $recResponArr : null;
//     }

//     //Other Employee List Arr Rec..
//     public function OtherEmployeeList()
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.team_req_otheremp.emp_name as userfullname,$db1.team_req_otheremp.fld_id");
//         $this->db->from("$db1.team_req_otheremp");
//         $this->db->where(["$db1.team_req_otheremp.status" => "1"]);
//         $this->db->order_by("$db1.team_req_otheremp.emp_name", "ASC");
//         $this->db->group_by("$db1.team_req_otheremp.emp_email");
//         $this->db->group_by("$db1.team_req_otheremp.emp_contact");
//         $recDarr = $this->db->get()->result();
//         return ($recDarr) ? $recDarr : null;
//     }

//     //Get Single Rows..
//     public function GetSingleRowReimbursable($id)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.reimbursable_on_project.id,$db3.reimbursable_on_project.reim_rate,$db3.reimbursable_on_project.reim_mm,$db3.reimbursable_on_project.reim_tot_amount,$db3.reimbursable_on_project.reim_unit,$db3.reimbursable_on_project.reim_qty,$db3.reimbursable_on_project.reim_constr_rate,$db3.reimbursable_on_project.reim_constr_mm,$db3.reimbursable_on_project.reim_maint_rate,$db3.reimbursable_on_project.reim_maint_mm,$db3.reimbursable_on_project.assign_comp_id,$db3.reimbursable_on_project.reim_cumul_prev_mm,$db3.reimbursable_on_project.reim_cumul_prev_rate");
//         $this->db->from("$db3.reimbursable_on_project");
//         $this->db->where("$db3.reimbursable_on_project.id", $id);
//         $this->db->where("$db3.reimbursable_on_project.status", "1");
//         $singleRows = $this->db->get()->row();
//         return ($singleRows) ? $singleRows : "";
//     }

//     //Get Reimbursable Current Tbl Data..
//     public function curr_month_reimbursableByInvoiceID($invcID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.curr_month_reimbursable.*");
//         $this->db->from("$db3.curr_month_reimbursable");
//         $this->db->where(["$db3.curr_month_reimbursable.invoice_id" => $invcID, "$db3.curr_month_reimbursable.status" => "1"]);
//         $respResult = $this->db->get()->result();
//         $returnArr = array();
//         if ($respResult) {
//             foreach ($respResult as $Key => $roWs) {
//                 $returnArr[$roWs->reimbursable_id] = $roWs;
//             }
//         }
//         return ($returnArr) ? $returnArr : null;
//     }

//     //Invoice Details By Id..
//     public function InvoiceTblList($accinfoID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db1.accountinfo.project_id,$db1.accountinfo.invoice_formate_type,$db1.accountinfo.invoice_formate_type,$db1.invoicedetail.*");
//         $this->db->from("$db1.accountinfo");
//         $this->db->join("$db1.invoicedetail", "$db1.invoicedetail.project_numberid=$db1.accountinfo.project_numberid", "LEFT");
//         $this->db->where(["$db1.accountinfo.id" => $accinfoID, "$db1.accountinfo.status" => '1', "$db1.invoicedetail.status" => "1"]);
//         // $this->db->where("$db1.invoicedetail.purpose_status", "2");

//         $this->db->order_by("$db1.invoicedetail.invoice_date", "DESC");
//         $respRecArr = $this->db->get()->result();
//         return ($respRecArr) ? $respRecArr : null;
//     }

//     //Get Tax on Invoice.. Code Asheesh..
//     public function GetTaxesRecArr($invoiceID)
//     {
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.tax_master.tax_name,$db3.tax_master.percentage,$db3.tax_assign_on_invoice.cumul_prev_tot,$db3.tax_assign_on_invoice.identity_status,$db3.tax_assign_on_invoice.current_month_tot,$db3.tax_assign_on_invoice.cumul_current_tot,$db3.tax_assign_on_invoice.cvtax_tot_const,$db3.tax_assign_on_invoice.cvtax_tot_maint,$db3.tax_assign_on_invoice.cvtax_tot");
//         $this->db->from("$db3.tax_assign_on_invoice");
//         $this->db->join("$db3.tax_master", "$db3.tax_assign_on_invoice.tax_id=$db3.tax_master.id", "LEFT");
//         $this->db->where(["$db3.tax_assign_on_invoice.invoice_id" => $invoiceID, "$db3.tax_assign_on_invoice.status" => "1"]);
//         $recResult = $this->db->get()->result();
//         return ($recResult) ? $recResult : null;
//     }

//     //Reimbursable Details..
//     public function GetAllReimburDetailsListArr_invc($bdProjectID, $invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recdArr = $this->GetReimbursable_Byproj($bdProjectID);
//         $respReturnArr = array();
//         if ($recdArr) {
//             foreach ($recdArr as $kEyY => $RecD) {
//                 $this->db->select("$db3.reimbursable_on_project.*,$db1.main_company.company_name,$db3.curr_month_reimbursable.cumulative_prev_month,$db3.curr_month_reimbursable.cumulative_prev_month_amnt,$db3.curr_month_reimbursable.curr_month_reimb,$db3.curr_month_reimbursable.curr_month_reimb_amnt,$db3.curr_month_reimbursable.cumulative_tot_month,$db3.curr_month_reimbursable.cumulative_tot_month_amnt");
//                 $this->db->from("$db3.reimbursable_on_project");
//                 $this->db->join("$db1.main_company", "$db3.reimbursable_on_project.assign_comp_id=$db1.main_company.fld_id", "LEFT");
//                 $this->db->join("$db3.curr_month_reimbursable", "($db3.curr_month_reimbursable.reimbursable_id=$db3.reimbursable_on_project.id AND $db3.curr_month_reimbursable.invoice_id=$invoiceID)", "LEFT");

//                 $this->db->where("$db3.reimbursable_on_project.project_id", $bdProjectID);
//                 $this->db->where("$db3.reimbursable_on_project.reimburs_category", $RecD->reim_type_id);
//                 $this->db->where("$db3.reimbursable_on_project.status", "1");
//                 $rec2Arr = $this->db->get()->result();
//                 if ($rec2Arr) {
//                     $respReturnArr[$RecD->reim_type_id] = $rec2Arr;
//                 }
//             }
//         }
//         return ($respReturnArr) ? $respReturnArr : null;
//     }

//     //Get All Proj Designation Category Wise..
//     public function GetProjectDesignationListArr($hrmsProjid)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recDArr = $this->GetProjectDesignCategByProjID($hrmsProjid);
//         $responS = '';
//         if ($recDArr) {
//             foreach ($recDArr as $recDs) {
//                 $designCategID = $recDs->design_categid;
//                 if ($designCategID) {
//                     $this->db->select("$db3.ppdss_proj_basicinfo.start_date,$db1.team_req_otheremp.emp_name,$db3.team_on_proj_designation.user_identity,$db3.team_on_proj_designation.account_date,$db3.team_on_proj_designation.user_id,$db2.main_employees_summary.employeeId,$db2.main_employees_summary.userfullname,$db3.assign_designation_onproj.tot_amount,$db3.assign_designation_onproj.cumul_prev_mm,$db3.assign_designation_onproj.cumul_prev_rate,$db3.assign_designation_onproj.fld_id,$db3.assign_designation_onproj.design_categid,$db3.assign_designation_onproj.designation_id,$db3.assign_designation_onproj.bd_projid,$db3.assign_designation_onproj.hrms_projid,$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.mm,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.constr_mm,$db3.assign_designation_onproj.maint_rate,$db3.assign_designation_onproj.maint_mm,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.company_id,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.balance_amnt,$db1.designation_master_requisition.designation_name,$db1.main_company.company_name,$db3.team_on_proj_designation.fld_id as teamfld_id,$db3.team_on_proj_designation.reduction_perc,$db2.repl.prefix_name as prefix_name_repl,$db2.repl.userfullname as userfullname_repl,$db2.main_employees_summary.isactive,,$db2.tm_project_employees.is_intermittent");
//                     $this->db->from("$db3.assign_designation_onproj");
//                     $this->db->join("$db1.designation_master_requisition", "$db3.assign_designation_onproj.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//                     $this->db->join("$db1.main_company", "$db3.assign_designation_onproj.company_id=$db1.main_company.fld_id", "LEFT");
//                     $this->db->join("$db3.team_on_proj_designation", "($db3.team_on_proj_designation.designation_id=$db3.assign_designation_onproj.designation_id AND $db3.assign_designation_onproj.bd_projid=$db3.team_on_proj_designation.bd_project_id)", "LEFT");
//                     $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     $this->db->join("$db1.team_req_otheremp", "$db1.team_req_otheremp.fld_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     $this->db->join("$db3.empl_replacem_list_proj_desig", "$db3.empl_replacem_list_proj_desig.fld_id=$db3.team_on_proj_designation.parent_id", "LEFT");
//                     $this->db->join("$db2.main_employees_summary as repl", "$db2.repl.user_id=$db3.empl_replacem_list_proj_desig.empl_id", "LEFT");

//                     $this->db->join("$db2.tm_project_employees", "$db3.assign_designation_onproj.hrms_projid=$db2.tm_project_employees.project_id AND $db2.tm_project_employees.emp_id=$db3.team_on_proj_designation.user_id AND $db2.tm_project_employees.is_active='1'", "LEFT");
//                     $this->db->join("$db3.ppdss_proj_basicinfo", "$db3.ppdss_proj_basicinfo.hrms_id=$db3.assign_designation_onproj.hrms_projid", "LEFT");

//                     $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrmsProjid, "$db3.assign_designation_onproj.design_categid" => $designCategID, "$db3.assign_designation_onproj.status" => '1']);
//                     $this->db->order_by("$db3.assign_designation_onproj.sr_no", "ASC");
//                     $recDarr = $this->db->get()->result();
//                 }
//                 $responS[$recDs->design_categid] = $recDarr;
//             }
//         }
//         return ($responS) ? $responS : null;
//     }

//     //22-06-2020,,,
//     public function GetReplacementDesignationListArr($hrmsprojid)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;
//         $recDArr = $this->GetProjectDesignCategByProjID($hrmsprojid);
//         $responS = '';
//         if ($recDArr) {
//             foreach ($recDArr as $recDs) {
//                 $designCategID = $recDs->design_categid;
//                 $this->db->select("$db3.empl_replacem_list_proj_desig.fld_id,$db3.empl_replacem_list_proj_desig.from_date_join,$db3.empl_replacem_list_proj_desig.to_date_resign,$db1.designation_master_requisition.designation_name,$db3.assign_designation_onproj.design_categid,$db2.main_employees_summary.prefix_name,$db2.main_employees_summary.userfullname");
//                 $this->db->from("$db3.empl_replacem_list_proj_desig");
//                 $this->db->join("$db1.designation_master_requisition", "$db3.empl_replacem_list_proj_desig.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//                 $this->db->join("$db3.assign_designation_onproj", "($db3.assign_designation_onproj.hrms_projid=$db3.empl_replacem_list_proj_desig.hrmsproject_id AND $db3.assign_designation_onproj.designation_id=$db3.empl_replacem_list_proj_desig.designation_id)", "LEFT");
//                 $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.empl_replacem_list_proj_desig.empl_id", "LEFT");
//                 $this->db->where(["$db3.assign_designation_onproj.design_categid" => $designCategID, "$db3.empl_replacem_list_proj_desig.hrmsproject_id" => $hrmsprojid, "$db3.empl_replacem_list_proj_desig.status" => "1"]);
//                 $this->db->order_by("$db3.empl_replacem_list_proj_desig.from_date_join", "ASC");
//                 $replRecArr = $this->db->get()->result();
//                 $responS[$recDs->design_categid] = $replRecArr;
//             }
//         }
//         return ($responS) ? $responS : null;
//     }

//     //Get Invoice ID..
//     public function GetInvoiceID($hrmsProjId, $yearMM)
//     {
//         $db1 = $this->db1->database;
//         $this->db->select("$db1.invoicedetail.id as invoice_id");
//         $this->db->from("$db1.invoicedetail");
//         $this->db->where(["$db1.invoicedetail.status" => "1", "$db1.invoicedetail.project_numberid" => $hrmsProjId]);
//         $this->db->where("DATE_FORMAT($db1.invoicedetail.invoice_date,'%Y-%m') =", $yearMM);
//         $recResultArr = $this->db->get()->row();
//         return ($recResultArr->invoice_id) ? $recResultArr->invoice_id : null;
//     }

//     //Get Current Month Bill Amount.. By Invoice ID..
//     public function GetCurrMonthBillAmount_Team($invoice_id)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select_sum("$db3.curr_month_invc_team.curr_month_amnt");
//         $this->db->from("$db3.curr_month_invc_team");
//         $this->db->where(["$db3.curr_month_invc_team.status" => "1", "$db3.curr_month_invc_team.invoice_id" => $invoice_id]);
//         $recResultArr = $this->db->get()->row();
//         return ($recResultArr->curr_month_amnt) ? $recResultArr->curr_month_amnt : 0;
//     }

//     //Get Current Month Bill Amount.. By Invoice ID..
//     public function GetCurrMonthBillAmount_Reimb($invoice_id)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select_sum("$db3.curr_month_reimbursable.curr_month_reimb_amnt");
//         $this->db->from("$db3.curr_month_reimbursable");
//         $this->db->where(["$db3.curr_month_reimbursable.status" => "1", "$db3.curr_month_reimbursable.invoice_id" => $invoice_id]);
//         $recResultArr = $this->db->get()->row();
//         return ($recResultArr->curr_month_reimb_amnt) ? $recResultArr->curr_month_reimb_amnt : 0;
//     }

//     //Get Current Month Bill Amount Escalation .. By Invoice ID..
//     public function GetCurrMonthBillAmount_Escal($invoice_id)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select_sum("$db3.escalation_on_invoice.current_month_tot");
//         $this->db->from("$db3.escalation_on_invoice");
//         $this->db->where(["$db3.escalation_on_invoice.identity_status" => "1", "$db3.escalation_on_invoice.status" => "1", "$db3.escalation_on_invoice.invoice_id" => $invoice_id]);
//         $recResultArr = $this->db->get()->row();
//         return ($recResultArr->current_month_tot) ? $recResultArr->current_month_tot : 0;
//     }

//     public function getInvoiceDetailByid($invoice_id)
//     {
//         $db1 = $this->db1->database;
//         $this->db->select("$db1.invoicedetail.*,$db1.accountinfo.project_id");
//         $this->db->from("$db1.invoicedetail");
//         $this->db->join("$db1.accountinfo", "$db1.invoicedetail.infoid=$db1.accountinfo.id", "LEFT");
//         $this->db->where("$db1.invoicedetail.id", $invoice_id);
//         return $recArr = $this->db->get()->row();
//     }

//     public function GetAllEscalation_Invoice($invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.escalation_on_invoice.*");
//         $this->db->from("$db3.escalation_on_invoice");
//         $this->db->where(["$db3.escalation_on_invoice.invoice_id" => $invoiceID, "$db3.escalation_on_invoice.status" => "1"]);
//         $RecResultEsc = $this->db->get()->result();
//         return ($RecResultEsc) ? $RecResultEsc : null;
//     }

//     public function GetAllEscalation_onProject($BdprojID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.escalation_on_project.*");
//         $this->db->from("$db3.escalation_on_project");
//         $this->db->where(["$db3.escalation_on_project.bdproject_id" => $BdprojID, "$db3.escalation_on_project.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->result();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     public function getCurrEscalation($invcID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.escalation_on_invoice.escalation_on_projid,$db3.escalation_on_invoice.cumul_current_tot");
//         $this->db->from("$db3.escalation_on_invoice");
//         $this->db->where(["$db3.escalation_on_invoice.invoice_id" => $invcID, "$db3.escalation_on_invoice.identity_status" => "1", "$db3.escalation_on_invoice.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->result();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     public function getCurrTaxRec($invcID)
//     {
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.tax_assign_on_invoice.assign_tax_onprojid,$db3.tax_assign_on_invoice.cumul_current_tot");
//         $this->db->from("$db3.tax_assign_on_invoice");
//         $this->db->where(["$db3.tax_assign_on_invoice.invoice_id" => $invcID, "$db3.tax_assign_on_invoice.identity_status" => "1", "$db3.tax_assign_on_invoice.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->result();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     //Get Record By Acc Info..
//     public function getRecByaccInfoID($infoID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;

//         $this->db->select("$db1.accountinfo.*,$db2.tm_projects.project_name");
//         $this->db->from("$db1.accountinfo");
//         $this->db->join("$db2.tm_projects", "$db1.accountinfo.project_numberid=$db2.tm_projects.id", "LEFT");
//         $this->db->where(["$db1.accountinfo.id" => $infoID, "$db1.accountinfo.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->row();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     //Get Single Record Details By Assign Designation on Proj ID..
//     public function GetBasicDetails_Asign_Design_ProjID($fld_ID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.a.bd_projid,$db3.a.hrms_projid,$db3.a.designation_id,$db3.a.rate,$db3.a.mm,$db3.a.constr_rate,$db3.a.constr_mm,$db3.a.maint_rate,$db3.a.maint_mm,$db3.a.balance_mm,$db3.a.balance_amnt,$db3.a.tot_amount,$db3.a.cumul_prev_mm,$db3.a.cumul_prev_rate,$db3.a.company_id,$db3.b.user_id,$db3.b.user_identity,$db3.b.is_child,$db3.b.parent_id,$db3.b.reduction_perc,$db3.b.account_date");
//         $this->db->from("$db3.assign_designation_onproj as a");
//         $this->db->join("$db3.team_on_proj_designation as b", "($db3.a.designation_id=$db3.b.designation_id AND $db3.a.bd_projid=$db3.b.bd_project_id)", "LEFT");
//         $this->db->where(["$db3.a.fld_id" => $fld_ID, "$db3.a.status" => "1"]);
//         $singleRowRec = $this->db->get()->row();
//         return ($singleRowRec) ? $singleRowRec : null;
//     }

//     //Get Single Record Details By Assign Designation on Proj ID..
//     public function GetBasicDetailsReimbusable_ReimbID($fld_ID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.a.project_id,$db3.a.hrms_projid,$db3.a.reim_rate,$db3.a.reim_mm,$db3.a.reim_tot_amount,$db3.a.reim_unit,$db3.a.reim_qty,$db3.a.reim_constr_rate,$db3.a.reim_constr_mm,$db3.a.reim_maint_rate,$db3.a.reim_maint_mm,$db3.a.assign_comp_id,$db1.b.invoice_formate_type");
//         $this->db->from("$db3.reimbursable_on_project as a");
//         $this->db->join("$db1.accountinfo as b", "($db1.b.project_numberid=$db3.a.hrms_projid AND $db1.b.status='1')", "LEFT");

//         $this->db->where("$db3.a.status", "1");
//         $this->db->where("$db3.a.id", $fld_ID);
//         $singleRecReimb = $this->db->get()->row();
//         return ($singleRecReimb) ? $singleRecReimb : null;
//     }

//     public function GetAllEscalation_Proj_invc($BdprojID, $invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.escalation_on_project.*,$db3.escalation_on_invoice.current_month_tot");
//         $this->db->from("$db3.escalation_on_project");
//         $this->db->join("$db3.escalation_on_invoice", "($db3.escalation_on_project.fld_id=$db3.escalation_on_invoice.escalation_on_projid AND $db3.escalation_on_invoice.invoice_id=$invoiceID)", "LEFT");
//         $this->db->where(["$db3.escalation_on_project.bdproject_id" => $BdprojID, "$db3.escalation_on_project.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->result();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     //Escalation Details By ID..
//     public function EscalationDetailsByID($EsclID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.escalation_on_project.*");
//         $this->db->from("$db3.escalation_on_project");
//         $this->db->where(["$db3.escalation_on_project.fld_id" => $EsclID, "$db3.escalation_on_project.status" => "1"]);
//         $singleRecEscl = $this->db->get()->row();
//         return ($singleRecEscl) ? $singleRecEscl : null;
//     }

//     public function GetAllTax_Proj_invc($BdprojID, $invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.tax_assign_on_project.*,$db3.tax_assign_on_invoice.current_month_tot,$db3.tax_master.tax_name,$db3.tax_master.percentage");
//         $this->db->from("$db3.tax_assign_on_project");
//         $this->db->join("$db3.tax_master", "$db3.tax_master.id=$db3.tax_assign_on_project.tax_master_id", "LEFT");
//         $this->db->join("$db3.tax_assign_on_invoice", "($db3.tax_assign_on_project.fld_id=$db3.tax_assign_on_invoice.assign_tax_onprojid AND $db3.tax_assign_on_invoice.invoice_id=$invoiceID)", "LEFT");
//         $this->db->where(["$db3.tax_assign_on_project.bdproject_id" => $BdprojID, "$db3.tax_assign_on_project.status" => "1"]);
//         $ReturnrecArr = $this->db->get()->result();
//         return ($ReturnrecArr) ? $ReturnrecArr : null;
//     }

//     //Tax Details By ID..
//     public function TaxDetailsByID($taxID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.tax_assign_on_project.*");
//         $this->db->from("$db3.tax_assign_on_project");
//         $this->db->where(["$db3.tax_assign_on_project.fld_id" => $taxID, "$db3.tax_assign_on_project.status" => "1"]);
//         $singleRecTax = $this->db->get()->row();
//         return ($singleRecTax) ? $singleRecTax : null;
//     }

//     //Get All Proj Designation Category Wise..
//     public function GetProjectDesignationListArr_all($hrmsProjid, $invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $responS = '';
//         $this->db->select("$db1.team_req_otheremp.emp_name,$db3.team_on_proj_designation.user_identity,$db3.team_on_proj_designation.account_date,$db3.team_on_proj_designation.user_id,$db2.main_employees_summary.userfullname,$db3.assign_designation_onproj.tot_amount,$db3.assign_designation_onproj.cumul_prev_mm,$db3.assign_designation_onproj.cumul_prev_rate,$db3.assign_designation_onproj.fld_id,$db3.assign_designation_onproj.design_categid,$db3.assign_designation_onproj.designation_id,$db3.assign_designation_onproj.bd_projid,$db3.assign_designation_onproj.hrms_projid,$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.mm,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.constr_mm,$db3.assign_designation_onproj.maint_rate,$db3.assign_designation_onproj.maint_mm,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.company_id,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.balance_amnt,$db1.designation_master_requisition.designation_name,$db1.main_company.company_name,$db3.team_on_proj_designation.fld_id as teamfld_id,$db3.curr_month_invc_team.cumulative_prev_month,$db3.curr_month_invc_team.cumulative_prev_month_amnt,$db3.curr_month_invc_team.curr_month_mm,$db3.curr_month_invc_team.curr_month_amnt,$db3.curr_month_invc_team.cumulative_tot_month,$db3.curr_month_invc_team.cumulative_tot_month_amnt,$db3.team_on_proj_designation.reduction_perc,$db2.repl.prefix_name as prefix_name_repl,$db2.repl.userfullname as userfullname_repl");
//         $this->db->from("$db3.assign_designation_onproj");
//         $this->db->join("$db1.designation_master_requisition", "$db3.assign_designation_onproj.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//         $this->db->join("$db1.main_company", "$db3.assign_designation_onproj.company_id=$db1.main_company.fld_id", "LEFT");
//         $this->db->join("$db3.team_on_proj_designation", "($db3.team_on_proj_designation.designation_id=$db3.assign_designation_onproj.designation_id AND $db3.assign_designation_onproj.bd_projid=$db3.team_on_proj_designation.bd_project_id )", "LEFT");
//         $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.team_on_proj_designation.user_id", "LEFT");
//         $this->db->join("$db1.team_req_otheremp", "$db1.team_req_otheremp.fld_id=$db3.team_on_proj_designation.user_id", "LEFT");
//         $this->db->join("$db3.curr_month_invc_team", "($db3.assign_designation_onproj.fld_id=$db3.curr_month_invc_team.assign_design_onproj_id AND $db3.curr_month_invc_team.invoice_id=$invoiceID)", "LEFT");
//         $this->db->join("$db3.empl_replacem_list_proj_desig", "$db3.empl_replacem_list_proj_desig.fld_id=$db3.team_on_proj_designation.parent_id", "LEFT");
//         $this->db->join("$db2.main_employees_summary as repl", "$db2.repl.user_id=$db3.empl_replacem_list_proj_desig.empl_id", "LEFT");
//         $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrmsProjid, "$db3.assign_designation_onproj.status" => '1']);
//         $this->db->order_by("$db3.assign_designation_onproj.sr_no", "ASC");
//         $Recresp = $this->db->get()->result();

//         if ($Recresp) {
//             foreach ($Recresp as $rEcd) {
//                 $responS[$rEcd->fld_id] = $rEcd;
//             }
//         }

//         return ($responS) ? $responS : null;
//     }

//     //Get Single Record Details By Assign Designation on Proj ID..
//     public function GetBasicDetails_Asign_Design_ProjID_ppdss($fld_ID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.a.bd_projid,$db3.a.hrms_projid,$db3.a.designation_id,$db3.a.rate,$db3.a.mm,$db3.a.constr_rate,$db3.a.constr_mm,$db3.a.maint_rate,$db3.a.maint_mm,$db3.a.balance_mm,$db3.a.balance_amnt,$db3.a.tot_amount,$db3.a.cumul_prev_mm,$db3.a.cumul_prev_rate,$db3.a.company_id,$db3.b.user_id,$db3.b.user_identity,$db3.b.is_child,$db3.b.parent_id,$db3.b.reduction_perc,$db3.b.account_date,$db3.c.work_category,c.devlp_mm,c.const_mm,c.maint_mm,c.id as ppdss_mm_on_designation_id");
//         $this->db->from("$db3.assign_designation_onproj as a");
//         $this->db->join("$db3.team_on_proj_designation as b", "($db3.a.designation_id=$db3.b.designation_id AND $db3.a.bd_projid=$db3.b.bd_project_id)", "LEFT");
//         $this->db->join("$db3.ppdss_mm_on_designation as c", "$db3.c.assign_design_onproj_id=$db3.a.fld_id", "LEFT");

//         $this->db->where(["$db3.a.fld_id" => $fld_ID, "$db3.a.status" => "1"]);
//         $singleRowRec = $this->db->get()->row();
//         return ($singleRowRec) ? $singleRowRec : null;
//     }

//     //Get Replacement Designation List..
//     public function GetReplacementDesignList($hrmsProjID, $designID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.a.from_date_join,$db3.a.to_date_resign,$db3.a.reduction_perc,$db2.b.prefix_name,$db2.b.userfullname,$db2.b.isactive");
//         $this->db->from("$db3.empl_replacem_list_proj_desig as a");
//         $this->db->join("$db2.main_employees_summary as b", "$db2.b.user_id=$db3.a.empl_id", "LEFT");
//         $this->db->where(["$db3.a.hrmsproject_id" => $hrmsProjID, "$db3.a.designation_id" => $designID, "$db3.a.status" => "1"]);
//         $this->db->order_by("$db3.a.to_date_resign", "DESC");
//         $respRecArr = $this->db->get()->result();
//         return ($respRecArr) ? $respRecArr : null;
//     }

//     public function allvacancy_statuslist()
//     {
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.a.id,$db3.a.status_name");
//         $this->db->from("$db3.ppdss_vacancy_status_master as a");
//         $this->db->where("$db3.a.status", '1');
//         $this->db->order_by("$db3.a.status_name", 'ASC');
//         $res = $this->db->get()->result_object();
//         return isset($res) ? $res : false;
//     }

//     //Get Current Vacant Status of PPdss.
//     public function GetCurrVacantPPDS_Status($assignDesignID)
//     {
//         $db3 = $this->db3->database;

//         $this->db->select("$db3.a.id,$db3.a.status_id,$db3.a.vacant_resign_date,$db3.b.status_name");
//         $this->db->from("$db3.ppdss_vacant_status as a");
//         $this->db->join("$db3.ppdss_vacancy_status_master as b", "$db3.b.id=$db3.a.status_id", "LEFT");
//         $this->db->where(["$db3.a.status" => '1', "$db3.a.assign_design_onproj_id" => $assignDesignID]);
//         $res = $this->db->get()->row();
//         return isset($res) ? $res : null;
//     }

//     //Assign Designation Details on Project Get Record..
//     public function GetRecordByDesignIDprojID($hrmsProjID, $designation)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.a.fld_id,$db3.a.bd_projid");
//         $this->db->from("$db3.assign_designation_onproj as a");
//         $this->db->where(["$db3.a.status" => "1", "$db3.a.hrms_projid" => $hrmsProjID, "$db3.a.designation_id" => $designation]);
//         $recRows = $this->db->get()->row();
//         return $recRows;
//     }

//     //Get All Proj Designation Category Wise..
//     public function GetProjectDesignationListArr_eot($hrmsProjid, $eotID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recDArr = $this->GetProjectDesignCategByProjID($hrmsProjid);
//         $responS = '';
//         if ($recDArr) {
//             foreach ($recDArr as $recDs) {
//                 $designCategID = $recDs->design_categid;
//                 if ($designCategID) {
//                     $this->db->select("$db1.team_req_otheremp.emp_name,$db3.team_on_proj_designation.user_identity,$db3.team_on_proj_designation.account_date,$db3.team_on_proj_designation.user_id,$db2.main_employees_summary.userfullname,$db3.assign_designation_onproj.tot_amount,$db3.assign_designation_onproj.cumul_prev_mm,$db3.assign_designation_onproj.cumul_prev_rate,$db3.assign_designation_onproj.fld_id,$db3.assign_designation_onproj.design_categid,$db3.assign_designation_onproj.designation_id,$db3.assign_designation_onproj.bd_projid,$db3.assign_designation_onproj.hrms_projid,$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.mm,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.constr_mm,$db3.assign_designation_onproj.maint_rate,$db3.assign_designation_onproj.maint_mm,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.company_id,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.balance_amnt,$db1.designation_master_requisition.designation_name,$db1.main_company.company_name,$db3.team_on_proj_designation.fld_id as teamfld_id,$db3.team_on_proj_designation.reduction_perc,$db2.repl.prefix_name as prefix_name_repl,$db2.repl.userfullname as userfullname_repl,$db2.main_employees_summary.isactive,$db3.eot_on_designation.utl_tot_mm,$db3.eot_on_designation.utl_tot_amount,$db3.eot_on_designation.eot_mm,$db3.eot_on_designation.eot_rate");
//                     $this->db->from("$db3.assign_designation_onproj");
//                     $this->db->join("$db1.designation_master_requisition", "$db3.assign_designation_onproj.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//                     $this->db->join("$db1.main_company", "$db3.assign_designation_onproj.company_id=$db1.main_company.fld_id", "LEFT");
//                     $this->db->join("$db3.team_on_proj_designation", "($db3.team_on_proj_designation.designation_id=$db3.assign_designation_onproj.designation_id AND $db3.assign_designation_onproj.bd_projid=$db3.team_on_proj_designation.bd_project_id)", "LEFT");
//                     $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     $this->db->join("$db1.team_req_otheremp", "$db1.team_req_otheremp.fld_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     $this->db->join("$db3.empl_replacem_list_proj_desig", "$db3.empl_replacem_list_proj_desig.fld_id=$db3.team_on_proj_designation.parent_id", "LEFT");
//                     $this->db->join("$db2.main_employees_summary as repl", "$db2.repl.user_id=$db3.empl_replacem_list_proj_desig.empl_id", "LEFT");
//                     $this->db->join("$db3.eot_on_designation", "($db3.eot_on_designation.assign_design_onproj_id=$db3.assign_designation_onproj.fld_id AND $db3.eot_on_designation.eot_id=$eotID)", "LEFT");
//                     $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrmsProjid, "$db3.assign_designation_onproj.design_categid" => $designCategID, "$db3.assign_designation_onproj.status" => '1']);
//                     $this->db->order_by("$db3.assign_designation_onproj.sr_no", "ASC");
//                     $recDarr = $this->db->get()->result();
//                 }
//                 $responS[$recDs->design_categid] = $recDarr;
//             }
//         }
//         return ($responS) ? $responS : null;
//     }

//     //For EOT ...
//     public function GetAllReimburDetailsListArr_eot($bdProjectID, $eotID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recdArr = $this->GetReimbursable_Byproj($bdProjectID);
//         $respReturnArr = array();
//         if ($recdArr) {
//             foreach ($recdArr as $kEyY => $RecD) {
//                 $this->db->select("$db3.reimbursable_on_project.*,$db1.main_company.company_name,$db3.eot_on_reimbursable.reim_utl_tot_mm,$db3.eot_on_reimbursable.reim_utl_tot_amount,$db3.eot_on_reimbursable.eot_reim_mm,$db3.eot_on_reimbursable.eot_reim_qty,$db3.eot_on_reimbursable.eot_reim_rate");
//                 $this->db->from("$db3.reimbursable_on_project");
//                 $this->db->join("$db1.main_company", "$db3.reimbursable_on_project.assign_comp_id=$db1.main_company.fld_id", "LEFT");
//                 $this->db->join("$db3.eot_on_reimbursable", "($db3.eot_on_reimbursable.reimburs_id=$db3.reimbursable_on_project.id AND $db3.eot_on_reimbursable.eot_id=$eotID)", "LEFT");
//                 $this->db->where("$db3.reimbursable_on_project.project_id", $bdProjectID);
//                 $this->db->where("$db3.reimbursable_on_project.reimburs_category", $RecD->reim_type_id);
//                 $this->db->where("$db3.reimbursable_on_project.status", "1");
//                 $rec2Arr = $this->db->get()->result();
//                 if ($rec2Arr) {
//                     $respReturnArr[$RecD->reim_type_id] = $rec2Arr;
//                 }
//             }
//         }
//         return ($respReturnArr) ? $respReturnArr : null;
//     }

//     //Get All Proj Designation Category Wise..
//     public function GetProjectDesignationListArr_invc($hrmsProjid, $invoiceID)
//     {
//         $db1 = $this->db1->database;
//         $db2 = $this->db2->database;
//         $db3 = $this->db3->database;

//         $recDArr = $this->GetProjectDesignCategByProjID($hrmsProjid);

//         $responS = '';
//         if ($recDArr) {
//             foreach ($recDArr as $recDs) {
//                 $designCategID = $recDs->design_categid;
//                 if ($designCategID) {
//                     $this->db->select("$db1.team_req_otheremp.emp_name,$db3.team_on_proj_designation.user_identity,$db3.team_on_proj_designation.account_date,$db3.team_on_proj_designation.user_id,$db2.main_employees_summary.userfullname,$db3.assign_designation_onproj.tot_amount,$db3.assign_designation_onproj.cumul_prev_mm,$db3.assign_designation_onproj.cumul_prev_rate,$db3.assign_designation_onproj.fld_id,$db3.assign_designation_onproj.design_categid,$db3.assign_designation_onproj.designation_id,$db3.assign_designation_onproj.bd_projid,$db3.assign_designation_onproj.hrms_projid,$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.mm,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.constr_mm,$db3.assign_designation_onproj.maint_rate,$db3.assign_designation_onproj.maint_mm,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.company_id,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.balance_amnt,$db1.designation_master_requisition.designation_name,$db1.main_company.company_name,$db3.team_on_proj_designation.fld_id as teamfld_id,$db3.curr_month_invc_team.cumulative_prev_month,$db3.curr_month_invc_team.cumulative_prev_month_amnt,$db3.curr_month_invc_team.curr_month_mm,$db3.curr_month_invc_team.curr_month_amnt,$db3.curr_month_invc_team.cumulative_tot_month,$db3.curr_month_invc_team.cumulative_tot_month_amnt,$db3.team_on_proj_designation.reduction_perc,$db2.repl.prefix_name as prefix_name_repl,$db2.repl.userfullname as userfullname_repl,$db3.team_on_proj_designation.flag_of_repl,$db1.repl_empl_other.emp_name as repl_other_tbl_empl");
//                     $this->db->from("$db3.assign_designation_onproj");
//                     $this->db->join("$db1.designation_master_requisition", "$db3.assign_designation_onproj.designation_id=$db1.designation_master_requisition.fld_id", "LEFT");
//                     $this->db->join("$db1.main_company", "$db3.assign_designation_onproj.company_id=$db1.main_company.fld_id", "LEFT");
//                     $this->db->join("$db3.team_on_proj_designation", "($db3.team_on_proj_designation.designation_id=$db3.assign_designation_onproj.designation_id AND $db3.assign_designation_onproj.bd_projid=$db3.team_on_proj_designation.bd_project_id)", "LEFT");
//                     $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     $this->db->join("$db1.team_req_otheremp", "$db1.team_req_otheremp.fld_id=$db3.team_on_proj_designation.user_id", "LEFT");
//                     //Code Update By Asheesh 29-09-2020..
//                     $this->db->join("$db3.curr_month_invc_team", "($db3.assign_designation_onproj.fld_id=$db3.curr_month_invc_team.assign_design_onproj_id AND $db3.curr_month_invc_team.invoice_id=$invoiceID AND $db3.curr_month_invc_team.status='1')", "LEFT");
//                     $this->db->join("$db3.empl_replacem_list_proj_desig", "($db3.empl_replacem_list_proj_desig.fld_id=$db3.team_on_proj_designation.parent_id AND $db3.empl_replacem_list_proj_desig.flag_of_repl='1')", "LEFT");
//                     //Code For Repl From Other Table Code By Asheesh 03-02-2020
//                     $this->db->join("$db3.empl_replacem_list_proj_desig as replc_other", "($db3.replc_other.fld_id=$db3.team_on_proj_designation.parent_id AND $db3.replc_other.flag_of_repl='2')", "LEFT");

//                     $this->db->join("$db2.main_employees_summary as repl", "$db2.repl.user_id=$db3.empl_replacem_list_proj_desig.empl_id", "LEFT");
//                     $this->db->join("$db1.team_req_otheremp as repl_empl_other", "$db1.repl_empl_other.fld_id=$db3.replc_other.empl_id", "LEFT");

//                     $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrmsProjid, "$db3.assign_designation_onproj.design_categid" => $designCategID, "$db3.assign_designation_onproj.status" => '1']);
//                     //Code Comment By Asheesh 29-09-2020
//                     //================code start by durgesh(31-07-2020)=====================//
//                     // $this->db->where("$db3.curr_month_invc_team.status", '1');
//                     //================code end by durgesh(31-07-2020)======================//
//                     $this->db->order_by("$db3.assign_designation_onproj.sr_no", "ASC");
//                     // $this->db->group_by("$db3.team_on_proj_designation.user_id");
//                     $recDarr = $this->db->get()->result();
//                 }
//                 $responS[$recDs->design_categid] = $recDarr;
//             }
//         }
//         return ($responS) ? $responS : null;
//     }



//     //Get EOT Details... Approved.
//     public function ApprvEOTDetails_SumMM($hrmsProjID, $designationID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.a.eot_id");
//         $this->db->from("$db3.eot_details_main as a");
//         $this->db->where(["$db3.a.hrmsproj_id" => $hrmsProjID, "$db3.a.is_approved" => "1", "$db3.a.status" => "1"]);
//         $respRecd = $this->db->get()->result();

//         $respN = 0;
//         if ($respRecd) {
//             foreach ($respRecd as $recD) {
//                 $EotID = $recD->eot_id;
//                 $this->db->select("$db3.a.eot_mm");
//                 $this->db->from("$db3.eot_on_designation as a");
//                 $this->db->where(["$db3.a.eot_id" => $EotID, "$db3.a.hrms_projid" => $hrmsProjID, "$db3.a.designation_id" => $designationID]);
//                 $GeT = $this->db->get()->row();
//                 $respN += $GeT->eot_mm;
//             }
//         }
//         return $respN;
//     }



//     public function UnApprvEOTDetails_SumMM($hrmsProjID, $designationID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.a.eot_id");
//         $this->db->from("$db3.eot_details_main as a");
//         $this->db->where(["$db3.a.hrmsproj_id" => $hrmsProjID, "$db3.a.is_approved" => "0", "$db3.a.status" => "1"]);
//         $respRecd = $this->db->get()->result();

//         $respN = 0;
//         if ($respRecd) {
//             foreach ($respRecd as $recD) {
//                 $EotID = $recD->eot_id;
//                 $this->db->select("$db3.a.eot_mm");
//                 $this->db->from("$db3.eot_on_designation as a");
//                 $this->db->where(["$db3.a.eot_id" => $EotID, "$db3.a.hrms_projid" => $hrmsProjID, "$db3.a.designation_id" => $designationID]);
//                 $GeT = $this->db->get()->row();
//                 $respN += $GeT->eot_mm;
//             }
//         }
//         return  $respN;
//     }

//     //===========================================================================
//     public function getEndDateOfProjectByProjectID($hrmsProjID)
//     {
//         $db3 = $this->db3->database;
//         $this->db->select("$db3.a.eot_id,$db3.a.eot_extn_end_date");
//         $this->db->from("$db3.eot_details_main as a");
//         $this->db->where(["$db3.a.hrmsproj_id" => $hrmsProjID, "$db3.a.status" => "1"]);
//         $this->db->order_by("$db3.a.eot_id", "DESC");
//         $this->db->limit(1);
//         $respRecd = $this->db->get()->row();
//         return $respRecd;
//     }
// }
