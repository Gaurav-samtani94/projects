<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HrCategory_model extends CI_Model
{

    var $user_table = 'main_employees_summary as a';
    var $tick_ticket_raise = 'tick_ticket_raise as b';
    var $column_order = array(null, 'employeeId', 'userfullname', 'department_name', 'c_name');
    var $column_search = array('employeeId', 'userfullname', 'department_name', 'c_name');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }




    public function GetCatehoryecord()
    {
        $this->db->select('a.c_name,a.fld_id');
        $this->db->from('tick_ticket_category_master as a');
        //  $this->db->where(array("a.user_id" => $userID, "a.status" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }


    public function getHrlist()
    {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $UserId = $this->session->userdata('loginid');
        $this->db->select('a.user_id,a.department_name,b.userfullname');
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_users as b", "a.user_id=b.id", "LEFT");
        // $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "a.department_id" => "11"));
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }


    public function inserted_data($data)
    {
        $this->db->insert('hr_person_assign_to_category', $data);
        return true;
    }


    public function getassignlist()
    {
        // return "qwertyuiop";
        $this->db->select('count(a.hruser_id) as abc,a.category_id,a.hruser_id,a.assign_date,c.userfullname,');
        $this->db->from('hr_person_assign_to_category as a');
        // $this->db->join("emp_otherofficial_data as b", "a.hruser_id=b.user_id", "LEFT");
        $this->db->join("main_users as c", "a.hruser_id=c.id", "LEFT");
        // $this->db->join("tick_ticket_category_master as b", "b.fld_id=a.category_id", "LEFT");
        $this->db->group_by('a.hruser_id');
        $this->db->where(array("a.status" => "1"));
        $RecRows = $this->db->get()->result();



        return ($RecRows) ? $RecRows : null;
    }


    public function GetcategoryAssigndata($hruser_id)
    {
        // return "qwertyuiop"; "a.project_id" => $hruser_id
        $this->db->select('b.c_name,a.assign_date,c.userfullname');
        // $this->db->select('*');
        $this->db->from('hr_person_assign_to_category as a');
        $this->db->join("tick_ticket_category_master as b", "a.category_id=b.fld_id", "LEFT");
        $this->db->join("main_users as c", "a.hruser_id=c.id", "LEFT");
        //$this->db->group_by('hruser_id');
        $this->db->where(array("a.status" => "1", "hruser_id" => $hruser_id));
        $RecRows = $this->db->get()->result();



        return ($RecRows) ? $RecRows : null;
    }
}
