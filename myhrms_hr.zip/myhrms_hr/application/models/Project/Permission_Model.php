<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Permission_Model extends CI_Model
{

    var $table = 'main_employees_summary';
    var $column_order = array(null, 'userfullname', 'employeeId', 'department_name', 'position_name');
    var $column_search = array('userfullname', 'employeeId', 'department_name', 'position_name');
    var $order = array('userfullname' => 'ASC');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    private function _get_datatables_query()
    {

        //$user = $this->session->userdata('loginid');
        $this->db->select('a.userfullname,a.employeeId,a.department_name,a.position_name,c.emp_id,c.status');
        $this->db->from('main_employees_summary as a ');
        // $this->db->join("main_users as b", "b.id=a.user_id", "LEFT");
        $this->db->join("hrms_lock_edit as c", "c.emp_id=a.user_id", "LEFT");
        $this->db->where('a.user_id>', '175');
        $this->db->where('a.isactive', '1');

        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables()
    {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }


    public function Send_request_yes($emp_id)
    {
        $data = ['status' => '2'];
        $this->db->where('emp_id', $emp_id);
        $return = $this->db->update('hrms_lock_edit', $data);
        if ($return) {
            $msg = 'Permission Restrict Successfully';
        } else {
            $msg = 'Permission Not Restrict';
        }
        return $msg;
    }

    public function Send_request_no($emp_id)
    {
        $data = [
            'status' => '1',
        ];
        $this->db->where('emp_id', $emp_id);
        $return = $this->db->update('hrms_lock_edit', $data);
        if ($return) {
            $msg = 'Permission Grant Successfully';
        } else {
            $msg = 'Permission Not Grant';
        }
        return $msg;
    }
}
