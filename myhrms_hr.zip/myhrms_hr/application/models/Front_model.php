<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Front_model extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        $this->db2 = $this->load->database('default', TRUE);
        $this->db1 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }

    public function gettimesheetdetail($project_id, $designation_id, $month, $year) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;

        $this->db->select("$db1.timeshet_fill.emp_id , SUM(IF($db1.timeshet_fill.1 = 'l', 1,0) + IF($db1.timeshet_fill.2 = 'l', 1,0)
				+ IF($db1.timeshet_fill.3 = 'l', 1,0) + IF($db1.timeshet_fill.4 = 'l', 1,0) + IF($db1.timeshet_fill.5 = 'l', 1,0)
				+ IF($db1.timeshet_fill.6 = 'l', 1,0) + IF($db1.timeshet_fill.7 = 'l', 1,0) + IF($db1.timeshet_fill.8 = 'l', 1,0)
				+ IF($db1.timeshet_fill.9 = 'l', 1,0) + IF($db1.timeshet_fill.10 = 'l', 1,0) + IF($db1.timeshet_fill.11 = 'l', 1,0)
				+ IF($db1.timeshet_fill.12 = 'l', 1,0) + IF($db1.timeshet_fill.13 = 'l', 1,0) + IF($db1.timeshet_fill.14 = 'l', 1,0)
				+ IF($db1.timeshet_fill.15 = 'l', 1,0) + IF($db1.timeshet_fill.16 = 'l', 1,0) + IF($db1.timeshet_fill.17 = 'l', 1,0)
				+ IF($db1.timeshet_fill.18 = 'l', 1,0) + IF($db1.timeshet_fill.19 = 'l', 1,0) + IF($db1.timeshet_fill.20= 'l', 1,0)
				+ IF($db1.timeshet_fill.21 = 'l', 1,0) + IF($db1.timeshet_fill.22 = 'l', 1,0) + IF($db1.timeshet_fill.23 = 'l', 1,0)
				+ IF($db1.timeshet_fill.24 = 'l', 1,0) + IF($db1.timeshet_fill.25 = 'l', 1,0) + IF($db1.timeshet_fill.26 = 'l', 1,0)
				+ IF($db1.timeshet_fill.27 = 'l', 1,0) + IF($db1.timeshet_fill.28 = 'l', 1,0) + IF($db1.timeshet_fill.29 = 'l', 1,0)
				+ IF($db1.timeshet_fill.30 = 'l', 1,0) + IF($db1.timeshet_fill.31 = 'l', 1,0)
		)  AS 'leave' , SUM(IF($db1.timeshet_fill.1 = 'a', 1,0) + IF($db1.timeshet_fill.2 = 'a', 1,0)
				+ IF($db1.timeshet_fill.3 = 'a', 1,0) + IF($db1.timeshet_fill.4 = 'a', 1,0) + IF($db1.timeshet_fill.5 = 'a', 1,0)
				+ IF($db1.timeshet_fill.6 = 'a', 1,0) + IF($db1.timeshet_fill.7 = 'a', 1,0) + IF($db1.timeshet_fill.8 = 'a', 1,0)
				+ IF($db1.timeshet_fill.9 = 'a', 1,0) + IF($db1.timeshet_fill.10 = 'a', 1,0) + IF($db1.timeshet_fill.11 = 'a', 1,0)
				+ IF($db1.timeshet_fill.12 = 'a', 1,0) + IF($db1.timeshet_fill.13 = 'a', 1,0) + IF($db1.timeshet_fill.14 = 'a', 1,0)
				+ IF($db1.timeshet_fill.15 = 'a', 1,0) + IF($db1.timeshet_fill.16 = 'a', 1,0) + IF($db1.timeshet_fill.17 = 'a', 1,0)
				+ IF($db1.timeshet_fill.18 = 'a', 1,0) + IF($db1.timeshet_fill.19 = 'a', 1,0) + IF($db1.timeshet_fill.20= 'a', 1,0)
				+ IF($db1.timeshet_fill.21 = 'a', 1,0) + IF($db1.timeshet_fill.22 = 'a', 1,0) + IF($db1.timeshet_fill.23 = 'a', 1,0)
				+ IF($db1.timeshet_fill.24 = 'a', 1,0) + IF($db1.timeshet_fill.25 = 'a', 1,0) + IF($db1.timeshet_fill.26 = 'a', 1,0)
				+ IF($db1.timeshet_fill.27 = 'a', 1,0) + IF($db1.timeshet_fill.28 = 'a', 1,0) + IF($db1.timeshet_fill.29 = 'a', 1,0)
				+ IF($db1.timeshet_fill.30 = 'a', 1,0) + IF($db1.timeshet_fill.31 = 'a', 1,0)
		)  AS 'absent'
		,
		SUM(IF($db1.timeshet_fill.1 = 'p', 1,0) + IF($db1.timeshet_fill.2 = 'p', 1,0)
				+ IF($db1.timeshet_fill.3 = 'p', 1,0) + IF($db1.timeshet_fill.4 = 'p', 1,0) + IF($db1.timeshet_fill.5 = 'p', 1,0)
				+ IF($db1.timeshet_fill.6 = 'p', 1,0) + IF($db1.timeshet_fill.7 = 'p', 1,0) + IF($db1.timeshet_fill.8 = 'p', 1,0)
				+ IF($db1.timeshet_fill.9 = 'p', 1,0) + IF($db1.timeshet_fill.10 = 'p', 1,0) + IF($db1.timeshet_fill.11 = 'p', 1,0)
				+ IF($db1.timeshet_fill.12 = 'p', 1,0) + IF($db1.timeshet_fill.13 = 'p', 1,0) + IF($db1.timeshet_fill.14 = 'p', 1,0)
				+ IF($db1.timeshet_fill.15 = 'p', 1,0) + IF($db1.timeshet_fill.16 = 'p', 1,0) + IF($db1.timeshet_fill.17 = 'p', 1,0)
				+ IF($db1.timeshet_fill.18 = 'p', 1,0) + IF($db1.timeshet_fill.19 = 'p', 1,0) + IF($db1.timeshet_fill.20= 'p', 1,0)
				+ IF($db1.timeshet_fill.21 = 'p', 1,0) + IF($db1.timeshet_fill.22 = 'p', 1,0) + IF($db1.timeshet_fill.23 = 'p', 1,0)
				+ IF($db1.timeshet_fill.24 = 'p', 1,0) + IF($db1.timeshet_fill.25 = 'p', 1,0) + IF($db1.timeshet_fill.26 = 'p', 1,0)
				+ IF($db1.timeshet_fill.27 = 'p', 1,0) + IF($db1.timeshet_fill.28 = 'p', 1,0) + IF($db1.timeshet_fill.29 = 'p', 1,0)
				+ IF($db1.timeshet_fill.30 = 'p', 1,0) + IF($db1.timeshet_fill.31 = 'p', 1,0)
		)  AS 'present'
		");

        $this->db->from("$db1.timeshet_fill");
        //Code Comment By Asheesh in case of Replacement.. (29-11-2019)
        //$this->db->where("$db1.timeshet_fill.emp_id", $empid);
        $this->db->where("$db1.timeshet_fill.project_id", $project_id);
        //24-04-2019.. Harish
        $this->db->where("$db1.timeshet_fill.designation_id", $designation_id);
        $this->db->where("$db1.timeshet_fill.year", $year);
        $this->db->where("$db1.timeshet_fill.month", $month);
        $this->db->where("$db1.timeshet_fill.is_active", "1");

        $result = $this->db->get()->result();
        return isset($result[0]) ? $result[0] : false;
    }

    //New Attendance Code..
    public function getuseattendance($project_id, $designation_id, $month, $year) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;

        $this->db->select("$db1.timeshet_fill.emp_id , SUM(IF($db1.timeshet_fill.1 = 'l', 1,0) + IF($db1.timeshet_fill.2 = 'l', 1,0)
				+ IF($db1.timeshet_fill.3 = 'l', 1,0) + IF($db1.timeshet_fill.4 = 'l', 1,0) + IF($db1.timeshet_fill.5 = 'l', 1,0)
				+ IF($db1.timeshet_fill.6 = 'l', 1,0) + IF($db1.timeshet_fill.7 = 'l', 1,0) + IF($db1.timeshet_fill.8 = 'l', 1,0)
				+ IF($db1.timeshet_fill.9 = 'l', 1,0) + IF($db1.timeshet_fill.10 = 'l', 1,0) + IF($db1.timeshet_fill.11 = 'l', 1,0)
				+ IF($db1.timeshet_fill.12 = 'l', 1,0) + IF($db1.timeshet_fill.13 = 'l', 1,0) + IF($db1.timeshet_fill.14 = 'l', 1,0)
				+ IF($db1.timeshet_fill.15 = 'l', 1,0) + IF($db1.timeshet_fill.16 = 'l', 1,0) + IF($db1.timeshet_fill.17 = 'l', 1,0)
				+ IF($db1.timeshet_fill.18 = 'l', 1,0) + IF($db1.timeshet_fill.19 = 'l', 1,0) + IF($db1.timeshet_fill.20= 'l', 1,0)
				+ IF($db1.timeshet_fill.21 = 'l', 1,0) + IF($db1.timeshet_fill.22 = 'l', 1,0) + IF($db1.timeshet_fill.23 = 'l', 1,0)
				+ IF($db1.timeshet_fill.24 = 'l', 1,0) + IF($db1.timeshet_fill.25 = 'l', 1,0) + IF($db1.timeshet_fill.26 = 'l', 1,0)
				+ IF($db1.timeshet_fill.27 = 'l', 1,0) + IF($db1.timeshet_fill.28 = 'l', 1,0) + IF($db1.timeshet_fill.29 = 'l', 1,0)
				+ IF($db1.timeshet_fill.30 = 'l', 1,0) + IF($db1.timeshet_fill.31 = 'l', 1,0)
		)  AS 'leave' , SUM(IF($db1.timeshet_fill.1 = 'a', 1,0) + IF($db1.timeshet_fill.2 = 'a', 1,0)
				+ IF($db1.timeshet_fill.3 = 'a', 1,0) + IF($db1.timeshet_fill.4 = 'a', 1,0) + IF($db1.timeshet_fill.5 = 'a', 1,0)
				+ IF($db1.timeshet_fill.6 = 'a', 1,0) + IF($db1.timeshet_fill.7 = 'a', 1,0) + IF($db1.timeshet_fill.8 = 'a', 1,0)
				+ IF($db1.timeshet_fill.9 = 'a', 1,0) + IF($db1.timeshet_fill.10 = 'a', 1,0) + IF($db1.timeshet_fill.11 = 'a', 1,0)
				+ IF($db1.timeshet_fill.12 = 'a', 1,0) + IF($db1.timeshet_fill.13 = 'a', 1,0) + IF($db1.timeshet_fill.14 = 'a', 1,0)
				+ IF($db1.timeshet_fill.15 = 'a', 1,0) + IF($db1.timeshet_fill.16 = 'a', 1,0) + IF($db1.timeshet_fill.17 = 'a', 1,0)
				+ IF($db1.timeshet_fill.18 = 'a', 1,0) + IF($db1.timeshet_fill.19 = 'a', 1,0) + IF($db1.timeshet_fill.20= 'a', 1,0)
				+ IF($db1.timeshet_fill.21 = 'a', 1,0) + IF($db1.timeshet_fill.22 = 'a', 1,0) + IF($db1.timeshet_fill.23 = 'a', 1,0)
				+ IF($db1.timeshet_fill.24 = 'a', 1,0) + IF($db1.timeshet_fill.25 = 'a', 1,0) + IF($db1.timeshet_fill.26 = 'a', 1,0)
				+ IF($db1.timeshet_fill.27 = 'a', 1,0) + IF($db1.timeshet_fill.28 = 'a', 1,0) + IF($db1.timeshet_fill.29 = 'a', 1,0)
				+ IF($db1.timeshet_fill.30 = 'a', 1,0) + IF($db1.timeshet_fill.31 = 'a', 1,0)
		)  AS 'absent',
		SUM(IF($db1.timeshet_fill.1 = 'p', 1,0) + IF($db1.timeshet_fill.2 = 'p', 1,0)
				+ IF($db1.timeshet_fill.3 = 'p', 1,0) + IF($db1.timeshet_fill.4 = 'p', 1,0) + IF($db1.timeshet_fill.5 = 'p', 1,0)
				+ IF($db1.timeshet_fill.6 = 'p', 1,0) + IF($db1.timeshet_fill.7 = 'p', 1,0) + IF($db1.timeshet_fill.8 = 'p', 1,0)
				+ IF($db1.timeshet_fill.9 = 'p', 1,0) + IF($db1.timeshet_fill.10 = 'p', 1,0) + IF($db1.timeshet_fill.11 = 'p', 1,0)
				+ IF($db1.timeshet_fill.12 = 'p', 1,0) + IF($db1.timeshet_fill.13 = 'p', 1,0) + IF($db1.timeshet_fill.14 = 'p', 1,0)
				+ IF($db1.timeshet_fill.15 = 'p', 1,0) + IF($db1.timeshet_fill.16 = 'p', 1,0) + IF($db1.timeshet_fill.17 = 'p', 1,0)
				+ IF($db1.timeshet_fill.18 = 'p', 1,0) + IF($db1.timeshet_fill.19 = 'p', 1,0) + IF($db1.timeshet_fill.20= 'p', 1,0)
				+ IF($db1.timeshet_fill.21 = 'p', 1,0) + IF($db1.timeshet_fill.22 = 'p', 1,0) + IF($db1.timeshet_fill.23 = 'p', 1,0)
				+ IF($db1.timeshet_fill.24 = 'p', 1,0) + IF($db1.timeshet_fill.25 = 'p', 1,0) + IF($db1.timeshet_fill.26 = 'p', 1,0)
				+ IF($db1.timeshet_fill.27 = 'p', 1,0) + IF($db1.timeshet_fill.28 = 'p', 1,0) + IF($db1.timeshet_fill.29 = 'p', 1,0)
				+ IF($db1.timeshet_fill.30 = 'p', 1,0) + IF($db1.timeshet_fill.31 = 'p', 1,0)
		)  AS 'present'
	");

        $this->db->from("$db1.timeshet_fill");
        //Comment 24-04-2019 for Harish - Attendance calculation
        $this->db->where("$db1.timeshet_fill.designation_id", $designation_id);
        $this->db->where("$db1.timeshet_fill.project_id", $project_id);
        $this->db->where("$db1.timeshet_fill.year", $year);
        $this->db->where("$db1.timeshet_fill.month", $month);

        $result = $this->db->get()->result();
        return isset($result[0]) ? $result[0] : false;
    }

    //If is Intermmitent .. (New Code By Asheesh)
    public function getuseattendanceintermittent($project_id, $designation_id, $month, $year) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;

        $this->db->select("$db1.timeshet_fill.emp_id , SUM(IF($db1.timeshet_fill.1 = 'p', 1,0) + IF($db1.timeshet_fill.2 = 'p', 1,0)
				+ IF($db1.timeshet_fill.3 = 'p', 1,0) + IF($db1.timeshet_fill.4 = 'p', 1,0) + IF($db1.timeshet_fill.5 = 'p', 1,0)
				+ IF($db1.timeshet_fill.6 = 'p', 1,0) + IF($db1.timeshet_fill.7 = 'p', 1,0) + IF($db1.timeshet_fill.8 = 'p', 1,0)
				+ IF($db1.timeshet_fill.9 = 'p', 1,0) + IF($db1.timeshet_fill.10 = 'p', 1,0) + IF($db1.timeshet_fill.11 = 'p', 1,0)
				+ IF($db1.timeshet_fill.12 = 'p', 1,0) + IF($db1.timeshet_fill.13 = 'p', 1,0) + IF($db1.timeshet_fill.14 = 'p', 1,0)
				+ IF($db1.timeshet_fill.15 = 'p', 1,0) + IF($db1.timeshet_fill.16 = 'p', 1,0) + IF($db1.timeshet_fill.17 = 'p', 1,0)
				+ IF($db1.timeshet_fill.18 = 'p', 1,0) + IF($db1.timeshet_fill.19 = 'p', 1,0) + IF($db1.timeshet_fill.20= 'p', 1,0)
				+ IF($db1.timeshet_fill.21 = 'p', 1,0) + IF($db1.timeshet_fill.22 = 'p', 1,0) + IF($db1.timeshet_fill.23 = 'p', 1,0)
				+ IF($db1.timeshet_fill.24 = 'p', 1,0) + IF($db1.timeshet_fill.25 = 'p', 1,0) + IF($db1.timeshet_fill.26 = 'p', 1,0)
				+ IF($db1.timeshet_fill.27 = 'p', 1,0) + IF($db1.timeshet_fill.28 = 'p', 1,0) + IF($db1.timeshet_fill.29 = 'p', 1,0)
				+ IF($db1.timeshet_fill.30 = 'p', 1,0) + IF($db1.timeshet_fill.31 = 'p', 1,0)
		)  AS 'present'");

        $this->db->from("$db1.timeshet_fill");
        // $this->db->where("$db1.timeshet_fill.emp_id", $empid);
        //24-04-2019.. Harish
        $this->db->where("$db1.timeshet_fill.designation_id", $designation_id);
        $this->db->where("$db1.timeshet_fill.project_id", $project_id);
        $this->db->where("$db1.timeshet_fill.year", $year);
        $this->db->where("$db1.timeshet_fill.month", $month);
        $this->db->where("$db1.timeshet_fill.is_active", "1");

        $result = $this->db->get()->result();
        return isset($result[0]) ? $result[0] : false;
    }

    //Get All Intermittent Project List Employee Ids Wise.. Anil kumar code end here 17-06-2020 
    //Get All Intermittent Project List Employee Ids Wise.. Anil kumar code start here 17-06-2020 
    public function GetAllIntermittentProjectListEmpIdWise3($hrms_project_id, $designation_id) {
        $db3 = $this->db3->database;
        $this->db->select("$db3.assign_designation_onproj.*,$db3.curr_month_invc_team.cumulative_tot_month,$db3.curr_month_invc_team.invoice_id ,$db3.curr_month_invc_team.curr_month_mm");
        $this->db->from("$db3.assign_designation_onproj");
        $this->db->join("$db3.curr_month_invc_team", "($db3.curr_month_invc_team.designation_id=$db3.assign_designation_onproj.designation_id AND $db3.curr_month_invc_team.hrms_projid=$db3.assign_designation_onproj.		hrms_projid	)", "LEFT");
        $this->db->where(["$db3.assign_designation_onproj.hrms_projid" => $hrms_project_id, "$db3.assign_designation_onproj.designation_id" => $designation_id, "$db3.assign_designation_onproj.status" => '1']);
        $result = $this->db->get()->result_array();
        return isset($result) ? $result : false;
    }

    //Get All Intermittent Project List Employee Ids Wise.. Anil kumar code end here 17-06-2020 
    //Get Project Name ids Wise .. Anil kumar code start here 17-06-2020 
    public function getProjectBYId2($id) {
        //echo $id; die;
        $db2 = $this->db2->database;
        $this->db->select("$db2.tm_projects.project_name");
        $this->db->from("$db2.tm_projects");
        $this->db->where(["$db2.tm_projects.id" => $id, "$db2.tm_projects.is_active" => '1']);
        $Rec = $this->db->get()->result_array();

        if ($Rec[0]) {
            return $Rec[0]['project_name'];
        } else {
            return false;
        }
    }

    //Get Project Name ids Wise .. Anil kumar code end here 17-06-2020 
    //Get designation Name ids Wise .. Anil kumar code start here 17-06-2020 

    public function getDesignationBYId($id) {
        //echo $id; die;
        $db1 = $this->db1->database;
        $this->db->select("$db1.designation_master_requisition.designation_name");
        $this->db->from("$db1.designation_master_requisition");
        $this->db->where(["$db1.designation_master_requisition.fld_id" => $id, "$db1.designation_master_requisition.is_active" => '1']);
        $Rec = $this->db->get()->result_array();
        if ($Rec[0]) {
            return $Rec[0]['designation_name'];
        } else {
            return false;
        }
    }

    //Get designation Name ids Wise .. Anil kumar code end here 17-06-2020 
    public function Getinvoice_date($invoiceID) {
        //echo $id; die;
        $db1 = $this->db1->database;
        $this->db->select("$db1.invoicedetail.invoice_date");
        $this->db->from("$db1.invoicedetail");
        $this->db->where(["$db1.invoicedetail.id" => $invoiceID, "$db1.invoicedetail.status" => '1']);
        $Rec = $this->db->get()->result_array();
        return $Rec;
    }

    public function get_empname($hrms_project_id, $designation_id) {
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db2.main_employees_summary.userfullname");
        $this->db->from("$db3.team_on_proj_designation");
        $this->db->join("$db2.main_employees_summary", "$db2.main_employees_summary.user_id=$db3.team_on_proj_designation.user_id", "LEFT");
        $this->db->where(["$db3.team_on_proj_designation.hrms_project_id " => $hrms_project_id, "$db3.team_on_proj_designation.designation_id" => $designation_id]);
        $Rec = $this->db->get()->result_array();

        if ($Rec[0]) {
            return $Rec[0]['userfullname'];
        } else {
            return false;
        }
    }

    //Get All Intermittent Project List Employee Ids Wise..
    public function GetAllIntermittentProjectListEmpIdWiseReport($user_id) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db3.team_on_proj_designation.hrms_project_id,$db3.team_on_proj_designation.designation_id,$db2.tm_projects.project_name,$db1.designation_master_requisition.designation_name,$db3.assign_designation_onproj.mm,$db3.assign_designation_onproj.balance_mm,$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.maint_rate");
        $this->db->from("$db3.team_on_proj_designation");
        $this->db->join("$db2.tm_projects", "$db2.tm_projects.id=$db3.team_on_proj_designation.hrms_project_id", "LEFT");
        $this->db->join("$db1.designation_master_requisition", "$db1.designation_master_requisition.fld_id=$db3.team_on_proj_designation.designation_id", "LEFT");
        $this->db->join("$db3.assign_designation_onproj", "($db3.assign_designation_onproj.hrms_projid=$db3.team_on_proj_designation.hrms_project_id AND $db3.assign_designation_onproj.designation_id=$db3.team_on_proj_designation.designation_id)", "LEFT");
        $this->db->where(["$db3.team_on_proj_designation.user_id" => $user_id, "$db3.team_on_proj_designation.status" => '1', "$db3.team_on_proj_designation.user_identity" => '3']);
        $this->db->group_by("$db3.team_on_proj_designation.hrms_project_id");

        $result = $this->db->get()->result();
        return isset($result) ? $result : false;
    }

    //Get Consumed MM or Latest Tot Cumlative ..
    public function GetConsumedMM_emp_proj($projId, $designationID, $emplId) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.invoicedetail.id");
        $this->db->from("$db1.invoicedetail");
        $this->db->where("$db1.invoicedetail.status", "1");
        $this->db->where("$db1.invoicedetail.project_numberid", $projId);
        $recArr = $this->db->get()->row();

        if ($recArr->id) {
            $this->db->select("$db3.curr_month_invc_team.cumulative_tot_month");
            $this->db->from("$db3.curr_month_invc_team");
            $this->db->where(["$db3.curr_month_invc_team.invoice_id" => $recArr->id, "$db3.curr_month_invc_team.status" => "1", "$db3.curr_month_invc_team.hrms_projid" => $projId, "$db3.curr_month_invc_team.designation_id" => $designationID, "$db3.curr_month_invc_team.emp_id" => $emplId]);
            $cumul_tot_mm = $this->db->get()->row();
        }
        return ($cumul_tot_mm->cumulative_tot_month) ? $cumul_tot_mm->cumulative_tot_month : "0";
    }

    //Get Current MM of Proj Employee..
    public function GetCurrentMM_emp_proj($projId, $designationID, $emplId, $YearMonth) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $RecArr = array();
        $RecArr->curr_month_mm = "";
        $RecArr->curr_month_amnt = "";
        $RecArr->invoice_id = "";

        // $curr_mm = 0;
        $invoiceDate = $YearMonth . "-01";
        $invoiceDate = date("Y-m", strtotime($invoiceDate . " +1 month"));
        $table = "$db1." . "invoicedetail" . ".invoice_date";
        $dt = 'DATE_FORMAT(' . $table . ',"%Y-%m")';

        $this->db->select("$db1.invoicedetail.id");
        $this->db->from("$db1.invoicedetail");
        $this->db->where("$db1.invoicedetail.status", "1");
        $this->db->where("$db1.invoicedetail.project_numberid", $projId);
        $this->db->where($dt, $invoiceDate);
        $recArr = $this->db->get()->row();

        if ($recArr->id) {
            $this->db->select("$db3.curr_month_invc_team.curr_month_mm");
            $this->db->from("$db3.curr_month_invc_team");
            $this->db->where(["$db3.curr_month_invc_team.invoice_id" => $recArr->id, "$db3.curr_month_invc_team.status" => "1", "$db3.curr_month_invc_team.hrms_projid" => $projId, "$db3.curr_month_invc_team.designation_id" => $designationID, "$db3.curr_month_invc_team.emp_id" => $emplId]);
            $numRows = $this->db->get()->num_rows();
        }
        if ($numRows > 0) {
            $this->db->select("$db3.curr_month_invc_team.curr_month_mm,$db3.curr_month_invc_team.curr_month_amnt,$db3.curr_month_invc_team.invoice_id");
            $this->db->from("$db3.curr_month_invc_team");
            $this->db->where(["$db3.curr_month_invc_team.invoice_id" => $recArr->id, "$db3.curr_month_invc_team.status" => "1", "$db3.curr_month_invc_team.hrms_projid" => $projId, "$db3.curr_month_invc_team.designation_id" => $designationID, "$db3.curr_month_invc_team.emp_id" => $emplId]);
            $RecArr = $this->db->get()->row();
            return ($RecArr) ? $RecArr : null;
        } else {
            return ($RecArr) ? $RecArr : null;
            ;
        }
    }

    //Get Current Month Salary Employee..
    public function GetCurrMonthSalaryEmpl($emplId, $YearMonth) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $curr_salr = 0;

        $this->db->select("$db2.salarydetails_increm_month.duration_salary");
        $this->db->from("$db2.salarydetails_increm_month");
        $this->db->where(["$db2.salarydetails_increm_month.user_id" => $emplId, "$db2.salarydetails_increm_month.is_active" => "1"]);
        $this->db->where("$db2.salarydetails_increm_month.month_year LIKE '%$YearMonth%' ");
        $curr_salrRow = $this->db->get()->row()->duration_salary;
        $curr_salr = ($curr_salrRow) ? $curr_salrRow : null;

        if ($curr_salr) {
            return $curr_salr;
        } else {
            $curr_salr = $this->db->select("$db2.main_empsalarydetails.salary")->from("$db2.main_empsalarydetails")->where(["$db2.main_empsalarydetails.isactive" => "1", "$db2.main_empsalarydetails.user_id" => $emplId])->get()->row()->salary;
            return ($curr_salr) ? $curr_salr : "00";
        }
        return ($curr_salr) ? $curr_salr : 0;
    }

    //Get Compare Intermittent Employee Salary_Current_mm_on_Project..
    public function GetRateOnProjDesignation($projID, $designationID) {
        $db3 = $this->db3->database;

        $rateOnDesignation = 0;
        $this->db->select("$db3.assign_designation_onproj.rate,$db3.assign_designation_onproj.constr_rate,$db3.assign_designation_onproj.maint_rate");
        $this->db->from("$db3.assign_designation_onproj");
        $this->db->where(["$db3.assign_designation_onproj.status" => "1", "$db3.assign_designation_onproj.hrms_projid" => $projID, "$db3.assign_designation_onproj.designation_id" => $designationID]);
        $recordRows = $this->db->get()->row();
        $rateOnDesignation = ($recordRows->rate) ? $recordRows->rate : $recordRows->constr_rate;
        $rateOnDesignation = ($rateOnDesignation) ? $rateOnDesignation : $recordRows->maint_rate;
        return ($rateOnDesignation) ? $rateOnDesignation : 0;
    }

    //Escalation Perc Tot 
    public function EscalationPercTot($hrmsProjId, $invc_id) {
        //Only Man Power..
        $db3 = $this->db3->database;
        $this->db->select_sum("$db3.escalation_on_invoice.percentage");
        $this->db->from("$db3.escalation_on_invoice");
        $this->db->where(["$db3.escalation_on_invoice.invoice_id" => $invc_id, "$db3.escalation_on_invoice.status" => "1", "$db3.escalation_on_invoice.hrms_projid" => $hrmsProjId, "$db3.escalation_on_invoice.identity_status" => "1"]);
        $this->db->where("$db3.escalation_on_invoice.escalation_categ!=", "2");
        $GotPerc = $this->db->get()->row();
        return ($GotPerc->percentage) ? $GotPerc->percentage : 0;
    }

    //Bd Project Get Record Details... (Get Record from team_assign_member),
    public function GetProjRecSingleEmp_CRU($userID) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.bd_tenderdetail.TenderDetails,$db1.designation_master_requisition.designation_name,$db1.team_assign_member.designation_id,$db1.team_assign_member.id,$db1.team_assign_member.emailaddress,$db1.team_assign_member.contactnumber,$db1.team_assign_member.remarks_cru,$db1.team_assign_member.remarks_bd,$db1.bdproject_status.project_status,$db1.team_assign.man_months,$db1.team_assign.construction_months,$db1.team_assign.development_months,$db1.team_assign.om_months,$db1.bdtender_scope.visible_scope");
        $this->db->from("$db1.team_assign_member");
        $this->db->join("$db1.designation_master_requisition", "$db1.designation_master_requisition.fld_id=$db1.team_assign_member.designation_id", "LEFT");
        $this->db->join("$db1.bdproject_status", "$db1.bdproject_status.project_id=$db1.team_assign_member.project_id", "LEFT");
        $this->db->join("$db1.team_assign", "$db1.team_assign.id=$db1.team_assign_member.team_assign_id", "LEFT");
        $this->db->join("$db1.bd_tenderdetail", "$db1.bd_tenderdetail.fld_id=$db1.team_assign_member.project_id", "LEFT");
        $this->db->join("$db1.bdtender_scope", "($db1.bdtender_scope.project_id=$db1.team_assign_member.project_id AND $db1.bdtender_scope.businessunit_id='1')", "LEFT");
        $this->db->where(["$db1.team_assign_member.empname" => $userID, "$db1.team_assign_member.status" => "1", "$db1.team_assign_member.teamstatus" => "1"]);
        $this->db->group_by("$db1.team_assign_member.project_id");

        $recdArr = $this->db->get()->result();
        return ($recdArr) ? $recdArr : null;
    }

}

?>
