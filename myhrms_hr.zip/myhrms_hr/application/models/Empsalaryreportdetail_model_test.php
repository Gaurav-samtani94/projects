<?php

error_reporting(1);
defined('BASEPATH') OR exit('No direct script access allowed');

class Empsalaryreportdetail_model extends CI_Model {

    var $table = 'main_users as a';
    var $summery_table = 'main_employees_summary as b';
    var $empsalary_table = 'main_empsalarydetails as c';
    var $empsalincrement_table = 'main_empsal_increment as d';
    var $column_order = array(null, 'a.userfullname', 'b.position_name', 'b.department_name', 'a.contactnumber', 'a.company_id', 'a.emailaddress', 'a.employeeId', 'b.businessunit_name','d.bankname','d.accountholder_name','d.branchname','d.accountnumber');
    var $column_search = array('b.position_name', 'b.department_name', 'b.businessunit_name', 'a.contactnumber', 'a.company_id', 'a.userfullname', 'a.emailaddress', 'a.employeeId', 'b.businessunit_name','d.bankname','d.accountholder_name','d.branchname','d.accountnumber');
    var $order = array('a.userfullname' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
		if ($this->input->post('businessunit_name')) {
            $this->db->where('b.businessunit_id', $this->input->post('businessunit_name'));
        }
        if ($this->input->post('company_id')) {
            $this->db->like('a.company_id', $this->input->post('company_id'));
        }
        if ($this->input->post('department_id')) {
            $this->db->where('b.department_id', $this->input->post('department_id'));
        }
        if ($this->input->post('potion_design_id')) {
            $this->db->where('b.position_id', $this->input->post('potion_design_id'));
        }
        if ($this->input->post('from_date') and $this->input->post('to_date')) {
            $fromdate = date("Y-m-d", strtotime($this->input->post('from_date')));
            $todate = date("Y-m-d", strtotime($this->input->post('to_date')));
            $this->db->where('b.date_of_joining >=', $fromdate);
            $this->db->where('b.date_of_joining <=', $todate);
        }
		if ($this->input->post('userfullname')) {
            $this->db->like('a.userfullname', $this->input->post('userfullname'));
        }

        $this->db->select('e.payrollcode,c.appraisalduedate,a.*,b.date_of_joining, b.businessunit_name,b.position_name,b.department_name,b.reporting_manager_name,c.currencyid,c.salarytype,c.salary,c.bankname,c.accountholder_name,c.branchname,c.ifsc_code,c.pancard_no,c.accountnumber,c.appraisalduedate,d.*');
        $this->db->from($this->table);
        $this->db->join($this->summery_table, 'a.id = b.user_id', 'LEFT');
        $this->db->join($this->empsalary_table, 'a.id = c.user_id', 'LEFT');
        $this->db->join($this->empsalincrement_table, 'a.id = d.user_id', 'LEFT');
        $this->db->join('emp_otherofficial_data as e', 'a.id = e.user_id', 'LEFT');
		// $this->db->where('b.department_id', 18);
        // $this->db->where('b.businessunit_id', '3');
        $this->db->where('a.isactive', '1');
        $this->db->where('d.isactive', '1');
        $this->db->order_by('d.appraisal_datemmyy', 'desc');
        $this->db->where('c.isactive', '1');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
        // $recArr = $query->result();
        // $EmprecArrIDs = array();
        // $nullArr = array();
        // if ($recArr):
            // foreach ($recArr as $rowq) {
                // if (!(in_array($rowq->user_id, $EmprecArrIDs))) {
                    // array_push($EmprecArrIDs, $rowq->user_id);
                    // array_push($nullArr, $rowq);
                // }
            // }
        // endif;
        // return $nullArr;
    }
    
    
    function count_filtered() {
         $this->_get_datatables_query();
         $query = $this->db->get();
         return $query->num_rows();
        
    }

    public function count_all() {
         $this->db->from($this->table);
        return $this->db->count_all_results();
    }



}
