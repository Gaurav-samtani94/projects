<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Menpower_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function countmenpower($groupID,$st_date,$end_date) {
		if($end_date == ''):
		$end_date= date("Y-n-j", strtotime("last day of previous month"));
		endif;
		if($st_date == ''):
		$st_date= date("Y-n-j", strtotime("first day of previous month"));
		endif;
		$this->db->select('a.*');
        $this->db->from('main_users as a');
        $this->db->where_not_in('b.isactive','1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
		$this->db->where('date_of_leaving >=', $st_date);
		$this->db->where('date_of_leaving <=', $end_date);
		$this->db->where(array("b.jobtitle_id" => $groupID));
        $this->db->group_by('b.user_id');
		// $recArr = $this->db->count_all_results();
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function countmenpower_joined($groupID) {
        $st_date= date("Y-n-j", strtotime("first day of previous month"));
		$end_date= date("Y-n-j", strtotime("last day of previous month"));
		$this->db->select('a.*');
        $this->db->from('main_users as a');
        $this->db->where('b.isactive','1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
		$this->db->where('date_of_joining >=', $st_date);
		$this->db->where('date_of_joining <=', $end_date);
		$this->db->where(array("b.jobtitle_id" => $groupID));
        $this->db->group_by('b.user_id');
		// $recArr = $this->db->count_all_results();
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function countmenpower_open_bal($groupID) {
        $st_date= date("Y-n-j", strtotime("first day of previous month"));
		$end_date= date("Y-n-j", strtotime("last day of previous month"));
		$this->db->select('a.*');
        $this->db->from('main_users as a');
        $this->db->where('b.isactive','1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
		$this->db->where('date_of_joining <', $st_date);
		// $this->db->where('date_of_joining <=', $end_date);
		$this->db->where(array("b.jobtitle_id" => $groupID));
        $this->db->group_by('b.user_id');
		// $recArr = $this->db->count_all_results();
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function countmenpower_close_bal($groupID) {
        $st_date= date("Y-n-j", strtotime("first day of previous month"));
		$end_date= date("Y-n-j", strtotime("last day of previous month"));
		$this->db->select('a.*');
        $this->db->from('main_users as a');
        $this->db->where('b.isactive','1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
		$this->db->where('date_of_joining <', $end_date);
		// $this->db->where('date_of_leaving <', $end_date);
		$this->db->where(array("b.jobtitle_id" => $groupID));
        $this->db->group_by('b.user_id');
		// $recArr = $this->db->count_all_results();
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }


}

?>