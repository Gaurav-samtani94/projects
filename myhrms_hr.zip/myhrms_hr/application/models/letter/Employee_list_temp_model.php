<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_list_temp_model extends CI_Model {

    var $table = 'main_letter as a';
    var $column_order = array(null, 'tmp_emp_id', 'userfullname','contact','email','positionname','letter_date','current_status'); //set column field database for datatable orderable
    var $column_search = array('tmp_emp_id', 'userfullname','contact','email','positionname','letter_date','current_status'); //set column field database for datatable searchable 
    var $order = array('id' => 'DESC'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        //Filter 2,,
        if ($this->input->post('start_dates') AND ( $this->input->post('end_dates'))) {
            $start_date = $this->input->post('start_dates');
            $end_date = $this->input->post('end_dates');
            $where_date = "(a.letter_date>='$start_date' AND a.letter_date <= '$end_date')";
            $this->db->where($where_date);
        }
        //Filter 2,,
        if ($this->input->post('curr_status')){
            $this->db->where("a.status",$this->input->post('curr_status'));
        }
        //Filter 3,,
        if ($this->input->post('userfullname')){
            $userfullname = $this->input->post('userfullname');
            $this->db->where("a.userfullname LIKE '%$userfullname%'");
        }
        //Filter 4,,
        if ($this->input->post('emailid')){
            $emailid = $this->input->post('emailid');
            $this->db->where("a.email LIKE '%$emailid%'");
        }
        //Filter 5,,
        if ($this->input->post('contact_no')){
            $contact_no = $this->input->post('contact_no');
            $this->db->where("a.contact LIKE '%$contact_no%'");
        }
         //Filter 6,,
        if ($this->input->post('empl_position')){
            $this->db->where("a.position",$this->input->post('empl_position'));
        }

        $this->db->select("a.*,b.positionname,
                CASE WHEN status = 1 
                      THEN 'Added by CRU' 
                    WHEN status = 2 
                      THEN 'Added by HR' 
                    WHEN status = 3 
                      THEN 'Locked by HR' 
                    WHEN status = 4 
                      THEN 'Offer Letter Send'
                    WHEN status = 5 
                      THEN 'Accepted by Employee' 
                    WHEN status = 6 
                      THEN 'Filled By Employee' 
                    WHEN status = 7 
                      THEN 'Locked By Employee' 
                    WHEN status = 8 
                      THEN 'Generate Joining Letter' 
                    WHEN status = 9 
                      THEN 'Final Locked & Datamoved' 
                    ELSE '-'
                END AS current_status 
        ");

        $this->db->from($this->table);
        $this->db->join("main_positions as b", "a.position = b.id", "LEFT");
        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

     //Get All Position List ...
     public function GetAllPositionList(){
        $this->db->select("a.id,a.positionname,b.jobtitlename");
        $this->db->from("main_positions as a");
        $this->db->join("main_jobtitles as b","a.jobtitleid=b.id","LEFT");
        $this->db->where("a.isactive","1");
        $recordArr = $this->db->get()->result();
        return ($recordArr) ? $recordArr : null;
     }

     //Get All Position List ...
     public function GetSingleRowByID($id){
        $this->db->select("a.*,b.position_name");
        $this->db->from("main_letter as a");
        $this->db->join("main_employees_summary as b","a.hr_name=b.user_id","LEFT");

        $this->db->where("a.id",$id);
        $recordArr = $this->db->get()->row();
        return ($recordArr) ? $recordArr : null;
     }

     //New Function By Ash..
      public function TempEmpl_LetterRecArr($id)
    {
        $this->db->select('a.*,b.userfullname,b.tmp_emp_id, b.email, b.contact, c.letter_type_name,b.status');
        $this->db->from('main_temp_emp_letter as a');
        $this->db->join('main_letter as b', 'a.temp_id=b.id', 'LEFT');
        $this->db->join('letter_type_master as c', 'b.letter_type_id=c.id', 'LEFT');
        $this->db->where('a.temp_id', $id);
        $recordArr = $this->db->get()->row();

        return ($recordArr) ? $recordArr : null;
    }


}
