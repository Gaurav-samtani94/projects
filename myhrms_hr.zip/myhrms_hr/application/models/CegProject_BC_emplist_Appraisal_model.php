<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CegProject_BC_emplist_Appraisal_model extends CI_Model {

    var $table = 'appr_proj_formdata_bc as b';
    var $column_order = array(null, 'userfullname', 'employeeId', 'emailaddress', 'contactnumber');
    var $column_search = array('userfullname', 'employeeId', 'emailaddress', 'contactnumber');
    var $order = array('user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        $user_id = $this->session->userdata('loginid');
		$sessionYear = '10-2024';
        $this->db->select('b.user_id,b.current_status,d.userfullname,d.employeeId,b.rep_io_id,b.rep_ro_id,d.jobtitle_name,f.appraisalduedate');
        $this->db->from($this->table);
        $this->db->join("main_employees_summary as d", "d.user_id=b.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as e", "e.user_id=b.user_id", "LEFT");
        $this->db->join("main_empsalarydetails as f", "f.user_id=b.user_id", "LEFT");
        $this->db->where(array("b.session_appr_year" => $sessionYear, "d.businessunit_id" => '3'));
        // $this->db->where(array("d.businessunit_id" => '3',"f.appraisalduedate" => 'October 2020'));

        $this->db->group_by('b.user_id');


        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

}