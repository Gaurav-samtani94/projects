<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Seperationall_Model extends CI_Model {

  //  var $exit_process_table = 'main_exit_process as a';
    var $summary_table = 'main_employees_summary as a';
    var $other_table = 'emp_otherofficial_data as b';
  //  var $exit_type_table = 'main_exit_types as d';
    var $exit_process_table = 'main_seperation as c';
    var $column_order = array(null, 'b.userfullname');
    var $column_search = array('a.userfullname');
    var $order = array('a.user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query($id) {
        if ($this->input->post('businessunit_name')) {
            $this->db->where('a.businessunit_id', $this->input->post('businessunit_name'));
        }
        if ($this->input->post('company_name')) {
            $this->db->where('a.company_id', $this->input->post('company_name'));
        }
        if ($this->input->post('userfullname')) {
            $this->db->where('a.userfullname', $this->input->post('userfullname'));
        }
        if ($this->input->post('employeeId')) {
            $this->db->where('a.employeeId', $this->input->post('employeeId'));
        }
        if ($this->input->post('designation_name')) {
            $this->db->where('a.position_id', $this->input->post('designation_name'));
        }
        if ($this->input->post('department_name')) {
            $this->db->where('a.department_id', $this->input->post('department_name'));
        }
        if ($this->input->post('project_name')) {
            $this->db->where('b.on_project', $this->input->post('project_name'));
        }
		if ($this->input->post('status_type')) {
            $this->db->where('a.emp_status_id', $this->input->post('status_type'));
        }

        $this->db->select('b.noticeperiod,b.reviewing_officer_ro, a.*,c.emp_id');
       // $this->db->from($this->exit_process_table);
        $this->db->from($this->summary_table);
        $this->db->where_not_in('a.emprole','2');
       $this->db->where_not_in('a.user_id',$id);
       $this->db->where_in('a.isactive',['0','1','2']);
       $this->db->join($this->other_table, 'a.user_id = b.user_id', 'inner');
       $this->db->join($this->exit_process_table, 'c.emp_id = b.user_id', 'left');
       //$this->db->where_not_in('c.emp_id');
      //  $this->db->join($this->exit_type_table, 'd.id = a.exit_type_id', 'inner');
        $this->db->order_by('a.user_id', 'ASC');
        $this->db->group_by('a.user_id');


        ///  $this->db->select('a.*,c.noticeperiod,c.reviewing_officer_ro');
        //  $this->db->from($this->table);
        // $this->db->join($this->user_table, 'b.id = a.user_id', 'left');
        //   $this->db->join($this->other_table, 'c.user_id = a.user_id', 'left');
        //  $this->db->order_by('a.id', 'ASC');
        //   $this->db->group_by('a.user_id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($id) {
        $this->_get_datatables_query($id);
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
        return $recArr;
    }

    function count_filtered($id) {
        $this->_get_datatables_query($id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($id) {
        $this->db->from($this->summary_table);
        return $this->db->count_all_results();
    }

    public function get_list_businessunit() {
        $this->db->select('*');
        $this->db->from('main_businessunits');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        $businessunit = $result;
        return $businessunit;
    }

    public function get_list_companyname() {
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where('is_active', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_designation() {
        $this->db->select('id, positionname');
        $this->db->from('main_positions');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_department() {
        $this->db->select('id, deptname');
        $this->db->from('main_departments');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }
	


    public function getUsernameByID($id) {
        $arr = array('id' => $id, 'isactive' => '1');
        $this->db->select('*');
        $this->db->from('main_users');
        $this->db->where($arr);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_resignation() {
        $this->db->select('*');
        $this->db->from('main_resign');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    // Insert Record
    public function inserRecord($tablename, $arr) {
        if ($tablename && $arr) {
            $this->db->insert($tablename, $arr);
            $insert_id = $this->db->insert_id();
            return $insert_id;
        } else {
            return false;
        }
    }

}
