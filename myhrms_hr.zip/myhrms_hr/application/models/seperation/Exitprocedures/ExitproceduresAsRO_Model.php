<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ExitproceduresAsRO_Model extends CI_Model {

    var $summary_table = 'main_employees_summary as a';
    var $exit_type_process = 'main_exit_process as b';
    var $other_table = 'emp_otherofficial_data as c';
    var $exit_type_table = 'main_exit_types as d';
    var $column_order = array(null, 'b.userfullname');
    var $column_search = array('b.userfullname');
    var $order = array('a.id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        $user_id = $this->session->userdata('user_id');
        $this->db->select('a.employeeId,a.userfullname,a.position_name,a.department_name,b.*,c.noticeperiod,d.exit_type');
        $this->db->from($this->summary_table);
        $this->db->where('a.reporting_manager', $user_id);
        $this->db->join($this->exit_type_process, 'b.employee_id=a.user_id', 'inner');
        $this->db->join($this->other_table, 'c.user_id = a.user_id', 'inner');
        $this->db->join($this->exit_type_table, 'd.id = b.exit_type_id', 'inner');
        $this->db->order_by('a.user_id', 'ASC');
        $this->db->group_by('a.user_id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
        return $recArr;
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->summary_table);
        return $this->db->count_all_results();
    }

}
