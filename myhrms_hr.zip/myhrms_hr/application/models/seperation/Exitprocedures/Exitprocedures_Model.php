<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Exitprocedures_Model extends CI_Model {

    var $exit_process_table = 'main_exit_process as a';
    var $summary_table = 'main_employees_summary as b';
    var $other_table = 'emp_otherofficial_data as c';
    var $exit_type_table = 'main_exit_types as d';
    var $column_order = array(null, 'b.userfullname');
    var $column_search = array('b.userfullname');
    var $order = array('a.id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        $user_id = $this->session->userdata('loginid');
        $this->db->select('b.employeeId,b.userfullname,b.position_name,b.department_name,c.noticeperiod,d.exit_type,a.*');
        $this->db->from($this->exit_process_table);
        $this->db->where('employee_id', $user_id);
        $this->db->join($this->summary_table, 'b.user_id = a.employee_id', 'left');
        $this->db->join($this->other_table, 'c.user_id = a.employee_id', 'left');
        $this->db->join($this->exit_type_table, 'd.id = a.exit_type_id', 'left');
        $this->db->order_by('a.id', 'ASC');
        $this->db->group_by('a.employee_id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
           return $recArr;
    }
    function count_filtered() {
         $this->_get_datatables_query();
          $query = $this->db->get();
          return $query->num_rows(); 
    }

    public function count_all() {
         $this->db->from($this->exit_process_table);
         return $this->db->count_all_results();
    }
 
    public function get_list_exittype() {
        $this->db->select('id,exit_type');
        $this->db->from('main_exit_types');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return ($result)? $result:null;
    }
	
    public function GetRecordForEmailTemplate($user_id){
        $this->db->select('reporting_manager,userfullname,position_name,employeeId');
        $this->db->from('main_employees_summary');
        $this->db->where(array('user_id'=>$user_id,'isactive'=>1));
        $this->db->order_by('user_id','ASC');
        $this->db->group_by('user_id');
        $result= $this->db->get()->row_array();
        if($result)
        {
                return ($result) ?$result:null;
        }
    }
	 
    public function GetUserdetail($user_id)
     {
        $this->db->select('b.userfullname,b.position_name,b.reporting_manager,c.reviewing_officer_ro,b.reporting_manager_name,c.on_project,a.profileimg,b.date_of_joining,c.noticeperiod,b.employeeId,a.emailaddress,a.contactnumber');
        $this->db->from('main_users as a');
        $this->db->where(array('a.id'=>$user_id));
        $this->db->join('main_employees_summary as b','b.user_id=a.id','left');
        $this->db->join('emp_otherofficial_data as c','c.user_id=a.id','left');
        $result= $this->db->get()->row_array();
        return ($result)? $result:null;
     }
}
