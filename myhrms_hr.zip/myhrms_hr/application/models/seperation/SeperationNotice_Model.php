<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SeperationNotice_Model extends CI_Model {

    //var $exit_process_table = 'main_exit_process as a';
    var $exit_process_table = 'main_seperation as a';
    var $summary_table = 'main_employees_summary as b';
    var $other_table = 'emp_otherofficial_data as c';
    var $exit_type_table = 'main_exit_types as d';
    var $column_order = array(null, 'b.userfullname');
    var $column_search = array('b.userfullname');
    var $order = array('b.user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query($user_id) {
        if ($this->input->post('businessunit_name')) {
            $this->db->where('b.businessunit_id', $this->input->post('businessunit_name'));
        }
        if ($this->input->post('company_name')) {
            $this->db->where('b.company_id', $this->input->post('company_name'));
        }
        if ($this->input->post('userfullname')) {
            $this->db->where('b.userfullname', $this->input->post('userfullname'));
        }
        if ($this->input->post('employeeId')) {
            $this->db->where('b.employeeId', $this->input->post('employeeId'));
        }
        if ($this->input->post('designation_name')) {
            $this->db->where('b.position_id', $this->input->post('designation_name'));
        }
        if ($this->input->post('department_name')) {
            $this->db->where('b.department_id', $this->input->post('department_name'));
        }
        if ($this->input->post('project_name')) {
            $this->db->where('c.on_project', $this->input->post('project_name'));
        }
	if ($this->input->post('status_type')) {
            $this->db->where('b.emp_status_id', $this->input->post('status_type'));
        }
      
        

        $this->db->select('b.user_id,b.employeeId,b.userfullname,b.position_name,b.department_name,c.noticeperiod,d.exit_type,a.*');
        $this->db->from($this->exit_process_table);
        //$this->db->where_not_in('a.employee_id',$user_id);
        $this->db->where_not_in('a.emp_id',$user_id);
		// $this->db->from($this->summary_table);
       //  $this->db->where_not_in('b.user_id',$user_id);
//        $this->db->join($this->summary_table, 'b.user_id = a.employee_id', 'inner');
//        $this->db->join($this->other_table, 'c.user_id = a.employee_id', 'inner');
//        $this->db->join($this->exit_type_table, 'd.id = a.exit_type_id', 'inner');
                $this->db->join($this->summary_table, 'b.user_id = a.emp_id', 'inner');
        $this->db->join($this->other_table, 'c.user_id = a.emp_id', 'inner');
        $this->db->join($this->exit_type_table, 'd.id = a.type_of_seperation', 'inner');
        $this->db->order_by('a.id', 'ASC');
        $this->db->group_by('b.user_id');

//                $this->db->select('c.noticeperiod,c.reviewing_officer_ro, b.*');
//       // $this->db->from($this->exit_process_table);
//        $this->db->from($this->summary_table);
//        //$this->db->where_not_in('b.emprole','2');
//       $this->db->where_not_in('b.user_id',$user_id);
//       //$this->db->where_not_in('b.user_id',['175','173','190']);
//        $this->db->join($this->other_table, 'c.user_id = b.user_id', 'inner');
//      //  $this->db->join($this->exit_type_table, 'd.id = a.exit_type_id', 'inner');
//        $this->db->order_by('b.user_id', 'ASC');
//        $this->db->group_by('b.user_id');

        ///  $this->db->select('a.*,c.noticeperiod,c.reviewing_officer_ro');
        //  $this->db->from($this->table);
        // $this->db->join($this->user_table, 'b.id = a.user_id', 'left');
        //   $this->db->join($this->other_table, 'c.user_id = a.user_id', 'left');
        //  $this->db->order_by('a.id', 'ASC');
        //   $this->db->group_by('a.user_id');

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($user_id) {
        $this->_get_datatables_query($user_id);
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
        return $recArr;
    }

    function count_filtered($user_id) {
        $this->_get_datatables_query($user_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all($user_id) {
        $this->db->from($this->exit_process_table);
        return $this->db->count_all_results();
    }

    public function get_list_businessunit() {
        $this->db->select('*');
        $this->db->from('main_businessunits');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        $businessunit = $result;
        return $businessunit;
    }

    public function get_list_companyname() {
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where('is_active', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_designation() {
        $this->db->select('id, positionname');
        $this->db->from('main_positions');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_department() {
        $this->db->select('id, deptname');
        $this->db->from('main_departments');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function getUsernameByID($id) {
        $arr = array('id' => $id, 'isactive' => '1');
        $this->db->select('*');
        $this->db->from('main_users');
        $this->db->where($arr);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }
	
    public function get_list_empstatus() {
        $this->db->select('id, employemnt_status');
        $this->db->from('tbl_employmentstatus');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_resignation() {
        $this->db->select('*');
        $this->db->from('main_resign');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    // Insert Record
    public function inserRecord($tablename, $arr) {
        if ($tablename && $arr) {
            $this->db->insert($tablename, $arr);
            $insert_id = $this->db->insert_id();
            return $insert_id;
        } else {
            return false;
        }
    }

}
