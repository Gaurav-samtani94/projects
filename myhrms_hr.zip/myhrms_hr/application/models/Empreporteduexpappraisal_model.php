<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Empreporteduexpappraisal_model extends CI_Model {

    var $table = 'main_users as a';
    var $appr_mail_table = 'appr_mail_appraisal as s';
    var $summery_table = 'main_employees_summary as b';
    // var $edudetail_table = 'main_empeducationdetails as c';
    var $education_table = 'main_empeducationdetails as e';
    var $otherofficial_table = 'emp_otherofficial_data as g';
    var $column_order = array(null, 'g.payrollcode', 'a.userfullname', 'b.position_name', 'b.department_name', 'g.sub_department', 'e.educationlevel', 'a.contactnumber', 'a.employeeId', 'b.jobtitle_name');
    var $column_search = array('g.payrollcode', 'b.position_name', 'b.department_name', 'b.businessunit_name', 'e.educationlevel', 'a.contactnumber', 'a.userfullname', 'a.employeeId', 'b.jobtitle_name');
    var $order = array('a.userfullname' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
       

        $this->db->select('e.institution_name,e.from_date,a.*,b.years_exp,b.reporting_manager_name,b.date_of_joining, b.businessunit_name,b.position_name,g.company_location, g.sub_department,g.on_project, b.department_name, g.reviewing_officer_ro, g.payrollcode, b.reporting_manager_name,e.educationlevel,b.jobtitle_name,k.salary,k.appraisalduedate');
        // $this->db->select_max('l.empctc');
        $this->db->from($this->appr_mail_table);
        $this->db->join($this->table, 'a.id = s.emp_id', 'left');
        $this->db->join($this->summery_table, 'a.id = b.user_id', 'left');
        $this->db->join($this->education_table, 'a.id = e.user_id', 'left');
        $this->db->join($this->otherofficial_table, 'a.id = g.user_id', 'left');
        // $this->db->join("emp_otherofficial_data as h", 'a.id = h.user_id', 'LEFT');
        // $this->db->join("main_employees_summary as i", 'h.reviewing_officer_ro=i.user_id', 'LEFT');
        // $this->db->join("main_subdepartments as j", 'g.sub_department=j.id', 'LEFT');
        $this->db->join("main_empsalarydetails as k", 's.emp_id=k.user_id', 'LEFT');
        // $this->db->join("main_empsal_increment as l", 's.emp_id=l.user_id', 'LEFT');
        $this->db->where(array('a.isactive' => '1'));
        $this->db->where('b.businessunit_id', "1");
		
        $this->db->group_by('a.id');
		
		
		 if ($this->input->post('userfullname')) {
            $this->db->like('a.userfullname', $this->input->post('userfullname'));
        }
        if ($this->input->post('company_id')) {
            $this->db->like('a.company_id', $this->input->post('company_id'));
        }

        if ($this->input->post('department_id')) {
            $this->db->where('b.department_id', $this->input->post('department_id'));
        }
        if ($this->input->post('potion_design_id')) {
            $this->db->where('b.position_id', $this->input->post('potion_design_id'));
        }
        if ($this->input->post('from_date') and $this->input->post('to_date')) {
            $fromdate = date("Y-m-d", strtotime($this->input->post('from_date')));
            $todate = date("Y-m-d", strtotime($this->input->post('to_date')));
            $this->db->where('b.date_of_joining >=', $fromdate);
            $this->db->where('b.date_of_joining <=', $todate);
        }
        //$this->db->order_by('l.id','DESC');
        $i = 0;

        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recTbl = $query->result();
		// echo "<pre>"; print_r($recTbl); die;
        $returnArr = array();
        if ($recTbl) {
            foreach ($recTbl as $rOwr) {
                $userID = $rOwr->id;
                //=======echo $userID; die;
                $salrRow2017 = $this->GetCtc_seventeen($userID);
                $salrRow2018 = $this->GetCtc_eighteen($userID);
               

                // $ALLratingA = $this->Get_ratingA($userID);
                // $ALLratingB = $this->Get_ratingB($userID);
                // $ALLratingC = $this->Get_ratingC($userID);

                // $rOwr->ctc_eighteen = $salrRow2018->empctc;
                // $rOwr->gross_eighteen = $salrRow2018->grosssalary;
                
                // $rOwr->ctc_seventeen = $salrRow2017->empctc;
                // $rOwr->gross_seventeen = $salrRow2017->grosssalary;

                // $rOwr->self_ratingA = $ALLratingA->perform_fact_rating;
                // $rOwr->io_ratingA = $ALLratingA->ro_rating;
                // $rOwr->ro_ratingA = $ALLratingA->io_rating;
                
                // $rOwr->self_ratingB = $ALLratingB->perform_fact_rating;
                // $rOwr->io_ratingB = $ALLratingB->ro_rating;
                // $rOwr->ro_ratingB = $ALLratingB->io_rating;
                
                
                // $rOwr->self_ratingC = $ALLratingC->perform_fact_rating;
                // $rOwr->io_ratingC = $ALLratingC->ro_rating;
                // $rOwr->ro_ratingC = $ALLratingC->io_rating;
                

                $returnArr[] = $rOwr;
            }
        }
        return $recTbl;
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    public function get_list_businessunit() {
        $this->db->select('*');
        $this->db->from('main_businessunits');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        $businessunit = array();
        foreach ($result as $row) {
            $businessunit['unitname'] = $row->unitname;
            $businessunit['id'] = $row->unitname;
        }
        return $businessunit;
    }

    public function get_list_companyname() {
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where('is_active', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_educationcode() {
        $this->db->select('*');
        $this->db->from('main_educationlevelcode');
        $this->db->where('isactive', '1');
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    public function get_list_bycompanyid($id) {
        $arr = array('id' => $id, 'is_active' => '1');
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $this->db->where($arr);
        $this->db->order_by('id', 'asc');
        $query = $this->db->get();
        $result = $query->result();
        return $result[0]->company_name;
    }

    public function getUsernameByID($id) {
        $arr = array('id' => $id, 'isactive' => '1');
        $this->db->select('*');
        $this->db->from('main_users');
        $this->db->where($arr);
        $query = $this->db->get();
        $result = $query->result();
        return $result;
    }

    //Get Self Rating A..
    public function Get_ratingA($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1','appraisal_cycle_id' => '12');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
		// echo "<pre>"; print_r($resulArr); die;
        //$Retarr = '';
        if ($resulArr->fld_id) {
            //appr_performancefactor_master
            $this->db->SELECT('fld_id');
            $this->db->from('appr_performancefactor_master');
            $this->db->where(array("parent_id" => "1", "status" => "1", "master_group" => "1"));
            $array1 = $this->db->get()->result_array();
            $Retarr = array_map(function($value) {
                return $value['fld_id'];
            }, $array1);
            //Next Layer..
            $this->db->select_sum('a.perform_fact_rating');
            $this->db->select_sum('a.ro_rating');
             $this->db->select_sum('a.io_rating');
            $this->db->from('appr_performfactor as a');
            $this->db->where_in("perform_fact_masterid",$Retarr);
            $this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
            $RecorArrData = $this->db->get()->row();
        }
        return ($RecorArrData) ? $RecorArrData : false;
    }
    
    
     //Get Self Rating A..
    public function Get_ratingB($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
        //$Retarr = '';
        if ($resulArr->fld_id) {
            //appr_performancefactor_master
            $this->db->SELECT('fld_id');
            $this->db->from('appr_performancefactor_master');
            $this->db->where(array("parent_id" => "2", "status" => "1", "master_group" => "1"));
            $array1 = $this->db->get()->result_array();
            $Retarr = array_map(function($value) {
                return $value['fld_id'];
            }, $array1);
            //Next Layer..
            $this->db->select_sum('a.perform_fact_rating');
            $this->db->select_sum('a.ro_rating');
             $this->db->select_sum('a.io_rating');
            $this->db->from('appr_performfactor as a');
            $this->db->where_in("perform_fact_masterid",$Retarr);
            $this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
            $RecorArrData = $this->db->get()->row();
        }
        return ($RecorArrData) ? $RecorArrData : false;
    }
    
    
     public function Get_ratingC($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
        //$Retarr = '';
        if ($resulArr->fld_id) {
            //appr_performancefactor_master
            $this->db->SELECT('fld_id');
            $this->db->from('appr_performancefactor_master');
            $this->db->where(array("parent_id" => "3", "status" => "1", "master_group" => "1"));
            $array1 = $this->db->get()->result_array();
            $Retarr = array_map(function($value) {
                return $value['fld_id'];
            }, $array1);
            //Next Layer..
            $this->db->select_sum('a.perform_fact_rating');
            $this->db->select_sum('a.ro_rating');
             $this->db->select_sum('a.io_rating');
            $this->db->from('appr_performfactor as a');
            $this->db->where_in("perform_fact_masterid",$Retarr);
            $this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
            $RecorArrData = $this->db->get()->row();
        }
        return ($RecorArrData) ? $RecorArrData : false;
    }
    
    

    //Get 2018 CTC EMpid Wise...
    public function GetCtc_eighteen($id) {
        $arr = array('user_id' => $id, 'isactive' => '1');
        $this->db->SELECT('empctc,grosssalary');
        $this->db->from('main_empsal_increment');
        $this->db->where($arr);
        $this->db->where("appraisal_datemmyy LIKE '%2018%'");
        $this->db->order_by("id", "DESC");
        // $this->db->limit("1");
        $result = $this->db->get()->row();
        return $result;
    }

    //Get 2017 CTC and Gross..
    public function GetCtc_seventeen($id) {
        $arr = array('user_id' => $id, 'isactive' => '1');
        $this->db->SELECT('empctc,grosssalary');
        $this->db->from('main_empsal_increment');
        $this->db->where($arr);
        $this->db->where("appraisal_datemmyy LIKE '%2017%'");
        $this->db->order_by("id", "DESC");
        // $this->db->limit("1");
        $result = $this->db->get()->row();
        return $result;
    }

}
