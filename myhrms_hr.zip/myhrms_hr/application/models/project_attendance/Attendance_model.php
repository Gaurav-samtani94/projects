<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attendance_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();

        $this->db1 = $this->load->database('default', TRUE);
        $this->db2 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }

    //Get Experiance Details..
//    public function ProjectListAll() {
//        $db1 = $this->db1->database;
//        $db2 = $this->db2->database;
//        $db3 = $this->db3->database;
//
//        $this->db->select("$db3.a.hrms_projid,$db1.b.project_name");
//        $this->db->from("$db3.assign_designation_onproj as a");
//        $this->db->join("$db1.tm_projects as b", "$db3.a.hrms_projid=$db1.b.id", "LEFT");
//        $this->db->where(array("$db3.a.status" => "1", "$db1.b.is_active" => "1"));
//        $this->db->group_by("$db3.a.hrms_projid");
//        $this->db->order_by("$db1.b.project_name", "ASC");
//        $RecRows = $this->db->get()->result();
//        return ($RecRows) ? $RecRows : null;
//    }

    //reuse by durgesh(21-10-2020)
    public function ProjectListAll() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.a.id,$db1.a.project_name");
        $this->db->from("$db1.tm_projects as a");
       // $this->db->join("$db1.tm_projects as b", "$db3.a.hrms_projid=$db1.b.id", "LEFT");
        $this->db->where(array("$db1.a.is_active" => "1"));
        //$this->db->group_by("$db3.a.hrms_projid");
        $this->db->order_by("$db1.a.project_name", "ASC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
            
        
    public function AllEmployeeListArr() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.a.user_id,$db1.a.userfullname,$db1.a.employeeId");
        $this->db->from("$db1.main_employees_summary as a");
        $this->db->where(array("$db1.a.isactive" => "1"));
        $this->db->where("$db1.a.businessunit_id!=", "2");
        $this->db->order_by("$db1.a.userfullname", "ASC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    public function AllEmpPermissionListArr($projectID) {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db2.a.fld_id,$db1.b.userfullname,$db1.b.employeeId,$db1.c.project_name");
        $this->db->from("$db2.doctrol_siteofc_permission as a");
        $this->db->join("$db1.main_employees_summary as b","$db1.b.user_id=$db2.a.perm_userides","LEFT");
        $this->db->join("$db1.tm_projects as c","$db1.c.id=$db2.a.project_id","LEFT");
        
        
        $this->db->where(array("$db2.a.project_id" => $projectID));
        $this->db->order_by("$db1.b.userfullname", "DESC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
    
    public function AllProjectIDListArr() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        
        $UserId = $this->session->userdata('loginid');
        
        $this->db->select("$db2.a.project_id,");
        $this->db->from("$db2.doctrol_siteofc_permission as a");
        $this->db->join("$db1.main_employees_summary as b","$db1.b.user_id=$db2.a.perm_userides","LEFT");
        $this->db->join("$db1.tm_projects as c","$db1.c.id=$db2.a.project_id","LEFT");
        // $this->db->where(array("$db2.a.perm_userides" => $UserId));
        $this->db->order_by("$db1.b.userfullname", "DESC");
        $RecRows = $this->db->get()->result();
       
        $resPArr = array();
        if($RecRows){
            foreach ($RecRows as $kEy=>$rOws){
              $resPArr[] = $rOws->project_id; 
            }
        }
        return ($resPArr) ? $resPArr : null; 
    } 
    
    
    //code by durgesh
    public function AllProjectIDListNewArr() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        
        $UserId = $this->session->userdata('loginid');
        
        $this->db->select("$db1.c.id,$db1.c.project_name,$db1.b.userfullname,$db2.d.fill_date");
        $this->db->from("$db2.doctrol_siteofc_permission as a");
        $this->db->join("$db1.main_employees_summary as b","$db1.b.user_id=$db2.a.perm_userides","LEFT");
        $this->db->join("$db1.tm_projects as c","$db1.c.id=$db2.a.project_id","LEFT");
		$this->db->join("$db2.timeshet_fill as d", "$db1.c.id = $db2.d.project_id", 'Left');
        // $this->db->where(array("$db2.a.perm_userides" => $UserId));
		$this->db->group_by("$db2.a.project_id");
        $this->db->order_by("$db1.b.userfullname", "DESC");
        $RecRows = $this->db->get()->result();
        if($RecRows){
            return ($RecRows)?$RecRows:"";  
        }
//        $resPArr = array();
//        if($RecRows){
//            foreach ($RecRows as $kEy=>$rOws){
//              $resPArr[] = $rOws->project_id; 
//            }
//        }
//        return ($resPArr) ? $resPArr : null; 
    }
	
	public function AllProjectIDListNewArrWithoutPerm() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        
        $UserId = $this->session->userdata('loginid');
        
        $this->db->select("$db2.a.project_id as id, $db1.c.project_name");
        $this->db->from("$db2.doctrol_siteofc_permission as a");
        // $this->db->join("$db1.main_employees_summary as b","$db1.b.user_id=$db2.a.perm_userides","LEFT");
        $this->db->join("$db1.tm_projects as c","$db1.c.id=$db2.a.project_id","LEFT");
        $this->db->where(array("$db2.a.perm_userides" => 1615));
        $this->db->order_by("$db2.a.project_id", "ASC");
		$this->db->group_by("$db2.a.project_id");
        $RecRows = $this->db->get()->result();
        if($RecRows){
            return ($RecRows)?$RecRows:"";  
        }
//        $resPArr = array();
//        if($RecRows){
//            foreach ($RecRows as $kEy=>$rOws){
//              $resPArr[] = $rOws->project_id; 
//            }
//        }
//        return ($resPArr) ? $resPArr : null; 
    } 
    

}

?>