<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Late_atten_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    //Get Employee Details for joining report ..
    public function late_atten_($selected_month = '') {
		$cur_month_st = date('n/1/Y');
		$cur_month_end = date('n/j/Y');
        $this->db->select("a.department_name,a.position_name,a.user_id,a.userfullname,a.employeeId,a.jobtitle_name,c.FirstIn,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_otherofficial_data as b","b.user_id=a.user_id","left");
        $this->db->join("thumb_attendance as c","b.thumbcode=c.EmployeeID","left");
        $this->db->where(array('a.isactive'=>'1'));
		$this->db->where("c.FirstIn >=", $cur_month_st);
		$this->db->where('c.FirstIn <=', $cur_month_end);
        $this->db->order_by("a.jobtitle_id",'ASC');
        // $this->db->group_by('a.user_id');
		// if ($selected_month) {
            // $this->db->where("c.FirstIn LIKE '%$selected_month%'");
        // }
		// else {
			// $this->db->where("a.date_of_joining>=", $cur_month_st);
			// $this->db->where('a.date_of_joining <=', $cur_month_end);
		// }
        $RecRows = $this->db->get()->result();
        // $RecRows = $this->db->get()->num_rows();
		 // print_r($RecRows); die;
        return ($RecRows) ? $RecRows : null;
    }
}

?>