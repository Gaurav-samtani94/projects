<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Airlines_model extends CI_Model
{

    var $user_table = 'travel_master as a';
    // var $tick_ticket_raise = 'tick_ticket_raise as b';
    var $column_order = array(null, 'air_lines', 'slug');
    var $column_search = array('air_lines', 'slug');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function  check_main_airlines($airlines_name, $air_slug)
    {

        $whereArr = array(
            "travel_master.air_lines" => $airlines_name
        );
        $num_results1 = $this->db->where($whereArr)->count_all_results("travel_master");
        $whereArr = array(
            "travel_master.slug" => $air_slug
        );
        $num_results = $this->db->where($whereArr)->count_all_results("travel_master");


        if ($num_results < 1) {
            if ($num_results1 < 1) {

                $this->db->query("INSERT  INTO travel_master(air_lines,slug)
                  VALUES('$airlines_name','$air_slug')");
                return TRUE;
            }
        } else {
            return FALSE;
        }
    }




    private function _get_datatables_query()
    {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("a.air_lines,a.slug");
        $this->db->from($this->user_table);
        $this->db->where('a.status', '1');

        // $this->db->group_by('a.user_id');
        $this->db->order_by("a.air_lines", "ASC");
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }


    function get_datatables()
    {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }


    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
}
