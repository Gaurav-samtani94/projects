<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ticket_Basic_model extends CI_Model
{

    var $user_table = 'main_employees_summary as a';
    var $tick_ticket_raise = 'tick_ticket_raise as b';
    var $column_order = array(null, 'employeeId', 'userfullname', 'department_name', 'c_name');
    var $column_search = array('employeeId', 'userfullname', 'department_name', 'c_name');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function GetCatehorybasicecord()
    {
        $this->db->select('a.c_name,a.fld_id');
        $this->db->from('tick_ticket_category_master as a');
        //  $this->db->where(array("a.user_id" => $userID, "a.status" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }


    public function   GetEmployeebasiccord()
    {
        $this->db->select('a.userfullname,b.entry_by');
        $this->db->from($this->user_table);
        $this->db->join("tick_ticket_raise as b", "b.entry_by=a.user_id", "LEFT");
        $this->db->where('b.parent_id', '0');
        $this->db->where('b.tick_status', '3');
        // $this->db->where(array('b.tick_status' => "3"));
        $this->db->group_by('a.user_id');
        //  $this->db->where(array("a.user_id" => $userID, "a.status" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }



    private function _get_datatables_query()
    {
        if (!empty($this->input->post('catgory_id'))) {
            $this->db->where('c.fld_id', $this->input->post('catgory_id'));
        }

        if (!empty($this->input->post('emp_id'))) {
            $this->db->where('b.entry_by', $this->input->post('emp_id'));
        }
        if ($this->input->post('start_date') && $this->input->post('end_date')) {

            $this->db->where('DATE_FORMAT(b.entry_date,"%Y-%m-%d") >=', $this->input->post('start_date'));
            $this->db->where('DATE_FORMAT(b.entry_date,"%Y-%m-%d") <=', $this->input->post('end_date'));
        }

        $this->db->select("a.position_name,a.employeeId,a.user_id,a.userfullname,a.department_name,b.ticket_no,b.tick_status,b.entry_date,c.c_name,b.parent_id,b.fld_id");
        $this->db->from($this->user_table);
        $this->db->join("tick_ticket_raise as b", "b.entry_by=a.user_id", "LEFT");
        $this->db->join("tick_ticket_category_master as c", "c.fld_id=b.category_id", "LEFT");
        $this->db->where('a.isactive', '1');
        $this->db->where('b.parent_id', '0');
        $this->db->where('b.tick_status', '3');
        $this->db->where_not_in('a.jobtitle_id', '8');

        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }


    function get_datatables($catgory_id, $emp_id, $start_date,  $end_date)
    {

        $this->_get_datatables_query($catgory_id, $emp_id, $start_date,  $end_date);

        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }


    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
}
