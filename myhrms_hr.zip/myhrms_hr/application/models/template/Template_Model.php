<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Template_Model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->db1 = $this->load->database('default', TRUE);
        $this->db2 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }
    //Empl.. Job History..
    public function GetAllEmpljobhistoryDetails()
    {
        $this->db->select('a.*,g.userfullname,g.employeeId,b.unitname,c.deptname,d.jobtitlename,e.positionname,f.company_name');
        $this->db->from('main_empjobhistory as a');
        $this->db->join('main_employees_summary as g', 'a.user_id=g.user_id', 'LEFT');
        $this->db->join('main_businessunits as b', 'a.businessunit=b.id', 'LEFT');
        $this->db->join('main_departments as c', 'a.department=c.id', 'LEFT');
        $this->db->join('main_jobtitles as d', 'a.jobtitleid=d.id', 'LEFT');
        $this->db->join('main_positions as e', 'a.positionheld=e.id', 'LEFT');
        $this->db->join('tbl_companyname as f', 'a.vendor=f.id', 'LEFT');
        $this->db->where(['a.isactive' => '1']);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }
    public function getLatestLetterheadNumber()
    {
        return $this->db->from('letterheads')->where('status', 'active')->order_by('id', 'DESC')->limit(1)->get()->row('letterhead_number');
    }

}