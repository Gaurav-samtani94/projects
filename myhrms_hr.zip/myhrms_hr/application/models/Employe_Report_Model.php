
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Employe_Report_Model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        // $this->load->database();
        $this->db1 = $this->load->database('online', TRUE); //BD
        $this->db2 = $this->load->database('default', TRUE); //sentrifugo
        $this->db3 = $this->load->database('accdept_db', TRUE); //acc
    }
    public function index($bunitid, $department_id, $reporting_manager)
    {
        $this->db->select('*');
        $this->db->from('main_employees_summary');
        $this->db->where('businessunit_id', $bunitid);
        $this->db->where('department_id', $department_id);
        $this->db->where('reporting_manager', $reporting_manager);
        $data = $this->db->get()->result();
        //   print_r($data);
        return $data;
    }
    public function getEmpDetailsByUserID($bunitid, $department_id, $sub_department, $reporting_manager, $empID, $status)
    { //144
        // $this->db->select(max('id'));
        // $this->db->from('main_empsal_increment');
        // $subquery = $this->db->get()->result();
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $this->db->select("max(af.id) as afids,a.employeeId,c.payrollcode,o.prefix,b.userfullname,b.date_of_joining,i.aadhar_no_enrolment,i.dob,p.company_name,
        q.unitname,b.department_name,b.position_name,b.jobtitle_name,af.basicsalary,af.emp_hra,
        af.education_allowance,af.bonus_adv,af.special_allowance,af.grosssalary,af.medical_allowance,
        af.vehicle_agreement,af.leave_travel_allowance,af.emp_gratuity,af.driver_wagers,af.fuel_expenses,b.emprole_name,
        g.user_id,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,g.pancard_no,g.appraisalduedate,
        ad.pf_uan,ad.pf_ac_no,ad.pf_date,ae.esic_no as esic_ip_no,ae.esic_dob as esic_start_date,m.gendername,a.contactnumber,a.emailaddress,
        c.floor_number,s.course as diplomacource,s.to_date as diplomatodate,s.institution_name as diplomaInstitute,u.course as ugcource,
        u.to_date as ugtodate,u.institution_name as ugInstitute,w.course as pgcource,w.to_date as pgtodate,w.institution_name as pgInstitute
        ,x.course as doctratecource,x.to_date as doctratetodate,x.institution_name as doctrateInstitute,aa.country_name as per_country_name,
        ab.state_name as perm_state_name,ac.city_name as perm_city_name,summary.userfullname as io,
        r.reviewing_officer_ro as ro,c.probation_date,c.join_date_withceg,b.date_of_leaving,ah.project_name,$db1.ai.designation_name,d.subdepartment"); //,n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining                    //s.course as diploma,s.to_date as diplomatodate,s.institution_name as diplomaInstitute,
        // $this->db->select("j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");

        //emp_gratuity,
        $this->db->from("main_users as a");
        $this->db->join("tm_projects as ah", "ah.id=a.emp_onproject", "LEFT"); // abhi
        $this->db->join("$db1.designation_master_requisition as ai", "$db1.ai.fld_id=a.emp_project_designation", "LEFT"); // abhi
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as c", "a.id=c.user_id", "LEFT");
        $this->db->join("main_subdepartments as d", "d.id=c.sub_department", "LEFT");
        $this->db->join("tbl_ofclocation as f", "c.company_location=f.id", "LEFT");
        $this->db->join("main_empsalarydetails as g", "a.id=g.user_id", "LEFT");
        $this->db->join("main_payfrequency as h", "g.salarytype=h.id", "LEFT");
        $this->db->join("main_emppersonaldetails as i", "i.user_id=a.id", "LEFT");
        $this->db->join("main_maritalstatus as j", "i.maritalstatusid=j.id", "LEFT");
        $this->db->join("main_nationality as k", "i.nationalityid=k.id", "LEFT");
        $this->db->join("tbl_religion as l", "i.religion=l.id", "LEFT");
        $this->db->join("main_gender as m", "i.genderid=m.id", "LEFT");
        $this->db->join("main_roles as n", "b.emprole=n.id", "LEFT"); //emp_otherofficial_data
        $this->db->join("main_prefix as o", "o.id=b.prefix_id", "LEFT");
        $this->db->join("tbl_companyname as p", "p.id=c.company_name", "LEFT");
        $this->db->join("main_businessunits as q", "q.id=b.businessunit_id", "LEFT");
        $this->db->join("main_employees_summary as summary", "summary.user_id=b.reporting_manager", "LEFT");
        $this->db->join("emp_otherofficial_data as r", "r.user_id=b.user_id", "LEFT");
        $this->db->join("main_empeducationdetails as s", "s.user_id=b.user_id AND s.educationlevel=6", "LEFT"); //
        $this->db->join("main_empeducationdetails as u", "u.user_id=b.user_id AND u.educationlevel=3", "LEFT");
        $this->db->join("main_empeducationdetails as w", "w.user_id=b.user_id AND w.educationlevel=4", "LEFT");
        $this->db->join("main_empeducationdetails as x", "x.user_id=b.user_id AND x.educationlevel=5", "LEFT");
        $this->db->join("main_empcommunicationdetails as z", "z.user_id=b.user_id", "LEFT");
        $this->db->join('tbl_countries as aa', "aa.id=z.perm_country", "LEFT");
        $this->db->join('tbl_states as ab', "ab.id=z.perm_state", "LEFT");
        $this->db->join('tbl_cities as ac', "ac.id=z.perm_city", "LEFT"); //aa.country_name as per_country_name,ab.state_name as perm_state_name,ac.city_name as perm_city_name
        $this->db->join('emp_pf_details as ad', "ad.emp_id=b.user_id", "LEFT"); //pfdetail
        $this->db->join('emp_esic_details as ae', "ae.emp_id=b.user_id", "LEFT"); //esic
        $this->db->join('main_empsal_increment as af', "af.user_id=b.user_id", "LEFT");
        // $this->db->where('af.id', $subquery);
        //   $this->db->join("main_educationlevelcode as x", "x.id=w.educationlevel", "LEFT");
        //  $this->db->or_where("s.educationlevel", 6); //diploma
        // $this->db->order_by('af.id', 'asc');
        // $this->db->join("");
        // $this->db->join("main_empeducationdetails as r", "r.user_id=b.", "LEFT");
        // $this->db->where('af.id', 'afids');
        if ($bunitid > 0) {
            $this->db->where('b.businessunit_id', $bunitid);
        }
        if ($empID > 0) {
            $this->db->where(array("a.id" => $empID));
        }
        if ($department_id > 0) {
            $this->db->where(array("b.department_id" => $department_id));
        }
        if ($sub_department > 0) // this is added for sub department
        {
            $this->db->where(array("c.sub_department" => $sub_department));
        }
        if ($reporting_manager > 0) {
            $this->db->where(array("b.reporting_manager" => $reporting_manager));
        }
        if ($status != 'A') {
            // print_r($status);
            // die();
            $this->db->where(array("b.isactive" => $status));
        }
        // if ($status == 1) {
        //     $this->db->where(array("b.isactive" => $status));
        // }

        // $this->db->where("u.educationlevel", 3);
        // $this->db->where("w.educationlevel", 4);
        $this->db->group_by('a.id');
        // $this->db->order_by('af.id', 'asc');
        // $this->db->group_by('af.id,af.user_id');
        // $this->db->order_by('af.user_id', 'asc');
        //  $this->db->order_by("af.id", "desc"); //af
        // $this->db->or_where("w.educationlevel", 4);
        $recResp = $this->db->get()->result();
        // echo "<pre>";
        // print_r($recResp);
        // die();

        // echo "ss<pre>"; print_r($recResp);
        // main_empsalarydetails
        return $recResp;

        //e10adc3949ba59abbe56e057f20f883e 
        //  398941213d64a76ddd2d5ebb1f86cd4d
    }

    // public function getEmpDetailsByUserID($empID)
    // {
    //     $this->db->select("n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
    //     // $this->db->select("j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
    //     $this->db->from("main_users as a");
    //     $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
    //     $this->db->join("emp_otherofficial_data as c", "a.id=c.user_id", "LEFT");
    //     $this->db->join("main_subdepartments as d", "d.id=c.sub_department", "LEFT");
    //     $this->db->join("tbl_ofclocation as f", "c.company_location=f.id", "LEFT");
    //     $this->db->join("main_empsalarydetails as g", "a.id=g.user_id", "LEFT");
    //     $this->db->join("main_payfrequency as h", "g.salarytype=h.id", "LEFT");
    //     $this->db->join("main_emppersonaldetails as i", "i.user_id=a.id", "LEFT");
    //     $this->db->join("main_maritalstatus as j", "i.maritalstatusid=j.id", "LEFT");
    //     $this->db->join("main_nationality as k", "i.nationalityid=k.id", "LEFT");
    //     $this->db->join("tbl_religion as l", "i.religion=l.id", "LEFT");
    //     $this->db->join("main_gender as m", "i.genderid=m.id", "LEFT");
    //     $this->db->join("main_roles as n", "b.emprole=n.id", "LEFT");
    //     $this->db->where(array("a.id" => $empID));
    //     $recResp = $this->db->get()->row();
    //     // echo "ss<pre>"; print_r($recResp);
    //     return $recResp;
    // }
    // public function GetContactDetailRecByID($userID)
    // {
    //     $this->db->select('a.*,b.country_name as per_country_name,c.country_name as current_country_name,d.state_name as perm_state_name,e.state_name as current_state_name,f.city_name as perm_city_name,g.city_name as current_city_name');
    //     $this->db->from('main_empcommunicationdetails as a');
    //     $this->db->join('tbl_countries as b', "a.perm_country=b.id", "LEFT");
    //     $this->db->join('tbl_countries as c', "a.current_country=c.id", "LEFT");
    //     $this->db->join('tbl_states as d', "a.perm_state=d.id", "LEFT");
    //     $this->db->join('tbl_states as e', "a.current_state=e.id", "LEFT");
    //     $this->db->join('tbl_cities as f', "a.perm_city=f.id", "LEFT");
    //     $this->db->join('tbl_cities as g', "a.current_city=g.id", "LEFT");
    //     $this->db->where(array("a.user_id" => 2, "a.isactive" => "1"));
    //     $RecRows = $this->db->get()->row();
    //     // print_R($RecRows);
    //     return ($RecRows) ? $RecRows : null;
    // }
    // public function GetRecEmplSkillsDetails($empID)
    // {
    //     $this->db->select('a.*,b.competencylevel');
    //     $this->db->from('main_empskills as a');
    //     $this->db->join("main_competencylevel as b", "a.competency_level=b.id", "LEFT");
    //     $this->db->where(['a.isactive' => '1', 'a.user_id' => 2]);
    //     $result = $this->db->get()->result();
    //     return ($result) ? $result : null;
    // }
    // public function GetRecEmpljobhistoryDetails($empID)
    // {
    //     $this->db->select('a.*,b.unitname,c.deptname,d.jobtitlename,e.positionname,f.company_name');
    //     $this->db->from('main_empjobhistory as a');
    //     $this->db->join('main_businessunits as b', 'a.businessunit=b.id', 'LEFT');
    //     $this->db->join('main_departments as c', 'a.department=c.id', 'LEFT');
    //     $this->db->join('main_jobtitles as d', 'a.jobtitleid=d.id', 'LEFT');
    //     $this->db->join('main_positions as e', 'a.positionheld=e.id', 'LEFT');
    //     $this->db->join('tbl_companyname as f', 'a.vendor=f.id', 'LEFT');

    //     $this->db->where(['a.isactive' => '1', 'a.user_id' => 322]);
    //     $result = $this->db->get()->result();
    //     return ($result) ? $result : null;
    // }
    // public function GetRecEmplFamilyDetails($empID)
    // {
    //     $this->db->select('a.*');
    //     $this->db->from('main_empdependencydetails as a');
    //     $this->db->where(['a.isactive' => '1', 'a.user_id' => 113]);
    //     $result = $this->db->get()->result();

    //     return ($result) ? $result : null;
    // }
    // public function GetRecentPayslipDetails($empID)
    // {

    //     $this->db->select('a.payroll_with_name');
    //     $this->db->from('emp_otherofficial_data as a');
    //     $this->db->where(['a.status' => '1', 'a.user_id' => 2]);
    //     $result = $this->db->get()->row();
    //     if ($result->payroll_with_name) {
    //         $this->db->select('p.year,p.month,p.payroll_with_name');
    //         $this->db->from('payslip_filepath as p');
    //         $this->db->where(["p.payroll_with_name" => $result->payroll_with_name, "p.is_active" => "1"]);
    //         $this->db->order_by("p.id", "DESC");
    //         $this->db->limit("10");
    //         $recordArr = $this->db->get()->result();
    //     }
    //     return ($recordArr) ? $recordArr : null;
    // }
    // public function GetTableData($cegth_table, $Where)
    // {
    //     // $recArr = array();
    //     $this->db->select('*');
    //     $this->db->from($cegth_table);
    //     $this->db->order_by("id", "DESC");
    //     $this->db->where($Where);
    //     $recArr = $this->db->get()->result();
    //     // print_R($recArr);
    //     // die();
    //     return ($recArr) ? $recArr : null;
    // }
    // public function GetReferencesDetailRecByID($userID)
    // {
    //     $this->db->select('a.reference_name,a.organisation,a.designation,a.contact_no,a.reference_type');
    //     $this->db->from('personnel_professional_reference as a');
    //     $this->db->where(array("a.user_id" => 296, "a.status" => "0"));
    //     $RecRows = $this->db->get()->result();
    //     return ($RecRows) ? $RecRows : null;
    // }
    // public function GetEmployeeDocsDetailRecByID($userID)
    // {
    //     $this->db->select('a.*');
    //     $this->db->from('main_employeedocuments as a');
    //     $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
    //     $RecRows = $this->db->get()->result();
    //     return ($RecRows) ? $RecRows : null;
    // }
    // public function getOtherUserRecordByUserID($userID)
    // {
    //     $this->db->select('a.*');
    //     $this->db->from('other_user_record as a');
    //     $this->db->where(array("a.user_id" => 296, "a.status" => "1"));
    //     $RecRows = $this->db->get()->result();
    //     return ($RecRows) ? $RecRows : null;
    // }
} ?>