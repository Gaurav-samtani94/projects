<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hr_Chat_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
         $this->db1 = $this->load->database('default', TRUE);//sentrifugo
		$this->db2 = $this->load->database('default', TRUE);
		$this->db3 = $this->load->database('accdept_db', TRUE);
    }
    public function GetAllInboxMessage(){
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.*");
        $this->db->from("$db1.hrchat_message as a");
        $this->db->where("$db1.a.status", "Yes");
        $this->db->where("$db1.a.from_user_id !=", "1");
        $this->db->ORDER_BY("$db1.a.chat_message_id", "DESC");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
     }
     public function GetChatMessageBYId($chat_id)
     {
         $db1 = $this->db1->database;
         $this->db->select("$db1.a.*,$db1.b.userfullname");
        $this->db->from("$db1.hrchat_message as a");
         $this->db->join("$db1.main_employees_summary as b", "$db1.b.user_id=$db1.a.entry_by", "left");
        $this->db->where("$db1.a.from_user_id", $chat_id);
          $this->db->or_where("$db1.a.to_user_id", $chat_id);
        $this->db->where("$db1.a.status", "Yes");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }
   
     public function GetuserNameById($uid)
  {
     $db1 = $this->db1->database;
    $this->db->select("$db1.a.userfullname");
    $this->db->from("$db1.main_employees_summary as a");
    $this->db->where("$db1.a.user_id", $uid);
    $recordList = $this->db->get()->row();
    return ($recordList) ? $recordList : null;
  }
  public function GetuserById($chat_id)
  {
    $db1 = $this->db1->database;
    $this->db->select("$db1.a.userfullname");
    $this->db->from("$db1.main_employees_summary as a");
    $this->db->where("$db1.a.user_id", $chat_id);
    $recordList = $this->db->get()->row();
    return ($recordList) ? $recordList : null;
  }
    public function GetAllusermessage($userid)
     {
         $db1 = $this->db1->database;
        $this->db->select("$db1.a.*,$db1.b.userfullname");
        $this->db->from("$db1.hrchat_message as a");
         $this->db->join("$db1.main_employees_summary as b", "$db1.b.user_id=$db1.a.entry_by", "left");
        $this->db->where("$db1.a.from_user_id", $userid);
          $this->db->or_where("$db1.a.to_user_id", $userid);
         $this->db->where("$db1.a.status", "Yes");
        $Allrecord=$this->db->get()->result();
        return ($Allrecord) ? $Allrecord : "NUll";
    }
    //    public function GetAllusermessage($userid)
    // {
    //       $db1 = $this->db1->database;
    //       //$toid=$this->login_user_id;
    //       $this->db->select("$db1.a.*");
    //       $this->db->from("$db1.hrchat_message as a");
    //       $this->db->where("$db1.a.status", "Yes");
    //       //$this->db->where("$db1.a.from_user_id !=", "1");
    //       //$this->db->where("$db1.a.to_user_id", $toid);
    //      $recordList = $this->db->get()->result();
    //     return ($recordList) ? $recordList : null;
    // }

  

}