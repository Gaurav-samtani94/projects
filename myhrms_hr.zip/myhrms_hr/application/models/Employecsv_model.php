
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Employecsv_model extends CI_Model
{

    public function getEmpDetailsByUserID($empID)
    {
        $this->db->select("n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
        // $this->db->select("j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
        $this->db->from("main_users as a");
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as c", "a.id=c.user_id", "LEFT");
        $this->db->join("main_subdepartments as d", "d.id=c.sub_department", "LEFT");
        $this->db->join("tbl_ofclocation as f", "c.company_location=f.id", "LEFT");
        $this->db->join("main_empsalarydetails as g", "a.id=g.user_id", "LEFT");
        $this->db->join("main_payfrequency as h", "g.salarytype=h.id", "LEFT");
        $this->db->join("main_emppersonaldetails as i", "i.user_id=a.id", "LEFT");
        $this->db->join("main_maritalstatus as j", "i.maritalstatusid=j.id", "LEFT");
        $this->db->join("main_nationality as k", "i.nationalityid=k.id", "LEFT");
        $this->db->join("tbl_religion as l", "i.religion=l.id", "LEFT");
        $this->db->join("main_gender as m", "i.genderid=m.id", "LEFT");
        $this->db->join("main_roles as n", "b.emprole=n.id", "LEFT");
        $this->db->where(array("a.id" => $empID));
        $recResp = $this->db->get()->row();
        // echo "ss<pre>"; print_r($recResp);
        return $recResp;
    }
    public function GetContactDetailRecByID($userID)
    {
        $this->db->select('a.*,b.country_name as per_country_name,c.country_name as current_country_name,d.state_name as perm_state_name,e.state_name as current_state_name,f.city_name as perm_city_name,g.city_name as current_city_name');
        $this->db->from('main_empcommunicationdetails as a');
        $this->db->join('tbl_countries as b', "a.perm_country=b.id", "LEFT");
        $this->db->join('tbl_countries as c', "a.current_country=c.id", "LEFT");
        $this->db->join('tbl_states as d', "a.perm_state=d.id", "LEFT");
        $this->db->join('tbl_states as e', "a.current_state=e.id", "LEFT");
        $this->db->join('tbl_cities as f', "a.perm_city=f.id", "LEFT");
        $this->db->join('tbl_cities as g', "a.current_city=g.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }
    public function GetRecEmplSkillsDetails($empID)
    {
        $this->db->select('a.*,b.competencylevel');
        $this->db->from('main_empskills as a');
        $this->db->join("main_competencylevel as b", "a.competency_level=b.id", "LEFT");
        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }
    public function GetRecEmpljobhistoryDetails($empID)
    {
        $this->db->select('a.*,b.unitname,c.deptname,d.jobtitlename,e.positionname,f.company_name');
        $this->db->from('main_empjobhistory as a');
        $this->db->join('main_businessunits as b', 'a.businessunit=b.id', 'LEFT');
        $this->db->join('main_departments as c', 'a.department=c.id', 'LEFT');
        $this->db->join('main_jobtitles as d', 'a.jobtitleid=d.id', 'LEFT');
        $this->db->join('main_positions as e', 'a.positionheld=e.id', 'LEFT');
        $this->db->join('tbl_companyname as f', 'a.vendor=f.id', 'LEFT');

        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }
    public function GetRecEmplFamilyDetails($empID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empdependencydetails as a');
        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();

        return ($result) ? $result : null;
    }
    public function GetRecentPayslipDetails($empID)
    {

        $this->db->select('a.payroll_with_name');
        $this->db->from('emp_otherofficial_data as a');
        $this->db->where(['a.status' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->row();
        if ($result->payroll_with_name) {
            $this->db->select('p.year,p.month,p.payroll_with_name');
            $this->db->from('payslip_filepath as p');
            $this->db->where(["p.payroll_with_name" => $result->payroll_with_name, "p.is_active" => "1"]);
            $this->db->order_by("p.id", "DESC");
            $this->db->limit("10");
            $recordArr = $this->db->get()->result();
        }
        return ($recordArr) ? $recordArr : null;
    }
    public function GetTableData($cegth_table, $Where, $fields)
    {
        // $recArr = array();
        $this->db->select($fields);
        $this->db->from($cegth_table);
        $this->db->order_by("id", "DESC");
        $this->db->where($Where);
        $recArr = $this->db->get()->result();
        // print_R($recArr);
        // die();
        return ($recArr) ? $recArr : null;
    }
    public function GetReferencesDetailRecByID($userID)
    {
        $this->db->select('a.reference_name,a.organisation,a.designation,a.contact_no,a.reference_type');
        $this->db->from('personnel_professional_reference as a');
        $this->db->where(array("a.user_id" => $userID, "a.status" => "0"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
    public function GetEmployeeDocsDetailRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_employeedocuments as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
    public function getOtherUserRecordByUserID($userID)
    {
        $this->db->select('a.candidate_source,a.candidate_reference,a.criminal_offense,a.drug_alcohal_abuse,a.criminal_offense_detail,a.drug_abuse_detail,a.pre_existing_illness,a.partial_disabilities,a.pre_existing_illness_detail,a.partial_disabilities_detail,a.relative_employed_ceg,a.employed_ceg_relation,a.employed_ceg_user_id,a.previous_employed_with_ceg,a.previous_reason_for_leaving_ceg,a.previous_employee_code');
        $this->db->from('other_user_record as a');
        $this->db->where(array("a.user_id" => $userID, "a.status" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
} ?>