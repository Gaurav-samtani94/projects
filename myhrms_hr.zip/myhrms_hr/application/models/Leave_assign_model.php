<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Leave_assign_model extends CI_Model
{

    var $user_table = 'main_employees_summary as a';
    var $main_allottedleaveslog = 'main_allottedleaveslog as b';
    var $column_order = array(null, 'employeeId', 'userfullname', 'department_name');
    var $column_search = array('employeeId', 'userfullname', 'department_name');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function GetEmployeerecord()
    {
        $this->db->select('a.userfullname,a.user_id,a.employeeId');
        $this->db->from('main_employees_summary as a');
        $this->db->where(array("a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
    // Abhishek 31-08-2022 update this code 
    public function check_main_allottedleaveslog($emp_id, $year, $leave_day)
    {
        $totalleaves = 0;
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $id = $this->session->userdata('loginid');
        $this->db->where('userid', $emp_id);
        $this->db->where('year', $year);
        // $data = ['assignedleaves' => 'assignedleaves' + $leave_day];
        $query = $this->db->get('main_allottedleaveslog');
        if ($query->num_rows() > 0) {
            $this->db->select('assignedleaves');
            $this->db->from('main_allottedleaveslog');
            $this->db->where('userid', $emp_id);
            $this->db->where('year', $year);
            $emp_leave_limit = $this->db->get()->row();
            $total_days = $emp_leave_limit->assignedleaves + $leave_day;
            if ($total_days <= 24) {
                $this->db->query("UPDATE main_allottedleaveslog SET assignedleaves=assignedleaves+'$leave_day',modifiedby='$id',modifieddate='$date'  WHERE userid=$emp_id and `year`= $year");
            }

            return true;
        } else {
            $this->db->query("INSERT  INTO main_allottedleaveslog (userid,assignedleaves,totalleaves,`year`,createdby,createddate)
            VALUES('$emp_id','$leave_day',  '$totalleaves','$year','$id', '$date')");

            return true;
        }
    }
    public function check_main_employeeleaves($emp_id, $year, $leave_day)
    {
        $used_leaves = 0;
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $id = $this->session->userdata('loginid');
        $this->db->where('user_id', $emp_id);
        $this->db->where('alloted_year', $year);
        // $data = ['assignedleaves' => 'assignedleaves' + $leave_day];
        $query = $this->db->get('main_employeeleaves');
        if ($query->num_rows() > 0) {
            $this->db->select('emp_leave_limit');
            $this->db->from('main_employeeleaves');
            $this->db->where('user_id', $emp_id);
            $this->db->where('alloted_year', $year);
            $emp_leave_limit = $this->db->get()->row();
            $total_days = $emp_leave_limit->emp_leave_limit + $leave_day;
            if ($total_days <= 24) {
                $this->db->query("UPDATE main_employeeleaves SET emp_leave_limit=emp_leave_limit+'$leave_day',`modifiedby`='$id',`modifieddate`='$date' WHERE `user_id`=$emp_id and `alloted_year`=$year");
            }

            return true;
        } else {
            $this->db->query("INSERT  INTO main_employeeleaves (`user_id`,`emp_leave_limit`,`used_leaves`,`alloted_year`,`createdby`,`createddate`)
            VALUES('$emp_id','$leave_day', '$used_leaves','$year','$id','$date')");

            return true;
        }
    }


    private function _get_datatables_query()
    {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("a.position_name,a.employeeId,a.user_id,a.userfullname,a.department_name,b.emp_leave_limit,b.alloted_year,b.used_leaves");
        $this->db->from($this->user_table);
        $this->db->join("main_employeeleaves as b", "b.user_id=a.user_id", "LEFT");
        $this->db->where('a.isactive', '1');
        // $this->db->where_not_in('a.jobtitle_id', '8');
        // $this->db->group_by('a.user_id');
        $this->db->order_by("b.alloted_year", "DESC");
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }


    function get_datatables()
    {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }


    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    // Abhishek 09-05-2022 
   public function check_main_allottedleaveslog_secound($emp_id, $year, $leave_day)
    {
        $totalleaves = 0;
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $id = $this->session->userdata('loginid');
        $this->db->select("*");
        $this->db->from("main_allottedleaveslog");
        $this->db->where('userid', $emp_id);
        $this->db->where('year', $year);
        // $data = ['assignedleaves' => 'assignedleaves' + $leave_day];
        $query = $this->db->get();
        // echo"<pre>";
        // print_r($query);
        // die();
        if ($query->num_rows() > 0) {
            $this->db->select('assignedleaves');
            $this->db->from('main_allottedleaveslog');
            $this->db->where('userid', $emp_id);
            $this->db->where('year', $year);
            $emp_leave_limit = $this->db->get()->row();
            $total_days = $leave_day;
         
            if ($total_days <= 24) {
               
              $this->db->query("UPDATE main_allottedleaveslog SET `assignedleaves`='$leave_day',`modifiedby`='$id',`modifieddate`='$date'  WHERE `userid`=$emp_id and `year`= $year");
            //   print_R($re); 
            //   print_r($total_days);
                // die();
            }
			  if ($total_days > 24) {
               $leave_days = 24;
              $this->db->query("UPDATE main_allottedleaveslog SET `assignedleaves`='$leave_days',`modifiedby`='$id',`modifieddate`='$date'  WHERE `userid`=$emp_id and `year`= $year");
            //   print_R($re); 
            //   print_r($total_days);
                // die();
            }
// die();
            return true;
        } else {
            $uparray_inset = array("userid"=>$emp_id,
        "assignedleaves"=>$leave_day,
    );
            $this->db->insert("main_allottedleaveslog",);
            $this->db->query("INSERT  INTO main_allottedleaveslog (userid,assignedleaves,totalleaves,`year`,createdby,createddate)
            VALUES('$emp_id','$leave_day','$totalleaves','$year','$id', '$date')");

            return true;
        }
    }
    public function check_main_employeeleaves_secound($emp_id, $year, $leave_day)
    {
        $used_leaves = 0;
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $id = $this->session->userdata('loginid');
        $this->db->where('user_id', $emp_id);
        $this->db->where('alloted_year', $year);
        // $data = ['assignedleaves' => 'assignedleaves' + $leave_day];
        $query = $this->db->get('main_employeeleaves');
        if ($query->num_rows() > 0) {
            $this->db->select('emp_leave_limit');
            $this->db->from('main_employeeleaves');
            $this->db->where('user_id', $emp_id);
            $this->db->where('alloted_year', $year);
            $emp_leave_limit = $this->db->get()->row();
            $total_days = $leave_day;
            if ($total_days <= 24) {
                $uparray = array('emp_leave_limit'=>$leave_day,
            'modifiedby'=>$id,
            'modifieddate'=>$date
        );
        $this->db->where("user_id",$emp_id);
        $this->db->where("alloted_year",$year);
                $this->db->update("main_employeeleaves",$uparray);
             //   $this->db->query("UPDATE main_employeeleaves SET `emp_leave_limit`='$leave_day',`modifiedby`='$id',`modifieddate`='$date' WHERE `user_id`=$emp_id and `alloted_year`=$year");
            }
			   if ($total_days > 24) {
                $uparray = array('emp_leave_limit'=> 24,
            'modifiedby'=>$id,
            'modifieddate'=>$date
        );
        $this->db->where("user_id",$emp_id);
        $this->db->where("alloted_year",$year);
                $this->db->update("main_employeeleaves",$uparray);
             //   $this->db->query("UPDATE main_employeeleaves SET `emp_leave_limit`='$leave_day',`modifiedby`='$id',`modifieddate`='$date' WHERE `user_id`=$emp_id and `alloted_year`=$year");
            }

            return true;
        } else {
            $this->db->query("INSERT  INTO main_employeeleaves(`user_id`,`emp_leave_limit`,`used_leaves`,`alloted_year`,`createdby`,`createddate`)
            VALUES('$emp_id','$leave_day','$used_leaves','$year','$id','$date')");

            return true;
        }
    }

}
