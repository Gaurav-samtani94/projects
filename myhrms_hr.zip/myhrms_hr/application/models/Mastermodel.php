<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mastermodel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->db1 = $this->load->database('default', TRUE);
        $this->db2 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }

    public function GetloginCountries()
    {
        $this->db->select('*');
        $this->db->from('tbl_countries');
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }

    //######### New Hrms 07-02-1992 ###########
    public function GetBasicRecLoginUser()
    {
        $id = $this->session->userdata('loginid');
        $this->db->select('user.*,b.thumbcode,b.payroll_with_name');
        $this->db->from('main_employees_summary as user');
        $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->where(array("user.user_id" => $id, "user.isactive" => "1"));
        $RecSingleRow = $this->db->get()->row();
        return ($RecSingleRow) ? $RecSingleRow : null;
    }

    //Get Official Rec By UserId.. 
    public function GetOfficialDataByUserId($userID)
    {
        $this->db->select('user.*,c.prefix_name as prefix_name_ro,c.userfullname as userfullname_ro,d.subdepartment,e.company_name,b.probation_period_no,b.noticeperiod,b.payroll_with_name,'); //b.payrollid
        $this->db->from('main_employees_summary as user');
        $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->join("main_employees_summary c", "b.reviewing_officer_ro=c.user_id", "LEFT");
        $this->db->join("main_subdepartments d", "b.sub_department=d.id", "LEFT");
        $this->db->join("tbl_companyname e", "b.company_name=e.id", "LEFT");
        $this->db->where(array("user.user_id" => $userID, "user.isactive" => "1"));
        $RecSingleRow = $this->db->get()->row();
        // echo "<pre>";
        // print_r($RecSingleRow);
        // die();
        return ($RecSingleRow) ? $RecSingleRow : null;
    }

    //Get Experiance Details..
    public function GetExperianceDetailByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empexperiancedetails as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Skill..
    public function GetSkillRecordDetailByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empskills as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    public function GetEducationDetailRecByID($userID)
    {
        $this->db->select('a.*,b.educationlevelcode');
        $this->db->from('main_empeducationdetails as a');
        $this->db->join('main_educationlevelcode as b', "a.educationlevel=b.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Family Details..
    public function GetFamilyDetailRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empdependencydetails as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Employee Docs..
    public function GetEmployeeDocsDetailRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_employeedocuments as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }



    //Get Personnal Details..
    public function GetPersonalDetailsRecByID($userID)
    {
        $this->db->select('a.*,b.maritalstatusname,c.nationalitycode,d.languagename');
        $this->db->from('main_emppersonaldetails as a');
        $this->db->join('main_maritalstatus as b', "a.maritalstatusid=b.id", "LEFT");
        $this->db->join('main_nationality as c', "a.nationalityid=c.id", "LEFT");
        $this->db->join('main_language as d', "a.languageid=d.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }

    //Contact Details..
    public function GetContactDetailRecByID($userID)
    {
        $this->db->select('a.*,b.country_name as per_country_name,c.country_name as current_country_name,d.state_name as perm_state_name,e.state_name as current_state_name,f.city_name as perm_city_name,g.city_name as current_city_name');
        $this->db->from('main_empcommunicationdetails as a');
        $this->db->join('tbl_countries as b', "a.perm_country=b.id", "LEFT");
        $this->db->join('tbl_countries as c', "a.current_country=c.id", "LEFT");
        $this->db->join('tbl_states as d', "a.perm_state=d.id", "LEFT");
        $this->db->join('tbl_states as e', "a.current_state=e.id", "LEFT");
        $this->db->join('tbl_cities as f', "a.perm_city=f.id", "LEFT");
        $this->db->join('tbl_cities as g', "a.current_city=g.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }

    //Get Previous Day In Time And Out Time..
    public function GetInOutTimeDetails($userThumbID)
    {
        $this->db->select('a.*');
        $this->db->from('thumb_attendance as a');
        $this->db->where(array("a.EmployeeID" => $userThumbID));
        $this->db->where(array("a.Status" => "1"));
        $this->db->order_by("a.thumbid", "DESC");
        $this->db->limit(1);
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }

    //Get Employee Salary Details..
    public function GetEmpSalaryDetailRecByID($userID)
    {
        $this->db->select('a.*,b.currencyname,c.freqtype');
        $this->db->from('main_empsalarydetails as a');
        $this->db->join('main_currency as b', "a.currencyid=b.id", "LEFT");
        $this->db->join('main_payfrequency as c', "a.salarytype=c.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }

    //Pay Slips Details..
    public function GetEmpPayslipsRecByuserID($payroll_with_name, $year = '')
    {
        $this->db->select('a.*');
        $this->db->from('payslip_filepath as a');
        $this->db->where(array("a.payroll_with_name" => $payroll_with_name, "a.is_active" => "1"));
        if ($year) {
            $this->db->where("a.year", $year);
        }
        $this->db->order_by("a.id", "DESC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Get ITR Form Record By User Id..
    public function GetItrFormDetailsRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_itr as a');
        $this->db->where(array("a.user_id" => $userID, "a.is_active" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Get My Team Details..
    public function GetMyTeamDetailsRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_employees_summary as a');
        $this->db->where(array("a.reporting_manager" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Get All Applied Leave..
    public function GetMyAllAppliedLeaves($userID)
    {
        $this->db->select('a.*');
        $this->db->from('main_leaverequest_summary as a');
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $this->db->order_by("a.id", "DESC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Get All Holidays List..
    public function GetAllHolidaysListRec($hgroupID = '', $hyear = '')
    {
        $this->db->select('a.*,b.groupname');
        $this->db->from('main_holidaydates as a');
        $this->db->join('main_holidaygroups as b', "a.groupid=b.id", "LEFT");
        $this->db->where(array("a.isactive" => "1"));
        if ($hgroupID) {
            $this->db->where(array("a.groupid" => $hgroupID));
        }
        if ($hyear) {
            $this->db->where(array("a.holidayyear" => $hyear));
        }
        $this->db->order_by("a.holidaydate", "ASC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Get All Tour List By UserID..
    public function GetAllAppliedTourListRec($userID)
    {
        $this->db->select('a.*,b.project_name,c.prefix_name,c.userfullname');
        $this->db->from('emp_tourapply as a');
        $this->db->join('tm_projects as b', "a.project_id=b.id", "LEFT");
        $this->db->join('main_employees_summary as c', "a.emp_id=c.user_id", "LEFT");
        $this->db->where(array("a.emp_id" => $userID, "a.is_active" => "1"));
        $this->db->order_by("a.start_date", "DESC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //check login
    public function login_user_action($LoginCredentialArr)
    {
        $Where = array('employeeId' => $LoginCredentialArr['username'], 'emppassword' => md5($LoginCredentialArr['password']), 'isactive' => '1');
        $this->db->select('*');
        $this->db->from('main_users');
        $this->db->where($Where);
        $recArr = $this->db->get()->result();
        if ($recArr) :
            return $recArr;
        else :
            return false;
        endif;
    }

    //code by govind
    //Edited By #GDSINGH 15012020

    public function getTotalActiveEmployeeCeg($id)
    {
        // $this->db1->database;
        // $db2 = $this->db2->database;
        $this->db->select('*');
        $this->db->from('main_employees_summary');
        $this->db->where(array('isactive' => '1', 'businessunit_id' => $id));
        $result = $this->db->get()->result();
        $resultCount = count($result);
        return isset($resultCount) ? $resultCount : 'N/A';
    }

    //code by gaurav
    //Get Table Data Record.
    public function GetTableData($cegth_table, $Where)
    {
        $this->db->select('*');
        $this->db->from($cegth_table);
        $this->db->order_by("id", "DESC");
        $this->db->where($Where);
        $recArr = $this->db->get()->result();
        return $recArr;
    }

    //Get All Applied Leave..
    public function GetAllActiveProjectList()
    {
        $this->db->select('a.id,a.project_name');
        $this->db->from('tm_projects as a');
        $this->db->where(array("a.is_active" => "1"));
        $this->db->order_by("a.project_name", "DESC");
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    public function set_prodesignation_byprojidbd_dropd_ajax($tsProjId)
    {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        //JPG Tonk D..Static ID..
        $BDprojID = $this->GetProjIdTStoBDProjID($tsProjId);
        if ($BDprojID) {
            $this->db->select('a.designation_id,b.designation_name');
            $this->db->from("$db2.assign_finalteam as a");
            $this->db->join("$db2.designation_master_requisition as b", "a.designation_id=b.fld_id", "INNER");
            $this->db->where(array("a.status" => "1", "a.project_id" => $BDprojID));
            $this->db->group_by("a.designation_id");
            $this->db->order_by("b.designation_name", "ASC");
            $designationList = $this->db->get()->result();
        }
        return ($designationList) ? $designationList : null;
    }

    //Get Proj Id TS to BD Proj ID..
    public function GetProjIdTStoBDProjID($tsProjID)
    {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $this->db->select('a.project_id');
        $this->db->from("$db2.accountinfo as a");
        $this->db->where(array("a.status" => "1", "a.project_numberid" => $tsProjID));
        $BdProjID = $this->db->get()->row();
        return ($BdProjID) ? $BdProjID->project_id : "";
    }

    //Get Employee Code..
    public function GetEmpIDCode()
    {
        $this->db->select('a.employee_code');
        $this->db->from("main_identitycodes as a");
        $EmpCode = $this->db->get()->row();
        return ($EmpCode) ? $EmpCode->employee_code : "";
    }

    //Get Last Employee Id By CompanyID..
    public function GetLastEmpIdByCompanyID($compID)
    {
        $this->db->select('a.employeeId');
        $this->db->from("main_users as a");
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->where("a.company_id", $compID);
        $this->db->where("b.businessunit_id!=", "3");
        $this->db->order_by("a.id", "DESC");
        $this->db->limit("1");
        $EmpCode = $this->db->get()->row();
        return ($EmpCode) ? $EmpCode->employeeId : "";
    }

    //Get Last Employee Id CEG Project..
    public function GetLastEmpIdCEGProj()
    {
        $this->db->select('a.employeeId');
        $this->db->from("main_users as a");
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->where("b.businessunit_id", "3");
        $this->db->order_by("a.employeeId", "DESC");
        $this->db->limit("1");
        $EmpCode = $this->db->get()->row();
        return ($EmpCode) ? $EmpCode->employeeId : "";
    }

    //Get Employee Official Details By UserID..
    public function GetEmpOfficialDataByUserID($empID)
    {
        $this->db->select('b.*,a.*,b.profileimg,c.emp_leave_limit,a.country_mobcode_id');
        $this->db->from("main_users as a");
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->join("main_employeeleaves as c", "a.id=c.user_id", "LEFT");
        $this->db->where(array("a.id" => $empID)); //"a.isactive" => '1', 
        $recSingleEmplDetails = $this->db->get()->row();
        return ($recSingleEmplDetails) ? $recSingleEmplDetails : null;
    }

    //Get Table Data Record.
    public function GetTableDataRec($cegth_table, $Where)
    {
        $this->db->select('*');
        $this->db->from($cegth_table);
        $this->db->where($Where);
        $this->db->order_by("fld_id", "DESC");
        $recArr = $this->db->get()->result();
        return $recArr;
    }

    //Get All Active Thumb Code..
    public function GetAllActiveThumbCode()
    {
        $this->db->select('a.EmployeeName,a.EmployeeID');
        $this->db->from("thumb_attendance as a");
        $this->db->where(["a.Status" => "1"]);
        $this->db->group_by("a.EmployeeID");
        $recArr = $this->db->get()->result();
        return $recArr;
    }

    //Get Employee Other Official Data...
    public function GetEmpotherOfficialDataByUserID($empID)
    {
        $this->db->select('a.*');
        $this->db->from("emp_otherofficial_data as a");
        $this->db->where(["a.status" => "1", "a.user_id" => $empID]);
        $this->db->limit("1");
        $recArr = $this->db->get()->row();
        return $recArr;
    }

    //Get Employee Salary Details..
    public function GetEmpSalaryDetailsByUserID($empID)
    {
        $this->db->select('a.*');
        $this->db->from("main_empsalarydetails as a");
        $this->db->where(["a.isactive" => "1", "a.user_id" => $empID]);
        $this->db->limit("1");
        $recArr = $this->db->get()->row();
        return $recArr;
    }

    //Get Employee Personal Details...
    public function GetEmpPersonalDetailsByUserID($empID)
    {
        $this->db->select('a.*');
        $this->db->from("main_emppersonaldetails as a");
        $this->db->where(["a.isactive" => "1", "a.user_id" => $empID]);
        $this->db->limit("1");
        $recArr = $this->db->get()->row();
        return $recArr;
    }

    public function getCompanyLocation($table_name)
    {
        $this->db->select('*');
        $this->db->from($table_name);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    //###### GDSINGH 17012020 ############

    public function getCompanyGradeAjax($location_id, $business_id = '', $company_id = '')
    {
        $this->db->select('tbl.city_name as cityName, mj.jobtitlecode as Grade, count(ms.jobtitle_id) as countGrade');
        $this->db->from('main_employees_summary as ms');
        $this->db->join("emp_otherofficial_data eod", "ms.user_id = eod.user_id", "LEFT");
        $this->db->join("main_jobtitles mj", "ms.jobtitle_id = mj.id", "LEFT");
        $this->db->join("tbl_ofclocation tbl", "eod.company_location = tbl.id", "LEFT");

        $this->db->where(array("ms.isactive" => 1));
        if (isset($location_id) && $location_id !== '') {
            $this->db->where(array("tbl.id" => $location_id));
        }

        if ($business_id == 1 || $business_id == 100) {
            $this->db->where(array("ms.businessunit_id" => 1));
        }
        if ($company_id < 100) {
            $this->db->where(array("eod.company_name" => $company_id));
        }

        $this->db->group_by("ms.jobtitle_id");
        $result = $this->db->get()->result();

        //print_r($this->db->last_query()); 
        return ($result) ? $result : null;
    }

    public function getCompanyGradeByIdAjax($business_id = '', $company_id = '')
    {
        $this->db->select('tbl.city_name as cityName, mj.jobtitlecode as Grade, count(ms.jobtitle_id) as countGrade');
        $this->db->from('main_employees_summary as ms');
        $this->db->join("emp_otherofficial_data eod", "ms.user_id = eod.user_id", "LEFT");
        $this->db->join("main_jobtitles mj", "ms.jobtitle_id = mj.id", "LEFT");
        $this->db->join("tbl_ofclocation tbl", "eod.company_location = tbl.id", "LEFT");
        $this->db->where(array("ms.isactive" => 1));

        if ($business_id < 100) {
            $this->db->where(array("ms.businessunit_id" => $business_id));
        }
        if ($company_id < 100) {
            $this->db->where(array("eod.company_name" => $company_id));
        }
        $this->db->group_by("ms.jobtitle_id");
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    public function getCompanyProjectGradeAjax($location_id, $business_id = '', $company_id = '')
    {
        $this->db->select('tbl.city_name as cityName, mj.jobtitlecode as Grade, count(ms.jobtitle_id) as countGrade');
        $this->db->from('main_employees_summary as ms');
        $this->db->join("emp_otherofficial_data eod", "ms.user_id = eod.user_id", "LEFT");
        $this->db->join("main_jobtitles mj", "ms.jobtitle_id = mj.id", "LEFT");
        $this->db->join("tbl_ofclocation tbl", "eod.company_location = tbl.id", "LEFT");

        $this->db->where(array("ms.isactive" => 1));
        if (isset($location_id) && $location_id !== '') {
            $this->db->where(array("tbl.id" => $location_id));
        }

        if ($business_id == 1 || $business_id == 100) {
            $this->db->where(array("ms.businessunit_id" => 1));
        }
        if ($company_id < 100) {
            $this->db->where(array("eod.company_name" => $company_id));
        }

        $this->db->group_by("ms.jobtitle_id");
        $result = $this->db->get()->result();
        //print_r($this->db->last_query()); 
        return ($result) ? $result : null;
    }

    public function getEmployeeList()
    {
        $this->db->select('mu.id,ms.department_name as departmentName, ms.isactive as employeeStatus, mu.firstname as firstName, mu.lastname as lastName, ms.profileimg as profilePic, mu.employeeId as employeeCode, ms.reporting_manager_name as immediateOfficer');
        $this->db->from('main_users  mu');
        $this->db->join("main_employees_summary  ms", "mu.id = ms.user_id", "LEFT");
        $this->db->where_not_in('mu.id', [1, 2]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    public function getBusinessUnit()
    {
        $this->db->select('*');
        $this->db->from('main_businessunits');
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    public function getCompanyName()
    {
        $this->db->select('*');
        $this->db->from('tbl_companyname');
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    //Check Existance With Tbl Name..
    public function chkExistanceRec($Table = '', $WhereArr = '')
    {
        $this->db->where($WhereArr);
        $num = $this->db->count_all_results($Table);
        return ($num) ? $num : null;
    }

    //Get All countries..
	   public function GetAllcountries()
    {
        $this->db->select('*');
        $this->db->from('tbl_countries');
        $this->db->where('is_active', '1');
        $this->db->order_by('country_name', 'ASC');
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }
    // public function GetAllcountries()
    // {
        // $this->db->select('*');
        // $this->db->from('countries');
        // $this->db->where('status', '1');
        // $this->db->order_by('country_name', 'ASC');
        // $result = $this->db->get()->result();
        // return ($result) ? $result : null;
    // }

    //Get Contact Details..
    public function GetRecEmplContactDetails($empID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empcommunicationdetails as a');
        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->row();
        return ($result) ? $result : null;
    }

    //Get Single Rec of Skills..
    public function GetRecEmplSkillsDetails($empID)
    {
        $this->db->select('a.*,b.competencylevel');
        $this->db->from('main_empskills as a');
        $this->db->join("main_competencylevel as b", "a.competency_level=b.id", "LEFT");
        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    //Get Family Details Rec of Family..
    public function GetRecEmplFamilyDetails($empID)
    {
        $this->db->select('a.*');
        $this->db->from('main_empdependencydetails as a');
        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    //Recent Pay Slip..
    public function GetRecentPayslipDetails($empID)
    {
        $recordArr = null;
        $this->db->select('a.payroll_with_name');
        $this->db->from('emp_otherofficial_data as a');
        $this->db->where(['a.status' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->row();
        if ($result->payroll_with_name) {
            $this->db->select('p.year,p.month,p.payroll_with_name');
            $this->db->from('payslip_filepath as p');
            $this->db->where(["p.payroll_with_name" => $result->payroll_with_name, "p.is_active" => "1"]);
            $this->db->order_by("p.id", "DESC");
            $this->db->limit("10");
            $recordArr = $this->db->get()->result();
        }
        return ($recordArr) ? $recordArr : null;
    }

    //Empl.. Job History..
    public function GetRecEmpljobhistoryDetails($empID)
    {
        $this->db->select('a.*,b.unitname,c.deptname,d.jobtitlename,e.positionname,f.company_name');
        $this->db->from('main_empjobhistory as a');
        $this->db->join('main_businessunits as b', 'a.businessunit=b.id', 'LEFT');
        $this->db->join('main_departments as c', 'a.department=c.id', 'LEFT');
        $this->db->join('main_jobtitles as d', 'a.jobtitleid=d.id', 'LEFT');
        $this->db->join('main_positions as e', 'a.positionheld=e.id', 'LEFT');
        $this->db->join('tbl_companyname as f', 'a.vendor=f.id', 'LEFT');

        $this->db->where(['a.isactive' => '1', 'a.user_id' => $empID]);
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    public function FamilyMemberRelationMaster()
    {
        $returnArr = array(
            "child" => "Child",
            "son" => "Son",
            "daughter" => "Daughter",
            "sister" => "Sister",
            "brother" => "Brother",
            "father" => "Father",
            "mother" => "Mother",
            "wife" => "Wife",
            "husband" => "Husband",
            "ex_spouse" => "ex Spouse",
            "grand_daughter" => "Grand daughter",
            "grandfather" => "Grandfather",
            "grandmother" => "Grandmother",
            "spouse" => "Spouse",
            "grandson" => "Grandson"
        );
        return ($returnArr) ? $returnArr : null;
    }

    public function GetAllEmployeeListReplacedWith()
    {
        $this->db->select('a.id,a.userfullname,a.employeeId');
        $this->db->from('main_users as a');
        // $this->db->where('a.isactive', '1');
        $this->db->order_by('a.userfullname', "ASC");
        $result = $this->db->get()->result();
        return ($result) ? $result : null;
    }

    function getDatesFromRange($startDate, $endDate)
    {
        $return = array($startDate);
        $start = $startDate;
        $i = 1;
        if (strtotime($startDate) < strtotime($endDate)) {
            while (strtotime($start) < strtotime($endDate)) {
                $start = date('Y-m-d', strtotime($startDate . '+' . $i . ' days'));
                $return[] = $start;
                $i++;
            }
        }
        return $return;
    }


    public function getEmpDetailsByUserID($empID)
    {
        // ep($empID);
        $this->db->select("n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,c.noticeperiod,c.floor_number,c.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
        // $this->db->select("j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining");
        $this->db->from("main_users as a");
        $this->db->join("main_employees_summary as b", "a.id=b.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as c", "a.id=c.user_id", "LEFT");
        $this->db->join("main_subdepartments as d", "d.id=c.sub_department", "LEFT");
        $this->db->join("tbl_ofclocation as f", "c.company_location=f.id", "LEFT");
        $this->db->join("main_empsalarydetails as g", "a.id=g.user_id", "LEFT");
        $this->db->join("main_payfrequency as h", "g.salarytype=h.id", "LEFT");
        $this->db->join("main_emppersonaldetails as i", "i.user_id=a.id", "LEFT");
        $this->db->join("main_maritalstatus as j", "i.maritalstatusid=j.id", "LEFT");
        $this->db->join("main_nationality as k", "i.nationalityid=k.id", "LEFT");
        $this->db->join("tbl_religion as l", "i.religion=l.id", "LEFT");
        $this->db->join("main_gender as m", "i.genderid=m.id", "LEFT");
        $this->db->join("main_roles as n", "b.emprole=n.id", "LEFT");
        $this->db->where(array("a.id" => $empID));
        $recResp = $this->db->get()->row();
        // epd($recResp);
        // echo "ss<pre>"; print_r($recResp);
        return $recResp;
    }

    //Employee Other..
    public function getOtherUserRecordByUserID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('other_user_record as a');
        $this->db->where(array("a.user_id" => $userID, "a.status" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    //Reference Details
    public function GetReferencesDetailRecByID($userID)
    {
        $this->db->select('a.*');
        $this->db->from('personnel_professional_reference as a');
        $this->db->where(array("a.user_id" => $userID, "a.status" => "0"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
 // 05-07-2022 vivek
     public function GetChatUserPic($picid)
    {
        //$id = $this->session->userdata('loginid');
        $this->db->select('user.*,b.thumbcode,b.payroll_with_name');
        $this->db->from('main_employees_summary as user');
        $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->where(array("user.user_id" => $picid, "user.isactive" => "1"));
        $RecSingleRow = $this->db->get()->row();
        return ($RecSingleRow) ? $RecSingleRow : null;
    }

    //New Function By Asheesh.. 25-07-2022/..
    public function set_prodesignation_byprojidbd_dropd_ajax_new($tsProjId=''){
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $designationList = null;

        if ($tsProjId) {
            $this->db->select("$db3.a.*,$db2.b.designation_name");
            $this->db->from("$db3.assign_designation_onproj as a");
            $this->db->join("$db2.designation_master_requisition as b", "$db3.a.designation_id=$db2.b.fld_id", "INNER");
            $this->db->where(array("$db3.a.status" => "1", "$db3.a.hrms_projid" => $tsProjId));
            $this->db->group_by("$db3.a.designation_id");
            $this->db->order_by("$db2.b.designation_name", "ASC");
            $designationList = $this->db->get()->result();
        }
        return ($designationList) ? $designationList : null;
    }
	 // 11-10-2022 (vivek)
    public function GetAllCompanyList(){
           $db2 = $this->db2->database;
           $this->db->select("$db2.a.fld_id,$db2.a.company_name");
           $this->db->from("$db2.main_company as a");
           $this->db->where(array("$db2.a.status" => "1"));
           $designationList = $this->db->get()->result();
           return ($designationList) ? $designationList : "";
    }
	// 19-10-2022 creatby(vivek)
    public function GetSingleSkillsDetails($edit_Id){
        $this->db->select('a.*');
        $this->db->from('main_empskills as a');
        $this->db->where(['a.isactive' => '1', 'a.id' => $edit_Id]);
        $result = $this->db->get()->row();
        return ($result) ? $result : null;  
    }
	public function get_all_edulevel()
    {
        $db1 = $this->db1->database;
        $this->db->select("$db1.a.id,$db1.a.educationlevelcode");
        $this->db->from("$db1.main_educationlevelcode as a");
        $this->db->where("$db1.a.isactive","1");
       $data = $this->db->get()->result();
       return $data?$data:'';
        }
    public function Getdegree($empID)
    {
        
        $this->db->select('a.*,b.educationlevelcode,c.degreename,d.course_name');
        $this->db->from("main_empeducationdetails as a");
        $this->db->join("main_educationlevelcode as b","b.id=a.educationlevel","LEFT");
        $this->db->join("tbldegree as c","c.id=a.course","LEFT");
        $this->db->join("tbl_coursetype as d","d.id=a.coursetype_id","LEFT");
        
        $this->db->order_by("a.id", "DESC");
        $this->db->where("a.user_id",$empID);
        $this->db->where("a.isactive","1");
        $recArr = $this->db->get()->result();
        return $recArr;
    }
	public function GetSinglejobDetails($edit_Id){
        $this->db->select('a.*');
        $this->db->from('main_empjobhistory as a');
        $this->db->where(['a.isactive' => '1', 'a.id' => $edit_Id]);
        $result = $this->db->get()->row();
        return ($result) ? $result : null;  
    }
    public function GetCountries()
    {
        $this->db->select('*');
        $this->db->from('tbl_countries');
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
    public function SelectRecordFld($cegth_table, $Where, $orderfield = '', $ordtype = '') {
        $this->db->select('*');
        $this->db->from($cegth_table);
        $this->db->order_by($orderfield, $ordtype);
        $this->db->where($Where);
        return $this->db->get()->result();
    }
    //Get All Holidays List.. (vivek jul 10 2023)
    public function holidayCount($startDate, $endDate)
    {
        $ReturnHolidateArr = array();
        $status=array();
        $this->db->select('id,holidaydate');
        $this->db->from('main_holidaydates');
        $where_date = " `holidaydate` BETWEEN '$startDate' AND '$endDate' ";
        $this->db->where($where_date);

        $arr = array('isactive' => '1', 'groupid' => '1');
        $this->db->where($arr);
        $res = $this->db->get()->result();

        if ($res) {
            foreach ($res as $val) {
                $ReturnHolidateArr[] = date("d-m-Y", strtotime($val->holidaydate));
                $status[] = '5';
            }
        }

        return ($ReturnHolidateArr) ? array_combine($ReturnHolidateArr,$status) : null;
    }
    //################## Get All Leave Request List #####################
    public function GetAllLeaveListArr($start_date, $end_date, $loginID)
    {
        $fromdate = date("Y-m-d", strtotime($start_date));
        $todate = date("Y-m-d", strtotime($end_date));
        $this->db->select('from_date,to_date,leavetypeid,leaveday');
        $this->db->from('main_leaverequest');
        $this->db->where(array('isactive' => '1', 'user_id' => $loginID));
        $where_date = "((`from_date` BETWEEN '" . $fromdate . "' AND '" . $todate . "') OR (`to_date` BETWEEN '" . $fromdate . "' AND '" . $todate . "') OR (`from_date`<='" . $fromdate . "' AND `to_date`>='" . $todate . "'))";
        $this->db->where($where_date);
        $this->db->where("leavestatus !=", "Cancel");
        $this->db->where("leavestatus !=", "Rejected");
        $LeaveReqList = $this->db->get()->result();
        // epd($LeaveReqList);
       
        //Loop Cond..
        $AllDatesArr = array();
        $status=array();

        //All Leaves Dates..
        if ($LeaveReqList) {
            foreach ($LeaveReqList as $keys=>$LvDate) {
                $recDDarr = $this->getDatesFromRange($LvDate->from_date, $LvDate->to_date);
                if ($recDDarr) :
                    foreach ($recDDarr as $keys=>$rEdRows) :
                        if(date("m", strtotime($rEdRows)) == date("m", strtotime($start_date))){
                        $AllDatesArr[] = date("d-m-Y", strtotime($rEdRows));
                        $status[] = ($LvDate->leavetypeid == 3) ? $LvDate->leaveday : '4';
                        }
                    endforeach;
                endif;
            }
        }
        return ($AllDatesArr) ? array_combine($AllDatesArr,$status) : $AllDatesArr;
    }
    //################## Get All Tour Request List #####################
    public function GetAllTourListArr($start_date, $end_date, $loginID)
    {
        // epd($end_date);
        $fromdate = date("Y-m-d", strtotime($start_date));
        $todate = date("Y-m-d", strtotime($end_date));

        $this->db->select('start_date as from_date,end_date as to_date');
        $this->db->from('emp_tourapply');
        $this->db->where(array('is_active' => '1', 'emp_id' => $loginID));
        $where_date = "((`start_date` BETWEEN '" . $fromdate . "' AND '" . $todate . "') OR (`end_date` BETWEEN '" . $fromdate . "' AND '" . $todate . "') OR (`start_date`<='" . $fromdate . "' AND `end_date`>='" . $todate . "'))";
        $this->db->where($where_date);
        $this->db->where("approved_bypmanager !=", "2");
        $this->db->where("approved_bylmanager !=", "2");
        $TourReqList = $this->db->get()->result();
        // epd($TourReqList);

        //Loop Cond..
        $AllDatesArr = array();
        $status=array();
        //All Leaves Dates..
        if ($TourReqList) {
            foreach ($TourReqList as $LvDate) {
                $recDDarr = $this->getDatesFromRange($LvDate->from_date, $LvDate->to_date);
                if ($recDDarr) :
                    foreach ($recDDarr as $rEdRows) :
                        if(date("m", strtotime($rEdRows)) == date("m", strtotime($start_date))){
                            $AllDatesArr[] = date("d-m-Y", strtotime($rEdRows));
                            $status[] = '6';
                        }
                    endforeach;
                endif;
            }
        }
        return ($AllDatesArr) ? array_combine($AllDatesArr,$status) : NULL;
    }
    //=========code by durgesh for wok from home condition(29-10-2020)============//
    public function WorkFromHome($emp_id, $month, $year, $actdate)
    {
        $this->db->select(array('*'));
        $this->db->from('roster_weekly_schedule');
        $this->db->where(array('user_id' => $emp_id, 'roster_month' => $month, 'roster_year' => $year, 'status' => '1'));
        $recArr = $this->db->get()->result();
        if ($recArr) :
            foreach ($recArr as $wfhcols) :
                switch ($actdate) {
                    case ($actdate):

                        //Monday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->mon_date))) and $wfhcols->mon_action == 'WFH') {
                            return 1;
                        }

                        //Tuesday Date WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->tue_date))) and $wfhcols->tue_action == 'WFH') {
                            return 1;
                        }

                        //Wednesday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->wed_date))) and $wfhcols->wed_action == 'WFH') {
                            return 1;
                        }

                        //Thusday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->thu_date))) and $wfhcols->thu_action == 'WFH') {
                            return 1;
                        }

                        //Friday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->fri_date))) and $wfhcols->fri_action == 'WFH') {
                            return 1;
                        }

                        //Saturday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->sat_date))) and $wfhcols->sat_action == 'WFH') {
                            return 1;
                        }

                        //Sunday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->sun_date))) and $wfhcols->sun_action == 'WFH') {
                            return 1;
                        }
                }

            endforeach;
        endif;
        return false;
    }

    //Get All Punch
    public function GetAllPunchDetail($punchDate, $userID)
    {
        $tablemonth=date("n", strtotime($punchDate));
        $tableyear=date("Y", strtotime($punchDate));
        $table='DeviceLogs_'.$tablemonth.'_'. $tableyear;
        $this->db->select("DATE_FORMAT(`LogDate`,'%H:%i:%s %p') as punchtime");
        $this->db->from($table);
        $this->db->where("(`UserId` = '" . $userID . "' and DATE_FORMAT(`LogDate`,'%d-%m-%Y')='" . $punchDate . "')");
        $this->db->order_by("LogDate", "ASC");
        $this->db->group_by("LogDate");
        $PunchRecData = $this->db->get()->result();
        $In_timeArr = array();
        $Out_timeArr = array();
        $status='';
        if ($PunchRecData) {
            foreach ($PunchRecData as $kKeY => $rEcd) {
                $returnM = ($kKeY % 2);
                if ($returnM == 0) {
                    array_push($In_timeArr, $rEcd->punchtime);
                }
                if ($returnM == 1) {
                    array_push($Out_timeArr, $rEcd->punchtime);
                }
                if($returnM == 0 OR $returnM == 1){
                    if($Out_timeArr){
                        $status='P';
                    }elseif($In_timeArr){
                        $status='MP';
                    }else{
                        $status='A';
                    }
                }
                
            }
            return $status;
        } else {
            return $status='A';
        }
    }

    //Get Single Date Atten Details By User ID..
    public function getSingleDateAttByUserID($punchDate, $userID,$uId)
    {
        $tablemonth=date("n", strtotime($punchDate));
        $tableyear=date("Y", strtotime($punchDate));
        $table='DeviceLogs_'.$tablemonth.'_'. $tableyear;
        // $uId = $this->session->userdata('loginid');
        $this->db->select("shift_out_time, shift_in_time");
        $this->db->from("emp_otherofficial_data");
        $this->db->where(array("status" => "1", "user_id" => $uId));
        $rsp = $this->db->get()->result();

        $this->db->select("LogDate,DATE_FORMAT(`LogDate`,'%H:%i:%s %p') as punchtime,TIME_FORMAT(`LogDate`,'%H:%i:%s') as punchouttime");
        $this->db->from($table  );
        $this->db->where("(`UserId` = '" . $userID . "' and DATE_FORMAT(`LogDate`,'%d-%m-%Y')='" . $punchDate . "')");
        $this->db->order_by("LogDate", "ASC");
        $this->db->group_by("LogDate");
        $PunchRecData = $this->db->get()->result();
        // epd($PunchRecData);
        if (@$PunchRecData) {
            $recArrReturn["intime"] = $PunchRecData[0]->punchtime;
            $FunllInTim = date("h:i:s A", strtotime($PunchRecData[0]->punchtime));

            //code edit by durgesh (28-10-2020)
            if ((strtotime($FunllInTim) > strtotime($rsp[0]->shift_in_time . ":00 AM"))) {
                //$recArrReturn["lateby"] = round(abs(strtotime($FunllInTim) - strtotime($rsp[0]->shift_in_time.":00 AM")) / 60, 2);
                $recArrReturn["lateby"] = floor(abs(strtotime($FunllInTim) - strtotime($rsp[0]->shift_in_time . ":00 AM")) / 60);
            }

            //Out Time..
            if (count($PunchRecData) > 0) :
                foreach ($PunchRecData as $Pkey => $rows) {
                    $return = ($Pkey % 2);
                    if ($return == 1) :
                        $recArrReturn["outtime"] = date("H:i:s A", strtotime($rows->LogDate));

                        $punchOut = date("H:i:s", strtotime($rows->punchtime));
                        $shift_out = $rsp[0]->shift_out_time;
                        $shift_out_arr = date("H:i:s", strtotime("$shift_out PM"));
                        $varb1 = end($PunchRecData);
                        $varb2 = $varb1->punchouttime;
                        if (strtotime($varb2) < strtotime($shift_out_arr)) {
                            //$recArrReturn["earlyby"] = round(abs(strtotime($shift_out_arr) - strtotime($varb2)) / 60, 2);
                            $recArrReturn["earlyby"] = floor(abs(strtotime($shift_out_arr) - strtotime($varb2)) / 60);
                        }

                    endif;
                }
            endif;
            return ($recArrReturn) ? $recArrReturn : null;
        } else {
            return null;
        }
    }

}
