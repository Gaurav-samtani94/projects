<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Update_emp_punchModel extends CI_Model {

    // var $table = 'main_employees_summary as a';
    var $column_order = array(null, 'a.employeeId','a.userfullname','a.jobtitle_name');
    var $column_search = array('a.employeeId','a.userfullname','a.jobtitle_name');
    var $order = array('a.user_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {

		
		if($this->input->post('department_id')){
            $this->db->where("a.businessunit_id", $this->input->post('department_id'));
        }
		$today = date("Y-m-d"); 
        $buss_id = array('1','2');
        $this->db->select("a.user_id,b.machine_id,a.department_name,a.prefix_name,a.userfullname,a.employeeId,b.floor_number");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        // $this->db->join("DeviceLogs_Processed as c", "b.machine_id=c.UserId", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1","b.company_location" => '1'));
        // $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where_in("a.businessunit_id",$buss_id);
		$this->db->group_by("a.user_id");
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from('main_employees_summary');
        return $this->db->count_all_results();
    }
	
	//Get Single Date Atten Details By User ID..
    Public function getSingleDateAttByUserID($punchDate, $userID) {
        //$punchDate = "01-01-2020";
        // $userID = "127";

        $this->db->select("LogDate,DATE_FORMAT(`LogDate`,'%H:%i:%s %p') as punchtime");
        $this->db->from('DeviceLogs_Processed');
        $this->db->where("(`UserId` = '" . $userID . "' and DATE_FORMAT(`LogDate`,'%d-%m-%Y')='" . $punchDate . "')");
        $this->db->order_by("LogDate", "ASC");
        $this->db->group_by("LogDate");
        $PunchRecData = $this->db->get()->result();
        if (@$PunchRecData) {
            $recArrReturn["intime"] = $PunchRecData[0]->punchtime;
            $FunllInTim = date("h:i:s A", strtotime($PunchRecData[0]->punchtime));
            if ((strtotime($FunllInTim) > strtotime("09:30:00 AM")) AND ( strtotime($FunllInTim) < strtotime("10:01:00 AM"))) {
                $recArrReturn["lateby"] = round(abs(strtotime($FunllInTim) - strtotime("09:30:00 AM")) / 60, 2);
            }
            //Out Time..
            if (count($PunchRecData) > 0):
                foreach ($PunchRecData as $Pkey => $rows) {
                    $return = ($Pkey % 2);
                    if ($return == 1):
                        $recArrReturn["outtime"] = $rows->punchtime;
                    endif;
                }
            endif;
            return ($recArrReturn) ? $recArrReturn : null;
        } else {
            return null;
        }
    }
	
	public function get_in_out_time() {
		// $today = date("Y-m-d"); 
		$today = date('Y-m-d',strtotime("-1 days"));
        $buss_id = array('1','2');
        $this->db->select("a.user_id,a.userfullname,c.LogDate");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "b.machine_id=c.UserId", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1","b.company_location" => '1',"c.C4" => "10","c.Direction" => "in"));
        $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where_in("a.businessunit_id",$buss_id);
		$this->db->group_by("a.user_id");
		$recArrReturn = $this->db->get()->result();
		return ($recArrReturn) ? $recArrReturn : null;
	}

}
