<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class All_emplist_with_IO_RO_model extends CI_Model {
	
	
    var $table = 'main_employees_summary as a';
    var $column_order = array('a.userfullname');
    var $column_search = array('a.userfullname','a.department_name');
    var $order = array('a.id' => 'asc'); 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
		  $empArr = array("2", "173", "175", "190");
        $this->db->select("a.*,c.appraisalduedate,d.reviewing_officer_ro");
        $this->db->from($this->table);
        $this->db->join("main_empsalarydetails as c", "c.user_id=a.user_id", "LEFT");
        $this->db->join("emp_otherofficial_data as d", "a.user_id = d.user_id", "LEFT");

        $this->db->where(array("a.isactive" => "1"));
        $this->db->where_not_in("a.user_id", $empArr);
		if ($this->input->post('dept_name')) {
            $this->db->where('a.department_id', $this->input->post('dept_name'));
        }
        if ($this->input->post('businessunit_name')) {
            $this->db->where('a.businessunit_id', $this->input->post('businessunit_name'));
        }
        $this->db->group_by("a.user_id");
		
        $i = 0;

        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
         $this->_get_datatables_query();
         $query = $this->db->get();
         return $query->num_rows();
        
    }

    public function count_all() {
         $this->db->from($this->table);
        return $this->db->count_all_results();
        
    }
	
	
	
    


}

?>