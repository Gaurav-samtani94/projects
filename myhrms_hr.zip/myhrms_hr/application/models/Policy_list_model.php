<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Policy_list_model extends CI_Model {
    
	public function __construct() {
        parent::__construct();
        $this->load->database();
    }
	
    public function GetAllPolicys() {
        $this->db->select('*');
        $this->db->from('policy_master');
		$this->db->where("is_active", "1");
		$this->db->order_by("id", "DESC");
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
	
	public function GetSinglePolicyDetailsByID($policy_id){
		$this->db->select('*');
        $this->db->from('policy_master');
        $this->db->where("id",$policy_id);
        $NewsRecord = $this->db->get()->row();
        return ($NewsRecord) ? $NewsRecord : null;
	}
	
	public function Getmain_departmentsByID($unit_id){
		$this->db->select('id,deptname');
        $this->db->from('main_departments');
        $this->db->where("unitid",$unit_id);
        $NewsRecord = $this->db->get()->result();
		return ($NewsRecord) ? $NewsRecord : null;
	}
	
	
	

}
