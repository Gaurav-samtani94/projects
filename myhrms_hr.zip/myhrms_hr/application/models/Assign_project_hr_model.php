

<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Assign_project_hr_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function getProjectlist()
    {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $UserId = $this->session->userdata('loginid');
        $this->db->select('id,project_name');
        $this->db->from('tm_projects as a');
        $this->db->where(array("a.is_active" => "1"));
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }
    public function getHrlist()
    {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $UserId = $this->session->userdata('loginid');
        $this->db->select('a.user_id,a.department_name,b.userfullname');
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_users as b", "a.user_id=b.id", "LEFT");
        // $this->db->join("emp_otherofficial_data b", "user.user_id=b.user_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "a.department_id" => "11"));
        $Rec = $this->db->get()->result();
        return ($Rec) ? $Rec : null;
    }

    public function inserted_data($data)
    {
        $this->db->insert('hr_person_assign_to_project', $data);
        return true;
    }

    public function getassignlist()
    {
        // return "qwertyuiop";
        $this->db->select('count(a.hruser_id) as abc,a.project_id,a.hruser_id,a.assign_date,c.userfullname');
        $this->db->from('hr_person_assign_to_project as a');
        // $this->db->join("emp_otherofficial_data as b", "a.hruser_id=b.user_id", "LEFT");
        $this->db->join("main_users as c", "a.hruser_id=c.id", "LEFT");
        $this->db->group_by('hruser_id');
        $this->db->where(array("a.status" => "1"));
        $RecRows = $this->db->get()->result();



        return ($RecRows) ? $RecRows : null;
    }




    public function getbookfloordata($hruser_id)
    {
        // return "qwertyuiop"; "a.project_id" => $hruser_id
        $this->db->select('b.project_name,a.assign_date,c.userfullname');
        // $this->db->select('*');
        $this->db->from('hr_person_assign_to_project as a');
        $this->db->join("tm_projects as b", "a.project_id=b.id", "LEFT");
        $this->db->join("main_users as c", "a.hruser_id=c.id", "LEFT");
        //$this->db->group_by('hruser_id');
        $this->db->where(array("a.status" => "1", "hruser_id" => $hruser_id));
        $RecRows = $this->db->get()->result();



        return ($RecRows) ? $RecRows : null;
    }
}
