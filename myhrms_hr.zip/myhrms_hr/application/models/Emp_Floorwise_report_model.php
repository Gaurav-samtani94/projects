<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_Floorwise_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    //Get Employee Details for joining report ..
    public function floorwise_details() {
		$buss_id = array('1','2');
		$keyOfficials = array('2','173','175','190');
        $this->db->select("a.user_id,a.department_name,a.prefix_name,a.userfullname,a.employeeId,b.floor_number");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        // $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        $this->db->where(array("a.isactive" => "1", "b.status" => "1","b.company_location" => '1'));
        $this->db->where_in("a.businessunit_id",$buss_id);
        $this->db->where_not_in("a.user_id",$keyOfficials);
		$this->db->group_by("a.user_id");
        // $recArr = $this->db->get()->num_rows();
        $recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '01';
    }

}

?>