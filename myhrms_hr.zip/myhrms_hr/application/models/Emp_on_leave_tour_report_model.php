<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_on_leave_tour_report_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
	
	public function tour_atten_report_ceg() {
		$today = date("Y-m-d"); 
		$this->db->select("a.user_id,d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.start_date,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_tourapply as b","a.user_id=b.emp_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','start_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '0';
    }
	     
	public function leave_atten_report_ceg1() {
		$today = date("Y-m-d"); 
		$this->db->select("b.appliedleavescount,a.user_id,b.leaveday,d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.leavestatus,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_leaverequest as b","a.user_id=b.user_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','b.from_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_tour_atten_report_ceg($bid) {
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.start_date,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_tourapply as b","a.user_id=b.emp_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','start_date'=>$today));
		$this->db->where_in("a.businessunit_id", $bid);
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return $recArr;
    }
	
	public function count_leave_atten_report_ceg1() {
		$today = date("Y-m-d"); 
		$this->db->select("a.user_id,b.leaveday,d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.leavestatus,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_leaverequest as b","a.user_id=b.user_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','b.from_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_present_atten_report_ceg1() {
		$today = date("Y-m-d"); 
		// $this->db->select("a.user_id,c.*");
		$this->db->select("a.userfullname,b.user_id,b.machine_id");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1"));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        // $recArr = $this->db->get()->result();
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_absent() {
		$cl = array('1');
		$bid = array('1','2');
		$today = date("Y-m-d"); 
		$this->db->select("a.userfullname,b.user_id,b.machine_id");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1"));
        // $this->db->where_in("b.company_location", $cl);
        $this->db->where_in("a.businessunit_id", $bid);
        // $this->db->where_in("b.machine_id", NULL);
        // $recArr = $this->db->get()->result();
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	public function count_absent_list() {
		$cl = array('1');
		$bid = array('1','2');
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,a.businessunit_name");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("tbl_ofclocation as d","d.id=b.company_location","left");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1"));
        // $this->db->where_in("b.company_location", $cl);
        $this->db->where_in("a.businessunit_id", $bid);
        // $this->db->where_in("b.machine_id", NULL);
        $recArr = $this->db->get()->result();
        // $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_tour_atten_report_ceg_absent() {
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_tourapply as b","a.user_id=b.emp_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','start_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
		// $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_leave_atten_report_ceg_absent() {
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_leaverequest as b","a.user_id=b.user_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','b.from_date'=>$today));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
		// $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_present_atten_report_ceg_absent() {
		$today = date("Y-m-d"); 
		// $this->db->select("a.user_id,c.*");
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,a.businessunit_name");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        $this->db->join("tbl_ofclocation as d","d.id=b.company_location","left");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1"));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->result();
        // $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	//Emp leave count based on business Id
	public function count_leave_by_businessid($bid) {
		$today = date("Y-m-d"); 
		$this->db->select("b.appliedleavescount,a.user_id,b.leaveday,d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.leavestatus,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("main_leaverequest as b","a.user_id=b.user_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','b.from_date'=>$today,'a.businessunit_id' => $bid));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->result();
        return $recArr;
    }
	
	public function count_tour_atten_report_ceg_nd_cegth($bid) {
		$today = date("Y-m-d"); 
		$this->db->select("d.city_name,a.userfullname,a.employeeId,a.jobtitle_name,b.start_date,a.businessunit_name");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_tourapply as b","a.user_id=b.emp_id","left");
        $this->db->join("emp_otherofficial_data as c","c.user_id=a.user_id","left");
        $this->db->join("tbl_ofclocation as d","d.id=c.company_location","left");
        $this->db->where(array('a.isactive'=>'1','start_date'=>$today,'a.businessunit_id'=>$bid));
        $this->db->order_by("a.jobtitle_id",'ASC');
        $this->db->group_by('a.user_id');
		$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
	
	public function count_present_atten_report_ceg_nd_cegth($bid) {
		$today = date("Y-m-d"); 
		// $this->db->select("a.user_id,c.*");
		$this->db->select("a.userfullname,b.user_id,b.machine_id");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
		$this->db->where(array("a.isactive" => "1", "b.status" => "1", "a.businessunit_id" => $bid));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        // $recArr = $this->db->get()->result();
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }

    public function count_present_atten_report_ceg_nd_cegth_full_detail($bid) {
        $today = date("Y-m-d"); 
        // $this->db->select("a.user_id,c.*");
        $this->db->select("a.userfullname,b.user_id,b.machine_id,a.employeeId,a.jobtitle_name,a.businessunit_name");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "a.businessunit_id" => $bid));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
         $recArr = $this->db->get()->result();
        //$recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }
 public function emp_on_tour_today() //Abhishek 27-01-2022
    {
        $this->db->select('a.emp_id as empid, a.start_date as stdate,a.end_date as endate,b.businessunit_id as busid,b.userfullname as username,b.jobtitle_name as titlename,businessunit_name as busname ,b.employeeId as empuserid');
        $this->db->from('emp_tourapply as a');
        $this->db->join('main_employees_summary as b', 'b.user_id=a.emp_id', 'LEFT');
        // $this->db->join('main_users as d', 'd.id=a.emp_id', 'LEFT');
        $data = $this->db->get()->result();
        return ($data) ? $data : '0';
    }

}

?>