<?php

defined('BASEPATH') or exit('No direct script access allowed');

class All_employee_list_appr_Model extends CI_Model
{

    var $summary_table = 'main_employees_summary as a';
    var $column_order = array(null, 'userfullname', 'emailaddress', 'contactnumber', 'employeeId','department_name','businessunit_name');
    var $column_search = array('userfullname', 'emailaddress', 'contactnumber', 'employeeId','department_name','businessunit_name');
    
    var $order = array('id' => 'DESC'); // default order 

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query()
    {
        // exit;
        $keyOfficials = array("173", "2", "175", "190", "191");
            $row[] = isset($dataRow->contactnumber) ? $dataRow->contactnumber : '';
            $this->db->select('a.user_id,a.profileimg,a.profileimg,a.isactive,a.userfullname,a.contactnumber,a.emailaddress,a.department_name,a.businessunit_name');
        $this->db->from($this->summary_table);
        $this->db->where_not_in('a.user_id', $keyOfficials);
        // $this->db->where("a.isactive",1);
        // $this->db->order_by('a.userfullname', 'ASC');
        $this->db->group_by('a.user_id');

        if ($this->input->post('isactive') == '1') {
            $this->db->where("a.isactive", $this->input->post('isactive'));
        } elseif ($this->input->post('isactive') == '5') {
            $this->db->where("a.isactive!=", "1");
        } else {

        }

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($user_id = ''){
        $this->_get_datatables_query($user_id);
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $recArr = $query->result();
        return $recArr;
    }

    function count_filtered($user_id = ''){
        $this->_get_datatables_query($user_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all(){
        $this->db->from($this->summary_table);
        return $this->db->count_all_results();
    }

    public function getDataByUserId($user_id) {
        $this->db->select('a.userfullname,a.user_id,a.position_name,a.department_name,a.businessunit_id,e.company_id,a.jobtitle_name, c.company_name,b.on_project,d.project_name');
        $this->db->from('main_employees_summary as a');
        $this->db->where('a.user_id', $user_id);
        $this->db->join('emp_otherofficial_data as b',"a.user_id = b.user_id",'left');
        $this->db->join('main_users as e',"a.user_id = e.id",'left');
        $this->db->join('tbl_companyname as c',"c.id = e.company_id",'left');
        $this->db->join('tm_projects as d',"d.id = b.on_project",'left');
        // $this->db->where('a.isactive', 1);
        $data = $this->db->get()->row();
        // echo "<pre>"; print_r($data); die;
        return ($data) ? $data : "";
    }

    public function addSalaryAnextureDataTemp($user_details, $salary_details) {
        // $this->db->select('a.*');
        // $this->db->from('temp_sal_structure as a');
        // $this->db->where(['a.user_id' => $user_details->user_id, 'a.is_active' => 1]);
        // $dataCount = $this->db->get()->result();
        // echo $this->session->userdata('loginid');
        // echo "dd<pre>"; print_r($salary_details); die;
        $insertArr = array(
            'user_id' => $user_details->user_id,
            'ctc' => $salary_details->ctc,
            'pf_applicable' => $salary_details->pf_applicable,
            'vpf_applicable' => $salary_details->vpf_applicable,
            'esi_applicable' => $salary_details->esi_applicable,
            'metro_non_metro' => $salary_details->metro_non,
            'gratuity_applicable' => $salary_details->gratuity_applicable,
            'mediclaim_applicable' => $salary_details->mediclaim_applicable,
            'annual_bonus_applicable' => $salary_details->annual_bonus_applicable,
            'basic_sal' => $salary_details->basic_sal,
            'hra' => $salary_details->hra,
            'edu_allow' => $salary_details->edu_allow,
            'tele_allow' => $salary_details->tele_allow,
            'special_allow' => $salary_details->special_allow,
            'gadget_allow' => $salary_details->gadget_allow,
            'gross' => $salary_details->gross,
            'employer_pf' => $salary_details->employer_pf,
            'employer_esi' => $salary_details->employer_esi,
            'employer_gratuity' => $salary_details->employer_gratuity,
            'gpai' => $salary_details->gpai,
            'mediclaim' => $salary_details->mediclaim,
            'employees_pf' => $salary_details->emp_pf,
            'employees_vpf' => $salary_details->emp_vpf,
            'employees_esi' => $salary_details->emp_esi,
            'monthly_ctc' => $salary_details->monthly_ctc,
            'ann_bonus' => $salary_details->ann_bonus,
            'total_ctc' => $salary_details->total_ctc,
            'net_salary' => $salary_details->net_sal,
            "effective_date" => $salary_details->effective_date,
            "bonus_adv" => $salary_details->bonus_adv,
            'created_by' => $this->session->userdata('loginid'),
        );
        // echo "ddss  <pre>"; print_r($insertArr); die;
        $query = $this->db->get_where('temp_sal_structure', array(//making selection
            'user_id' => $user_details->user_id
        ));
        // echo $query->row()->fld_id; die;
// echo "<pre>"; print_r($query->row()->fld_id); die;
        $count = $query->num_rows(); //counting result from query
// echo "<pre>"; print_r($insertArr); die;
        if ($count === 0) {
            $this->db->insert('temp_sal_structure', $insertArr);
            $insert_id = $this->db->insert_id();
            // echo "mytest".$insert_id; die;
            return $insert_id;
        }
        else{
            // echo "de<pre>"; print_r($insertArr); die;
            $this->db->where('user_id', $user_details->user_id);
            $this->db->update('temp_sal_structure', $insertArr);
            return $query->row()->fld_id;
        }  

    }

    public function getRowCountSalaryAnexture($user_id) {
        // echo $user_id; die;
        $this->db->select('a.*');
        $this->db->from('temp_sal_structure as a');
        $this->db->where(['a.user_id' => $user_id, 'a.is_active' => 1]);
        $data = $this->db->get()->row();
        // echo "dd<pre>"; print_r($data); die;
        return ($data) ? $data : "";
    }



    public function getGpaiTeleAmt($grade) {
        $this->db->select('a.*');
        $this->db->from('sal_anex_fixed_amt_master as a');
        $this->db->where(['a.grade' => $grade, 'a.is_active' => 1]);
        $data = $this->db->get()->row();
        // echo "<pre>"; print_r($data); die;
        return ($data) ? $data : 0;
    }

    public function getGpaiTeleAmount() {
        $this->db->select('a.*');
        $this->db->from('sal_anex_fixed_amt_master as a');
        $this->db->where(['a.is_active' => 1]);
        $this->db->order_by('grade','ASC');
        $data = $this->db->get()->result();
        // echo "<pre>"; print_r($data); die;
        return ($data) ? $data : "";
    }

    public function updateFixedAmt($tableName, $updateArr,$fld_id) {
        $this->db->where('fld_id', $fld_id);
        $data = $this->db->update($tableName, $updateArr);
        return ($data) ? 1 : "0";
    }
    
    public function insertFixedAmt($tableName,$requestArr) {
        $data = $this->db->insert($tableName, $requestArr);
        return ($data) ? 1 : "0";
    }

    public function getMediclaimPremiumAmt() {
        $this->db->select('a.*');
        $this->db->from('sal_anex_mediclaim_premium as a');
        $this->db->where(['a.is_active' => 1]);
        $this->db->order_by('fld_id','ASC');
        $data = $this->db->get()->row();
        // echo "<pre>"; print_r($data); die;
        return ($data) ? $data : "";
    }

    public function getRowOfSalaryAnextureByFldId($fld_id) {
        // echo $user_id; die;
        $this->db->select('a.*');
        $this->db->from('temp_sal_structure as a');
        $this->db->where(['a.fld_id' => $fld_id, 'a.is_active' => 1]);
        $data = $this->db->get()->row();
        // echo "dd<pre>"; print_r($data); die;
        return ($data) ? $data : "";
    }

}