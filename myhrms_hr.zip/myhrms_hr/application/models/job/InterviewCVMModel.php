<?php
defined('BASEPATH') or exit('No direct script access allowed');

class InterviewCVMModel extends CI_Model
{
    public $jobs_table = 'job_interview_cvm as a';
    public $column_order = ['a.id'];
    public $column_search = ['a.id'];

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->db1 = $this->load->database('default', true);
        $this->db2 = $this->load->database('online', true);
        $this->db3 = $this->load->database('accdept_db', true);
        $this->db4 = $this->load->database('cvmanager', true);
        //epd($db4);
    }

    private function _get_datatables_query()
    {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $db4 = $this->db4->database;
        $this->db->where('a.interview_round_status',1);
        $this->db->where('a.selection_decision','4');
        $this->db->where('a.salary !=',null);
        
        $this->db->select('a.*'); 
        $this->db->from($this->jobs_table);
        
        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) {
                    $this->db->group_end();
                }
            }
            ++$i;
        }
        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } elseif (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function get_datatables()
    {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1) {
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        $query = $this->db->get();

        return $query->result();
    }

    public function count_filtered()
    {
        $this->_get_datatables_query();
        
        $query = $this->db->get();

        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->where('a.interview_round_status',1);
        $this->db->where('a.selection_decision','4');
        $this->db->where('a.salary !=',null);
        $this->db->from($this->jobs_table);
        
        return $this->db->count_all_results();
    }

    private function  interview_round_id(){
        $logined_id = $this->session->userdata('loginid');
        $this->db->select('interview_id');
        $this->db->from('job_interview_round_cvm');
        $this->db->group_by('interview_id');
        $this->db->where('interviewers_id', $logined_id);
        $this->db->where('interviewer_accept', 1);
        $query = $this->db->get()->result();
        
        $int_data = [];
        if(!empty($query)){
            foreach ($query as $key => $value) {
                $int_data[] = $value->interview_id;
            }
        }
        
        return $int_data;
    }
}
