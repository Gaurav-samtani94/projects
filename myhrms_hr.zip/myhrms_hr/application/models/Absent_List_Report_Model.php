<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Absent_List_Report_Model extends CI_Model {

    // var $table = 'emp_otherofficial_data as a';
    // var $table_summary = 'DeviceLogs_Processed as b';
    var $column_order = array(null);
    var $column_search = array(null);
    // var $order = array('a.id' => 'DESC');

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
		$dt = 'DATE_FORMAT(b.LogDate,"%Y-%m-%d")';
		$current_dt = date("Y-m-d");
		$this->db->select('a.machine_id,b.LogDate');
		$this->db->from('emp_otherofficial_data as a');
		$this->db->join('DeviceLogs_Processed as b',"b.UserId=a.machine_id ",'left');
		// and DATE_FORMAT(b.LogDate,'%Y-%m-%d') = '2021-03-03'
		// $this->db->where('b.LogDate >=', $current_dt);
		// $this->db->where('b.LogDate <=', $current_dt);
		$this->db->where($dt,$current_dt);
		// $this->db->like("b.LogDate","2021-03-03");
		$this->db->where("a.machine_id !=","");
		$this->db->group_by('a.machine_id');
        $i = 0;

        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) {
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        // return $query->result();
        $res = $query->result();
        $newArr = array();
        $newArr2 = array();
		foreach($res as $val):
			if($val->machine_id):
				$newArr[] = $val->machine_id;
			endif;
		endforeach;
		// $dt = 'DATE_FORMAT(LogDate,"%Y-%m-%d")';
		// $current_dt = date("Y-m-d");
		$this->db->select('b.contactnumber,a.machine_id,b.userfullname,b.employeeId,b.jobtitle_name,b.user_id');
		$this->db->from("emp_otherofficial_data as a");
		$this->db->join("main_employees_summary as b","a.user_id=b.user_id","LEFT");
		$this->db->where_not_in('a.machine_id', $newArr);
		$this->db->where("b.jobtitle_id !=",8);
		$this->db->where(array("b.isactive"=>"1","b.businessunit_id"=>1));
		$results = $this->db->get()->result();
		// foreach($result as $val):
			// if($val->machine_id):
				// $newArr2[] = $val->machine_id;
			// endif;
		// endforeach;
		// $NewResult=array_diff($newArr,$newArr2);
		
		return $results;
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

}
