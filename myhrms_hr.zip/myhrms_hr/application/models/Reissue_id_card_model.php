<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Reissue_id_card_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    //Get Employee Details for ID card ..
    public function GetDetailForidCardRecByID($userID) {
        $this->db->select('a.*,c.company_name');
        $this->db->from('main_employees_summary as a');
        $this->db->join('emp_otherofficial_data as b', "a.user_id=b.user_id", "LEFT");
        $this->db->join('tbl_companyname as c', "b.company_name=c.id", "LEFT");
        $this->db->where(array("a.user_id" => $userID, "a.isactive" => "1"));
        $RecRows = $this->db->get()->row();
        return ($RecRows) ? $RecRows : null;
    }
	
	//Get Details of applied ID card..
    public function GetDetailofappliedIdCard($userId) {
        $this->db->select('a.*,d.*');
        $this->db->from('hrm_reissue_idcard as a');
        // $this->db->join('emp_otherofficial_data as b', "a.approved_by=b.user_id", "LEFT");
        // $this->db->join('main_subdepartments as c', "b.sub_department=c.id", "LEFT");
        $this->db->join('main_employees_summary as d', "d.user_id=a.user_id", "LEFT");
        $this->db->where(array("a.user_id" => $userId,"a.is_active" => "1"));
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
	
	//Insert All Master
    public function InsertData($recArr, $tablename) {
        if ($recArr && $tablename):
            return $this->db->insert($tablename, $recArr);
        else:
            return false;
        endif;
    }
	
	//Update Record..
    public function update_visitingcard_rqst($table, $Where, $data) {
		if($table && $Where && $data):
			$this->db->where($Where);
			return $this->db->update($table, $data);
		else:
			return false;
		endif;
    }

}
?>