<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report_appraisalnew_model extends CI_Model {

    var $table = 'main_employees_summary as a';
    var $column_order = array(null, 'a.reporting_manager_name', 'a.userfullname');
    var $column_search = array('a.reporting_manager_name', 'a.userfullname');
    var $order = array('a.user_id' => 'asc');

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {
        // $whereSession = '09-2021';
        if ($this->input->post('session_id')) {
            $sessionYear = $this->input->post('session_id');
        }
        if ($this->input->post('rep_mngr_id')) {
            $reptManagerIdes[] = $this->input->post('rep_mngr_id');
        } else {
            $reptManagerIdes = $this->apprReportingManagerList();
        }

        $this->db->select("a.user_id,a.jobtitle_name,a.date_of_joining,a.reporting_manager,a.reporting_manager_name,a.userfullname,a.employeeId,b.current_status as bc_current_status,d.current_status as de_current_status,sal.appraisalduedate");
        $this->db->from($this->table);
        $this->db->join("main_empsalarydetails as sal", "a.user_id=sal.user_id", "LEFT");
        $this->db->join("appr_proj_formdata_bc as b", "(b.user_id=a.user_id AND b.session_appr_year='04-2024')", "LEFT");
        $this->db->join("appr_proj_formdata_de as d", "(d.user_id=a.user_id AND d.session_appr_year='04-2024')", "LEFT");
        $this->db->where_in("a.reporting_manager", $reptManagerIdes);
        $this->db->where("a.isactive", "1");
        $this->db->where("(a.jobtitle_id='9' OR a.jobtitle_id='10' OR a.jobtitle_id='11' OR a.jobtitle_id='12')", NULL, FALSE);
        // $this->db->where("sal.appraisalduedate", "September 2021");
        $this->db->like("sal.appraisalduedate", date("F",strtotime($sessionYear)),"both");

        $this->db->group_by("a.user_id");
        $this->db->order_by("a.userfullname", "ASC");

        $i = 0;

        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end();
            }
            $i++;
        }

        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    public function apprReportingManagerList() {
        $this->db->select("a.rep_manager_id");
        $this->db->from("appr_proj_assignbyhr as a");
        $this->db->where("a.status", "1");
        $this->db->group_by("a.rep_manager_id");

        $recordArr = $this->db->get()->result();

        $returnResp = array();
        if ($recordArr) {
            foreach ($recordArr as $kEy => $rOws) {
                $returnResp[] = $rOws->rep_manager_id;
            }
        }

        return ($returnResp) ? $returnResp : null;
    }

}