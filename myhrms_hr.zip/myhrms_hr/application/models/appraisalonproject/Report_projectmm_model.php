<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report_projectmm_model extends CI_Model {

    var $table = 'main_employees_summary as a';
    var $column_order = array(null, 'tm_projects.project_name');
    var $column_search = array('tm_projects.project_name');
    var $order = array('tm_projects.id' => 'asc');

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->db1 = $this->load->database('online', TRUE);
        $this->db2 = $this->load->database('default', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }

    private function _get_datatables_query() {

        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.accountinfo.project_id,$db2.tm_projects.project_name,$db2.tm_projects.id");
        $this->db->from("$db1.accountinfo");
        $this->db->join("$db2.tm_projects", "$db1.accountinfo.project_numberid=$db2.tm_projects.id", "LEFT");
        $this->db->where(array("$db1.accountinfo.status" => '1'));
        $this->db->order_by("$db2.tm_projects.project_name", "ASC");
        $this->db->group_by("$db2.tm_projects.id");


        $i = 0;

        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end();
            }
            $i++;
        }

        if (isset($_POST['order'])) {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables() {
        $this->_get_datatables_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

}
