<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attendance extends CI_Model {

    var $table = 'monthly_attendance as a';
    var $summary_table = 'main_employees_summary as s';
    private $table_name = 'monthly_attendance';
    private $table_employee_summary = 'main_employees_summary';
    var $column_order = array(null, 's.userfullname', 's.position_name', 's.department_name');
    var $column_search = array('s.userfullname', 's.position_name', 's.department_name');
    var $order = array('fld_id' => 'asc'); // default order 

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query($term = '', $repyear = '', $repmonth = '') {
        $this->db->select('a.*, s.userfullname, s.position_name, s.department_name');
        $this->db->from($this->table);
        $this->db->join($this->summary_table, 'a.emp_id = s.user_id', 'left');
      //  $this->db->where("(a.emp_id='414' OR a.emp_id='296')", NULL, FALSE);

        $this->db->where('a.is_active', '1');
        $this->db->where('s.isactive', '1');
        $this->db->where('a.year', $repyear);
        $this->db->where('a.month', $repmonth);

        $i = 0;
        foreach ($this->column_search as $item) {
            if ($_POST['search']['value']) {
                if ($i === 0) { // first loop
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($repyear, $repmonth) {
        $term = $_REQUEST['search']['value'];
        $this->_get_datatables_query($term, $repyear, $repmonth);
        // $recordArr = array();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        $Recquery = $query->result_array();
        $rowrArr = array();
        $finalresult = array();
        if ($Recquery) {
            foreach ($Recquery as $key => $rowr) {
                // $rowr['no_of_late_hd'] = $this->getno_of_lateHd($repyear, $repmonth, $rowr['emp_id']);
                array_push($finalresult, $rowr);
            }
        }
        return $finalresult;
    }

    //New Function By Asheesh..
//    public function getno_of_lateHd($repyear, $repmonth, $emp_id) {
//        $this->db->select('*');
//        $this->db->from('monthly_attendance');
//        $this->db->where(array('emp_id' => $emp_id, 'year' => $repyear, 'month' => $repmonth));
//        $recArr = $this->db->get()->row_array();
//        if ($recArr):
//            $hdNo = 0;
//            for ($i = 1; $i < 32; $i++):
//                if (($recArr[$i] != '0') and ( date('l', strtotime($repyear . "-" . $repmonth . "-" . $i)) != "Sunday")):
//                    $Record_att = str_replace("&nbsp;", "", $recArr[$i]);
//                    $Record_att = str_replace(" ", "", $Record_att);
//                    $AllRec = explode(",", $Record_att);
//                    $inampm = substr($AllRec['0'], -2);
//                    $outampm = substr($AllRec['1'], -2);
//                    $i_tm = date('h:i:s', strtotime($AllRec['0']));
//                    $o_tm = date('h:i:s', strtotime($AllRec['1']));
//                    $realintm = $i_tm . " " . $inampm;
//                    $realouttm = $o_tm . " " . $outampm;
//
//                    if ((strtotime($realintm) > strtotime('09:45:00 AM')) and ( strtotime($realintm) < strtotime('10:31:00 AM'))) {
//                        $hdNo = $hdNo + 1;
//                    }
//                    
//                endif;
//            endfor;
//        endif;
//        return ($hdNo) ? $hdNo : '0';
//    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        $this->db->where('a.is_active', '1');
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->table);
        $this->db->where('a.is_active', '1');
        return $this->db->count_all_results();
    }

    //All Tour
    public function getallTourDates($empid) {
        $this->db->select(array('start_date', 'end_date'));
        $this->db->from('emp_tourapply');
        $this->db->where(array('emp_id' => $empid, 'is_active' => '1'));
        $this->db->where('approved_bypmanager <', '2');
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? $recArr : false;
    }

    //All Emp Leave
    public function all_emp_leaves($empId) {
        $this->db->select(array('from_date', 'to_date', 'leavestatus', 'leavetypeid'));
        $this->db->from('main_leaverequest_summary');
        $this->db->where(array('user_id' => $empId, 'isactive' => '1'));
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? $recArr : false;
    }

    // //Check Is Holiday on a Particular Date..
    public function check_isholidays($actDate) {
        $this->db->select('holidayname');
        $this->db->from('main_holidaydates');
        $this->db->where(array('holidaydate' => $actDate, 'isactive' => '1', 'groupid' => '1'));
        $recArr = $this->db->get()->result_array();
        return ($recArr) ? true : false;
    }

}

?>