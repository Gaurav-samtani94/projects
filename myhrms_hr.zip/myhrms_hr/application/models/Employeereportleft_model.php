<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Employeereportleft_model extends CI_Model
{

    // var $table = 'main_users as a';
    // var $summery_table = 'main_employees_summary as b';
    // var $otherofficial_table = 'emp_otherofficial_data as g';
    // var $sal_increment_table = 'main_empsal_increment as h';
    // var $column_order = array(null, 'a.userfullname', 'b.position_name', 'b.department_name', 'b.position_name', 'b.reporting_manager_name', 'g.reviewing_officer_ro', 'b.date_of_leaving', 'h.empctc');
    // var $column_search = array('b.position_name', 'a.userfullname', 'b.department_name', 'b.position_name', 'b.reporting_manager_name', 'g.reviewing_officer_ro', 'b.date_of_leaving', 'h.empctc');
    // var $order = array('a.userfullname' => 'ASC'); // default order 

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function _get_datatables_query($bus_unit = '', $company = '', $dpt = '', $design = '', $from_date = '', $to_date = '', $emp_name = '')
    {

        $this->db->select('a.*,b.date_of_joining,b.businessunit_name,b.emp_status_name,b.position_name,b.date_of_leaving,b.reporting_manager_name,b.department_name,b.position_name,b.reporting_manager_name,g.reviewing_officer_ro,h.empctc');
        $this->db->from('main_users as a');
        $this->db->where_not_in('b.isactive', '1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
        $this->db->join("emp_otherofficial_data as g", 'a.id = g.user_id', 'left');
        $this->db->join("main_empsal_increment as h", 'a.id = h.user_id', 'left');
        if ($emp_name) {
            $this->db->like('b.userfullname', $emp_name);
        }
        if ($company) {
            $this->db->where('g.company_name', $company);
        }
        if ($bus_unit) {
            $this->db->where('b.businessunit_id', $bus_unit);
        }
        if ($dpt) {
            $this->db->where('b.department_id', $dpt);
        }
        if ($design) {
            $this->db->where('b.position_id', $design);
        }

        if ($from_date && $to_date) {
            // $this->db->where('date_of_joining >=', $from_date);
            // $this->db->where('date_of_joining <=', $to_date);
            $this->db->where('b.date_of_leaving >=', $from_date);
            $this->db->where('b.date_of_leaving <=', $to_date);
        }
        $this->db->order_by("id", "desc");
        $this->db->group_by('b.user_id');
        $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }

    public function get_left_emp_graph($st_date, $end_date)
    {

        $this->db->select('a.*');
        $this->db->from('main_users as a');
        $this->db->where_not_in('b.isactive', '1');
        $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
        $this->db->where('date_of_leaving >=', $st_date);
        $this->db->where('date_of_leaving <=', $end_date);
        $this->db->group_by('b.user_id');
        $RecRows = $this->db->count_all_results();
        // $RecRows = $this->db->num_rows();
        // $RecRows = $this->db->get()->result();
        return ($RecRows) ? $RecRows : null;
    }
}
