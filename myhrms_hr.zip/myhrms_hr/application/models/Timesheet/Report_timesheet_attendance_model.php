<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report_timesheet_attendance_model extends CI_Model {

    var $user_table = 'main_employees_summary as a';
    var $timesheets_table = 'tm_emp_timesheets as b';
    var $column_order = array(null, 'a.employeeId', 'a.userfullname', 'a.department_name');
    var $column_search = array('a.employeeId', 'a.userfullname', 'a.department_name');

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    private function _get_datatables_query() {


        if (!empty($this->input->post('unit_name'))) {
            $this->db->where('a.businessunit_id', $this->input->post('unit_name'));
        }

        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');

//        if (!empty($start_date) && !empty($end_date)) :
//            $last_date = date('Y-m-t', strtotime($end_date));
//            $this->db->where("(a.date_of_joining<=$last_date)", NULL, FALSE);
//        endif;
  if (!empty($start_date) && !empty($end_date)) :

    $this->db->where('DATE_FORMAT(a.date_of_joining,"%Y-%m")  <= "' . date('Y-m', strtotime($end_date)) . '"');
           // $this->db->where('DATE_FORMAT(a.date_of_joining,"%Y-%m")  BETWEEN "' . date('Y-m', strtotime($start_date)) . '" and "' . date('Y-m', strtotime($end_date)) . '"');

        endif;

        $this->db->select('a.position_name,a.employeeId,a.user_id,a.userfullname,a.department_name,a.date_of_joining,a.isactive');
        $this->db->from($this->user_table);
        $this->db->where('a.isactive', '1');
//$this->db->where('a.date_of_joining',$start_date);
        $this->db->where_not_in('a.jobtitle_id', '8');
        $this->db->group_by('a.user_id');
        $this->db->order_by('a.user_id');
        $i = 0;
        foreach ($this->column_search as $item) { // loop column
            if ($_POST['search']['value']) { // if datatable send POST for search
                if ($i === 0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if (count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
        if (isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($start_date, $end_date) {
        $this->_get_datatables_query($start_date, $end_date);
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);


        if (!empty($start_date) && !empty($end_date)) :

            $query = $this->db->get();
            return $query->result();
        else:
            $query = $this->db->get();
            return $query->result();
        endif;
    }

    function count_filtered() {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all() {
        $this->db->from($this->user_table);
        $this->db->where('a.isactive', '1');
        return $this->db->count_all_results();
    }

    //code for get another time
    public function getattenreport($emp_id, $start_date, $end_date) {
        //if (!empty($start_date) && !empty($end_date)) {
        $start_month = date('m', strtotime($start_date));
        $start_year = date('Y', strtotime($start_date));
        $end_month = date('m', strtotime($end_date));
        $end_year = date('Y', strtotime($end_date));
        $where_date = "((ts_month >='$start_month' AND ts_year >= '$start_year') AND ( ts_month <='$end_month' AND ts_year <= '$end_year'))";
        $this->db->select('SUM(week_duration) as total_hour');
        $this->db->from('tm_emp_timesheets');
        $this->db->where(array('emp_id' => $emp_id));
        $this->db->where($where_date);
        $resultArr = $this->db->get()->row();
        if ($resultArr) {
            return ($resultArr) ? $resultArr : "";
        }
        //}
    }

    //code for get another time
    public function getanotherattenreport($emp_id, $start_date, $end_date) {
        $start_month = date('m', strtotime($start_date));
        $start_year = date('Y', strtotime($start_date));
        $end_month = date('m', strtotime($end_date));
        $end_year = date('Y', strtotime($end_date));
        $where_date = "((month_no >='$start_month' AND Year >= '$start_year') AND ( month_no <='$end_month' AND Year <= '$end_year'))";

        $this->db->select('SUM(working_hour) as another_hour');
        $this->db->from('emp_projectanother_task_activities');
        $this->db->where(array('emp_id' => $emp_id));
        $this->db->where($where_date);
        $resultArr = $this->db->get()->row();
        if ($resultArr) {
            return ($resultArr) ? $resultArr : "";
        }
    }

}
