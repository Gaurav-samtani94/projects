import React, { useState } from "react";
import {
  Upload,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Check,
} from "lucide-react";

export default function Application() {
  const [currentStep, setCurrentStep] = useState(1);
  const [pdfPreview, setPdfPreview] = useState(null);
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",

    // Education
    // highestEducation: "",
    // university: "",
    // graduationYear: "",
    // cgpa: "",

    // Experience
    // totalExperience: "",
    // currentCompany: "",
    // Position: "",

    // Cover Letter & Resume
    coverLetter: "",
    resume: null,

    // Expected Salary
    expectedSalary: "",
    salaryNegotiable: false,

    // Terms & Conditions
    agreeTerms: false,
    agreePrivacy: false,
  });

  const [errors, setErrors] = useState({});

  const steps = [
    { id: 1, title: "Personal Information", completed: false },
    { id: 2, title: "Education", completed: false },
    { id: 3, title: "Experience", completed: false },
    { id: 4, title: "Cover Letter & Resume", completed: false },
    { id: 5, title: "Expected Salary", completed: false },
  ];

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({
      ...prev,
      resume: file,
    }));

    if (errors.resume) {
      setErrors((prev) => ({
        ...prev,
        resume: "",
      }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1:
        if (!formData.firstName)
          newErrors.firstName = "This field is required.";
        if (!formData.lastName) newErrors.lastName = "This field is required.";
        if (!formData.email) newErrors.email = "This field is required.";
        if (!formData.phone) newErrors.phone = "This field is required.";
        if (!formData.address) newErrors.address = "This field is required.";
        break;

      //   case 2:
      //     if (!formData.highestEducation)
      //       newErrors.highestEducation = "This field is required.";
      //     if (!formData.university)
      //       newErrors.university = "This field is required.";
      //     if (!formData.graduationYear)
      //       newErrors.graduationYear = "This field is required.";
      //     break;

      //   case 3:
      //     if (!formData.totalExperience)
      //       newErrors.totalExperience = "This field is required.";
      //     break;

      case 4:
        if (!formData.coverLetter)
          newErrors.coverLetter = "This field is required.";
        if (!formData.resume) newErrors.resume = "This field is required.";
        break;

      case 5:
        if (!formData.expectedSalary)
          newErrors.expectedSalary = "This field is required.";
        if (!formData.agreeTerms)
          newErrors.agreeTerms = "You must agree to the terms and conditions.";
        if (!formData.agreePrivacy)
          newErrors.agreePrivacy = "You must agree to the privacy policy.";
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const [educationList, setEducationList] = useState([
    {
      highestEducation: "",
      university: "",
      graduationYear: "",
      cgpa: "",
    },
  ]);
  const handleEducationChange = (index, e) => {
    const { name, value } = e.target;
    const updatedList = [...educationList];
    updatedList[index][name] = value;
    setEducationList(updatedList);
  };
  const handleAddEducation = () => {
    setEducationList([
      ...educationList,
      {
        highestEducation: "",
        university: "",
        graduationYear: "",
        cgpa: "",
      },
    ]);
  };

  const [experienceList, setExperienceList] = useState([
    { totalExperience: "", currentCompany: "", position: "" },
  ]);

  const handleExperienceChange = (index, e) => {
    const { name, value } = e.target;
    const updatedList = [...experienceList];
    updatedList[index][name] = value;
    setExperienceList(updatedList);
  };

  const handleAddExperience = () => {
    setExperienceList([
      ...experienceList,
      { totalExperience: "", currentCompany: "", position: "" },
    ]);
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 6));
    }
  };

  const handlePrevious = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep(6)) {
      console.log("Form submitted:", formData);
      alert("Application submitted successfully!");
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Personal Information
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  First Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.firstName ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {errors.firstName && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.firstName}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Last Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.lastName ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {errors.lastName && (
                  <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.email ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.phone ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {errors.phone && (
                  <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.address ? "border-red-500" : "border-gray-300"
                  }`}
                />
                {errors.address && (
                  <p className="text-red-500 text-sm mt-1">{errors.address}</p>
                )}
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          //   <div className="space-y-6">
          //     <h3 className="text-lg font-semibold text-gray-900 mb-4">
          //       Education
          //     </h3>

          //     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           Highest Education <span className="text-red-500">*</span>
          //         </label>
          //         <select
          //           name="highestEducation"
          //           value={formData.highestEducation}
          //           onChange={handleInputChange}
          //           className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
          //             errors.highestEducation
          //               ? "border-red-500"
          //               : "border-gray-300"
          //           }`}
          //         >
          //           <option value="">Select Education Level</option>
          //           <option value="10th">10th Grade</option>
          //           <option value="12th">12th Grade</option>
          //           <option value="diploma">Diploma</option>
          //           <option value="bachelor">Bachelor's Degree</option>
          //           <option value="master">Master's Degree</option>
          //           <option value="phd">PhD</option>
          //         </select>
          //         {errors.highestEducation && (
          //           <p className="text-red-500 text-sm mt-1">
          //             {errors.highestEducation}
          //           </p>
          //         )}
          //       </div>

          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           University/College <span className="text-red-500">*</span>
          //         </label>
          //         <input
          //           type="text"
          //           name="university"
          //           value={formData.university}
          //           onChange={handleInputChange}
          //           className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
          //             errors.university ? "border-red-500" : "border-gray-300"
          //           }`}
          //         />
          //         {errors.university && (
          //           <p className="text-red-500 text-sm mt-1">
          //             {errors.university}
          //           </p>
          //         )}
          //       </div>

          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           Graduation Year <span className="text-red-500">*</span>
          //         </label>
          //         <input
          //           type="number"
          //           name="graduationYear"
          //           value={formData.graduationYear}
          //           onChange={handleInputChange}
          //           min="1990"
          //           max="2030"
          //           className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
          //             errors.graduationYear ? "border-red-500" : "border-gray-300"
          //           }`}
          //         />
          //         {errors.graduationYear && (
          //           <p className="text-red-500 text-sm mt-1">
          //             {errors.graduationYear}
          //           </p>
          //         )}
          //       </div>

          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           CGPA/Percentage
          //         </label>
          //         <input
          //           type="text"
          //           name="cgpa"
          //           value={formData.cgpa}
          //           onChange={handleInputChange}
          //           className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          //         />
          //       </div>
          //     </div>
          //   </div>
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Education
            </h3>

            {educationList.map((edu, index) => (
              <div
                key={index}
                className="grid grid-cols-1 md:grid-cols-2 gap-6 border p-4 rounded-md shadow-sm bg-white"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Highest Education <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="highestEducation"
                    value={edu.highestEducation}
                    onChange={(e) => handleEducationChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Education Level</option>
                    <option value="10th">10th Grade</option>
                    <option value="12th">12th Grade</option>
                    <option value="diploma">Diploma</option>
                    <option value="bachelor">Bachelor's Degree</option>
                    <option value="master">Master's Degree</option>
                    <option value="phd">PhD</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    University/College <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="university"
                    value={edu.university}
                    onChange={(e) => handleEducationChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Graduation Year <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    name="graduationYear"
                    min="1990"
                    max="2030"
                    value={edu.graduationYear}
                    onChange={(e) => handleEducationChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    CGPA/Percentage
                  </label>
                  <input
                    type="text"
                    name="cgpa"
                    value={edu.cgpa}
                    onChange={(e) => handleEducationChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            ))}

            {/* Add Button */}
            <button
              type="button"
              onClick={handleAddEducation}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 4v16m8-8H4"
                />
              </svg>
              Add Education
            </button>
          </div>
        );

      case 3:
        return (
          //   <div className="space-y-6">
          //     <h3 className="text-lg font-semibold text-gray-900 mb-4">
          //       Experience
          //     </h3>

          //     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           Total Experience <span className="text-red-500">*</span>
          //         </label>
          //         <select
          //           name="totalExperience"
          //           value={formData.totalExperience}
          //           onChange={handleInputChange}
          //           className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
          //             errors.totalExperience
          //               ? "border-red-500"
          //               : "border-gray-300"
          //           }`}
          //         >
          //           <option value="">Select Experience</option>
          //           <option value="fresher">Fresher</option>
          //           <option value="0-1">0-1 Years</option>
          //           <option value="1-3">1-3 Years</option>
          //           <option value="3-5">3-5 Years</option>
          //           <option value="5-10">5-10 Years</option>
          //           <option value="10+">10+ Years</option>
          //         </select>
          //         {errors.totalExperience && (
          //           <p className="text-red-500 text-sm mt-1">
          //             {errors.totalExperience}
          //           </p>
          //         )}
          //       </div>

          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           Current Company
          //         </label>
          //         <input
          //           type="text"
          //           name="currentCompany"
          //           value={formData.currentCompany}
          //           onChange={handleInputChange}
          //           className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          //         />
          //       </div>

          //       <div>
          //         <label className="block text-sm font-medium text-gray-700 mb-2">
          //           Position
          //         </label>
          //         <input
          //           type="text"
          //           name="Position"
          //           value={formData.Position}
          //           onChange={handleInputChange}
          //           className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          //         />
          //       </div>
          //     </div>
          //   </div>

          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Experience
            </h3>

            {experienceList.map((exp, index) => (
              <div
                key={index}
                className="grid grid-cols-1 md:grid-cols-2 gap-6 border p-4 rounded-md shadow-sm bg-white"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Total Experience <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="totalExperience"
                    value={exp.totalExperience}
                    onChange={(e) => handleExperienceChange(index, e)}
                    className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
                  >
                    <option value="">Select Experience</option>
                    <option value="fresher">Fresher</option>
                    <option value="0-1">0-1 Years</option>
                    <option value="1-3">1-3 Years</option>
                    <option value="3-5">3-5 Years</option>
                    <option value="5-10">5-10 Years</option>
                    <option value="10+">10+ Years</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Company
                  </label>
                  <input
                    type="text"
                    name="currentCompany"
                    value={exp.currentCompany}
                    onChange={(e) => handleExperienceChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Position
                  </label>
                  <input
                    type="text"
                    name="position"
                    value={exp.position}
                    onChange={(e) => handleExperienceChange(index, e)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            ))}

            {/* Add Experience Button */}
            <button
              type="button"
              onClick={handleAddExperience}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 4v16m8-8H4"
                />
              </svg>
              Add Experience
            </button>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Cover Letter & Resume
            </h3>

            {/* Cover Letter Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cover Letter <span className="text-red-500">*</span>
              </label>
              <textarea
                name="coverLetter"
                value={formData.coverLetter}
                onChange={handleInputChange}
                rows={6}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.coverLetter ? "border-red-500" : "border-gray-300"
                }`}
                placeholder="Write your cover letter here..."
              />
              {errors.coverLetter && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.coverLetter}
                </p>
              )}
            </div>

            {/* Resume Upload Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Resume <span className="text-red-500">*</span>
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="file"
                  id="resume"
                  name="resume"
                  onChange={(e) => {
                    handleFileChange(e);
                    const file = e.target.files[0];
                    if (file && file.type === "application/pdf") {
                      const fileURL = URL.createObjectURL(file);
                      setPdfPreview(fileURL); // <-- Add this state below
                    } else {
                      setPdfPreview(null);
                    }
                  }}
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                />
                <label
                  htmlFor="resume"
                  className={`cursor-pointer px-4 py-2 border rounded-md hover:bg-gray-50 transition-colors ${
                    errors.resume ? "border-red-500" : "border-gray-300"
                  }`}
                >
                  <Upload size={16} className="inline mr-2" />
                  Choose File
                </label>
                <span className="text-gray-500 text-sm">
                  {formData.resume ? formData.resume.name : "No file chosen"}
                </span>
              </div>
              {errors.resume && (
                <p className="text-red-500 text-sm mt-1">{errors.resume}</p>
              )}
            </div>

            {/* PDF Preview Section */}
            {pdfPreview && (
              <div className="mt-4 border border-gray-300 rounded-md overflow-hidden">
                <iframe
                  src={pdfPreview}
                  title="PDF Preview"
                  className="w-full h-[700px]"
                ></iframe>
              </div>
            )}
          </div>
        );

      case 5:
        return (
          <div>
            <div className="py-10 space-y-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Expected Salary
              </h3>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expected Salary (₹ per annum){" "}
                  <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="expectedSalary"
                  value={formData.expectedSalary}
                  onChange={handleInputChange}
                  className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.expectedSalary ? "border-red-500" : "border-gray-300"
                  }`}
                  placeholder="e.g., 500000"
                />
                {errors.expectedSalary && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.expectedSalary}
                  </p>
                )}
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="salaryNegotiable"
                  name="salaryNegotiable"
                  checked={formData.salaryNegotiable}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label
                  htmlFor="salaryNegotiable"
                  className="ml-2 block text-sm text-gray-900"
                >
                  Salary is negotiable
                </label>
              </div>
            </div>
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Terms & Conditions
              </h3>

              <div className="space-y-4">
                <div className="flex items-start">
                  <input
                    type="checkbox"
                    id="agreeTerms"
                    name="agreeTerms"
                    checked={formData.agreeTerms}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mt-1"
                  />
                  <label
                    htmlFor="agreeTerms"
                    className="ml-2 block text-sm text-gray-900"
                  >
                    I agree to the{" "}
                    <a href="#" className="text-blue-600 hover:text-blue-700">
                      Terms and Conditions
                    </a>{" "}
                    <span className="text-red-500">*</span>
                  </label>
                </div>
                {errors.agreeTerms && (
                  <p className="text-red-500 text-sm">{errors.agreeTerms}</p>
                )}

                <div className="flex items-start">
                  <input
                    type="checkbox"
                    id="agreePrivacy"
                    name="agreePrivacy"
                    checked={formData.agreePrivacy}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mt-1"
                  />
                  <label
                    htmlFor="agreePrivacy"
                    className="ml-2 block text-sm text-gray-900"
                  >
                    I agree to the{" "}
                    <a href="#" className="text-blue-600 hover:text-blue-700">
                      Privacy Policy
                    </a>{" "}
                    <span className="text-red-500">*</span>
                  </label>
                </div>
                {errors.agreePrivacy && (
                  <p className="text-red-500 text-sm">{errors.agreePrivacy}</p>
                )}

                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="text-sm text-gray-700">
                    By submitting this application, you confirm that all
                    information provided is accurate and complete. You also
                    authorize us to verify the information and contact your
                    references.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">
              Job Application
            </h1>
            <button className="flex items-center gap-2 text-blue-600 hover:text-blue-700 text-sm">
              <ExternalLink size={16} />
              Apply with Indeed
            </button>
          </div>

          <div className="mb-8">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium ${
                      currentStep > step.id
                        ? "bg-green-500 text-white"
                        : currentStep === step.id
                        ? "bg-blue-500 text-white"
                        : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {currentStep > step.id ? <Check size={16} /> : step.id}
                  </div>
                  <span
                    className={`ml-2 text-sm ${
                      currentStep >= step.id ? "text-gray-900" : "text-gray-500"
                    }`}
                  >
                    {step.title}
                  </span>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-12 h-0.5 mx-4 ${
                        currentStep > step.id ? "bg-green-500" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {Object.keys(errors).length > 0 && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-700 text-sm">
                Please correct the errors below to continue.
              </p>
            </div>
          )}

          <div>
            {renderStepContent()}

            <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
              <button
                type="button"
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium ${
                  currentStep === 1
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                    : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                }`}
              >
                <ChevronLeft size={16} className="mr-1" />
                Previous
              </button>

              {currentStep < 6 ? (
                <button
                  type="button"
                  onClick={handleNext}
                  className="flex items-center px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm font-medium"
                >
                  Next
                  <ChevronRight size={16} className="ml-1" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm font-medium"
                >
                  Submit Application
                </button>
              )}
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-500">
              Powered by{" "}
              <a href="#" className="text-blue-600 hover:text-blue-700">
                Application System
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
