import React, { useState } from "react";
import { Upload } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function JobApplication() {
  const [formData, setFormData] = useState({
    resume: null,
  });
  const navigate = useNavigate();
  const handleApplyClick = () => {
    navigate("/applyform");
  };
  const [errors, setErrors] = useState({});

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({
      ...prev,
      resume: file,
    }));

    if (errors.resume) {
      setErrors((prev) => ({
        ...prev,
        resume: "",
      }));
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gray-50 py-8 px-4">
        <div className="max-w-7xl mx-auto  rounded-lg shadow-sm p-8">
          <div className="py-10 flex xl:flex-row flex-col gap-8 xl:gap-10 2xl:gap-16 text-[#3f3f3f]">
            <div className="flex flex-col gap-10 lg:w-1/2 grow w-full">
              <div className="">
                <div className="w-full mx-auto p-4">
                  <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200 p-6">
                    <div className="flex flex-col gap-4">
                      <h6 className="text-lg md:text-xl xl:text-2xl 2xl:text-3xl text-primaryColor font-bold font-satoshi">
                        Job Title:
                      </h6>
                      <p className="text-sm md:text-base lg:text-[15px] xl:text-lg 2xl:text-xl text-gray-700 leading-relaxed">
                        Project Manager - Depot & Buildings - K1
                      </p>
                    </div>
                  </div>
                </div>
                <div className="w-full mx-auto p-4">
                  <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200 p-6">
                    <div className="flex flex-col gap-4">
                      <h6 className="text-lg md:text-xl xl:text-2xl 2xl:text-3xl text-primaryColor font-bold font-satoshi">
                        Job Description:
                      </h6>
                      <p className="text-sm md:text-base lg:text-[15px] xl:text-lg 2xl:text-xl text-gray-700 leading-relaxed">
                        Responsible for planning, civil & system design
                        interface management, construction & contract
                        management, progress review of Civil, finishing and MEP
                        works of design & built contract of Metro Depot cum
                        Workshop infrastructures. Responsible for review of
                        detailed technical requirement and drawings for all
                        buildings, workshops and major pieces of equipment to be
                        installed within the depot to ensure that the design of
                        the depots and their associated facilities meets the
                        contractual and maintenance requirements.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="w-full mx-auto p-4">
                  <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200 p-6">
                    <div className="flex flex-col gap-4">
                      <h6 className="text-lg md:text-xl xl:text-2xl 2xl:text-3xl text-primaryColor font-bold font-satoshi">
                        Requirements:
                      </h6>
                      <ul className="text-sm md:text-base lg:text-[15px] xl:text-lg 2xl:text-xl text-gray-700 leading-relaxed">
                        A Bachelor’s degree in Mechanical Engineering and 15+
                        years of qualifying engineering experience in the
                        Wastewater Treatment engineering design or allied field
                        developing detailed process mechanical designs; OR", "An
                        Associate’s Degree or technical school certification in
                        civil or mechanical technology, technical drafting, or
                        other relevant technical curriculum and 20+ years of
                        qualifying engineering experience working in the
                        Wastewater Treatment engineering or allied design field
                        developing detailed process mechanical designs.",
                        "Equivalent education and experience in allied fields
                        will be considered.", "Currently active Professional
                        Engineer (PE) License.
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="w-full mx-auto p-4">
                  <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200 p-6">
                    <div className="flex flex-col gap-4">
                      <h6 className="text-lg md:text-xl xl:text-2xl 2xl:text-3xl text-primaryColor font-bold font-satoshi">
                        Job Responsibilities:
                      </h6>
                      <ul className="text-sm md:text-base lg:text-[15px] xl:text-lg 2xl:text-xl text-gray-700 leading-relaxed">
                        Ability to serve as the design discipline process
                        mechanical lead on large Groundwater or Wastewater
                        treatment projects.", "Developing process mechanical
                        designs to render functional and constructable contract
                        documents is essential.", "Experience to generate
                        three-dimensional models in AutoCAD Plant 3D and/or
                        Revit MEP and develop plans, elevations, details,
                        sections, etc. is a plus", "Ability to develop Piping
                        and Instrumentation Drawings (P&IDs), Process Flow
                        Diagrams, mass/flow/energy balances, equipment and
                        piping layouts as required for rendering a complete
                        design.", "Experience in developing Intergraph Caesar II
                        Pipe Stress analysis software is a plus.", "Ability to
                        develop and modify technical specifications for project
                        requirements and develop equipment data sheets",
                        "Experience with Hydraulic Modeling Software (PIPE-FLO,
                        DESIGNET, or similar) is a plus.", "Experience with
                        commissioning, and long-term operation requirements of
                        groundwater and industrial wastewater treatment plants
                        are a plus.", "Ability to develop piping isometrics at
                        industrial sites, by hand.", "Established technical
                        writing skills including development of Basis of Design
                        reports, process control narratives, technical
                        specifications and other technical documents.", "Ability
                        to function as a mechanical process lead, or technical
                        lead on large, multi-discipline projects.
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="w-full mx-auto p-4">
                <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200 p-6">
                  <div className="flex items-center justify-normal gap-40">
                    <div className="flex items-center">
                      <h6 className="p-4 text-base md:text-lg xl:text-xl 2xl:text-2xl text-primaryColor font-bold font-satoshi">
                        Upload CV:
                      </h6>
                      <input
                        type="file"
                        id="resume"
                        name="resume"
                        onChange={handleFileChange}
                        accept=".pdf,.doc,.docx"
                        className="hidden"
                      />
                      <label
                        htmlFor="resume"
                        className={`cursor-pointer px-4 py-2 border rounded-md hover:bg-gray-50 transition-colors ${
                          errors.resume ? "border-red-500" : "border-gray-300"
                        }`}
                      >
                        <Upload size={16} className="inline mr-2" />
                        Choose File
                      </label>
                      <span className="text-gray-500 text-sm">
                        {formData.resume
                          ? formData.resume.name
                          : "No file chosen"}
                      </span>
                    </div>

                    <div className="">
                      <button
                        type="button"
                        onClick={handleApplyClick}
                        className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors font-medium"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
