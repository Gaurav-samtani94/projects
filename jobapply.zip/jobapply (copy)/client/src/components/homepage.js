import React, { useState } from "react";
import {
  User,
  Mail,
  GraduationCap,
  Briefcase,
  Plus,
  Edit2,
  Save,
  X,
} from "lucide-react";
import Header from "../components/header";
import Resume from "../components/resume";

const UserProfilePage = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState("personal");
  const [profile, setProfile] = useState({
    personal: {
      firstName: "Shyam",
      lastName: "Singh",
      email: "shyam.singh@gmail.com",
      phone: "+1 (555) 123-4567",
      location: "San Francisco, CA",
      dateOfBirth: "1990-05-15",
      linkedin: "linkedin.com/in/shyamsingh",
      website: "shyam.singh",
      summary:
        "Experienced software developer with 5+ years in full-stack development. Passionate about creating scalable solutions and leading technical teams.",
    },
    education: [
      {
        id: 1,
        degree: "Bachelor of Science in Computer Science",
        institution: "Stanford University",
        location: "Stanford, CA",
        startDate: "2010-09",
        endDate: "2014-05",
        gpa: "3.8/4.0",
      },
      {
        id: 2,
        degree: "Master of Science in Software Engineering",
        institution: "UC Berkeley",
        location: "Berkeley, CA",
        startDate: "2014-08",
        endDate: "2016-05",
        gpa: "3.9/4.0",
      },
    ],
    experience: [
      {
        id: 1,
        title: "Senior Software Engineer",
        company: "Tech Solutions Inc.",
        location: "San Francisco, CA",
        startDate: "2020-03",
        endDate: "Present",
        description:
          "Lead a team of 5 developers in building scalable web applications. Implemented microservices architecture resulting in 40% performance improvement.",
      },
      {
        id: 2,
        title: "Software Engineer",
        company: "StartupXYZ",
        location: "Palo Alto, CA",
        startDate: "2017-06",
        endDate: "2020-02",
        description:
          "Developed full-stack applications using React and Node.js. Built REST APIs serving 100k+ daily active users.",
      },
      {
        id: 3,
        title: "Junior Developer",
        company: "WebDev Agency",
        location: "San Jose, CA",
        startDate: "2016-06",
        endDate: "2017-05",
        description:
          "Created responsive websites and mobile applications for various clients. Gained experience in multiple programming languages and frameworks.",
      },
    ],
  });

  const handlePersonalChange = (field, value) => {
    setProfile((prev) => ({
      ...prev,
      personal: {
        ...prev.personal,
        [field]: value,
      },
    }));
  };

  const addEducation = () => {
    const newEducation = {
      id: Date.now(),
      degree: "",
      institution: "",
      location: "",
      startDate: "",
      endDate: "",
      gpa: "",
    };
    setProfile((prev) => ({
      ...prev,
      education: [...prev.education, newEducation],
    }));
  };

  const updateEducation = (id, field, value) => {
    setProfile((prev) => ({
      ...prev,
      education: prev.education.map((edu) =>
        edu.id === id ? { ...edu, [field]: value } : edu
      ),
    }));
  };

  const removeEducation = (id) => {
    setProfile((prev) => ({
      ...prev,
      education: prev.education.filter((edu) => edu.id !== id),
    }));
  };

  const addExperience = () => {
    const newExperience = {
      id: Date.now(),
      title: "",
      company: "",
      location: "",
      startDate: "",
      endDate: "",
      description: "",
    };
    setProfile((prev) => ({
      ...prev,
      experience: [...prev.experience, newExperience],
    }));
  };

  const updateExperience = (id, field, value) => {
    setProfile((prev) => ({
      ...prev,
      experience: prev.experience.map((exp) =>
        exp.id === id ? { ...exp, [field]: value } : exp
      ),
    }));
  };

  const removeExperience = (id) => {
    setProfile((prev) => ({
      ...prev,
      experience: prev.experience.filter((exp) => exp.id !== id),
    }));
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="w-full mx-auto px-4 mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left side - User profile (2/3 width) */}
          <div className="md:col-span-2 overflow-y-auto h-[900px] scrollbar-hide">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                    {profile.personal.firstName[0]}
                    {profile.personal.lastName[0]}
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900">
                      {profile.personal.firstName} {profile.personal.lastName}
                    </h1>
                    <p className="text-gray-600 flex items-center mt-1">
                      <Mail className="w-4 h-4 mr-2" />
                      {profile.personal.email}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    isEditing
                      ? "bg-green-500 hover:bg-green-600 text-white"
                      : "bg-blue-500 hover:bg-blue-600 text-white"
                  }`}
                >
                  {isEditing ? (
                    <>
                      <Save className="w-4 h-4" />
                      <span>Save Profile</span>
                    </>
                  ) : (
                    <>
                      <Edit2 className="w-4 h-4" />
                      <span>Edit Profile</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="flex space-x-4 border-b mb-6">
              {["personal", "education", "experience"].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 font-medium ${
                    activeTab === tab
                      ? "border-b-2 border-blue-600 text-blue-600"
                      : "text-gray-600 hover:text-blue-500"
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>
            {activeTab === "personal" && (
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                {/* Personal Information */}
                <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Personal Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        value={profile.personal.firstName}
                        onChange={(e) =>
                          handlePersonalChange("firstName", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value={profile.personal.lastName}
                        onChange={(e) =>
                          handlePersonalChange("lastName", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        value={profile.personal.email}
                        onChange={(e) =>
                          handlePersonalChange("email", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Phone
                      </label>
                      <input
                        type="tel"
                        value={profile.personal.phone}
                        onChange={(e) =>
                          handlePersonalChange("phone", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Location
                      </label>
                      <input
                        type="text"
                        value={profile.personal.location}
                        onChange={(e) =>
                          handlePersonalChange("location", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Date of Birth
                      </label>
                      <input
                        type="date"
                        value={profile.personal.dateOfBirth}
                        onChange={(e) =>
                          handlePersonalChange("dateOfBirth", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        LinkedIn
                      </label>
                      <input
                        type="text"
                        value={profile.personal.linkedin}
                        onChange={(e) =>
                          handlePersonalChange("linkedin", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Website
                      </label>
                      <input
                        type="text"
                        value={profile.personal.website}
                        onChange={(e) =>
                          handlePersonalChange("website", e.target.value)
                        }
                        disabled={!isEditing}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Professional Summary
                    </label>
                    <textarea
                      value={profile.personal.summary}
                      onChange={(e) =>
                        handlePersonalChange("summary", e.target.value)
                      }
                      disabled={!isEditing}
                      rows={4}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === "education" && (
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                {/* Education Section */}
                <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                      <GraduationCap className="w-5 h-5 mr-2" />
                      Education
                    </h2>
                    {isEditing && (
                      <button
                        onClick={addEducation}
                        className="flex items-center space-x-1 text-blue-500 hover:text-blue-700"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Education</span>
                      </button>
                    )}
                  </div>
                  <div className="space-y-4">
                    {profile.education.map((edu) => (
                      <div
                        key={edu.id}
                        className="border border-gray-300 rounded-lg p-4 relative"
                      >
                        {isEditing && (
                          <button
                            onClick={() => removeEducation(edu.id)}
                            className="absolute top-2 right-2 text-red-500 hover:text-red-700"
                            title="Remove Education"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <input
                            type="text"
                            placeholder="Degree"
                            value={edu.degree}
                            onChange={(e) =>
                              updateEducation(edu.id, "degree", e.target.value)
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="text"
                            placeholder="Institution"
                            value={edu.institution}
                            onChange={(e) =>
                              updateEducation(
                                edu.id,
                                "institution",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="text"
                            placeholder="Location"
                            value={edu.location}
                            onChange={(e) =>
                              updateEducation(
                                edu.id,
                                "location",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="month"
                            placeholder="Start Date"
                            value={edu.startDate}
                            onChange={(e) =>
                              updateEducation(
                                edu.id,
                                "startDate",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="month"
                            placeholder="End Date"
                            value={edu.endDate}
                            onChange={(e) =>
                              updateEducation(edu.id, "endDate", e.target.value)
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="text"
                            placeholder="GPA"
                            value={edu.gpa}
                            onChange={(e) =>
                              updateEducation(edu.id, "gpa", e.target.value)
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "experience" && (
              <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                {/* Experience Section*/}
                <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                      <Briefcase className="w-5 h-5 mr-2" />
                      Work Experience
                    </h2>
                    {isEditing && (
                      <button
                        onClick={addExperience}
                        className="flex items-center space-x-1 text-blue-500 hover:text-blue-700"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Experience</span>
                      </button>
                    )}
                  </div>
                  <div className="space-y-4">
                    {profile.experience.map((exp) => (
                      <div
                        key={exp.id}
                        className="border border-gray-300 rounded-lg p-4 relative"
                      >
                        {isEditing && (
                          <button
                            onClick={() => removeExperience(exp.id)}
                            className="absolute top-2 right-2 text-red-500 hover:text-red-700"
                            title="Remove Experience"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <input
                            type="text"
                            placeholder="Job Title"
                            value={exp.title}
                            onChange={(e) =>
                              updateExperience(exp.id, "title", e.target.value)
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="text"
                            placeholder="Company"
                            value={exp.company}
                            onChange={(e) =>
                              updateExperience(
                                exp.id,
                                "company",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="text"
                            placeholder="Location"
                            value={exp.location}
                            onChange={(e) =>
                              updateExperience(
                                exp.id,
                                "location",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="month"
                            placeholder="Start Date"
                            value={exp.startDate}
                            onChange={(e) =>
                              updateExperience(
                                exp.id,
                                "startDate",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <input
                            type="month"
                            placeholder="End Date"
                            value={exp.endDate}
                            onChange={(e) =>
                              updateExperience(
                                exp.id,
                                "endDate",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded"
                          />
                          <textarea
                            placeholder="Description"
                            value={exp.description}
                            onChange={(e) =>
                              updateExperience(
                                exp.id,
                                "description",
                                e.target.value
                              )
                            }
                            disabled={!isEditing}
                            className="p-2 border border-gray-300 rounded col-span-2"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right side - Resume Upload & Preview (1/3 width) */}
          <div className="bg-white rounded-lg shadow-sm p-6 md:col-span-1">
            <Resume />
          </div>
        </div>
      </div>
    </>
  );
};

export default UserProfilePage;
