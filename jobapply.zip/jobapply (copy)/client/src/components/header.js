import React, { useEffect, useState } from 'react';
import { LogOut} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState('');
  const [id, setId] = useState('');

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      const { role, id } = JSON.parse(userData);
      setRole(role);
      setId(id);
    }
  }, []);

  const handleProfileClick = (e) => {
    e.preventDefault();
    navigate(`/profile/${id}`);
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
  };

  return (
    <header className="fixed top-0 w-full z-50 px-8 md:px-20 py-4 bg-white/70 backdrop-blur-md shadow-sm">
      <div className="flex justify-between items-center">
        {/* Logo */}
        <a
          href="/"
          className="text-2xl font-extrabold bg-gradient-to-r from-blue-500 to-blue-900 text-transparent bg-clip-text"
        >
          JobGrid
        </a>

        {/* Right-side Controls */}
        <div className="flex items-center gap-4">

          <button
            onClick={handleLogout}
            className="w-9 h-9 rounded-full bg-blue-50 hover:bg-blue-100 flex items-center justify-center"
          >
            <LogOut className="text-blue-700" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
