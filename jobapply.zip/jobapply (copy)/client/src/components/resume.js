import React, { useState } from 'react';
import { Upload } from 'lucide-react';

const UserProfilePage = () => {
  const [formData, setFormData] = useState({
    resume: null,   
  });

  const [pdfPreview, setPdfPreview] = useState(null);
  const [errors, setErrors] = useState({}); 

  const handleFileChange = (e) => {
    const file = e.target.files[0];

    setErrors(prev => ({ ...prev, resume: null }));

    if (!file) {
      setFormData(prev => ({ ...prev, resume: null }));
      setPdfPreview(null);
      return;
    }

    const validTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    if (!validTypes.includes(file.type)) {
      setErrors(prev => ({ ...prev, resume: 'Only PDF or Word documents are allowed.' }));
      setFormData(prev => ({ ...prev, resume: null }));
      setPdfPreview(null);
      return;
    }

    setFormData(prev => ({ ...prev, resume: file }));

    if (file.type === 'application/pdf') {
      const fileURL = URL.createObjectURL(file);
      setPdfPreview(fileURL);
    } else {
      setPdfPreview(null); 
    }
  };

  return (
    <div>
      {/* Resume Upload Field */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Resume <span className="text-red-500">*</span>
        </label>
        <div className="flex items-center gap-4">
          <input
            type="file"
            id="resume"
            name="resume"
            onChange={handleFileChange}
            accept=".pdf,.doc,.docx"
            className="hidden"
          />
          <label
            htmlFor="resume"
            className={`cursor-pointer px-4 py-2 border rounded-md hover:bg-gray-50 transition-colors ${
              errors.resume ? 'border-red-500' : 'border-gray-300'
            }`}
          >
            <Upload size={16} className="inline mr-2" />
            Choose File
          </label>
          <span className="text-gray-500 text-sm">
            {formData.resume ? formData.resume.name : 'No file chosen'}
          </span>
        </div>
        {errors.resume && (
          <p className="text-red-500 text-sm mt-1">{errors.resume}</p>
        )}
      </div>

      {/* PDF Preview Section */}
      {pdfPreview && (
        <div className="mt-4 border border-gray-300 rounded-md overflow-hidden">
          <iframe
            src={pdfPreview}
            title="PDF Preview"
            className="w-full h-[800px]"
          ></iframe>
        </div>
      )}
    </div>
  );
};

export default UserProfilePage;
