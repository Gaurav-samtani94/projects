import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import DetailPage from "./components/jobdetail";
import ApplyForm from "./components/applyform";
import LoginForm from "./components/loginPage";
import HomePage from "./components/homepage";

function App() {
  return (
    <Router>
      <Routes>
        <Route>
          <Route path="/loginPage" element={<LoginForm />} />
          <Route path="/" element={<DetailPage />} />
          <Route path="/applyform" element={<ApplyForm />} />
          <Route path="/dashboard" element={<HomePage />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
