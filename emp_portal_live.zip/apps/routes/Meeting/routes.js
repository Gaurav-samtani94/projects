const express = require('express');
const MeetingRoute = express.Router();
const MeetingController = require('../../controllers/CustomMeeting/CustomMetting');
const { protect } = require("../../middleware/authMiddleware");


MeetingRoute.post('/custom',protect,  MeetingController.CreateCustomMeeting);
MeetingRoute.get('/join/:meeting_url',protect, MeetingController.JoinMeeting);
MeetingRoute.get('/costom-meeting-list',protect, MeetingController.ListCustomMeetings);
MeetingRoute.post('/meeting-details',protect,MeetingController.MeetingDetails);
MeetingRoute.post('/update-meeting',protect,MeetingController.UpdateMeeting);
MeetingRoute.post('/attachments-delete',protect, MeetingController.DeleteAttachment);
MeetingRoute.post('/meeting-attachment',protect,MeetingController.GetAttachments);
MeetingRoute.post('/add-meeting-attachment',protect,MeetingController.addAttatchment);
MeetingRoute.post('/join-public/:meeting_url', MeetingController.PublicJoinMeeting);


module.exports = MeetingRoute;

