// File Created Code by Prajwal Date:- 26-03-2025 //
const express = require('express');
const Router = express.Router();
const { protect } = require('../../middleware/authMiddleware');
const { LeaveList, applyLeave, EditapplyLeave, LeaveAprvReje, MyteamList, DeleteLeave, HolidayList, getAllLeaveRequests, manageLeave } = require('../../controllers/Hrms/LeaveController');
const UserController = require('../../controllers/Hrms/UserController');
const { TourList, TourAnnouncementList, ApplyTour, EditApplyTour, DeleteApplyTour, ProjectList } = require('../../controllers/Hrms/TourController');
const { changePassword } = require('../../controllers/tracker/user/userController');


// tapesh route start
Router.get('/user-other-detail', protect, UserController.UserOtherDetails);
Router.get('/user-salary-detail', protect, UserController.UserSalaryDetails);
Router.get('/user-personal-detail', protect, UserController.UserPersonalInformation);
Router.get('/user-contact-detail', protect, UserController.UserCommunicationInformation);
Router.get('/user-skill-list', protect, UserController.UserSkillList);
Router.get('/user-job-history-list', protect, UserController.UserHrmsEmpJobList);
Router.get('/user-form-number-list', protect, UserController.UserFormNumberList);
Router.post('/user-attendance-list', protect, UserController.UserAttendanceDetail);
Router.post('/User-pay-slip-list', protect, UserController.UserPaySlipList);
Router.post('/User-change-password', protect, changePassword);
Router.get('/User-team-list', protect, UserController.userTeamList);
Router.post('/User-daily-attendances', UserController.userDailyAttendances);
Router.post('/forgot-Password', UserController.forgotPassword);
Router.get('/reset-passwords/:token', UserController.resetPasswords);
Router.post('/reset-password', UserController.resetPassword);




Router.get('/get-leave-requests', protect, getAllLeaveRequests)
Router.post('/manage-leave', protect, manageLeave)

// tapesh route end

// Route of HRMS/Leave // code by prajwal date- 28-03-2025 //
Router.get('/apply-leave-list', protect, LeaveList);
Router.post('/apply-leave', protect, applyLeave);
Router.post('/apply-leave-edit', protect, EditapplyLeave);
Router.post('/leave-aprv-rej', protect, LeaveAprvReje);
Router.get('/my-team-list', protect, MyteamList);
Router.delete('/apply-leave-dlt', protect, DeleteLeave);
Router.post('/holiday-list', protect, HolidayList);
Router.get('/tour-list', protect, TourList);
Router.get('/tour-announce-list', protect, TourAnnouncementList);
Router.post('/apply-tour', protect, ApplyTour);
Router.post('/edit-apply-tour', protect, EditApplyTour);
Router.delete('/dlt-apply-tour', protect, DeleteApplyTour);
Router.get('/project-list', protect, ProjectList);
module.exports = Router;