const express  = require('express');
const LiveKitRoute = express()
const LiveKitController = require('../../controllers/LiveKit/livekit');
LiveKitRoute.post('/create-room-chat',LiveKitController.createChatAndRoom);
LiveKitRoute.post('/generate-token',LiveKitController.GenerateToken);
LiveKitRoute.post("/group-room-create",LiveKitController.GroupRoomCreate)
module.exports = LiveKitRoute;