const express = require('express');
const ProjectRouter = express.Router();
const pmtController = require('../../controllers/Project_management/ProjectManagementController');
const checkPermission = require('../../middleware/checkPermission');
const { protect } = require('../../middleware/authMiddleware');





ProjectRouter.post('/create-project', pmtController.CreateProject);
ProjectRouter.get('/all-custom-fields', pmtController.customFieldList);
ProjectRouter.get('/project-list', pmtController.ProjectList);
ProjectRouter.put('/update-project', pmtController.updateProject);
ProjectRouter.put('/update-project-members', pmtController.updateProjectMembers);
ProjectRouter.post('/add-custom-field', pmtController.createCustomFieldOnProject);
ProjectRouter.post('/custom-field-options', pmtController.customFieldOptionList);
ProjectRouter.post('/delete-custom-field-option', pmtController.deleteCustomFieldOptions);
ProjectRouter.post('/custom-field-project-wise', pmtController.customFieldListByProject);
ProjectRouter.post('/add-custom-field-option', pmtController.addCustomFieldOption);
ProjectRouter.post('/update-custom-field-option', pmtController.updateCustomFieldOptions);
ProjectRouter.put('/delete-custom-field', pmtController.deleteCustomFieldOnProject);
ProjectRouter.put('/update-project-field', pmtController.updateColumnOnProject);
ProjectRouter.post('/delete-project', pmtController.deleteProject);
ProjectRouter.post('/update-option-order', pmtController.updateOptionsSerial);
ProjectRouter.get('/project-list-inprogress', pmtController.inProgressProjectList);
ProjectRouter.post('/task-time-track', pmtController.taskTrackTime);
ProjectRouter.get('/task-track-list', pmtController.taskTimeList);
ProjectRouter.post('/delete-project-attachment', pmtController.deleteAttachmentOnProject);
ProjectRouter.post('/update-task-comment', pmtController.updateCommentOnTask);
ProjectRouter.post('/delete-task-comment', pmtController.deleteTaskComment);
ProjectRouter.post('/delete-project-comment', pmtController.deleteProjectComment);
ProjectRouter.post('/update-project-comment', pmtController.updateCommentOnProject);
ProjectRouter.post('/project-comment-list', pmtController.projectCommentList);
ProjectRouter.post('/update-custom-field-order', pmtController.setCustomFieldSerialNo);
ProjectRouter.post('/add-project-attachment', pmtController.addProjectAttachments);
ProjectRouter.post('/add-description-attachment', pmtController.addProjectDescriptionAttachments);
ProjectRouter.get('/get-notification-list', pmtController.getNotificationList);
// ProjectRouter.post("/add-remove-user-to-project", pmtController.AddRemoveUserToProject);
// ProjectRouter.delete('/delete-project', pmtController.DeleteProject);
// ProjectRouter.post('/project-team-member', pmtController.projectTeamMember);

// ### ## #### Code by prajwal Date:-10-04-2025 #### ## ###
ProjectRouter.post('/project-task-list', pmtController.ProjectTaskList);
ProjectRouter.post('/project-task-add', pmtController.ProjectTaskAdd);
ProjectRouter.put('/project-task-update', pmtController.ProjectTaskUpdate);
ProjectRouter.delete('/project-task-delete',pmtController.ProjectTaskDelete);



ProjectRouter.put('/task-field-update', pmtController.updateTaskField);
ProjectRouter.post('/update-all-fields', pmtController.updateAllFields);
ProjectRouter.post('/update-task-serial', pmtController.updateTaskSerial);

ProjectRouter.post('/set-task-est-time', protect, pmtController.setTaskEstTime)
ProjectRouter.post('/get-task-est-time', protect, pmtController.getTaskEstTime)


ProjectRouter.get('/project-custom-fields', pmtController.ProjectCustomFields);
ProjectRouter.post('/add-type-key', pmtController.AddTypeKey);
ProjectRouter.put('/update-type-key', pmtController.updateTypeKey);
ProjectRouter.delete('/delete-type-key', pmtController.deleteTypeKey);


ProjectRouter.put('/task-field-update', pmtController.updateTaskField);






ProjectRouter.post('/task-comment-list', pmtController.TaskCommentList);
ProjectRouter.post('/project-status-options', pmtController.projectStatusOptions);
ProjectRouter.post('/task-order-update', pmtController.taskOrderUpdate);
module.exports = ProjectRouter;


