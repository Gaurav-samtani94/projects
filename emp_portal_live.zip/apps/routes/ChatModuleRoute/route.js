const express = require('express');
const router = express.Router();
const chatController = require('../../controllers/ChatModule/Controller');

// Single Chat
router.post('/user-list', chatController.chatuserList);
router.post('/single/messages', chatController.sendSingleMessage);
router.post('/single/chat-history', chatController.getSingleChatMessages);
router.post('/single/documents', chatController.uploadSingleDocument);
router.delete('/user-chat-delete',chatController.DeleteChat);
router.post('/chat-forward',chatController.Chatforward);
router.post('/mark-as-read',chatController.markMessagesAsReadByUser);

// Group Chat
router.post('/create-group', chatController.createGroupChat);
router.post('/group/messages', chatController.sendGroupMessage);
router.post('/group/chat-history', chatController.getGroupChatMessages);
router.get("/group-list",chatController.GroupList);
router.post('/calls/start', chatController.startCall);
router.put('/calls/end', chatController.endCall);
router.post('/group/documents', chatController.uploadGroupDocument);
router.post('/update-group', chatController.updateGroupDetails);
module.exports = router;
