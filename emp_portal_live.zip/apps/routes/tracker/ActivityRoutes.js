const express = require('express')
const {protect} = require('../../middleware/authMiddleware')
const Router = express.Router()

const ActivityController = require('../../controllers/tracker/Activity/ActivityController')

Router.post('/add-daily-system-stats', protect, ActivityController.addDailySystemStats)
Router.post('/add-daily-calculated-system-stats', protect, ActivityController.addDailyCalculatedSystemStats)
Router.post('/add-daily-app-activity', protect, ActivityController.addDailyAppActivity)
Router.post('/add-daily-app-usage', protect, ActivityController.addDailyAppUsage)



Router.post('/insert-status-logs',protect,  ActivityController.statusActivityLog)
Router.post('/insert-work-logs', protect, ActivityController.workActivityLog)
Router.post('/insert-apps-duration-log', protect, ActivityController.AppsDurationLog)






Router.post('/insert-apps-duration-log', protect, ActivityController.AppsDurationLog)
Router.post('/get-user-apps-duration', protect, ActivityController.getAppsDuration)
Router.post('/get-user-work-logs', protect, ActivityController.getWorkLogs)
Router.post('/get-user-activity-logs', protect, ActivityController.getActivityLogs)
Router.post('/get-user-status-logs', protect, ActivityController.getStatusLogs)
Router.post('/start-session', protect, ActivityController.addSession)
Router.post('/get-session', protect, ActivityController.getSession)
Router.post('/end-session', protect, ActivityController.endSession)
Router.post('/insert-secreenshot', ActivityController.ScreenShot)


module.exports = Router