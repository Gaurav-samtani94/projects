const express = require('express')
const Router = express.Router()
const {loginUser, registerUser, usersList, allUsersList, getUserDetails, updateUserDetails, changePassword} = require('../../controllers/tracker/user/userController')
const {protect} = require('../../middleware/authMiddleware')
const {GetWorkZone, addWorkZone} = require('../../controllers/tracker/workZone/workzone')

Router.post('/register', protect, registerUser)
Router.post('/login', loginUser)
Router.get('/users',protect, usersList)
Router.get('/all-users', protect, allUsersList)
Router.post('/user-details', protect, getUserDetails)
Router.post('/user-details-update/:update_id', protect, updateUserDetails)
Router.get('/work-zone-by-user',protect,GetWorkZone)
Router.post('/add-work-zone',protect,addWorkZone)
Router.post('/change-password',protect,changePassword)


module.exports = Router;