// Code by Prajwal Date:- 26-03-2025 //
const express = require('express');
const Router = express.Router();
const { GetCountryList, GetStateList, GetCitesList, GetLanguageList, GetBusinessUnit, getDepartment, GetDesignationList, GetTimezoneList, GetCurrencyList } = require('../../controllers/Master/MasterController');
Router.get('/get-country-list', GetCountryList);
Router.get('/get-state-list', GetStateList);
Router.get('/get-cities-list', GetCitesList);
Router.get('/get-language-list', GetLanguageList);
Router.get('/get-business-list', GetBusinessUnit);
Router.get('/get-department-list', getDepartment);
Router.get('/get-designation-list', GetDesignationList);
Router.get('/get-timezone-list', GetTimezoneList);
Router.get('/get-currency-list', GetCurrencyList);

module.exports = Router;