require('dotenv').config();

async function sendDynamicEmail(to, subject, html, res) {
    const { SMTPClient } = await import('emailjs'); // Dynamic Import

    const client = new SMTPClient({
        user: process.env.MAIL_USER,
        password: process.env.MAIL_PASS,
        host: process.env.MAIL_HOST,
        ssl: false,
    });

    try {
        const message = {
            from: `"GGPL" <${process.env.MAIL_FROM}>`,
            to: to,
            cc: '',
            subject: subject,
            
            attachment: [{ data: html, alternative: true }],
        };

        client.send(message, function (err, response) {
            if (err) {
                const dataArr = [];
                dataArr['error'] = true;
                dataArr['error_msg'] = err;
                dataArr['message'] = 'Something went wrong';
                return dataArr;

            } else {
                const dataArr = [];
                dataArr['error'] = false;
                dataArr['error_msg'] = '';
                dataArr['message'] = 'Reset password link sent';
                return dataArr;
                
            }

            
        });
    } catch (error) {
        const dataArr = [];
        dataArr['error'] = true;
        dataArr['error_msg'] = error;
        dataArr['message'] = 'Internal server error';
        return dataArr;
    }
}

module.exports = { sendDynamicEmail };



/*
const nodemailer = require('nodemailer');

const handlebars = require('handlebars');
const fs = require('fs');
const transporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST,
    port: process.env.MAIL_PORT,
    secure: false, // 465 ke alawa false rakhein
    auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS,
    },
    ignoreTLS: true,  // Force karega ki TLS bypass ho
    tls: {
        rejectUnauthorized: false,
    },
});

async function sendDynamicEmail(to, subject, text, html, retries = 2, delayMs = 10000) {
    const mailOption = {
        from: process.env.MAIL_FROM,
        to,
        subject,
        text,
        html,
    };

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const info = await transporter.sendMail(mailOption);
            console.log("✅ Email sent successfully:", info.response);
            transporter.close(); // Connection close karein
            return info;
        } catch (error) {
            console.error(`❌ Attempt ${attempt} failed:`, error);
            
            if (error.responseCode === 421) {
                console.log("🚫 SMTP Server is busy, retrying...");
            }

            if (attempt < retries) {
                let retryDelay = delayMs * attempt; // Exponential backoff
                console.log(`⏳ Retrying in ${retryDelay / 1000} seconds...`);
                await new Promise(resolve => setTimeout(resolve, retryDelay));
            } else {
                console.error("🚫 All attempts failed.");
                throw error;
            }
        }
    }
}


function loadTemplate(templatePath, replacements) {
    const template = fs.readFileSync(templatePath, 'utf8');
    const compiledTemplate = handlebars.compile(template);
    return compiledTemplate(replacements);
}

function sendEmailWith_temp(to, subject = null, body = null, templatePath, dynamicData) {
    const mailOptions = {
        from: process.env.MAIL_FROM,
        to,
        subject,
        html: loadTemplate(templatePath, dynamicData),
    };
    return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Email not sent: ', error);
                reject(error);
            } else {
                console.log('Email sent: ' + info.response);
                resolve(info.response);
            }
        });
    });
}
module.exports = { sendDynamicEmail, sendEmailWith_temp };*/


