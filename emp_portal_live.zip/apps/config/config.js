module.exports = {
    JWT_SECRET: process.env.JWT_SECRET || 'H765#bdT',
    MONGO_URI:  'mongodb://users:ceg@202.131.122.246:27017/tracker',
  };

  