const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'mysql', 
    // host: 'localhost',
    // username: 'root',
    // password: '',
    // database: 'emp_portal',
    
    host: 'demo2.growthgrids.com',
    username: 'emp_portal',
    password: 'ed!ds!$425$124!%$EW%',
    database: 'emp_portal',

    timezone: '+05:30',
    define: {
        timestamps: false, 
    },
    logging:false
});

// sequelize.sync().then(()=>{
//     console.log("Database connected successfully");
// })




module.exports = sequelize;
