// code by prajwal date:- 28-03-2025 //
const Joi = require('joi');
require('dotenv').config();
const { Op, where } = require('sequelize');
const Leave = require('../../models/Hrms/LeaveModel');
const RhLeaveSummary = require('../../models/Hrms/RHLeaveModel');
const UsersTbl = require('../../models/tracker/user/User');
const Holiday = require('../../models/Hrms/HolidayModel');
const HolidayGrp = require('../../models/Hrms/HolidayGrpModel');

const moment = require('moment');


// Define the Joi schema for validatio
const leaveSchema = Joi.object({
    user_id: Joi.number().required(),
    reason: Joi.string().required(),
    approver_comments: Joi.string().optional().allow(''),
    leavetypeid: Joi.number().valid(1, 2).required(), // 1: Paid Leave, 2: Restricted Holiday
    leaveday: Joi.number().valid(1, 2, 3).when('leavetypeid', {
        is: 1,
        then: Joi.required(),
        otherwise: Joi.optional().allow('')
    }),
    from_date: Joi.date().iso().required(),
    to_date: Joi.date().iso().required(),
    leavestatus: Joi.string().optional().allow(''),
    rep_mang_id: Joi.number().optional().allow(null),
    hr_id: Joi.number().optional().allow(null),
    half_day_type: Joi.string().optional().allow(''),
    appliedleavescount: Joi.number().optional(),
    is_sat_holiday: Joi.boolean().optional(),
    createdby: Joi.string().optional().allow(''),
    modifiedby: Joi.string().optional().allow(''),
    createddate: Joi.date().optional(),
    modifieddate: Joi.date().optional(),
    isactive: Joi.boolean().optional(),

    // Updated to allow null
    hd_pre_post_lunch: Joi.alternatives().try(
        Joi.string().valid('1', '2', '3'),
        Joi.allow(null) // Allowing null explicitly
    ).when('leaveday', {
        is: 2, // Required only for half-day leave
        then: Joi.required(),
        otherwise: Joi.optional().allow('')
    }),

    sort_leave_exptime: Joi.string().when('leaveday', {
        is: 3, // Required only for short leave
        then: Joi.required(),
        otherwise: Joi.optional().allow('')
    })
});


// Edit schema extends leaveSchema and requires 'id'
const editLeaveSchema = Joi.object({
    id: Joi.number().required(),
    reason: Joi.string().required()
});

// Leave Approve & Reject schema extends leaveSchema
const AprvRejSch = Joi.object({
    id: Joi.number().required(),
    user_id: Joi.number().required(),
    leavestatus: Joi.string().valid("Approved", "Rejected").required(), // Only allow these two values
    rep_mang_id: Joi.number().required()
});

// Apply leave List //
const LeaveList = async (req, res) => {
    try {
        const user_id = req.user?.id;

        if (!user_id) {
            return res.status(401).json({
                success: false,
                message: "Unauthorized: User ID not found",
                error: true,
            });
        }

        const response = await Leave.findAll({
            where: { user_id },
            order: [['id', 'ASC']],
            attributes: [
                'id', 'user_id', 'reason', 'approver_comments', 'leavetypeid',
                'leaveday', 'from_date', 'to_date', 'leavestatus', 'rep_mang_id',
                'hr_id', 'half_day_type', 'appliedleavescount', 'is_sat_holiday',
                'createdby', 'modifiedby', 'createddate', 'modifieddate', 'isactive',
                'sort_leave_exptime', 'hd_pre_post_lunch'
            ]
        });

        if (response.length === 0) {
            return res.status(404).json({
                success: false,
                message: "No leave records found.",
                error: false,
                data: [],
            });
        }

        const statusMap = {
            "Pending for approval": 1,
            "Approved": 2,
            "Rejected": 3
        };

        const modifiedData = response.map(item => {
            const statusName = item.leavestatus;
            const statusCode = statusMap[statusName] || 0;

            return {
                ...item.dataValues,
                leavestatus: {
                    name: statusName,
                    status: statusCode
                }
            };
        });

        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: modifiedData
        });

    } catch (error) {
        console.error("Error fetching leave list:", error);
        res.status(500).json({
            success: false,
            message: "An error occurred while fetching the Apply Leave list.",
            error: true,
        });
    }
};


// Apply leave Add //

const {Leavetemplate, leaveRejectedTemplate, leaveApprovedTemplate} = require('./leaveTemplate')


const applyLeave = async (req, res) => {
    try {
        const { error, value } = leaveSchema.validate(req.body, { abortEarly: false });
        if (error) {
            return res.status(400).json({
                message: `Validation failed: ${error.details.map(err => err.message).join(', ')}`,
                status: '0',
                error: true,
                success: true
            });
        }

        const {
            user_id,
            reason,
            approver_comments,
            leavetypeid,
            leaveday,
            from_date,
            to_date,
            leavestatus,
            rep_mang_id,
            hr_id,
            half_day_type,
            is_sat_holiday,
            createdby,
            modifiedby,
            createddate,
            modifieddate,
            isactive,
            sort_leave_exptime,
            hd_pre_post_lunch,
        } = value;

        const fromDate = moment(from_date, 'YYYY-MM-DD');
        const toDate = moment(to_date, 'YYYY-MM-DD');

        if (!fromDate.isValid() || !toDate.isValid()) {
            return res.status(400).json({
                message: 'Invalid date format for from_date or to_date.',
                success: false,
                error: true
            });
        }

        const user = await UsersTbl.findOne({ where: { id: user_id } });
        if (!user) {
            return res.status(400).json({
                message: 'User not found.',
                success: false,
                error: true,
            });
        }
        let reporting_manager = user.reporting_manager;
        let reporting_manager_name = user.reporting_manager_name;

        let leaveDayToApply = leaveday;
        if (leavetypeid === 2) {
            if (!fromDate.isSame(toDate, 'day')) {
                return res.status(400).json({
                    message: 'For Restricted Holiday (RH) leave, from_date and to_date must be the same.',
                    success: false,
                    error: true,
                });
            }

            const rhLeave = await RhLeaveSummary.findOne({ where: { RH_date: fromDate.format('YYYY-MM-DD') } });
            if (!rhLeave) {
                return res.status(400).json({
                    message: 'No matching Restricted Holiday (RH) found for the selected date.',
                    success: false,
                    error: true,
                });
            }
            leaveDayToApply = null;
        }

        if ((leaveday === 2 || leaveday === 3) && !fromDate.isSame(toDate, 'day')) {
            return res.status(400).json({
                message: 'Half-day or short leave must have the same from_date and to_date.',
                success: false,
                error: true,
            });
        }

        if (leaveday === 2 && !hd_pre_post_lunch) {
            return res.status(400).json({
                message: 'For half-day leave, hd_pre_post_lunch is a required field.',
                success: false,
                error: true,
            });
        }

        if (leaveday === 3 && !sort_leave_exptime) {
            return res.status(400).json({
                message: 'For short leave, sort_leave_exptime is a required field.',
                success: false,
                error: true,
            });
        }

        let existingLeave = null;
        if (leavetypeid === 1 && leaveday === 1) {
            existingLeave = await Leave.findOne({
                where: {
                    user_id,
                    leavetypeid: 1,
                    [Op.or]: [{
                        from_date: { [Op.lte]: fromDate.format('YYYY-MM-DD') },
                        to_date: { [Op.gte]: toDate.format('YYYY-MM-DD') },
                    }],
                },
            });
            if (existingLeave) {
                return res.status(400).json({
                    message: 'You have already applied for leave on this day.',
                    success: false,
                    error: true,
                });
            }
        }

        if (leavetypeid === 1) {
            const existingRHLeave = await Leave.findOne({
                where: {
                    user_id,
                    leavetypeid: 2,
                    from_date: fromDate.format('YYYY-MM-DD'),
                    to_date: toDate.format('YYYY-MM-DD')
                },
            });
            if (existingRHLeave) {
                return res.status(400).json({
                    message: 'You cannot apply for Paid Leave on the same dates where you have already applied for Restricted Holiday (RH) leave.',
                    success: false,
                    error: true,
                });
            }
        }

        if (leaveday === 2 || leaveday === 3) {
            const overlappingFullDayLeave = await Leave.findOne({
                where: {
                    user_id,
                    leavetypeid: 1,
                    from_date: { [Op.lte]: fromDate.format('YYYY-MM-DD') },
                    to_date: { [Op.gte]: toDate.format('YYYY-MM-DD') },
                },
            });
            if (overlappingFullDayLeave) {
                return res.status(400).json({
                    message: 'You cannot apply for half-day or short leave within an existing full-day leave period.',
                    success: false,
                    error: true,
                });
            }
        }

        let appliedleavescount = leaveday === 1 ? toDate.diff(fromDate, 'days') + 1 : (leaveday === 2 ? 0.5 : 1);
        appliedleavescount = leavetypeid === 2 ? 1 : appliedleavescount;

        const newLeave = await Leave.create({
            user_id,
            reason,
            approver_comments,
            leavetypeid,
            leaveday: leaveDayToApply,
            from_date: fromDate.format('YYYY-MM-DD'),
            to_date: toDate.format('YYYY-MM-DD'),
            leavestatus,
            rep_mang_id: reporting_manager,
            hr_id,
            half_day_type,
            appliedleavescount,
            is_sat_holiday,
            createdby,
            modifiedby,
            createddate: Date.now(),
            modifieddate: Date.now(),
            isactive,
            sort_leave_exptime,
            hd_pre_post_lunch,
        });

        const reportingManager = await UsersTbl.findOne({
            where: {
                id: reporting_manager
            }
        })


        const LeaveType = leavetypeid == 1 ? 'PL' : 'RH'
        const LeaveFor = leaveDayToApply == 1 ? 'Full Day' : leaveDayToApply == 2 ? 'Half Day' : 'QL';

        // Convert to IST (+5:30)
        const istOffset = 5.5 * 60; // 5 hours 30 minutes in minutes
        const now = new Date()
        const istTime = new Date(now.getTime() + istOffset * 60 * 1000);

        const LeaveApplyDate = formatDateTime(istTime)


        const html = Leavetemplate(newLeave.id, reporting_manager_name, user.employeeId, user.userfullname, LeaveType, from_date, to_date, appliedleavescount, reason, LeaveApplyDate, LeaveFor)


        if (reportingManager) {
            const reportingManagerEmail = reportingManager.emailaddress

             const result = await sendEmail(reportingManagerEmail, 'Leave Application', html)

        } else {
            console.log('Unable to send Email, Reporting Manager not found')
        }


        return res.status(201).json({
            message: 'Leave applied successfully!',
            leave: newLeave,
            success: '1',
            error: false,
            status: '1'
        });
    } catch (error) {
        return res.status(500).json({
            message: 'An error occurred while applying for leave.',
            error: error.message,
            stack: error.stack,
            success: '0'
        });
    }
};



// Format date and time properly
const formatDateTime = (date) => {
    const pad = (n) => n.toString().padStart(2, '0');

    const year = date.getUTCFullYear();
    const month = pad(date.getUTCMonth() + 1);
    const day = pad(date.getUTCDate());

    const hours = pad(date.getUTCHours());
    const minutes = pad(date.getUTCMinutes());
    const seconds = pad(date.getUTCSeconds());

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// Apply Leave Edit //
const EditapplyLeave = async (req, res) => {
    try {
        // Validate request body using Joi (only ID and reason are required)
        const {
            error,
            value
        } = editLeaveSchema.validate(req.body, {
            abortEarly: false
        });

        if (error) {
            return res.status(400).json({
                message: `Validation failed: ${error.details.map(err => err.message).join(', ')}`,
                status: '0',
                error: true,
                success: false
            });
        }

        const {
            id,
            reason
        } = value;

        // Ensure `id` is provided
        if (!id) {
            return res.status(400).json({
                message: 'Leave request ID is required for editing.',
                success: false,
                error: true,
            });
        }

        // Check if leave request exists
        const existingLeave = await Leave.findOne({
            where: {
                id
            }
        });

        if (!existingLeave) {
            return res.status(404).json({
                message: 'Leave request not found.',
                success: false,
                error: true,
            });
        }

        // Restrict updates to only the `reason` field
        await existingLeave.update({
            reason,
            modifieddate: new Date()
        });

        return res.status(200).json({
            message: 'Leave request reason updated successfully!',
            leave: existingLeave,
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: 'An error occurred while updating the leave request reason.',
            error: error.message,
            stack: error.stack,
        });
    }
};

// Leave Approved or Rejected By IO // 
const LeaveAprvReje = async (req, res) => {
    try {
        // Validate request body using Joi
        const {
            error,
            value
        } = AprvRejSch.validate(req.body, {
            abortEarly: false
        });
        if (error) {
            return res.status(400).json({
                message: `Validation failed: ${error.details.map(err => err.message).join(', ')}`,
                status: "0",
                error: true,
                success: false
            });
        }

        const {
            id,
            user_id,
            leavestatus,
            rep_mang_id
        } = value;

        // Step 1: Ensure `id` is provided (primary key of leave request)
        if (!id) {
            return res.status(400).json({
                message: "Leave request ID is required.",
                success: false,
                error: true
            });
        }

        // Step 2: Check if leave request exists
        const leaveRequest = await Leave.findOne({
            where: {
                id
            }
        });

        if (!leaveRequest) {
            return res.status(404).json({
                message: "Leave request not found.",
                success: false,
                error: true
            });
        }

        // Step 3: Prevent updates if leave is already Approved or Rejected
        if (["Approved", "Rejected"].includes(leaveRequest.leavestatus)) {
            return res.status(400).json({
                message: `This leave request has already been ${leaveRequest.leavestatus} and cannot be changed.`,
                success: false,
                error: true
            });
        }

        // Step 4: Check if `user_id` exists in `tbl_User`
        const userExists = await UsersTbl.findOne({
            where: {
                id: user_id
            },
            attributes: ["reporting_manager", "reporting_manager_name", "userfullname"]
        });

        if (!userExists) {
            return res.status(400).json({
                message: "User ID does not exist in tbl_User.",
                success: false,
                error: true
            });
        }

        // Step 5: Check if `rep_mang_id` exists in `tbl_User`
        const reportingManager = await UsersTbl.findOne({
            where: {
                id: rep_mang_id
            }
        });

        if (!reportingManager) {
            return res.status(400).json({
                message: "Invalid reporting manager ID.",
                success: false,
                error: true
            });
        }

        // Step 6: Ensure only "Approved" or "Rejected" status is allowed
        if (!["Approved", "Rejected"].includes(leavestatus)) {
            return res.status(400).json({
                message: "Invalid leave status. Only 'Approved' or 'Rejected' are allowed.",
                success: false,
                error: true
            });
        }

        // Step 7: Update leave request
        await Leave.update({
            leavestatus,
            modifieddate: new Date()
        }, {
            where: {
                id
            }
        });

        // Step 8: Fetch updated leave record
        const updatedLeave = await Leave.findOne({
            where: {
                id
            },
            attributes: ["id", "user_id", "leavestatus", "modifieddate"] // Returning only necessary fields
        });

        return res.status(200).json({
            message: `Leave request has been ${leavestatus} successfully.`,
            success: true,
            leave: updatedLeave
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "An error occurred while processing the leave request.",
            error: error.message,
            success: false
        });
    }
};


// My Team Leave Listing //

const MyteamList = async (req, res) => {
    try {
        // Fetch all employees, grouping them by their reporting manager
        const response = await UsersTbl.findAll({
            order: [
                ['reporting_manager', 'ASC'],
                ['id', 'ASC']
            ], // Sort by manager, then by ID
            attributes: [
                "id",
                "userfullname",
                "emailaddress",
                "date_of_joining",
                "emp_status_name",
                "businessunit_name",
                "department_name",
                "jobtitle_name",
                "contactnumber",
                "profileimg",
                "reporting_manager",
                "reporting_manager_name"
            ]
        });

        // Group employees by their reporting manager
        const groupedData = response.reduce((acc, employee) => {
            const managerId = employee.reporting_manager;
            const managerName = employee.reporting_manager_name || "Unknown Manager";

            if (!acc[managerId]) {
                acc[managerId] = {
                    reporting_manager_id: managerId,
                    reporting_manager_name: managerName,
                    team_members: []
                };
            }

            acc[managerId].team_members.push(employee);
            return acc;
        }, {});

        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: Object.values(groupedData) // Convert object to array for API response
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the My Team list.',
            error: true,
        });
    }
};


// Delete Leave //

const DeleteLeave = async (req, res) => {
    try {
        // Validate request body using Joi (only ID is required)
        const deleteLeaveSchema = Joi.object({
            id: Joi.number().required(), // Leave request ID is required
        });

        const {
            error,
            value
        } = deleteLeaveSchema.validate(req.body, {
            abortEarly: false
        });

        if (error) {
            return res.status(400).json({
                message: `Validation failed: ${error.details.map(err => err.message).join(', ')}`,
                status: '0',
                error: true,
                success: false
            });
        }

        const {
            id
        } = value;

        // Check if leave request exists
        const existingLeave = await Leave.findOne({
            where: {
                id
            }
        });

        if (!existingLeave) {
            return res.status(404).json({
                message: 'ID not found.',
                success: false,
                error: true,
            });
        }

        // Delete the leave request
        await existingLeave.destroy();

        return res.status(200).json({
            message: 'Leave request deleted successfully!',
            success: true,
            error: false,
            status: "1"
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: 'An error occurred while deleting the leave request.',
            error: error.message,
            stack: error.stack,
        });
    }
};


// Holiday List //
const HolidayList = async (req, res) => {
    try {
        const { groupid, holidayyear } = req.body;
        const filters = {};
        if (groupid) filters.groupid = groupid;
        if (holidayyear) filters.holidayyear = holidayyear;

        const holidays = await Holiday.findAll({
            where: filters,
            include: [
                {
                    model: HolidayGrp,
                    as: 'group',
                    attributes: ['groupname'],
                    required: false
                }
            ],
            order: [['holidaydate', 'ASC']],
        });

        return res.status(200).json({
            message: "Holiday list fetched successfully!",
            status: '1',
            error: false,
            success: true,
            data: holidays
        });

    } catch (error) {
        console.error("Error fetching holiday list:", error);
        return res.status(500).json({
            message: "An error occurred while fetching the holiday list.",
            success: false,
            error: error.message,
        });
    }
};



const sendEmail = async (to, subject, html) => {

    const { SMTPClient } = await import('emailjs'); // Dynamic Import

    const client = new SMTPClient({
        user: process.env.EMAIL_USER,
        password: process.env.EMAIL_PASSWORD,
        host: process.env.EMAIL_HOST,
        ssl: false,
    });
    try {
        const message = {
            from: `"GGPL" <${process.env.EMAIL_USER}>`,
            to: to,
            cc: '',
            subject: subject,

            attachment: [{ data: html, alternative: true }],
        };

        const response = await client.send(message, function (err, response) {
            if (err) {
                const dataArr = [];
                dataArr['error'] = true;
                dataArr['error_msg'] = err;
                dataArr['message'] = 'Something went wrong';
                return dataArr;

            } else {
                const dataArr = [];
                dataArr['error'] = false;
                dataArr['error_msg'] = '';
                dataArr['message'] = 'Reset password link sent';
                return dataArr;

            }
        });

        return response

    } catch (error) {
        const dataArr = [];
        dataArr['error'] = true;
        dataArr['error_msg'] = error;
        dataArr['message'] = 'Internal server error';
        return dataArr;
    }


}


//Code by Himanshu Sharan

const getAllLeaveRequests = async (req, res) => {
    try {
        const leaveRequest = await Leave.findAll({
            where: {
                rep_mang_id: req.user.id,
                isactive: '1'
            },
            include: {
                model: UsersTbl,
                required: true,
                where: {
                    isactive: '1'
                },
                attributes: ['id', 'userfullname', 'emailaddress', 'employeeId']
            },
            order: [['createddate', 'DESC']]
        })

        if (leaveRequest[0]) {
            return res.status(200).json({
                message: 'Record found',
                status: '1',
                data: leaveRequest
            })
        } else {
            return res.status(404).json({
                message: 'Record not found',
                status: '0'
            })
        }

    } catch (error) {

        return res.status(500).json({
            message: 'Something went wrong',
            error: error.message,
            status: '0'
        })

    }
}


const manageLeave = async (req, res) => {
    try {
        const schema = Joi.object({
            leave_id: Joi.number().required(),
            comment: Joi.string().allow('').optional(),
            status: Joi.string().allow('Approved', 'Rejected', 'Pending for approval').required()
        })

        const { error, value } = await schema.validate(req.body)

        if (error) {
            return res.status(400).json({
                message: error.message,
                status: '0'
            })
        }

        if(value.status == 'Rejected' && value.comment == null || ''){
            return res.status(400).json({
                message: 'Reason for Rejection is required',
                status: '0'
            })
        }


        const leave = await Leave.findOne({
            where: {
                id: value.leave_id,
                isactive: '1'
            }
        })

        if(leave){
         const updated = await leave.update({
            approver_comments: value.comment,
            leavestatus: value.status,
            modifiedby: req.user.id,
            modifieddate: Date.now()

            })
            const approver = req.user.userfullname

            const leaveType = leave.leavetypeid == 1 ? 'PL' : leave.leavetypeid == 2 ? 'RH': ''

            const user = await UsersTbl.findOne({
                where: {
                    id: leave.user_id
                },
                attributes: ['id', 'userfullname', 'emailaddress']
            })

            if(user){
                let htmlData = ''

                if(value.status == 'Approved'){
                    htmlData = leaveApprovedTemplate(leave.id, user.userfullname, leaveType, formatDateTime(leave.from_date), formatDateTime(leave.to_date), leave.appliedleavescount, leave.reason, approver )
                }

                 if(value.status == 'Rejected'){
                    htmlData = leaveRejectedTemplate(leave.id, user.userfullname, leaveType, formatDateTime(leave.from_date) , formatDateTime(leave.to_date), leave.appliedleavescount, leave.reason, approver, value.comment )
                }

                console.log(leave.from_date)

                  const result = await sendEmail(user.emailaddress, `Leave ${value.status}`, htmlData)

                //   console.log(result, 'is email result')


            }else{
                console.log('user not found, unable to send email')
            }

        return res.status(200).json({
            message: `Leave ${value.status}`,
            status: '1'
        })
        }else{
            return res.status(404).json({
                message: 'Leave request not found!',
                status: '0'
            })
        }

    } catch (error) {
        return res.status(500).json({
            message: 'Something went wrong',
            status: '0',
            error: error.message
        })

    }
}


module.exports = {
    LeaveList, applyLeave, EditapplyLeave, LeaveAprvReje,
    MyteamList, DeleteLeave, HolidayList, getAllLeaveRequests, manageLeave
};