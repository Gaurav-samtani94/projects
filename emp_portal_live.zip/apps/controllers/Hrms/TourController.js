// code by prajwal date 2023-10-04 //

const Joi = require('joi');
require('dotenv').config();
const Tour = require('../../models/Hrms/ApplyTourModel');
const Announcement = require('../../models/Hrms/AnnounceModel');
const Project = require('../../models/Hrms/ProjectModel');
const moment = require('moment');
const { Op } = require('sequelize');

// Tour List //
Tour.belongsTo(Project, { foreignKey: 'project_id' });
const TourList = async (req, res) => {
    try {
        const response = await Tour.findAll({
            order: [['id', 'ASC']],
            attributes: [
                'id', 'emp_id', 'project_id', 'week_no', 'year_week', 'month_no',
                'Year', 'start_date', 'end_date', 'tour_location', 'description',
                'rejected_notes', 'approved_bypmanager', 'approved_bylmanager',
                'applyed_assets_id', 'applyed_ticked_id', 'is_active', 'created_by',
                'tour_type', 'expected_out_time', 'created_date'
            ],
            include: [{
                model: Project,
                attributes: ['id', 'project_name']
            }]
        });

        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Tour list. ' + error.message,
            error: true,
        });
    }
};


// Tour Announcement List //

const TourAnnouncementList = async (req, res) => {
    try {
        const response = await Announcement.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'announcement_title', 'description', 'announcement_type', 'announcement_date', 'end_date', 'is_full_day', 'createdby', 'modifiedby', 'createddate', 'modifieddate', 'isactive']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Tour announcement list.',
            error: true,
        });
    }
}

// Apply Tour //
const ApplyTour = async (req, res) => {
    const schema = Joi.object({
        project_id: Joi.string().required(),
        tour_location: Joi.string().required(),
        description: Joi.string().allow(''),
        tour_type: Joi.string().required(),
        start_date: Joi.date().required(),
        end_date: Joi.date().required(),
        expected_out_time: Joi.string()
            .pattern(/^([0-1]\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/)
            .when('tour_type', {
                is: '2',
                then: Joi.required().messages({
                    'any.required': 'expected_out_time is required',
                    'string.pattern.base': 'expected_out_time must be in HH:mm or HH:mm:ss format',
                }),
                otherwise: Joi.optional()
            }),
    });

    const { error } = schema.validate(req.body);

    if (error) {
        return res.status(400).json({
            success: false,
            message: error.details[0].message,
            error: true,
        });
    }

    try {
        const { project_id, tour_location, description, tour_type, start_date, end_date, expected_out_time } = req.body;


        const user_id = req.user?.id;
        if (!user_id) {
            return res.status(401).json({
                success: false,
                status: '0',
                message: 'Unauthorized access',
                error: true,
            });
        }

        const start = moment(start_date).startOf('day');
        const end = moment(end_date).endOf('day');
        const existingTour = await Tour.findOne({
            where: {
                emp_id: user_id,
                start_date: { [Op.lte]: end.toDate() },
                end_date: { [Op.gte]: start.toDate() },
            }
        });

        if (existingTour) {
            return res.status(409).json({
                success: false,
                status: '0',
                message: 'You already have a tour applied during this date range.',
                error: true,
            });
        }

        const year_week = parseInt(start.format('W'));
        const month_no = parseInt(start.format('MM'));
        const year = parseInt(start.format('YYYY'));
        const formattedStart = start.format('YYYY-MM-DD');
        const formattedEnd = end.format('YYYY-MM-DD');
        const week_no = getWeekOfMonth(formattedStart);

        const tourData = {
            emp_id: user_id,
            project_id,
            tour_location,
            description,
            tour_type,
            start_date: formattedStart,
            end_date: formattedEnd,
            year_week,
            month_no,
            Year: year,
            week_no,
            rejected_notes: null,
            approved_bypmanager: "0",
            approved_bylmanager: "0",
            applyed_assets_id: null,
            applyed_ticked_id: null,
            is_active: "1",
            created_by: user_id,
            created_date: new Date().toISOString(),
            expected_out_time: tour_type === "2" ? expected_out_time : null,
        };

        const newTour = await Tour.create(tourData);

        res.status(201).json({
            success: true,
            error: false,
            status: "1",
            message: 'Tour applied successfully',
            data: newTour,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while applying for the tour.',
            error: true,
            status: '0',
            details: error.message,
        });
    }
};

// Edit Apply Tour //

const EditApplyTour = async (req, res) => {
    const schema = Joi.object({
        id: Joi.string().required(),
        project_id: Joi.string().required(),
        tour_location: Joi.string().required(),
        description: Joi.string().required(),
    });

    const { error } = schema.validate(req.body);
    if (error) {
        return res.status(400).json({
            success: false,
            message: error.details[0].message,
            error: true,
        });
    }

    try {
        const { id: tourId, project_id, tour_location, description } = req.body;
        const user_id = req.user?.id;

        if (!user_id) {
            return res.status(401).json({
                success: false,
                status: '0',
                message: 'Unauthorized access',
                error: true,
            });
        }

        const tour = await Tour.findOne({
            where: {
                id: tourId,
            }
        });

        if (!tour) {
            return res.status(404).json({
                success: false,
                error: true,
                message: 'Tour not found or not authorized to edit',
            });
        }

        await tour.update({
            project_id,
            tour_location,
            description,
            updated_by: user_id,
            updated_date: new Date().toISOString(),
        });

        res.status(200).json({
            success: true,
            error: false,
            status: "1",
            message: 'Tour updated successfully',
            data: {
                id: tourId,
                project_id,
                tour_location,
                description,
            },
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while updating the tour.',
            error: true,
            status: '0',
            details: error.message,
        });
    }
};


// Helper: Week of Month
function getWeekOfMonth(dateStr) {
    const date = new Date(dateStr);
    const year = date.getFullYear();
    const month = date.getMonth();
    const day = date.getDate();

    let week = 1;
    for (let i = 1; i <= day; i++) {
        const current = new Date(year, month, i);
        if (i > 1 && current.getDay() === 0) {
            week++;
        }
    }

    return week;
}

// Delete Apply Tour //
const DeleteApplyTour = async (req, res) => {
    const schema = Joi.object({
        id: Joi.string().required(),
    });

    const { error } = schema.validate(req.body);
    if (error) {
        return res.status(400).json({
            success: false,
            message: error.details[0].message,
            error: true,
        });
    }
    try {
        const { id: tourId } = req.body;
        const user_id = req.user?.id;

        if (!user_id) {
            return res.status(401).json({
                success: false,
                status: '0',
                message: 'Unauthorized access',
                error: true,
            });
        }

        const tour = await Tour.findOne({
            where: {
                id: tourId,
            }
        });

        if (!tour) {
            return res.status(404).json({
                success: false,
                error: true,
                message: 'Tour not found or not authorized to delete',
            });
        }

        await Tour.destroy({ where: { id: tourId } });

        res.status(200).json({
            success: true,
            error: false,
            status: "1",
            message: 'Tour deleted successfully',
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while deleting the tour.',
            error: true,
            status: '0',
            details: error.message,
        });
    }
}


// Project List //

const ProjectList = async (req, res) => {
    try {
        const response = await Project.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'project_name', 'key', 'description', 'project_type', 'project_lead', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Project list.' + error.message,
            error: true,
        });
    }
}
module.exports = {
    TourList, TourAnnouncementList, ApplyTour, EditApplyTour, DeleteApplyTour, ProjectList
};