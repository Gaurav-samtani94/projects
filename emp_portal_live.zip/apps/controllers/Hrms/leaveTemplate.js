const Leavetemplate = (leaveId, managerName, EmpID, EmpName, leaveType, startDate, endDate, TotalDays, reason, applyDate, leaveFor) => {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Leave Application Email</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4; padding: 20px;">
    <tr>
      <td>
        <table width="600" align="center" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
          <tr style="background-color: #004080;">
            <td style="padding: 20px; text-align: center; color: #ffffff; font-size: 20px; font-weight: bold;">
              Leave Application - ID: ${leaveId}
            </td>
          </tr>
          <tr>
            <td style="padding: 20px; color: #333333;">
              <p>Dear ${managerName},</p>
              <p>
                I, <strong>${EmpName}</strong> (Employee ID: <strong>${EmpID}</strong>), would like to apply for a leave.
              </p>
              <table width="100%" cellpadding="5" cellspacing="0" style="border-collapse: collapse; margin-top: 15px;">
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Leave Type:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${leaveType}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Leave For:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${leaveFor}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Start Date:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${startDate}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>End Date:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${endDate}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Total Days:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${TotalDays}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Reason:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${reason}</td>
                </tr>
                <tr>
                  <td style="border-bottom: 1px solid #cccccc;"><strong>Applied Date:</strong></td>
                  <td style="border-bottom: 1px solid #cccccc;">${applyDate}</td>
                </tr>
              </table>
              <p style="margin-top: 20px;">Kindly consider my request.</p>
              <p>Thank you,</p>
              <p><strong>${EmpName}</strong></p>
            </td>
          </tr>
          <tr style="background-color: #eeeeee;">
            <td style="padding: 15px; text-align: center; font-size: 12px; color: #555;">
              This is an automated leave application email.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`
}



const leaveApprovedTemplate = (leaveId,empName, leaveType, startDate, endDate, totalDays,reason, approver ) => {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Leave Approved</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 20px; background-color: #f4f4f4;">
    <tr>
      <td>
        <table align="center" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); overflow: hidden;">
          <tr style="background-color: #28a745;">
            <td style="padding: 20px; text-align: center; color: #ffffff; font-size: 20px; font-weight: bold;">
              Leave Approved - ID: ${leaveId}
            </td>
          </tr>
          <tr>
            <td style="padding: 20px; color: #333;">
              <p>Dear ${empName},</p>
              <p>Your leave request (ID: <strong>${leaveId}</strong>) has been <strong style="color: #28a745;">approved</strong>.</p>
              <table width="100%" cellpadding="5" cellspacing="0" style="border-collapse: collapse; margin-top: 15px;">
                <tr>
                  <td><strong>Leave Type:</strong></td>
                  <td>${leaveType}</td>
                </tr>
                <tr>
                  <td><strong>Start Date:</strong></td>
                  <td>${startDate}</td>
                </tr>
                <tr>
                  <td><strong>End Date:</strong></td>
                  <td>${endDate}</td>
                </tr>
                <tr>
                  <td><strong>Total Days:</strong></td>
                  <td>${totalDays}</td>
                </tr>
                <tr>
                  <td><strong>Reason:</strong></td>
                  <td>${reason}</td>
                </tr>
              </table>
              <p style="margin-top: 20px;">Please ensure to update your team and handover responsibilities if needed.</p>
              <p>Best regards,<br>${approver}</p>
            </td>
          </tr>
          <tr style="background-color: #eeeeee;">
            <td style="padding: 15px; text-align: center; font-size: 12px; color: #555;">
              This is an automated notification.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`
}

const leaveRejectedTemplate = (leaveId,empName, leaveType, startDate, endDate, totalDays,reason, approver, approver_comment) => {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Leave Rejected</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding: 20px; background-color: #f4f4f4;">
    <tr>
      <td>
        <table align="center" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); overflow: hidden;">
          <tr style="background-color: #dc3545;">
            <td style="padding: 20px; text-align: center; color: #ffffff; font-size: 20px; font-weight: bold;">
              Leave Rejected - ID: ${leaveId}
            </td>
          </tr>
          <tr>
            <td style="padding: 20px; color: #333;">
              <p>Dear ${empName},</p>
              <p>We regret to inform you that your leave request (ID: <strong>${leaveId}</strong>) has been <strong style="color: #dc3545;">rejected</strong>.</p>
              <table width="100%" cellpadding="5" cellspacing="0" style="border-collapse: collapse; margin-top: 15px;">
                <tr>
                  <td><strong>Leave Type:</strong></td>
                  <td>${leaveType}</td>
                </tr>
                <tr>
                  <td><strong>Start Date:</strong></td>
                  <td>${startDate}</td>
                </tr>
                <tr>
                  <td><strong>End Date:</strong></td>
                  <td>${endDate}</td>
                </tr>
                <tr>
                  <td><strong>Total Days:</strong></td>
                  <td>${totalDays}</td>
                </tr>
                <tr>
                  <td><strong>Reason:</strong></td>
                  <td>${reason}</td>
                </tr>
              </table>
              <p style="margin-top: 20px;"><strong>Rejection Reason:</strong> ${approver_comment}</p>
              <p>We appreciate your understanding.</p>
              <p>Best regards,<br>${approver}</p>
            </td>
          </tr>
          <tr style="background-color: #eeeeee;">
            <td style="padding: 15px; text-align: center; font-size: 12px; color: #555;">
              This is an automated notification.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`
}

module.exports = {Leavetemplate, leaveRejectedTemplate, leaveApprovedTemplate}