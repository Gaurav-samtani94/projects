const Joi = require('joi');
const jwt = require("jsonwebtoken");
const md5 = require('md5');

const { JWT_SECRET } = require("../../config/config");
const { sendDynamicEmail } = require('../../config/mail');
const { Sequelize } = require('sequelize')

const User = require('../../models/tracker/user/User');
const EmployeeSummary = require("../../models/Hrms/user/EmployeeSummary");
const HrmsOtherOfficialData = require("../../models/Hrms/user/HrmsOtherOfficialData");
const EmpSalaryDetails = require("../../models/Hrms/user/EmpSalaryDetails");
const Currency = require("../../models/Hrms/user/Currency");
const EmpPersonalDetails = require("../../models/Hrms/user/EmpPersonalDetails");
const Gender = require("../../models/Hrms/user/Gender");
const HrmsEmpCommunicationDetails = require("../../models/Hrms/user/HrmsEmpCommunicationDetails");
const EmpSkills = require("../../models/Hrms/user/EmpSkills");
const HrmsEmpJobHistory = require("../../models/Hrms/user/HrmsEmpJobHistory");
const BusinessUnit = require("../../models/Hrms/user/BusinessUnit");
const HrmsItr = require("../../models/Hrms/user/HrmsItr");
const MonthlyAttendance = require("../../models/Hrms/user/MonthlyAttendance");
const PayslipFilepath = require("../../models/Hrms/user/PayslipFilepath");
const HrmsPayrollMainSalary = require("../../models/Hrms/user/HrmsPayrollMainSalary");

const UserOtherDetails = async (req, res) => {
    try {
        let user_id = req.user.id;

        const details = await User.findOne({
            where: {
                id: user_id,
                isactive: 1
            },
            include: [
                {
                    model: EmployeeSummary,
                    as: 'employeeSummary' // Use the alias if defined in associations
                }, {
                    model: HrmsOtherOfficialData,
                    as: 'hrmsOtherOfficialData' // Use the alias if defined in associations
                }
            ]
        });

        if (details) {
            return res.status(200).send({
                message: "Emp details",
                status: "1",
                error: false,
                success: true,
                data: details
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserSalaryDetails = async (req, res) => {
    try {
        let user_id = req.user.id;

        const salaryDetails = await EmpSalaryDetails.findOne({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: Currency,
                    as: 'currencyDetails', // Use the alias if defined in associations
                    attributes: ['id', 'name', 'currency_symbol', 'currency_code']
                }, {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ]
        });

        if (salaryDetails) {
            return res.status(200).send({
                message: "Emp salary details",
                status: "1",
                error: false,
                success: true,
                data: salaryDetails
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserPersonalInformation = async (req, res) => {
    try {
        let user_id = req.user.id;

        const personalDetails = await EmpPersonalDetails.findOne({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: Gender,
                    as: 'genderDetails', // Use the alias if defined in associations
                    attributes: ['id', 'gendercode', 'gendername']
                }, {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ]
        });
        
        if (personalDetails) {
            return res.status(200).send({
                message: "Emp personal details",
                status: "1",
                error: false,
                success: true,
                data: personalDetails
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserCommunicationInformation = async (req, res) => {
    try {
        let user_id = req.user.id;

        const communicationDetails = await HrmsEmpCommunicationDetails.findOne({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ]
        });

        if (communicationDetails) {
            return res.status(200).send({
                message: "Emp Contact details",
                status: "1",
                error: false,
                success: true,
                data: communicationDetails
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserSkillList = async (req, res) => {
    try {
        let user_id = req.user.id;

        const skillList = await EmpSkills.findAll({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ]
        });


        if (skillList.length > 0) {
            return res.status(200).send({
                message: "Emp Skill List",
                status: "1",
                error: false,
                success: true,
                data: skillList
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};
const UserHrmsEmpJobList = async (req, res) => {
    try {
        let user_id = req.user.id;

        const hrmsEmpJobList = await HrmsEmpJobHistory.findAll({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }, {
                    model: BusinessUnit,
                    as: 'businessunits', // Use the alias if defined in associations
                    attributes: ['id', 'unitname', 'unitcode', 'description']
                }
            ]
        });


        if (hrmsEmpJobList.length > 0) {
            return res.status(200).send({
                message: "Emp Skill List",
                status: "1",
                error: false,
                success: true,
                data: hrmsEmpJobList
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserFormNumberList = async (req, res) => {
    try {
        let user_id = req.user.id;
        
        const UserForm16List = await HrmsItr.findAll({
            where: {
                user_id: user_id,
                status: 1
            },
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ],
            order: [['id', 'DESC']] // Ordering by id in descending order
        });
        const form_urls_Array = [];        
        let defalut_urls = 'https://apps.cegtechno.com/myhrms/uploads/newitrfiles/';
        if (UserForm16List.length > 0) {
            let ik = 0;
            for (const formdatas of UserForm16List) {
                // Ensure form_urls_Array[ik] is initialized before assigning properties
                if (!form_urls_Array[ik]) {
                    form_urls_Array[ik] = {}; // Initialize as an empty object
                }
                form_urls_Array[ik]['id'] = formdatas.id;
                form_urls_Array[ik]['user_id'] = formdatas.user_id;
                form_urls_Array[ik]['finyear'] = formdatas.finyear;
                form_urls_Array[ik]['folder_name'] = formdatas.folder_name;
                form_urls_Array[ik]['file_path'] = formdatas.file_path;
                form_urls_Array[ik]['file_path'] = formdatas.file_path;
                form_urls_Array[ik]['form_urls'] = defalut_urls+formdatas.finyear+'/'+formdatas.folder_name+'/'+formdatas.file_path;
                form_urls_Array[ik]['emailaddress'] = formdatas.userDetails.emailaddress;
                form_urls_Array[ik]['emprole_name'] = formdatas.userDetails.emprole_name;
                form_urls_Array[ik]['firstname'] = formdatas.userDetails.firstname;
                form_urls_Array[ik]['lastname'] = formdatas.userDetails.lastname;
                form_urls_Array[ik]['userfullname'] = formdatas.userDetails.userfullname;
                form_urls_Array[ik]['contactnumber'] = formdatas.userDetails.contactnumber;
                ik++;
            }
            
            return res.status(200).send({
                message: "Emp Form Number List",
                status: "1",
                error: false,
                success: true,
                data: form_urls_Array
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserAttendanceDetail = async (req, res) => {
    
    const DataToValidate = {
        month:req.body.month,
        year:req.body.year
    };
    
    
    try {
        let user_id = req.user.id;
        let month = 0;
        let year = 0;
        month = req.body.month;
        year = req.body.year;
        if (!month) {
            month = new Date().getMonth() + 1;  // getMonth() returns 0-11, so add 1 for 1-12
        }
        
        if (!year) {
            year = new Date().getFullYear();  // getFullYear() returns the current year
        }
        const attendanceRecord = await MonthlyAttendance.findAll({
            where: {
                user_id: user_id,
                month: month,
                year: year
            },
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                }
            ]
        });
        if (attendanceRecord.length > 0) {
            for (const formdatas of attendanceRecord) {
                const parsedData = JSON.parse(formdatas.action);

                formdatas.action = parsedData;
            }
            return res.status(200).send({
                message: "Emp Attendance  List",
                status: "1",
                error: false,
                success: true,
                data: attendanceRecord
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
        
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserPaySlipList = async (req, res) => {
    const Schema = Joi.object({
        year:Joi.number().required()
    });
    const DataToValidate = {        
        year:req.body.year
    };
    const result = Schema.validate(DataToValidate);
    if(result.error){
        return res.status(404).send({
            message: result.error.details[0].message,
            status:"0",
            success:false,
            error:true
        })
    }
    try {
        let user_id = req.user.id;
        const payslipRecord = await HrmsPayrollMainSalary.findOne({
            where: {
                user_id: user_id,
            },
            attributes: [ 'user_id'],
            include: [
                {
                    model: User,
                    as: 'userDetails', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber']
                },
                {
                    model: PayslipFilepath,
                    as: 'payslipdetails', // Use the alias if defined in associations
                    where: {
                        year: req.body.year
                    },

                }
            ]
        });
        if (payslipRecord) {
            //let defalut_urls = 'https://apps.cegtechno.com/hrms/';
            let defalut_urls = 'https://staging-emp.growthgrids.com/';
            
            console.log(payslipRecord);
            return res.status(200).send({
                message: "Emp Pay Slip List",
                status: "1",
                error: false,
                success: true,
                defalut_urls: defalut_urls,
                data: payslipRecord
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
        
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const userDailyAttendances = async (req, res) => {
    
    const dataSckima= {        
        month:req.body.month,
        year:req.body.year,
        email_address:req.body.email_address,
        employee_id:req.body.employee_id,
        in_time:req.body.in_time,
        out_time:req.body.out_time,
        late_by:req.body.late_by,
        early_by:req.body.early_by,
        working_hours:req.body.working_hours,
        action:req.body.action,
        working_status:req.body.working_status,
        date:req.body.date
    };
    
    
    try {
        console.log(dataSckima);
        const details = await User.findOne({
            where: {
                emailaddress: dataSckima.email_address,
                //employee_id: dataSckima.employee_id,
                isactive: 1
            }
        });
        if(details){
            dataSckima.entry_by = 1;
            const attendanceArray = {};
            attendanceArray['month'] = dataSckima.month;
            attendanceArray['year'] = dataSckima.year;
            attendanceArray['user_id'] = details.id;
            attendanceArray['in_time'] = dataSckima.in_time;
            attendanceArray['out_time'] = dataSckima.out_time;
            attendanceArray['late_by'] = dataSckima.late_by;
            attendanceArray['early_by'] = dataSckima.early_by;
            attendanceArray['working_hour'] = dataSckima.working_hours;
            attendanceArray['action'] = dataSckima.action;
            attendanceArray['working_status'] = dataSckima.working_status;
            attendanceArray['date'] = dataSckima.date;
            attendanceArray['entry_by'] = 1;
            const attendanceDetails = await MonthlyAttendance.findOne({
                where: {
                    month: dataSckima.month,
                    year: dataSckima.year,
                    user_id: details.id,
                    date: dataSckima.date
                }
            });

            if(attendanceDetails){
                const updatedAttendance = await MonthlyAttendance.update(
                    attendanceArray,
                    { where: { id: attendanceDetails.id } }
                );
                return res.status(200).send({
                    message: "Emp attendance updated",
                    status: "1",
                    error: false,
                    success: true,
                    data: updatedAttendance
                });
            } else  {
                const insertWorkZone = await MonthlyAttendance.create(attendanceArray);
                return res.status(200).send({
                    message: "Emp attendance inserted",
                    status: "1",
                    error: false,
                    success: true,
                    data: insertWorkZone
                });
            }

        } else {
            res.status(404).send({
                message: "Record user not found",
                status: "0",
                success: false,
                error: true
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const UserChangePassword = async (req, res) => {
    const Schema = Joi.object({
        oldPassword: Joi.string().required(),
        newPassword: Joi.string()
        .min(8)
        .pattern(new RegExp('(?=.*[A-Z])')) // At least one uppercase letter
        .pattern(new RegExp('(?=.*[a-z])')) // At least one lowercase letter
        .pattern(new RegExp('(?=.*[0-9])')) // At least one digit
        .pattern(new RegExp('(?=.*[@$!#%*?&])')) // At least one special character
        .required()
        .messages({
            'string.min': 'Password must be at least 8 characters long.',
            'string.pattern.base': 'Password must include uppercase, lowercase, number, and special character.',
        }),
        confirmPassword: Joi.any().valid(Joi.ref('newPassword')).required()
        .messages({ 'any.only': 'Confirm password must match new password.' })
    });
    const DataToValidate = {
        oldPassword:req.body.oldPassword,
        newPassword:req.body.newPassword,
        confirmPassword:req.body.confirmPassword
    };
    const result = Schema.validate(DataToValidate);
    if(result.error){
        return res.status(404).send({
            message: result.error.details[0].message,
            status:"0",
            success:false,
            error:true
        });
    }
    try {
        let user_id = req.user.id;
        let old_password = md5(req.body.oldPassword);
        
        const oldRecord = await User.findOne({
            where: {
                id: user_id,
                password: old_password,
            },
            attributes: [ 'id'],
        });
        if(oldRecord){
            const attendanceArray = {};
            attendanceArray['password'] = md5(DataToValidate?.newPassword);
            const updatedAttendance = await User.update(
                attendanceArray,
                { where: { id: user_id } }
            );
            return res.status(200).send({
                message: "Profile change password successfully",
                status: "1",
                error: false,
                success: true
            });
        } else {
            return res.status(404).send({
                message: "Current password not here",
                status:"0",
                success:false,
                error:true
            });
        }
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const forgotPassword = async (req, res) => {
    const Schema = Joi.object({
        emailaddress: Joi.string().email().required()
    });
    const DataToValidate = {
        emailaddress:req.body.emailaddress
    };
    const result = Schema.validate(DataToValidate);
    if(result.error){
        return res.status(404).send({
            message: result.error.details[0].message,
            status:"0",
            success:false,
            error:true
        })
    }
    try {
        let emailAddress =req.body.emailaddress;
        const details = await User.findOne({
            where: {
                emailaddress: emailAddress,
                isactive: 1
            }
        });
        if(details){
            const tokenArr = {};
            tokenArr['user_id'] = details.id;
            tokenArr['currentDate'] = new Date();
            const secretKey = process.env.JWT_SECRET || "your-secret-key"; // Use environment variables for security

            
            const tokens = jwt.sign(tokenArr, secretKey, { expiresIn: "1h" });
            //const urltoken = 'http://192.168.11.144:3536/api/hrms/reset-passwords/'+tokens;
            const urltoken = 'https://staging-emp.growthgrids.com/api/hrms/reset-passwords/'+tokens;
            
            /*
            const response = sendDynamicEmail(
                emailAddress,
                'reset password Link',
                'Reset password link process',
                '<a href="'+urltoken+'">Reset Password</a>',
            );*/
            const responseMail = sendDynamicEmail(
                emailAddress,
                'reset password Link',
                'Reset password link process <a href="'+urltoken+'">Reset Password</a>'
            );
            
            
            return res.status(200).send({
                message: "Reset change password link send",
                status: "1",
                error: false,
                success: true,
                responseMail:responseMail,
                data:tokens
            });
        } else {
            return res.status(404).send({
                message: "Email address is not exist",
                status: "0",
                success:false,
                error:true
            });
        }
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const resetPassword = async (req, res) => {
    
    const Schema = Joi.object({
        token: Joi.string().required(),
        newPassword: Joi.string()
        .min(8)
        .pattern(new RegExp('(?=.*[A-Z])')) // At least one uppercase letter
        .pattern(new RegExp('(?=.*[a-z])')) // At least one lowercase letter
        .pattern(new RegExp('(?=.*[0-9])')) // At least one digit
        .pattern(new RegExp('(?=.*[@$!#%*?&])')) // At least one special character
        .required()
        .messages({
            'string.min': 'Password must be at least 8 characters long.',
            'string.pattern.base': 'Password must include uppercase, lowercase, number, and special character.',
        }),
        confirmPassword: Joi.any().valid(Joi.ref('newPassword')).required()
        .messages({ 'any.only': 'Confirm password must match new password.' })
    });
    const DataToValidate = {
        token:req.body.token,
        newPassword:req.body.newPassword,
        confirmPassword:req.body.confirmPassword
    };
    const result = Schema.validate(DataToValidate);
    if(result.error){
        return res.status(404).send({
            message: result.error.details[0].message,
            status:"0",
            success:false,
            error:true
        })
    }
    try {
        let token =req.body.token;
        
        let newPassword =req.body.newPassword;
        
        const decodeds = jwt.decode(token);
        let user_id =decodeds.user_id;
        const attendanceArray = {};
        attendanceArray['password'] = md5(newPassword);

        const reset_password = await User.update(
            attendanceArray,
            { where: { id: user_id } }
        );
            
            return res.status(200).send({
                message: "Reset password successfully",
                status: "1",
                error: false,
                success: true,
            });
        
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};




const userTeamList = async (req, res) => {
    
    try {
        let user_id = req.user.id;
        const teamRecord = await User.findAll({
            where: {
                reporting_manager: user_id,
            },
            attributes: [ 'id','emailaddress','userfullname','employee_id','contactnumber','department_name','position_name','department_name'],
            include: [
                {
                    model: User,
                    as: 'childUser', // Use the alias if defined in associations
                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber','position_name','department_name'],

                    include: [
                        {
                            model: User,
                            as: 'childUser', // Use the alias if defined in associations
                            attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber','position_name','department_name'],
                            include: [
                                {
                                    model: User,
                                    as: 'childUser', // Use the alias if defined in associations
                                    attributes: ['id', 'emailaddress', 'emprole_name', 'firstname', 'lastname', 'userfullname', 'contactnumber','position_name','department_name']
                                }
                            ]
                        }
                    ]
                }
            ]
        });
        if (teamRecord) {

            return res.status(200).send({
                message: "Emp Team user List",
                status: "1",
                error: false,
                success: true,
                
                data: teamRecord
            });
        } else {
            res.status(404).send({
                message: "Record Not Found",
                status: "0",
                success: false,
                error: true
            });
        }
        
        
    } catch (error) {
        return res.status(500).send({
            message: "Something went wrong",
            status: "0",
            error: error.message
        });
    }
};

const resetPasswords = async (req, res) => {
    const token = req.params.token;
    console.log("Token Received:", token);
    
    try {
        res.render("reset-password", { token });
    } catch (error) {
        console.error("Render Error:", error);
        res.status(500).send("Server Error: View not found.");
    }
};

module.exports = {
    UserOtherDetails,
    UserSalaryDetails,
    UserPersonalInformation,
    UserCommunicationInformation,
    UserSkillList,
    UserHrmsEmpJobList,
    UserFormNumberList,
    UserAttendanceDetail,
    UserPaySlipList,
    userDailyAttendances,
    UserChangePassword,
    forgotPassword,
    resetPasswords,
    resetPassword,
    userTeamList
    
}