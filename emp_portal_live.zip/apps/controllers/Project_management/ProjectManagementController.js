// Code by prajwal Date:- 10-04-2025 //
const Joi = require('joi')
const ProjectTask = require('../../models/Project_management/ProjectTaskModel')
const TaskComment = require('../../models/Project_management/TaskCommentModel')

const { MeetingRoomcreate } = require('../LiveKit/livekit')

const multer = require('multer')
const path = require('path')
const Project = require('../../models/Project_management/ProjectsModel')
const User = require('../../models/tracker/user/User')
const TeamMember = require('../../models/Project_management/projectTeamMember')
const Meeting = require('../../models/Meeting/Meeting')
const MeetingUsers = require('../../models/Meeting/MeetingUser')
const MeetingAttachments = require('../../models/Meeting/MeetingAttachment')
const md5 = require('md5')

const { RoomServiceClient, AccessToken } = require('livekit-server-sdk')
const ProjectCustomFieldsModel = require('../../models/Project_management/ProjectCustomFieldsModel')
const ProjectCustomFieldTypeKeyModel = require('../../models/Project_management/ProjectCustomFieldTypeKeyModel')

const ProjectCustomeFieldTypeValueModel = require('../../models/Project_management/ProjectCustomFieldTypeValueModel')
const ProjectCustomFieldTypeValueModel = require('../../models/Project_management/ProjectCustomFieldTypeValueModel')
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY || 'your_api_key'
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET || 'your_secret'
// const LIVEKIT_URL = process.env.LIVEKIT_URL || "https://your.livekit.cloud";
const { Sequelize, Op, where, fn, col } = require('sequelize')
const fs = require('fs')

const ProjectAttachmentsModel = require('../../models/Project_management/ProjectAttachmentsModel')
const ProjectCustomFieldTypeOptions = require('../../models/Project_management/ProjectCustomFieldOptions')
const ProjectsModel = require('../../models/Project_management/ProjectsModel')
const ProjectTaskTImeRecordModel = require('../../models/Project_management/ProjectTaskTImeRecordModel')
const ProjectComment = require('../../models/Project_management/ProjectCommentModel')
const NotificationHistory = require('../../models/Project_management/NotificationHistoryModel')

const TaskEstTimeModel = require('../../models/Project_management/TaskEstTimeModel')
const { model } = require('mongoose')

const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'application/pdf',
    'image/webp',
    'image/jpg',
    'image/gif',
  ] // Adjust based on allowed file types
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true)
  } else {
    cb(new Error('Invalid file type'), false)
  }
}

const addMemberOnProject = async () => { }

const customFieldListByProject = async (req, res) => {
  const schema = Joi.object().keys({
    project_id: Joi.number().required(),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    project_id: req.body.project_id,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const customFieldsByProjects =
        await ProjectCustomFieldTypeKeyModel.findAll({
          where: {
            status: '1',
            project_id: req.body.project_id,
          },
          include: [
            {
              model: ProjectCustomFieldsModel,
              as: 'type',
              attributes: ['field_name', 'field_value_type', 'field_code'],
            },
          ],
        })

      return res.status(200).send({
        message: 'Custom Field Project Wise',
        success: true,
        error: false,
        status: '1',
        data: customFieldsByProjects,
      })
    } catch (error) {
      return res.status(500).send({
        message: 'Something went wrong',
        success: false,
        error: error.message,
        status: '0',
      })
    }
  }
}

const customFieldList = async (req, res) => {
  try {
    const customFields = await ProjectCustomFieldsModel.findAll({
      where: {
        status: '1',
      },
      attributes: ['id', 'field_code', 'field_name', 'icon'],
    })

    return res.status(200).send({
      message: 'Custom Field found',
      success: true,
      error: false,
      status: '1',
      data: customFields,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const deleteCustomFieldOnProject = async (req, res) => {
  const schema = Joi.object().keys({
    field_id: Joi.number().required(),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    field_id: req.body.field_id,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const projectCustomFieldUpdate =
        await ProjectCustomFieldTypeKeyModel.update(
          {
            status: '0',
          },
          {
            where: {
              id: req.body.field_id, // your condition here
            },
          }
        )

      if (projectCustomFieldUpdate) {
        return res.status(200).send({
          message: 'Field Deleted Successfully',
          // data: projectCustomFieldUpdate,
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('CreateProject Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const createCustomFieldOnProject = async (req, res) => {
  const schema = Joi.object().keys({
    project_id: Joi.number().required(),
    field_type_id: Joi.string().required(),
    field_code: Joi.string().required(),
    label_name: Joi.string().required(),
    field_options: Joi.string().allow(null),
    createdby: Joi.number().required(),
  })

  const dataToValidate = {
    project_id: req.body.project_id,
    field_type_id: req.body.field_type_id,
    field_code: req.body.field_code,
    label_name: req.body.label_name,
    field_options: req.body.field_options,
    createdby: req.user.id,
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const checkLabel = await ProjectCustomFieldTypeKeyModel.findOne({
        where: {
          label_name: req.body.label_name,
          status: '1',
          project_id: req.body.project_id,
        },
      })

      if (checkLabel) {
        return res.status(200).send({
          message: 'Label Name Already Exist',
          success: false,
          status: 0,
        })
      }

      const getSrNo = await ProjectCustomFieldTypeKeyModel.max('sr_no', {
        where: { status: '1', project_id: req.body.project_id },
      })

      const projectField = await ProjectCustomFieldTypeKeyModel.create({
        project_id: req.body.project_id,
        type_id: req.body.field_type_id,
        label_name: req.body.label_name,
        is_default: 1,
        sr_no: getSrNo + 1,
        config_detail: req.body.field_code ? req.body.field_code : null,
        created_by: req.user.id,
      })

      const taskOnProject = await ProjectTask.findAll({
        where: { project_id: req.body.project_id, status: '1' },
      })

      if (taskOnProject && taskOnProject.length > 0) {
        await Promise.all(
          taskOnProject.map(async task => {
            await ProjectCustomFieldTypeValueModel.create({
              project_id: req.body.project_id,
              type_id: req.body.field_type_id,
              task_id: task.id,
              created_by_val: task.created_by,
              created_at_val: task.created_at,
              type_key_id: projectField.id,
              created_by: req.user.id,
            })
          })
        )
      }

      // const optionsArray = req.body.field_options.split(',').map(option => option.trim());

      // const bulkInsertData = optionsArray.map(optionName => ({
      //   option_name: optionName,
      //   type_key_id: projectField.id,
      //   created_by: req.user.id,
      // }));

      // if (bulkInsertData.length > 0) {
      //   await ProjectCustomFieldTypeOptions.bulkCreate(bulkInsertData);
      // }

      return res.status(200).send({
        message: 'Field Added Successfully',
        data: projectField,
        success: true,
        status: 1,
      })
    } catch (error) {
      console.error('CreateProject Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const deleteCustomFieldOptions = async (req, res) => {
  const schema = Joi.object().keys({
    option_id: Joi.number().required(),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    option_id: req.body.option_id,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const customFieldOptionUpd = await ProjectCustomFieldTypeOptions.update(
        {
          status: '0',
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.option_id, // your condition here
          },
        }
      )

      if (customFieldOptionUpd) {
        return res.status(200).send({
          message: 'option Deleted Successfully',
          // data: projectCustomFieldUpdate,
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Option Removed Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const customFieldOptionList = async (req, res) => {
  try {
    const schema = Joi.object({
      type_key_id: Joi.number().integer().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
      })
    }
    const fieldOptions = await ProjectCustomFieldTypeOptions.findAll({
      where: {
        status: '1',
        type_key_id: value.type_key_id,
      },
      // attributes: ["id", "sr_no", "option_name", "is_selected", "type_key_id"]
    })

    return res.status(200).send({
      message: 'Record Found',
      success: true,
      status: '1',
      data: fieldOptions,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const CreateProject = async (req, res) => {
  const { project_name, user_ids, ...rest } = req.body

  if (!project_name) {
    return res.status(400).send({
      message: 'project_name is required',
      success: false,
      error: true,
      status: '0',
    })
  }

  if (!user_ids || typeof user_ids !== 'string') {
    return res.status(400).send({
      message: 'user_ids must be a comma-separated string',
      success: false,
      error: true,
      status: '0',
    })
  }

  try {
    const existingProject = await Project.findOne({
      where: { project_name, status: '1' },
    })

    if (existingProject) {
      return res.status(409).send({
        message: 'A project with this name already exists.',
        success: false,
        error: true,
        status: '0',
      })
    }

    // Convert string to array of valid integers
    const userIds = user_ids
      .split(',')
      .map(id => parseInt(id.trim()))
      .filter(id => !isNaN(id))

    if (userIds.length === 0) {
      return res.status(400).send({
        message: 'No valid user IDs provided',
        success: false,
        status: '0',
      })
    }

    const userIdsString = userIds.join(',')

    // Create team member
    const team = await TeamMember.create({
      // name: project_name,
      user_ids: userIdsString,
      created_by: req.user.id,
    })
    // Create project
    const projectData = {
      project_name,
      team_id: team.id,
      project_status: 2,
      priority: 2,
      ...rest,
      created_by: req.user.id,
    }

    const project = await Project.create(projectData)

    if (project) {
      // Update team with project_id
      await TeamMember.update(
        { project_id: project.id },
        { where: { id: team.id } }
      )

      const insertObj = [
        { type: 'text_val', label: 'Name', type_id: 1, sr_no: 1 },
        { type: 'rich_text', label: 'Description', type_id: 18, sr_no: 2 },
        { type: 'person_val', label: 'Assigned To', type_id: 6, sr_no: 3 },
        { type: 'select_val', label: 'Priority', type_id: 2, sr_no: 4 },
        { type: 'date_val', label: 'Deadline', type_id: 5, sr_no: 5 },
        { type: 'select_val', label: 'Status', type_id: 2, sr_no: 6 },
        { type: 'select_val', label: 'Assigned By', type_id: 2, sr_no: 7 },
        {
          type: 'estimated_val',
          label: 'Estimated Time',
          type_id: 19,
          sr_no: 8,
        },

        // { type: "text_val", label: "Name", type_id: 1 },
        // { type: "rich_text", label: "Description", type_id: 18 },
        // { type: "multi_select_val", label: "Assigned To", type_id: 4 },
        // { type: "select_val", label: "Priority", type_id: 2 },
        // { type: "date_val", label: "Deadline", type_id: 5 },
        // { type: "select_val", label: "Status", type_id: 2 },
        // { type: "select_val", label: "Assigned By", type_id: 2 },
        // { type: "estimated_val", label: "Estimated Time", type_id: 19 },
      ]

      for (const field of insertObj) {
        if (field.type === 'select_val' && field.label === 'Priority') {
          const createdField = await ProjectCustomFieldTypeKeyModel.create({
            project_id: project.id ? project.id : 99999,
            sr_no: field.sr_no,
            type_id: field.type_id,
            label_name: field.label,
            is_default: 1,
            config_detail: field.type,
            created_by: req.user.id,
            updated_by: req.user.id,
          })

          const options = ['Low', 'Medium', 'High']
          for (const [index, option] of options.entries()) {
            await ProjectCustomFieldTypeOptions.create({
              type_key_id: createdField.id,
              sr_no: index + 1,
              option_name: option,
              color: '#9CA3AF',
              created_by: req.user.id,
              updated_by: req.user.id,
            })
          }
        } else if (field.type === 'select_val' && field.label === 'Status') {
          const createdField = await ProjectCustomFieldTypeKeyModel.create({
            project_id: project.id ? project.id : 99999,
            sr_no: field.sr_no,
            type_id: field.type_id,
            label_name: field.label,
            is_default: 1,
            config_detail: field.type,
            created_by: req.user.id,
            updated_by: req.user.id,
          })

          const options = ['Not-started', 'Inprogress', 'Completed']
          for (const [index, option] of options.entries()) {
            await ProjectCustomFieldTypeOptions.create({
              type_key_id: createdField.id,
              sr_no: index + 1,
              option_name: option,
              is_disabled: '1',
              color: '#9CA3AF',
              created_by: req.user.id,
              updated_by: req.user.id,
            })
          }
        } else if (
          field.type === 'select_val' &&
          field.label === 'Assigned By'
        ) {
          const createdField = await ProjectCustomFieldTypeKeyModel.create({
            project_id: project.id ? project.id : 99999,
            sr_no: field.sr_no,
            type_id: field.type_id,
            label_name: field.label,
            is_default: 0,
            config_detail: field.type,
            created_by: req.user.id,
            updated_by: req.user.id,
          })

          for (const [index, option] of userIds.entries()) {
            const userData = await User.findOne({
              where: { id: option, isactive: 1 },
            })
            if (userData) {
              await ProjectCustomFieldTypeOptions.create({
                type_key_id: createdField.id,
                sr_no: index + 1,
                option_name: userData.userfullname,
                color: '#9CA3AF',
                created_by: req.user.id,
                updated_by: req.user.id,
              })
            }
          }
        } else if (
          field.type === 'multi_select_val' &&
          field.label === 'Assigned To'
        ) {
          const createdField = await ProjectCustomFieldTypeKeyModel.create({
            project_id: project.id ? project.id : 99999,
            sr_no: field.sr_no,
            type_id: field.type_id,
            label_name: field.label,
            is_default: 0,
            config_detail: field.type,
            created_by: req.user.id,
            updated_by: req.user.id,
          })

          for (const [index, option] of userIds.entries()) {
            const userData = await User.findOne({
              where: { id: option, isactive: 1 },
            })
            if (userData) {
              await ProjectCustomFieldTypeOptions.create({
                type_key_id: createdField.id,
                sr_no: index + 1,
                option_type: '2',
                option_name: userData.userfullname,
                color: '#9CA3AF',
                created_by: req.user.id,
                updated_by: req.user.id,
              })
            }
          }
        }
        // else if (field.type === "created_by_val" || field.type === "created_at_val" || field.type === "updated_by_val" || field.type === "updated_at_val") {
        //       const createdField = await ProjectCustomFieldTypeKeyModel.create({
        //             project_id: project.id ? project.id : "",
        //             type_id: field.type_id,
        //             label_name: field.label,
        //             is_default: 0,
        //             config_detail: field.type,
        //             created_by: req.user.id,
        //             updated_by: req.user.id,
        //       });
        // }
        else {
          const createdField = await ProjectCustomFieldTypeKeyModel.create({
            project_id: project.id ? project.id : 99999,
            sr_no: field.sr_no,
            type_id: field.type_id,
            label_name: field.label,
            config_detail: field.type,
            created_by: req.user.id,
            updated_by: req.user.id,
          })
        }

        // if (field.type === 'select_val' && field.label === 'Priority') {
        //   const options = ['Low', 'Medium', 'High'];
        //   for (const [index, option] of options.entries()) {
        //     await ProjectCustomFieldTypeOptions.create({
        //       type_key_id: createdField.id,
        //       sr_no: index + 1,
        //       option_name: option,
        //       color:'#9CA3AF',
        //       created_by: req.user.id,
        //       updated_by: req.user.id,
        //     });
        //   }
        // }

        // else if(field.type === 'select_val' && field.label === 'Status'){
        //   const options = ['Started', 'In-Progress', 'Completed'];
        //   for (const [index, option] of options.entries()) {
        //     await ProjectCustomFieldTypeOptions.create({
        //       type_key_id: createdField.id,
        //       sr_no: index + 1,
        //       option_name: option,
        //       color:'#9CA3AF',
        //       created_by: req.user.id,
        //       updated_by: req.user.id,
        //     });
        //   }
        // }
      }
    }

    const finalProject = await Project.findOne({
      where: { id: project.id },
      include: [
        {
          model: TeamMember,
          as: 'team',
        },
        {
          model: ProjectCustomFieldTypeKeyModel,
          as: 'customFieldKeys',
        },
        {
          model: ProjectAttachmentsModel,
          as: 'attachment',
          where: { status: '1' },
          required: false,
        },
      ],
    })

    return res.status(200).send({
      message: 'Project created successfully',
      success: true,
      status: '1',
      data: finalProject,
    })
  } catch (error) {
    console.error(error)
    return res.status(500).send({
      message: 'An error occurred while creating the project',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const storageProjectFiles = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/project_attachments/') // Specify the directory where the files will be stored
  },
  filename: (req, file, cb) => {
    // Ensure unique file names by appending timestamp
    cb(null, file.originalname)
  },
})

const uploadMultiple = multer({
  storage: storageProjectFiles,
  fileFilter: fileFilter,
})

const updateProject = async (req, res) => {
  // uploadMultiple.array("files")(req, res, async (err) => {
  //   if (err) {
  //     return res.status(400).send({
  //       message: "File upload failed",
  //       success: false,
  //       error: err.message,
  //       status: "0",
  //     });
  //   } else {
  try {
    const { project_name, user_ids, ...rest } = req.body
    const estimatedTime = req.body.estimated_time
    if (estimatedTime) {
      const regex = /^(\d+w)?\s*(\d+d)?\s*(\d+h)?\s*(\d+m)?$/
      if (!regex.test(estimatedTime.trim()) || estimatedTime.trim() === '') {
        return res.status(400).send({
          message:
            "Invalid estimated time format. Use format like '15w 9d 14h 10m'",
          success: false,
          error: 'Invalid estimated time format',
          status: '0',
        })
      }
    }

    const projectExist = await Project.findOne({
      where: { project_name: req.body.project_name },
    })
    if (projectExist) {
      const projectTeam = await TeamMember.findOne({
        where: {
          project_id: projectExist.id,
          user_ids: {
            [Op.like]: `%${req.user.id}%`,
          },
        },
      })

      // if (projectTeam) {
      //   const teamArray = projectTeam.user_ids.split(',').map(id => id.trim());
      //   const userId = req.user.id.toString();

      //   if (teamArray.includes(userId)) {
      //     return res.status(400).send({
      //       message: "Project Name Already Exist for this user",
      //       success: false,
      //       error: "Project Name already exists for this user",
      //       status: "0",
      //     });
      //   }
      // }
    }

    if (!req.body.project_id) {
      return res.status(400).send({
        message: 'Missing required fields',
        success: false,
        error: 'project ID is required',
        status: '0',
      })
    }

    // console.log(req.files,"rewq files ");

    // if (req.files && req.files.length > 0) {

    //   const attachmentsData = req.files.map((file) => ({
    //     project_id: req.body.project_id,
    //     file_name: file.filename,
    //     file_path: file.path,
    //     file_size: file.size,
    //     created_by: req.user.id,
    //   }));

    //   await ProjectAttachmentsModel.bulkCreate(attachmentsData);
    // }

    const updateProject = await Project.update(
      {
        project_name: req.body.project_name,
        description: req.body.description,
        start_date: req.body.start_date ? req.body.start_date : null,
        end_date: req.body.end_date ? req.body.end_date : null,
        priority: req.body.priority ? req.body.priority : null,
        estimated_time: req.body.estimated_time
          ? req.body.estimated_time
          : null,
        project_status: req.body.project_status
          ? req.body.project_status
          : null,
        project_lead_ids: req.body.project_lead_ids
          ? req.body.project_lead_ids
          : null,
        // priority: req.body.priority ? req.body.priority : null,
        updated_by: req.user.id,
        updated_at: new Date(),
      },
      { where: { status: '1', id: req.body.project_id } }
    )

    const updateTeamOnProj = await TeamMember.update(
      {
        user_ids: req.body.user_ids,
        updated_by: req.user.id,
        updated_at: new Date(),
      },
      {
        where: { status: '1', project_id: req.body.project_id },
      }
    )

    const customFieldKeys = await ProjectCustomFieldTypeKeyModel.findAll({
      where: {
        project_id: req.body.project_id,
        [Op.or]: [
          { label_name: 'Assigned To' },
          { label_name: 'Assigned By' },
          // { config_detail: "person_val" }
        ],
      },
    })

    if (customFieldKeys && customFieldKeys.length > 0) {
      const user_ids = req.body.user_ids
        ?.split(',')
        .map(id => parseInt(id.trim()))
        .filter(Boolean)

      const users = await User.findAll({
        where: {
          id: user_ids,
        },
      })

      const userIdNameMap = {}
      users.forEach(user => {
        userIdNameMap[user.id] = user.userfullname
      })

      for (const key of customFieldKeys) {
        await ProjectCustomFieldTypeOptions.destroy({
          where: { type_key_id: key.id },
        })

        let sr_no = 1
        const newOptions = []

        user_ids.forEach(user_id => {
          const userName = userIdNameMap[user_id]

          if (userName) {
            newOptions.push({
              option_name: userName,
              sr_no: sr_no++,
              color: '#9CA3AF',
              option_type: key.label_name == 'Assigned To' ? '2' : '1',
              is_selected: '0',
              type_key_id: key.id,
              status: '1',
              created_by: req.user?.id || null,
            })
          }
        })

        if (newOptions.length > 0) {
          await ProjectCustomFieldTypeOptions.bulkCreate(newOptions)
        }
      }

      console.log('Options updated successfully.')
    }

    if (updateProject && updateTeamOnProj) {
      const projectList = await ProjectsModel.findOne({
        where: {
          id: req.body.project_id,
          status: '1',
        },
      })
      // Return the response
      return res.status(200).send({
        message: 'Project updated successfully',
        success: true,
        error: false,
        status: '1',
        data: projectList,
      })
    }
  } catch (error) {
    console.error('CreateProject Error:', error)
    return res.status(500).json({ status: false, error: error.message })
  }
  //   }
  // });
}

const updateProjectMembers = async (req, res) => {
  try {
    const schema = Joi.object({
      project_id: Joi.number().required(),
      user_ids: Joi.string().optional(),
      project_lead_ids: Joi.string().optional(),
    })

    const { value, error } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        error: true,
        status: '0'
      })
    }

    const projectExist = await Project.findOne({
      where: { id: value.project_id },
    })
    if (projectExist) {

      if (!value.project_lead_ids && !value.user_ids) {
        return res.status(400).json({
          message: 'Missing required fields. Provide either project lead or member'
        })
      }

      if (value.project_lead_ids) {
        const updateProject = await Project.update(
          {
            project_lead_ids: req.body.project_lead_ids,
            updated_by: req.user.id,
            updated_at: new Date(),
          },
          { where: { status: '1', id: req.body.project_id } }
        )

      }

      if (value.user_ids) {

        const updateTeamOnProj = await TeamMember.update(
          {
            user_ids: req.body.user_ids,
            updated_by: req.user.id,
            updated_at: new Date(),
          },
          {
            where: { status: '1', project_id: req.body.project_id },
          }
        )

      }

      return res.status(200).send({
        message: 'Members updated successfully',
        success: true,
        error: false,
        status: '1',
      })
    }
    else {
      return res.status(404).json({
        message: 'Project not found',
        error: true,
        success: false,
        status: '0'
      })
    }

  } catch (error) {
    return res.status(500).json({ message: 'Something went wrong', status: false, error: error.message })
  }

}

const ProjectList = async (req, res) => {
  try {
    const userId = req.user.id
    console.log(userId, 'userId')

    const projects = await Project.findAll({
      where: {
        status: '1',
        [Op.or]: [
          { created_by: userId },
          Sequelize.where(
            Sequelize.fn('FIND_IN_SET', userId, Sequelize.col('team.user_ids')),
            {
              [Op.gt]: 0,
            }
          ),
        ],
      },
      include: [
        {
          model: TeamMember,
          as: 'team',
          required: true,
        },
        {
          model: ProjectCustomFieldTypeKeyModel,
          as: 'customFieldKeys',
        },
        {
          model: ProjectAttachmentsModel,
          where: { status: '1' },
          as: 'attachment',
          required: false,
        },
      ],
      order: [['id', 'DESC']],
    })

    return res.status(200).send({
      message: 'Project found',
      success: true,
      error: false,
      status: '1',
      data: projects,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

// ################ Code By Prajwal Date:- 10-04-2025 ###################

const ProjectTaskListOld = async (req, res) => {
  try {
    const tasks = await ProjectTask.findAll({
      where: {
        status: '1',
      },
    })

    if (tasks.length > 0) {
      const taskMap = {}
      const taskList = []

      tasks.forEach(task => {
        taskMap[task.id] = { ...task.dataValues, children: [] }
        if (task.parent_id === 0) {
          taskList.push(taskMap[task.id])
        }
      })
      tasks.forEach(task => {
        if (task.parent_id !== 0 && taskMap[task.parent_id]) {
          taskMap[task.parent_id].children.push(taskMap[task.id])
        }
      })

      return res.status(200).send({
        message: 'Project Tasks found',
        success: true,
        error: false,
        status: '1',
        data: taskList,
      })
    } else {
      return res.status(404).send({
        message: 'No tasks found for this project',
        success: false,
        error: true,
        status: '0',
      })
    }
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const ProjectTaskList = async (req, res) => {
  try {
    const schema = Joi.object({
      project_id: Joi.number().integer().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
      })
    }
    const tasks = await ProjectTask.findAll({
      where: {
        status: '1',
        project_id: value.project_id,
      },
      include: [
        {
          model: ProjectCustomFieldTypeValueModel,
          as: 'task_fields',
          required: false,
          include: [
            {
              model: ProjectCustomFieldTypeOptions,
              required: false,
              as: 'single_select',
              where: {
                option_type: '1',
                status: '1',
              },
              include: {
                model: User,
                required: false,
                attributes: ['id', 'userfullname', 'emailaddress'],
              },
              // attributes: ['id', 'option_name', 'is_selected']
            },
            {
              model: ProjectCustomFieldTypeOptions,
              required: false,
              as: 'multi_select',
              where: {
                option_type: '2',
                status: '1',
              },
              include: {
                model: User,
                required: false,
                attributes: ['id', 'userfullname', 'emailaddress'],
              },
              // attributes: ['id', 'option_name', 'is_selected']
            },
            {
              model: User,
              as: 'creater',
              required: false,
              attributes: ['id', 'userfullname', 'emailaddress'],
            },
            {
              model: User,
              as: 'updater',
              required: false,
              attributes: ['id', 'userfullname', 'emailaddress'],
            },
          ],
        },
        {
          model: User,
          as: 'creater',
          required: false,
          attributes: ['id', 'userfullname', 'emailaddress'],
        },
        {
          model: User,
          as: 'updater',
          required: false,
          attributes: ['id', 'userfullname', 'emailaddress'],
        },
      ],
      attributes: [
        'id',
        'sr_no',
        'parent_id',
        'task_name',
        'project_id',
        'status',
      ],

      order: [['sr_no', 'ASC']],
    })

    const typeKeys = await ProjectCustomFieldTypeKeyModel.findAll({
      where: {
        status: '1',
        project_id: value.project_id,
      },
      // attributes: [
      //   "id",
      //   "project_id",
      //   "type_id",
      //   "label_name",
      //   "config_detail",
      //   "status",
      // ],
    })

    if (tasks.length === 0) {
      return res.status(404).send({
        message: 'No tasks found for this project',
        success: false,
        error: true,
        status: '0',
      })
    }

    const projectMembers = await TeamMember.findOne({
      where: {
        project_id: value.project_id,
        status: '1',
      },
    })

    let Members = []

    if (projectMembers) {
      const members = projectMembers.dataValues.user_ids.split(',')

      if (Array.isArray(members)) {
        const allusers = await User.findAll({
          where: {
            id: members,
            isactive: '1',
          },
          attributes: ['id', 'userfullname', 'emailaddress'],
        })

        Members = allusers
      }
    }

    // Step 1: Create a map of tasks
    const taskMap = {}
    tasks.forEach(task => {
      taskMap[task.id] = { ...task.dataValues, children: [] }
    })

    // Step 2: Build the tree
    const buildTree = () => {
      const rootTasks = []
      tasks.forEach(task => {
        const mappedTask = taskMap[task.id]
        if (task.parent_id && taskMap[task.parent_id]) {
          taskMap[task.parent_id].children.push(mappedTask)
        } else {
          rootTasks.push(mappedTask)
        }
      })
      return rootTasks
    }

    const taskTree = buildTree()

    const cleanedTree = await Promise.all(
      taskTree.map(async task => {
        const cleanTask = JSON.parse(JSON.stringify(task)) // deep clone

        const processFields = async t => {
          for (const field of t.task_fields) {
            // If type_id is '6', empty the single_select
            if (field.type_id == '6') {
              field.multi_select = Members
            }

            // If type_id is '4', fetch ProjectTask data into single_select
            if (field.type_id == '9') {
              const relatedTasks = await ProjectTask.findAll({
                where: {
                  status: '1',
                  project_id: t.project_id,
                  id: {
                    [Op.ne]: t.id, // Not equal to current task id
                  },
                },
                attributes: ['id', 'task_name', 'sr_no', 'parent_id'],
                order: [['sr_no', 'ASC']],
              })

              field.multi_select = relatedTasks.map(r => ({
                id: r.id,
                task_name: r.task_name,
              }))
            }
          }

          // Recursively process children
          if (t.children && t.children.length) {
            t.children = await Promise.all(t.children.map(processFields))
          }

          return t
        }

        return await processFields(cleanTask)
      })
    )

    return res.status(200).send({
      message: 'Project Tasks found',
      success: true,
      error: false,
      status: '1',
      data: cleanedTree,
      typeKeys: typeKeys,
      Members,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/project_task/') // Specify the directory where the files will be stored
  },
  filename: (req, file, cb) => {
    // Ensure unique file names by appending timestamp
    cb(null, file.originalname)
  },
})

// Initialize multer with storage and fileFilter
const upload = multer({ storage: storage, fileFilter: fileFilter })

// const ProjectTaskAddOld = async (req, res) => {
//   try {
//     if (!req.user || !req.user.id) {
//       return res.status(400).send({
//         message: "User is not authenticated",
//         success: false,
//         error: "No user found in request",
//         status: "0",
//       });
//     }

//     // Use req.user.id for created_by
//     const createdBy = req.user.id;

//     // Handle the file upload in the request
//     upload.single("attachment")(req, res, async (err) => {
//       if (err) {
//         return res.status(400).send({
//           message: "File upload failed",
//           success: false,
//           error: err.message,
//           status: "0",
//         });
//       }

//       const projectTask = await ProjectTask.findOne({
//         where: { task_name: req.body.task_name },
//       });
//       if (projectTask) {
//         return res.status(400).send({
//           message: "Task Name Already Exist",
//           success: false,
//           error: "Task ame already exist",
//           status: "0",
//         });
//       }

//       // Get the task data from the request body
//       const {
//         task_name,
//         project_id,
//         summary,
//         due_date,
//         description,
//         reporter,
//         assignee,
//         priority_id,
//         team_id,
//         label,
//         urgancy,
//         pending_reason,
//         issue_status_id,
//         linked_issue_id,
//         sr_no,
//         time_duration,
//         parent_id, // Parent task ID (optional)
//       } = req.body;

//       // If no parent_id is provided, set it to 0
//       const parentId = parent_id ? parseInt(parent_id) : 0;

//       // Check if the parent_id exists in the database (if it's not 0)
//       if (parentId !== 0) {
//         const parentTask = await ProjectTask.findOne({
//           where: { id: parentId },
//         });
//         if (!parentTask) {
//           return res.status(400).send({
//             message: `Parent task with ID ${parentId} not found`,
//             success: false,
//             error: `Parent task with ID ${parentId} does not exist`,
//             status: "0",
//           });
//         }
//       }

//       // Check if the required fields are provided
//       if (!task_name || !project_id) {
//         return res.status(400).send({
//           message: "Missing required fields",
//           success: false,
//           error: "Task name and project ID are required",
//           status: "0",
//         });
//       }

//       // Save the task to the database
//       const newTask = await ProjectTask.create({
//         task_name,
//         project_id,
//         summary,
//         due_date,
//         description,
//         reporter,
//         assignee,
//         priority_id,
//         team_id,
//         label,
//         urgancy,
//         pending_reason,
//         issue_status_id,
//         linked_issue_id,
//         sr_no,
//         time_duration,
//         attachment: req.file ? req.file.path : null, // Attach file path if available
//         parent_id: parentId, // Use the parent_id if provided, otherwise 0
//         status: "1", // Example: set the status as '1' for active
//         created_by: createdBy, // Set created_by to req.user.id
//         created_at: new Date(),
//         updated_by: createdBy,
//         updated_at: new Date(),
//       });

//       // Return the response
//       return res.status(200).send({
//         message: "Task created successfully",
//         success: true,
//         error: false,
//         status: "1",
//         data: newTask,
//       });
//     });
//   } catch (error) {
//     console.error(error);
//     return res.status(500).send({
//       message: "Something went wrong",
//       success: false,
//       error: error.message,
//       status: "0",
//     });
//   }
// };

const ProjectTaskAdd = async (req, res) => {
  try {
    const schema = Joi.object({
      sr_no: Joi.number().required(),
      parent_id: Joi.number().required(),
      project_id: Joi.number().required(),
      task_name: Joi.string().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        success: false,
        error: true,
      })
    }

    value.created_by = req.user.id

    const addTask = await ProjectTask.create(value)

    console.log(addTask.id, 'is newly created id')

    const typeKeys = await ProjectCustomFieldTypeKeyModel.findAll({
      where: {
        project_id: value.project_id,
        status: '1',
      },
      attributes: ['id', 'label_name', 'type_id', 'config_detail'],
    })

    const result = Promise.all(
      typeKeys.map(async key => {
        const nullInsertObj = {
          project_id: value.project_id,
          type_id: key.type_id,
          task_id: addTask.id,
          type_key_id: key.id,
          created_by: req.user.id,
        }

        if (key.label_name == 'Name') {
          nullInsertObj.text_val = value.task_name
          const createFieldWithName =
            await ProjectCustomFieldTypeValueModel.create(nullInsertObj)
        } else if (key.config_detail == 'created_by_val') {
          nullInsertObj.created_by_val = req.user.id
          const createFieldWithName =
            await ProjectCustomFieldTypeValueModel.create(nullInsertObj)
        } else if (key.config_detail == 'created_at_val') {
          nullInsertObj.created_at_val = Date.now()

          const createFieldWithName =
            await ProjectCustomFieldTypeValueModel.create(nullInsertObj)
        } else {
          const createFieldWithName =
            await ProjectCustomFieldTypeValueModel.create(nullInsertObj)
        }
      })
    )

    return res.status(200).json({
      message: 'Task Added',
      status: '1',
      error: false,
      success: true,
    })
  } catch (error) {
    console.error(error)
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const ProjectTaskUpdate = async (req, res) => {
  try {
    const schema = Joi.object({
      id: Joi.number().integer().required(),
      sr_no: Joi.number().required(),
      parent_id: Joi.number().required(),
      project_id: Joi.number().required(),
      task_name: Joi.string().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        success: false,
        error: true,
      })
    }

    value.updated_by = req.user.id
    value.updated_at = Date.now()

    const updateTask = await ProjectTask.update(value, {
      where: {
        id: value.id,
      },
    })

    if (!updateTask)
      return res.status(500).json({
        message: 'Something went wrong',
        error: true,
        success: false,
        status: '0',
      })

    return res.status(200).json({
      message: 'Task Updated',
      status: '1',
      error: false,
      success: true,
    })
  } catch (error) {
    console.error(error)
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const ProjectTaskDelete = async (req, res) => {
  try {
    const schema = Joi.object({
      id: Joi.number().integer().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        success: false,
        error: true,
      })
    }

    value.updated_by = req.user.id
    value.updated_at = Date.now()
    value.status = '0'

    const deleteTask = await ProjectTask.update(value, {
      where: {
        id: value.id,
      },
    })

    // Recursive function to update all child tasks
    const updateChildTasks = async parentId => {
      // Get all child tasks (tasks whose parent_id matches the current task)
      const childTasks = await ProjectTask.findAll({
        where: { parent_id: parentId },
      })

      // If there are child tasks, update their status
      if (childTasks.length > 0) {
        for (let child of childTasks) {
          // Set the child task's status to '0'
          await ProjectTask.update(
            {
              status: '0',
              updated_by: req.user.id,
              updated_at: Date.now(),
            },
            {
              where: {
                id: child.id,
              },
            }
          )

          // Recursively update the child's children (if any)
          await updateChildTasks(child.id)
        }
      }
    }

    // Call the recursive function for the parent task to delete its children
    await updateChildTasks(value.id)

    if (!deleteTask)
      return res.status(500).json({
        message: 'Something went wrong',
        error: true,
        success: false,
        status: '0',
      })

    return res.status(200).json({
      message: 'Task Deleted',
      status: '1',
      error: false,
      success: true,
    })
  } catch (error) {
    console.error(error)
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const TaskCommentList = async (req, res) => {
  try {
    const taskId = req.body.task_id
    if (!taskId) {
      return res.status(400).send({
        message: 'task_id is required',
        success: false,
        error: true,
        status: '0',
      })
    }
    const tasks = await TaskComment.findAll({
      where: {
        status: '1',
        task_id: taskId,
      },
      include: [
        {
          model: User,
          as: 'comment_by',
          attributes: ['id', 'userfullname'], // Adjust based on your User model
        },
      ],
      order: [['created_at', 'ASC']],
    })

    if (tasks.length > 0) {
      const taskMap = {}
      const taskCommentList = []

      tasks.forEach(task => {
        taskMap[task.id] = { ...task.dataValues, childComment: [] }
        if (task.parent_id === 0) {
          taskCommentList.push(taskMap[task.id])
        }
      })
      tasks.forEach(task => {
        if (task.parent_id !== 0 && taskMap[task.parent_id]) {
          taskMap[task.parent_id].childComment.push(taskMap[task.id])
        }
      })

      return res.status(200).send({
        message: 'Task Comments found',
        success: true,
        error: false,
        status: '1',
        data: taskCommentList,
      })
    } else {
      return res.status(404).send({
        message: 'No Comments found on this task',
        success: false,
        error: true,
        status: '0',
      })
    }
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const taskOrderUpdate = async (req, res) => {
  try {
    const { task_id, to_task_id } = req.body
    if (!task_id) {
      return res.status(400).send({
        message: 'Invalid request, task id is required.',
        success: false,
        error: true,
        status: '0',
      })
    }

    const updObj = {
      parent_id: to_task_id ? to_task_id : 0,
    }
    const updated = await ProjectTask.update(updObj, {
      where: {
        id: task_id,
        status: '1',
      },
    })
    if (updated) {
      return res.status(200).send({
        message: 'Task order updated successfully.',
        success: true,
        error: false,
        status: '1',
      })
    } else {
      return res.status(404).send({
        message: 'no changes made.',
        success: false,
        error: true,
        status: '0',
      })
    }
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong.',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

// const updateTaskField_old = async (req, res) => {
//   try {
//     const schema = Joi.object({
//       id: Joi.number().integer().optional(),
//       project_id: Joi.number().integer().required(),
//       type_id: Joi.number().integer().required(),
//       task_id: Joi.number().integer().required(),
//       type_key_id: Joi.number().integer().required(),
//       data: Joi.any().required(),
//     });

//     const { error, value } = await schema.validate(req.body);

//     if (error) {
//       return res.status(400).json({
//         message: error.message,
//         error: true,
//         success: false,
//         status: "0",

//       });
//     }

//     if (!req.body.id) {

//       let columnName = await ProjectCustomFieldsModel.findOne({
//         where: {
//           status: '1',
//           id: value.type_id
//         },
//         attributes: ["id", "field_code", "field_name"],

//       })

//       if (!columnName) {
//         return res.status(404).json({
//           message: 'Invalid type_id',
//           status: '0',
//           error: true
//         })
//       }
//       columnName = columnName.field_code;

//       console.log(columnName, 'is column name')

//       let createObj = {
//         project_id: value.project_id,
//         task_id: value.task_id,
//         type_id: value.type_id,
//         type_key_id: value.type_key_id,
//         [columnName]: value.data,
//         created_by: req.user.id,
//         created_at: Date.now(),
//       };

//       const create = await ProjectCustomFieldTypeValueModel.create(createObj);

//       console.log(create, 'create')

//       return res.status(200).json({
//         message: "Record Inserted",
//         status: "1",
//       });

//     }

//     const existingEntry = await ProjectCustomFieldTypeValueModel.findOne({
//       where: {
//         status: "1",
//         id: value.id
//       },
//     });

//     if (existingEntry) {

//       const typeDetails = await ProjectCustomFieldsModel.findOne({
//         where: {
//           status: "1",
//           id: existingEntry.dataValues.type_id,
//         },
//         attributes: ["id", "field_code", "field_name"],
//       });

//       if (!typeDetails) {
//         return res.status(400).json({
//           message: "Invalid value type",
//           status: "0",
//         });
//       }

//       const columnName = typeDetails.field_code;

//       if (columnName == 'select_val') {

//         let data = req.body.data

//         if (!Number(data)) {
//           return res.status(400).json({
//             message: 'Please provide a number (data)',
//             status: '0'
//           })
//         }

//         const updateObj = {
//           select_val: data,
//           updated_by: req.user.id,
//           updated_at: Date.now()
//         }

//         await existingEntry.update(updateObj)

//         await ProjectCustomFieldTypeOptions.update({ is_selected: '0' }, {
//           where: {
//             type_key_id: value.type_key_id
//           }
//         })

//         await ProjectCustomFieldTypeOptions.update({ is_selected: '1' }, {
//           where: {
//             id: data
//           }
//         })

//       } else if (columnName == 'multi_select_val') {

//         let data = req.body.data

//         const ids = data.split(',')

//         if (!Array.isArray(ids)) {
//           return res.status(400).json({
//             message: 'Please provide comma seprated ids (data)',
//             status: '0',
//             error: 'Please provide array of ids'
//           })
//         }

//         const updateObj = {
//           multi_select_val: data,
//           updated_by: req.user.id,
//           updated_at: Date.now()
//         }

//         await existingEntry.update(updateObj)

//         await ProjectCustomFieldTypeOptions.update({ is_selected: '0' }, {
//           where: {
//             type_key_id: value.type_key_id
//           }
//         })

//         await ProjectCustomFieldTypeOptions.update({ is_selected: '1' }, {
//           where: {
//             id: {
//               [Op.in]: ids
//             }
//           }
//         })

//       } else {

//         console.log(existingEntry)

//         const updateObj = {
//           [columnName]: req.body.data,
//           updated_by: req.user.id,
//           updated_at: Date.now()
//         }

//         await existingEntry.update(updateObj)

//       }

//       return res.status(200).json({
//         message: "Record updated",
//         status: "1",
//       });
//     } else {

//       return res.status(404).json({
//         message: 'Record not found',
//         status: '0',
//         error: true,
//         success: false
//       })

//     }
//   } catch (error) {
//     console.log(error.message);
//     return res.status(500).json({
//       message: "Something went wrong",
//       status: "0",
//       error: error.message,
//       success: false,
//     });
//   }
// };

const TaskAttachmentStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const uploadPath = `uploads/Projects/tasks`
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true })
      }
      cb(null, uploadPath)
    } catch (err) {
      cb(err) // In case of an error, pass it to multer
    }
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname)
  },
})

const TaskAttachmentUpload = multer({ storage: TaskAttachmentStorage })

const updateTaskField = async (req, res) => {
  TaskAttachmentUpload.single('file')(req, res, async err => {
    if (err) {
      console.error('Multer Error:', err)
      return res.status(500).json({
        message: 'File upload error',
        error: true,
        success: false,
        status: '0',
      })
    }

    try {
      const schema = Joi.object({
        id: Joi.number().integer().optional(),
        project_id: Joi.number().integer().required(),
        type_id: Joi.number().integer().required(),
        task_id: Joi.number().integer().required(),
        type_key_id: Joi.number().integer().required(),
        data: Joi.any().required(),
        file: Joi.any().optional(),
      })

      const { error, value } = await schema.validate(req.body)

      if (error) {
        return res.status(400).json({
          message: error.message,
          error: true,
          success: false,
          status: '0',
        })
      }

      const isTimeStarted = await ProjectTaskTImeRecordModel.findOne({
        where: {
          task_id: req.body.task_id,
          status: '1',
          end_time: null,
        },
      })

      if (isTimeStarted) {
        const isStatus = await ProjectCustomFieldTypeKeyModel.findOne({
          where: {
            id: req.body.type_key_id,
          },
        })

        if (isStatus.label_name == 'Status') {
          return res.status(400).json({
            message:
              'Time Tracker is running on this task. End it before changing the Status',
            error: true,
            success: false,
            status: '0',
          })
          // const isOption = await ProjectCustomFieldTypeOptions.findOne({
          //     where: {
          //       option_name: {
          //         [Op.ne]: "Inprogress",
          //       },
          //     }
          //   });
        }
      }

      if (!req.body.id) {
        let columnName = await ProjectCustomFieldsModel.findOne({
          where: {
            status: '1',
            id: value.type_id,
          },
          attributes: ['id', 'field_code', 'field_name'],
        })

        if (!columnName) {
          return res.status(404).json({
            message: 'Invalid type_id',
            status: '0',
            error: true,
          })
        }
        columnName = columnName.field_code

        console.log(columnName, 'is column name')

        let createObj = {
          project_id: value.project_id,
          task_id: value.task_id,
          type_id: value.type_id,
          type_key_id: value.type_key_id,
          [columnName]: value.data,
          created_by: req.user.id,
          created_at: Date.now(),
        }

        const create = await ProjectCustomFieldTypeValueModel.create(createObj)

        console.log(create, 'create')

        return res.status(200).json({
          message: 'Record Inserted',
          status: '1',
        })
      }

      const existingEntry = await ProjectCustomFieldTypeValueModel.findOne({
        where: {
          status: '1',
          id: value.id,
        },
      })

      if (existingEntry) {
        const typeDetails = await ProjectCustomFieldsModel.findOne({
          where: {
            status: '1',
            id: existingEntry.dataValues.type_id,
          },
          attributes: ['id', 'field_code', 'field_name'],
        })

        if (!typeDetails) {
          return res.status(400).json({
            message: 'Invalid value type',
            status: '0',
          })
        }

        const columnName = typeDetails.field_code

        if (columnName == 'select_val') {
          let data = req.body.data

          if (!Number(data)) {
            return res.status(400).json({
              message: 'Please provide a number (data)',
              status: '0',
            })
          }

          const updateObj = {
            select_val: data,
            updated_by: req.user.id,
            updated_at: Date.now(),
          }

          await existingEntry.update(updateObj)

          await ProjectCustomFieldTypeOptions.update(
            { is_selected: '0' },
            {
              where: {
                type_key_id: value.type_key_id,
              },
            }
          )

          await ProjectCustomFieldTypeOptions.update(
            { is_selected: '1' },
            {
              where: {
                id: data,
              },
            }
          )
        } else if (columnName == 'multi_select_val') {
          let data = req.body.data

          const ids = data.split(',')

          if (!Array.isArray(ids)) {
            return res.status(400).json({
              message: 'Please provide comma seprated ids (data)',
              status: '0',
              error: 'Please provide array of ids',
            })
          }

          const updateObj = {
            multi_select_val: data,
            updated_by: req.user.id,
            updated_at: Date.now(),
          }

          await existingEntry.update(updateObj)

          await ProjectCustomFieldTypeOptions.update(
            { is_selected: '0' },
            {
              where: {
                type_key_id: value.type_key_id,
              },
            }
          )

          await ProjectCustomFieldTypeOptions.update(
            { is_selected: '1' },
            {
              where: {
                id: {
                  [Op.in]: ids,
                },
              },
            }
          )
        } else if (columnName == 'attachment_val') {
          console.log(req.file)

          let data = req.file?.path || null
          const updateObj = {
            attachment_val: data,
            updated_by: req.user.id,
            updated_at: Date.now(),
          }

          await existingEntry.update(updateObj)
        } else {
          console.log(existingEntry)

          const updateObj = {
            [columnName]: req.body.data,
            updated_by: req.user.id,
            updated_at: Date.now(),
          }
          await existingEntry.update(updateObj)
        }

        //Update Details Field Update in Value TYPES MODEL

        const updatedAtValID = await ProjectCustomFieldsModel.findOne({
          where: {
            status: '1',
            field_code: 'updated_at_val',
          },
        })

        const updatedByValID = await ProjectCustomFieldsModel.findOne({
          where: {
            status: '1',
            field_code: 'updated_by_val',
          },
        })

        if (updatedAtValID) {
          await ProjectCustomFieldTypeValueModel.update(
            { updated_at_val: Date.now() },
            {
              where: {
                project_id: value.project_id,
                task_id: value.task_id,
                type_id: updatedAtValID.id,
              },
            }
          )
        }

        if (updatedByValID) {
          await ProjectCustomFieldTypeValueModel.update(
            { updated_by_val: req.user.id },
            {
              where: {
                project_id: value.project_id,
                task_id: value.task_id,
                type_id: updatedByValID.id,
              },
            }
          )
        }

        //END Update Details Field Update in Value TYPES MODEL

        const typeKeyDetails = await ProjectCustomFieldTypeKeyModel.findOne({
          where: {
            id: req.body.type_key_id,
          },
        })

        return res.status(200).json({
          message: 'Record updated',
          status: '1',
          type_key: typeKeyDetails
        })
      } else {
        return res.status(404).json({
          message: 'Record not found',
          status: '0',
          error: true,
          success: false,
        })
      }
    } catch (error) {
      console.log(error.message)
      return res.status(500).json({
        message: 'Something went wrong',
        status: '0',
        error: error.message,
        success: false,
      })
    }
  })
}

// const updateAllFields_old = async (req, res) => {
//   try {
//     const schema = Joi.object({
//       task_id: Joi.number().integer().required(),
//       data: Joi.any().required(),
//     });

//     const { error, value } = await schema.validate(req.body);

//     if (error) {
//       return res.status(400).json({
//         message: error.message,
//         error: true,
//         success: false,
//         status: "0",
//       });
//     }

//     let Bugs = [];

//     let array = [];

//     array = await JSON.parse(req.body.data);

//     const result = Promise.all(
//       array.map(async (field) => {
//         const existingEntry = await ProjectCustomFieldTypeValueModel.findOne({
//           where: {
//             status: "1",
//             id: field.id,
//           },
//         });

//         if (existingEntry) {
//           const typeDetails = await ProjectCustomFieldsModel.findOne({
//             where: {
//               status: "1",
//               id: existingEntry.dataValues.type_id,
//             },
//             attributes: ["id", "field_code", "field_name"],
//           });

//           if (typeDetails) {
//             const columnName = typeDetails.field_code;

//             if (columnName == "select_val") {
//               let data = field.value;

//               // if (!Number(data)) {
//               //   return res.status(400).json({
//               //     message: 'Please provide a number (data)',
//               //     status: '0'
//               //   })
//               // }

//               const updateObj = {
//                 select_val: data,
//                 updated_by: req.user.id,
//                 updated_at: Date.now(),
//               };

//               await existingEntry.update(updateObj);

//               await ProjectCustomFieldTypeOptions.update(
//                 { is_selected: "0" },
//                 {
//                   where: {
//                     type_key_id: existingEntry.dataValues.type_key_id,
//                   },
//                 }
//               );

//               await ProjectCustomFieldTypeOptions.update(
//                 { is_selected: "1" },
//                 {
//                   where: {
//                     id: data,
//                   },
//                 }
//               );
//             } else if (columnName == "multi_select_val") {
//               let data = field.value;

//               const ids = data.split(",");

//               if (Array.isArray(ids)) {
//                 const updateObj = {
//                   multi_select_val: data,
//                   updated_by: req.user.id,
//                   updated_at: Date.now(),
//                 };

//                 await existingEntry.update(updateObj);

//                 await ProjectCustomFieldTypeOptions.update(
//                   { is_selected: "0" },
//                   {
//                     where: {
//                       type_key_id: existingEntry.dataValues.type_key_id,
//                     },
//                   }
//                 );

//                 await ProjectCustomFieldTypeOptions.update(
//                   { is_selected: "1" },
//                   {
//                     where: {
//                       id: {
//                         [Op.in]: ids,
//                       },
//                     },
//                   }
//                 );
//               }
//             } else {
//               const updateObj = {
//                 [columnName]: field.value,
//                 updated_by: req.user.id,
//                 updated_at: Date.now(),
//               };

//               await existingEntry.update(updateObj);
//             }
//           } else {
//             Bugs.push(`Type Details Not found for id ${field.id}`);
//           }
//         } else {
//           Bugs.push(`No Record Found for id ${field.id}`);
//         }
//       })
//     );

//     return res.status(200).json({
//       message: "Record updated",
//       status: "1",
//       result,
//       Bugs,
//     });
//   } catch (error) {
//     console.log(error.message);
//     return res.status(500).json({
//       message: "Something went wrong",
//       status: "0",
//       error: error.message,
//       success: false,
//     });
//   }
// };

const updateAllFields = async (req, res) => {
  TaskAttachmentUpload.single('file')(req, res, async err => {
    if (err) {
      console.error('Multer Error:', err)
      return res.status(500).json({
        message: 'File upload error',
        error: true,
        success: false,
        status: '0',
      })
    }

    try {
      const schema = Joi.object({
        task_id: Joi.number().integer().required(),
        project_id: Joi.number().integer().required(),
        data: Joi.any().required(),
      })

      const { error, value } = await schema.validate(req.body)

      if (error) {
        return res.status(400).json({
          message: error.message,
          error: true,
          success: false,
          status: '0',
        })
      }

      let Bugs = []

      let array = []

      array = await JSON.parse(req.body.data)

      const result = Promise.all(
        array.map(async field => {
          const existingEntry = await ProjectCustomFieldTypeValueModel.findOne({
            where: {
              status: '1',
              id: field.id,
            },
          })

          console.log(existingEntry)

          if (existingEntry) {
            const typeDetails = await ProjectCustomFieldsModel.findOne({
              where: {
                status: '1',
                id: existingEntry.dataValues.type_id,
              },
              attributes: ['id', 'field_code', 'field_name'],
            })

            if (typeDetails) {
              const columnName = typeDetails.field_code

              if (columnName == 'select_val') {
                let data = field.value

                // if (!Number(data)) {
                //   return res.status(400).json({
                //     message: 'Please provide a number (data)',
                //     status: '0'
                //   })
                // }

                const updateObj = {
                  select_val: data,
                  updated_by: req.user.id,
                  updated_at: Date.now(),
                }

                await existingEntry.update(updateObj)

                await ProjectCustomFieldTypeOptions.update(
                  { is_selected: '0' },
                  {
                    where: {
                      type_key_id: existingEntry.dataValues.type_key_id,
                    },
                  }
                )

                await ProjectCustomFieldTypeOptions.update(
                  { is_selected: '1' },
                  {
                    where: {
                      id: data,
                    },
                  }
                )
              } else if (columnName == 'multi_select_val') {
                let data = field.value

                const ids = data.split(',')

                if (Array.isArray(ids)) {
                  const updateObj = {
                    multi_select_val: data,
                    updated_by: req.user.id,
                    updated_at: Date.now(),
                  }

                  await existingEntry.update(updateObj)

                  await ProjectCustomFieldTypeOptions.update(
                    { is_selected: '0' },
                    {
                      where: {
                        type_key_id: existingEntry.dataValues.type_key_id,
                      },
                    }
                  )

                  await ProjectCustomFieldTypeOptions.update(
                    { is_selected: '1' },
                    {
                      where: {
                        id: {
                          [Op.in]: ids,
                        },
                      },
                    }
                  )
                }
              } else if (columnName == 'attachment_val') {
                console.log(req.file)

                let data = req.file?.path || null
                const updateObj = {
                  attachment_val: data,
                  updated_by: req.user.id,
                  updated_at: Date.now(),
                }

                await existingEntry.update(updateObj)
              } else {
                const updateObj = {
                  [columnName]: field.value,
                  updated_by: req.user.id,
                  updated_at: Date.now(),
                }

                await existingEntry.update(updateObj)
              }
            } else {
              Bugs.push(`Type Details Not found for id ${field.id}`)
            }
          } else {
            Bugs.push(`No Record Found for id ${field.id}`)
          }
        })
      )

      //Update Details Field Update in Value TYPES MODEL

      const updatedAtValID = await ProjectCustomFieldsModel.findOne({
        where: {
          status: '1',
          field_code: 'updated_at_val',
        },
      })

      const updatedByValID = await ProjectCustomFieldsModel.findOne({
        where: {
          status: '1',
          field_code: 'updated_by_val',
        },
      })

      if (updatedAtValID) {
        await ProjectCustomFieldTypeValueModel.update(
          { updated_at_val: Date.now() },
          {
            where: {
              project_id: value.project_id,
              task_id: value.task_id,
              type_id: updatedAtValID.id,
            },
          }
        )
      }

      if (updatedByValID) {
        await ProjectCustomFieldTypeValueModel.update(
          { updated_by_val: req.user.id },
          {
            where: {
              project_id: value.project_id,
              task_id: value.task_id,
              type_id: updatedByValID.id,
            },
          }
        )
      }

      //END Update Details Field Update in Value TYPES MODEL

      return res.status(200).json({
        message: 'Record updated',
        status: '1',
        result,
        Bugs,
      })
    } catch (error) {
      console.log(error.message)
      return res.status(500).json({
        message: 'Something went wrong',
        status: '0',
        error: error.message,
        success: false,
      })
    }
  })
}

const updateTaskSerial = async (req, res) => {
  try {
    const schema = Joi.object({
      data: Joi.string().required(),
      project_id: Joi.number().required(),
    })

    const { value, error } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
      })
    }

    const ids = await JSON.parse(value.data)

    const result = Promise.all(
      ids.map(async (id, index) => {
        const updated = await ProjectTask.update(
          { sr_no: `${index + 1}` },
          {
            where: {
              id: id,
              project_id: value.project_id,
            },
          }
        )
      })
    )

    return res.status(200).json({
      message: 'Serial Updated',
      error: false,
      success: true,
      status: '1',
    })
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const ProjectCustomFields = async (req, res) => {
  try {
    const fields = await ProjectCustomFieldsModel.findAll({
      where: {
        status: '1',
      },
    })

    if (fields[0]) {
      return res.status(200).json({
        message: 'Record found',
        status: '1',
        error: false,
        success: true,
        data: fields,
      })
    } else {
      return res.status(404).json({
        message: 'Record not found',
        status: '0',
        error: true,
        success: false,
      })
    }
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const AddTypeKey = async (req, res) => {
  try {
    const schema = Joi.object({
      project_id: Joi.number().required(),
      type_id: Joi.number().required(),
      label_name: Joi.string().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        error: true,
        success: false,
      })
    }

    const existingEntry = await ProjectCustomFieldTypeKeyModel.findOne({
      where: {
        type_id: value.type_id,
        project_id: value.project_id,
        label_name: value.label_name,
        status: '1',
      },
    })

    if (existingEntry) {
      return res.status(409).json({
        message: 'Record already exists',
        status: '0',
        error: true,
        success: false,
      })
    } else {
      const create = await ProjectCustomFieldTypeKeyModel.create({
        type_id: value.type_id,
        project_id: value.project_id,
        label_name: value.label_name,
        status: '1',
        created_by: req.user.id,
        created_at: Date.now(),
      })

      return res.status(200).json({
        message: 'Record inserted',
        status: '1',
        error: false,
        success: true,
      })
    }
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const updateTypeKey = async (req, res) => {
  try {
    const schema = Joi.object({
      id: Joi.number().required(),
      project_id: Joi.number().required(),
      type_id: Joi.number().required(),
      label_name: Joi.string().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        error: true,
        success: false,
      })
    }

    const existingEntry = await ProjectCustomFieldTypeKeyModel.findOne({
      where: {
        type_id: value.type_id,
        project_id: value.project_id,
        label_name: value.label_name,
        status: '1',
        id: {
          [Op.ne]: value.id,
        },
      },
    })

    if (existingEntry) {
      return res.status(409).json({
        message: 'Record already exists',
        status: '0',
        error: true,
        success: false,
      })
    } else {
      const dataToUpdate = await ProjectCustomFieldTypeKeyModel.findOne({
        where: {
          id: value.id,
          type_id: value.type_id,
          project_id: value.project_id,
          status: '1',
        },
      })

      if (!dataToUpdate) {
        return res.status(404).json({
          message: 'Record not found',
          status: '0',
          success: false,
          error: true,
        })
      } else {
        await dataToUpdate.update({ label_name: value.label_name })
      }
      return res.status(200).json({
        message: 'Record updated',
        status: '1',
        error: false,
        success: true,
      })
    }
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const deleteTypeKey = async (req, res) => {
  try {
    const schema = Joi.object({
      id: Joi.number().required(),
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
        error: true,
        success: false,
      })
    }

    const existingEntry = await ProjectCustomFieldTypeKeyModel.findOne({
      where: {
        id: value.id,
        status: '1',
      },
    })

    if (!existingEntry) {
      return res.status(404).json({
        message: 'Record not found',
        status: '0',
        error: true,
        success: false,
      })
    } else {
      await existingEntry.update({ status: '0' })

      return res.status(200).json({
        message: 'Record deleted',
        status: '1',
        error: false,
        success: true,
      })
    }
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const addCustomFieldOption = async (req, res) => {
  const schema = Joi.object().keys({
    type_key_id: Joi.number().required(),
    sr_no: Joi.number().required(),
    color: Joi.string().required(),
    option_name: Joi.string().required(),
    created_by: Joi.number().allow(null),
    // updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    type_key_id: req.body.type_key_id,
    option_name: req.body.option_name,
    color: req.body.color,
    sr_no: req.body.sr_no,
    created_by: req.user.id,
    // updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const getFieldType = await ProjectCustomFieldTypeKeyModel.findOne({
        where: { status: '1', id: req.body.type_key_id },
        attributes: ['id', 'config_detail'],
      })

      if (!getFieldType) {
        return res.status(200).send({
          message: 'Field Type Key Not Available',
          error: true,
          success: false,
          status: '0',
        })
      }

      const projectCustomFieldCreate =
        await ProjectCustomFieldTypeOptions.create({
          option_name: req.body.option_name,
          sr_no: req.body.sr_no,
          color: req.body.color,
          option_type: getFieldType.config_detail == 'select_val' ? '1' : '2',
          type_key_id: req.body.type_key_id,
          created_by: req.user.id,
        })

      if (projectCustomFieldCreate) {
        return res.status(200).send({
          message: 'Field Created Successfully',
          data: projectCustomFieldCreate,
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('CreateProject Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const updateCustomFieldOptions = async (req, res) => {
  const schema = Joi.object().keys({
    option_id: Joi.number().required(),
    option_name: Joi.string().required(),
    color: Joi.string().allow(null),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    option_id: req.body.option_id,
    option_name: req.body.option_name,
    color: req.body.color,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const customFieldOptionUpd = await ProjectCustomFieldTypeOptions.update(
        {
          option_name: req.body.option_name,
          color: req.body.color,
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.option_id, // your condition here
          },
        }
      )

      if (customFieldOptionUpd) {
        return res.status(200).send({
          message: 'option Updated Successfully',
          // data: projectCustomFieldUpdate,
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Option Update Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const updateColumnOnProject = async (req, res) => {
  try {
    const user_id = req.user.id
    const field_id = req.body.field_id
    const label_name = req.body.label_name

    const user = await User.findOne({ where: { id: user_id, isactive: true } })
    if (!user) {
      return res.status(400).json({
        status: false,
        error: 'Invalid or inactive user',
      })
    }

    if (!field_id || !label_name) {
      return res.status(400).json({
        success: false,
        status: '0',
        error: 'field_id or Label name is required',
      })
    }

    const projectField = await ProjectCustomFieldTypeKeyModel.findOne({
      where: { id: field_id, status: '1' },
    })
    if (!projectField) {
      return res.status(404).json({
        status: false,
        error: 'Project Column not found',
      })
    }

    await ProjectCustomFieldTypeKeyModel.update(
      {
        label_name: label_name,
        updated_by: req.user.id,
        updated_at: new Date(),
      },
      {
        where: { id: field_id },
      }
    )

    return res.status(200).json({
      message: 'Column Updated successfully',
      status: '1',
      success: true,
      data: { field_id },
    })
  } catch (error) {
    console.error('DeleteAttachment Error:', error)
    return res.status(500).json({ status: false, error: error.message })
  }
}

const deleteProject = async (req, res) => {
  const schema = Joi.object().keys({
    project_id: Joi.number().required(),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    project_id: req.body.project_id,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const projectDelete = await Project.update(
        {
          status: '0',
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.project_id,
          },
        }
      )

      if (projectDelete) {
        return res.status(200).send({
          message: 'Project Deleted Successfully',
          // data: projectCustomFieldUpdate,
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Project Removed Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const updateOptionsSerial = async (req, res) => {
  try {
    const schema = Joi.object({
      data: Joi.string().required(),
      type_key_id: Joi.number().required(),
    })

    const { value, error } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
      })
    }

    const ids = await JSON.parse(value.data)

    const result = Promise.all(
      ids.map(async (id, index) => {
        const updated = await ProjectCustomFieldTypeOptions.update(
          { sr_no: `${index + 1}` },
          {
            where: {
              id: id,
              type_key_id: value.type_key_id,
            },
          }
        )
      })
    )

    return res.status(200).json({
      message: 'Options Serial Order Updated',
      error: false,
      success: true,
      status: '1',
    })
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const inProgressProjectList = async (req, res) => {
  try {
    let inProgressTypeKeyIDs = []
    let select_Val_IDs = []

    const inProgressTypeKeys = await ProjectCustomFieldTypeOptions.findAll({
      where: {
        option_name: 'Inprogress',
        status: '1',
      },
    })

    inProgressTypeKeys.map(key => {
      inProgressTypeKeyIDs.push(key.type_key_id)
      select_Val_IDs.push(key.id)
    })

    let uniqueProjectIds = await ProjectCustomFieldTypeValueModel.findAll({
      attributes: [
        [Sequelize.fn('DISTINCT', Sequelize.col('project_id')), 'project_id'],
      ],
      where: {
        type_key_id: {
          [Sequelize.Op.in]: inProgressTypeKeyIDs,
        },
        select_val: {
          [Sequelize.Op.in]: select_Val_IDs,
        },
      },
    })

    let idsToFind = []

    uniqueProjectIds.map(data => {
      idsToFind.push(data.project_id)
    })

    const userId = req.user.id
    console.log(userId, 'userId')

    const projects = await Project.findAll({
      where: {
        id: {
          [Op.in]: idsToFind, // Filter by the project IDs
        },
        status: '1',
        project_status: 2,
        [Op.or]: [
          { created_by: userId },
          Sequelize.where(
            Sequelize.fn('FIND_IN_SET', userId, Sequelize.col('team.user_ids')),
            {
              [Op.gt]: 0,
            }
          ),
        ],
      },
      include: [
        {
          model: TeamMember,
          as: 'team',
          required: false,
          attributes: ['id'],
        },
        {
          model: ProjectTask,
          as: 'tasks',
          required: false,
          include: {
            model: ProjectCustomFieldTypeValueModel,
            as: 'task_fields',
            where: {
              type_key_id: {
                [Sequelize.Op.in]: inProgressTypeKeyIDs,
              },
              select_val: {
                [Sequelize.Op.in]: select_Val_IDs,
              },
            },
            required: true,
          },
        },
      ],
    })

    return res.status(200).send({
      message: 'Project found',
      success: true,
      error: false,
      status: '1',
      data: projects,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const taskTrackTime = async (req, res) => {
  const today = new Date().toISOString().slice(0, 10)
  const schema = Joi.object().keys({
    task_id: Joi.number().required(),
    is_working: Joi.number().required(),
    // start_time: Joi.string().allow(null),
    // end_time: Joi.string().allow(null),
    work_date: Joi.string().allow(null),
    created_by: Joi.number().allow(null),
  })

  const dataToValidate = {
    task_id: req.body.task_id,
    is_working: req.body.is_working,
    // start_time: req.body.start_time,
    // end_time: req.body.end_time,
    work_date: req.body.work_date,
    created_by: req.user.id,
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      if (req.body.start_time || req.body.end_time) {
        const taskExist = await ProjectTask.findOne({
          where: { status: '1', id: req.body.task_id },
        })
        if (!taskExist) {
          return res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: 'Task Does not Exist',
          })
        }

        if (req.body.start_time) {
          const existingTaskTime = await ProjectTaskTImeRecordModel.findOne({
            where: { task_id: req.body.task_id, status: '1', end_time: null },
          })

          if (existingTaskTime) {
            return res.status(400).send({
              error: true,
              success: false,
              status: '0',
              message: 'Task has started already. Provide End Time',
            })
          }

          const taskStartTimeRecord = await ProjectTaskTImeRecordModel.create({
            task_id: req.body.task_id,
            user_id: req.user.id,
            start_time: today + ' ' + req.body.start_time,
            // end_time: req.body.end_time,
            // total_time: req.body.total_time,
            work_date: new Date(),
            created_by: req.user.id,
          })

          if (taskStartTimeRecord) {
            await ProjectTask.update(
              {
                is_working: 1,
              },
              { where: { status: '1', id: req.body.task_id } }
            )

            return res.status(200).send({
              message: 'Task Time Started',
              // data: projectCustomFieldUpdate,
              success: true,
              status: 1,
            })
          }
        } else if (req.body.end_time) {
          const existingTaskTime = await ProjectTaskTImeRecordModel.findOne({
            where: { task_id: req.body.task_id, status: '1', end_time: null },
          })

          if (existingTaskTime) {
            const taskEndTimeRecord = await ProjectTaskTImeRecordModel.update(
              {
                task_id: req.body.task_id,
                user_id: req.user.id,
                end_time: today + ' ' + req.body.end_time,
                work_date: new Date(),
                created_by: req.user.id,
              },
              {
                where: {
                  status: '1',
                  task_id: req.body.task_id,
                  end_time: null,
                },
              }
            )

            if (taskEndTimeRecord) {
              await ProjectTask.update(
                {
                  is_working: 2,
                },
                { where: { status: '1', id: req.body.task_id } }
              )
              return res.status(200).send({
                message: 'Task Time Ended',
                // data: projectCustomFieldUpdate,
                success: true,
                status: 1,
              })
            }
          } else {
            return res.status(400).send({
              error: true,
              success: false,
              status: '0',
              message: "Task doesn't start yet. Provide Start Time",
            })
          }
        }
      } else {
        return res.status(400).send({
          error: true,
          success: false,
          status: '0',
          message: 'Please Provide Start Time or End Time',
        })
      }
    } catch (error) {
      console.error('Option Update Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const taskTimeList = async (req, res) => {
  try {
    const userId = req.user.id
    console.log(userId, 'userId')

    const projects = await ProjectTask.findAll({
      where: {
        status: '1',
      },
      include: [
        {
          model: ProjectTaskTImeRecordModel,
          as: 'taskTime',
          where: {
            user_id: req.user.id
          },
          required: true,
        },
        {
          model: Project,
          as: 'projects',
          // required: true
        },
      ],
    })

    return res.status(200).send({
      message: 'Project found',
      success: true,
      error: false,
      status: '1',
      data: projects,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const deleteAttachmentOnProject = async (req, res) => {
  const schema = Joi.object().keys({
    attachment_id: Joi.number().required(),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    attachment_id: req.body.attachment_id,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const projectAttachmentDelete = await ProjectAttachmentsModel.update(
        {
          status: '0',
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.attachment_id,
          },
        }
      )

      if (projectAttachmentDelete) {
        return res.status(200).send({
          message: 'Project Attchment Deleted Successfully',
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Project Attachment Removed Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const updateCommentOnTask = async (req, res) => {
  const schema = Joi.object().keys({
    comment_id: Joi.number().required(),
    comment_text: Joi.string().required(),
    ping_users_info: Joi.string().allow(''),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    comment_id: req.body.comment_id,
    comment_text: req.body.comment_text,
    ping_users_info: req.body.ping_users_info,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const createdByCheck = await TaskComment.findOne({
        where: {
          status: '1',
          created_by: req.user.id,
        },
      })

      if (!createdByCheck) {
        return res.status(400).json({
          message:
            'You Cant Update this Comment ...! As You did not created this Comment',
          success: false,
          error: true,
          status: '0',
        })
      }

      const taskCommentUpdate = await TaskComment.update(
        {
          comment_text: req.body.comment_text,
          tag_user_ids: req.body.ping_users_info,
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.comment_id,
          },
        }
      )

      if (taskCommentUpdate) {
        return res.status(200).send({
          message: 'Task Update Updated Successfully',
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Task Comment Update Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const updateCommentOnProject = async (req, res) => {
  const schema = Joi.object().keys({
    comment_id: Joi.number().required(),
    comment_text: Joi.string().required(),
    ping_users_info: Joi.string().allow(''),
    updated_by: Joi.number().allow(null),
    updated_at: Joi.date().allow(null),
  })

  const dataToValidate = {
    comment_id: req.body.comment_id,
    comment_text: req.body.comment_text,
    ping_users_info: req.body.ping_users_info,
    updated_by: req.user.id,
    updated_at: new Date(),
  }

  const result = schema.validate(dataToValidate)
  if (result.error) {
    res.status(404).send({
      error: true,
      success: false,
      status: '0',
      message: result.error.details[0].message,
    })
  } else {
    try {
      const createdByCheck = await ProjectComment.findOne({
        where: {
          status: '1',
          created_by: req.user.id,
        },
      })

      if (!createdByCheck) {
        return res.status(400).json({
          message:
            'You Cant Update this Comment ...! As You did not created this Comment',
          success: false,
          error: true,
          status: '0',
        })
      }

      const projectCommentUpdate = await ProjectComment.update(
        {
          tag_user_ids: req.body.ping_users_info,
          comment_text: req.body.comment_text,
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        {
          where: {
            id: req.body.comment_id,
          },
        }
      )

      if (projectCommentUpdate) {
        return res.status(200).send({
          message: 'Project Comment Updated Successfully',
          success: true,
          status: 1,
        })
      }
    } catch (error) {
      console.error('Project Comment Update Error:', error)
      return res.status(500).json({ status: false, error: error.message })
    }
  }
}

const deleteTaskComment = async (req, res) => {
  try {
    const commentId = req.body.comment_id

    if (!commentId) {
      return res.status(400).json({
        message: 'comment_id is required',
        success: false,
        error: true,
        status: '0',
      })
    }

    const createdByCheck = await TaskComment.findOne({
      where: {
        status: '1',
        created_by: req.user.id,
      },
    })

    if (!createdByCheck) {
      return res.status(400).json({
        message:
          'You Cant Delete this Comment ...! As You did not created this Comment',
        success: false,
        error: true,
        status: '0',
      })
    }

    const descendantIds = await getAllNestedCommentIds(commentId)

    // Delete all nested comments
    if (descendantIds.length > 0) {
      await TaskComment.update(
        {
          status: '0',
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        { where: { id: descendantIds } }
      )
    }

    // Delete the parent comment itself
    await TaskComment.update(
      {
        status: '0',
        updated_by: req.body.updated_by,
        updated_at: req.body.updated_at,
      },
      { where: { id: commentId } }
    )

    return res.status(200).json({
      message: 'Comment deleted successfully',
      success: true,
      error: false,
      status: '1',
    })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return res.status(500).json({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const getAllNestedCommentIds = async parentId => {
  const children = await TaskComment.findAll({ where: { parent_id: parentId } })
  let ids = []

  for (const child of children) {
    ids.push(child.id)
    const childDescendants = await getAllNestedCommentIds(child.id)
    ids = ids.concat(childDescendants)
  }

  return ids
}

const deleteProjectComment = async (req, res) => {
  try {
    const commentId = req.body.comment_id

    if (!commentId) {
      return res.status(400).json({
        message: 'comment_id is required',
        success: false,
        error: true,
        status: '0',
      })
    }

    const createdByCheck = await ProjectComment.findOne({
      where: {
        status: '1',
        created_by: req.user.id,
      },
    })

    if (!createdByCheck) {
      return res.status(400).json({
        message:
          'You Cant Delete this Comment ...! As You did not created this Comment',
        success: false,
        error: true,
        status: '0',
      })
    }

    const descendantIds = await getAllProjectNestedCommentIds(commentId)
    // Delete all nested comments
    if (descendantIds.length > 0) {
      await ProjectComment.update(
        {
          status: '0',
          updated_by: req.body.updated_by,
          updated_at: req.body.updated_at,
        },
        { where: { id: descendantIds } }
      )
    }

    // Delete the parent comment itself
    await ProjectComment.update(
      {
        status: '0',
        updated_by: req.body.updated_by,
        updated_at: req.body.updated_at,
      },
      { where: { id: commentId } }
    )

    return res.status(200).json({
      message: 'Comment deleted successfully',
      success: true,
      error: false,
      status: '1',
    })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return res.status(500).json({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const getAllProjectNestedCommentIds = async parentId => {
  const children = await ProjectComment.findAll({
    where: { parent_id: parentId },
  })
  let ids = []

  for (const child of children) {
    ids.push(child.id)
    const childDescendants = await getAllProjectNestedCommentIds(child.id)
    ids = ids.concat(childDescendants)
  }

  return ids
}

const projectCommentList = async (req, res) => {
  try {
    const project_id = req.body.project_id
    if (!project_id) {
      return res.status(400).send({
        message: 'project_id is required',
        success: false,
        error: true,
        status: '0',
      })
    }
    const projects = await ProjectComment.findAll({
      where: {
        status: '1',
        project_id: project_id,
      },
      include: [
        {
          model: User,
          as: 'comment_by',
          attributes: ['id', 'userfullname'], // Adjust based on your User model
        },
      ],
      order: [['created_at', 'ASC']],
    })

    if (projects.length > 0) {
      const projectMap = {}
      const projectCommentList = []

      projects.forEach(project => {
        projectMap[project.id] = { ...project.dataValues, childComment: [] }
        if (project.parent_id === 0) {
          projectCommentList.push(projectMap[project.id])
        }
      })
      projects.forEach(project => {
        if (project.parent_id !== 0 && projectMap[project.parent_id]) {
          projectMap[project.parent_id].childComment.push(
            projectMap[project.id]
          )
        }
      })

      return res.status(200).send({
        message: 'Task Comments found',
        success: true,
        error: false,
        status: '1',
        data: projectCommentList,
      })
    } else {
      return res.status(404).send({
        message: 'No Comments found on this Project',
        success: false,
        error: true,
        status: '0',
      })
    }
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const setCustomFieldSerialNo = async (req, res) => {
  try {
    const schema = Joi.object({
      data: Joi.string().required(),
      project_id: Joi.number().required(),
    })

    const { value, error } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0',
      })
    }

    const ids = await JSON.parse(value.data)
    const result = Promise.all(
      ids.map(async (id, index) => {
        const updated = await ProjectCustomFieldTypeKeyModel.update(
          { sr_no: `${index + 1}` },
          {
            where: {
              id: id,
              project_id: value.project_id,
            },
          }
        )
      })
    )

    return res.status(200).json({
      message: 'Custom Field Serial Order Updated',
      error: false,
      success: true,
      status: '1',
    })
  } catch (error) {
    return res.status(500).json({
      message: 'Something went wrong',
      status: '0',
      error: error.message,
    })
  }
}

const projectStatusOptions = async (req, res) => {
  try {
    const projectId = req.body.project_id
    if (!projectId) {
      return res.status(400).send({
        message: 'Project Id is required',
        success: false,
        error: true,
        status: '0',
      })
    }

    const customFields = await ProjectCustomFieldTypeKeyModel.findAll({
      where: {
        status: '1',
        project_id: projectId,
        label_name: ['Status', 'Priority'],
      },
      include: {
        model: ProjectCustomFieldTypeOptions,
        as: 'key_options',
        attributes: [
          'id',
          'option_name',
          'sr_no',
          'option_type',
          'type_key_id',
        ],
        where: {
          status: '1',
        },
      },
    })

    const projectStatus = customFields.find(
      field => field.label_name === 'Status'
    )
    const projectPriority = customFields.find(
      field => field.label_name === 'Priority'
    )

    if (projectStatus) {
      return res.status(200).send({
        message: 'Project Status and Priority',
        success: true,
        error: false,
        status: '1',
        data: {
          project_status: projectStatus ? projectStatus.key_options : [],
          project_priority: projectPriority ? projectPriority.key_options : [],
        },
      })
    } else {
      return res.status(404).send({
        message: 'No status available',
        success: false,
        error: true,
        status: '0',
      })
    }
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}

const addProjectAttachments = async (req, res) => {
  uploadMultiple.array('files')(req, res, async err => {
    if (err) {
      return res.status(400).send({
        message: 'File upload failed',
        success: false,
        error: err.message,
        status: '0',
      })
    } else {
      try {
        if (!req.body.project_id) {
          return res.status(400).send({
            message: 'Missing required fields',
            success: false,
            error: 'project ID is required',
            status: '0',
          })
        }

        const projectExist = await Project.findOne({
          where: { id: req.body.project_id },
        })

        if (!projectExist) {
          return res.status(400).send({
            message: "Project does't exist",
            success: false,
            error: true,
            status: '0',
          })
        }

        console.log(req.files, 'rewq files ')

        if (req.files && req.files.length > 0) {
          const attachmentsData = req.files.map(file => ({
            project_id: req.body.project_id,
            file_name: file.filename,
            file_path: file.path,
            file_size: file.size,
            created_by: req.user.id,
          }))

          const addAttachments =
            await ProjectAttachmentsModel.bulkCreate(attachmentsData)

          if (addAttachments) {
            // const allAttachment = await ProjectAttachmentsModel.findAll({
            //   where: { project_id: req.body.project_id, status:"1" },
            //   attributes: {
            //     exclude: ['created_at', 'updated_at', 'updated_by', 'created_by']
            //   }
            // });
            return res.status(200).send({
              message: 'Attachment Added successfully',
              success: true,
              error: false,
              status: '1',
              data: addAttachments,
            })
          }
        }
      } catch (error) {
        console.error('projectAttachment Error:', error)
        return res.status(500).json({ status: false, error: error.message })
      }
    }
  })
}

const addProjectDescriptionAttachments = async (req, res) => {
  uploadMultipleDescAttach.array('files')(req, res, async err => {
    if (err) {
      return res.status(400).send({
        message: 'File upload failed',
        success: false,
        error: err.message,
        status: '0',
      })
    } else {
      try {
        if (!req.body.project_id) {
          return res.status(400).send({
            message: 'Missing required fields',
            success: false,
            error: 'project ID is required',
            status: '0',
          })
        }

        if (!req.body.is_description_attachment) {
          return res.status(400).send({
            message: 'Missing required fields! {{ is_description_attachment }}',
            success: false,
            error: 'project ID is required',
            status: '0',
          })
        }

        const projectExist = await Project.findOne({
          where: { id: req.body.project_id },
        })

        if (!projectExist) {
          return res.status(400).send({
            message: "Project does't exist",
            success: false,
            error: true,
            status: '0',
          })
        }

        // console.log(req.files,"rewq files ");

        if (req.files && req.files.length > 0) {
          const attachmentsData = req.files.map(file => ({
            project_id: req.body.project_id,
            file_name: file.filename,
            file_path: file.path,
            file_size: file.size,
            is_description_attachment: req.body.is_description_attachment
              ? 2
              : 1,
            created_by: req.user.id,
          }))

          const addAttachments =
            await ProjectAttachmentsModel.bulkCreate(attachmentsData)

          if (addAttachments) {
            // const allAttachment = await ProjectAttachmentsModel.findAll({
            //   where: { project_id: req.body.project_id, status:"1" },
            //   attributes: {
            //     exclude: ['created_at', 'updated_at', 'status', 'updated_by', 'created_by']
            //   }
            // });
            return res.status(200).send({
              message: 'Attachment Added successfully',
              success: true,
              error: false,
              status: '1',
              data: addAttachments,
            })
          }
        }
      } catch (error) {
        console.error('projectAndAttachment Error:', error)
        return res.status(500).json({ status: false, error: error.message })
      }
    }
  })
}

const storageProjectDescriptionFiles = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/project_description/') // Specify the directory where the files will be stored
  },
  filename: (req, file, cb) => {
    // Ensure unique file names by appending timestamp
    cb(null, file.originalname)
  },
})

const uploadMultipleDescAttach = multer({
  storage: storageProjectDescriptionFiles,
  fileFilter: fileFilter,
})

const getNotificationList = async (req, res) => {
  try {
    if (!req.user.id) {
      return res.status(400).json({
        error: true,
        status: 0,
        message: 'User is not authenticate',
      })
    }
    const notificationHistory = await NotificationHistory.findAll({
      where: {
        status: '1',
        user_id: req.user.id,
      },
    })

    return res.status(200).send({
      message: 'Record Found',
      success: true,
      status: '1',
      data: notificationHistory,
    })
  } catch (error) {
    return res.status(500).send({
      message: 'Something went wrong',
      success: false,
      error: error.message,
      status: '0',
    })
  }
}


const setTaskEstTime = async (req, res) => {
  try {

    const schema = Joi.object({
      data: Joi.string().required(),
      date: Joi.date().required()
    })


    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0'
      })
    }


    const TimesheetData = JSON.parse(value.data)

    console.log(TimesheetData)

    if (Array.isArray(TimesheetData)) {

      TimesheetData.map(async value => {

        const existingRecord = await TaskEstTimeModel.findOne({
          where: {
            task_id: value.task_id,
            user_id: req.user.id,
            work_date: req.body.date

          }
        })

        if (existingRecord) {

          const updatedData = await existingRecord.update({
            est_time: value.est_time,
            updated_at: Date.now(),
            updated_by: req.user.id
          })

        } else {
          const newRecord = await TaskEstTimeModel.create({
            task_id: value.task_id,
            user_id: req.user.id,
            est_time: value.est_time,
            work_date: req.body.date,
            created_by: req.user.id,
            created_at: Date.now()
          })

        }

      })

    }



    return res.status(200).json({
      message: 'Record Updated',
      status: '1'
    })


  } catch (error) {
    console.log(error)

    return res.status(500).json({
      message: 'Something went wrong',
      error: true,
      success: false
    })

  }
}

const getTaskEstTime = async (req, res) => {
  try {

    const schema = Joi.object({
      work_date: Joi.date().required()
    })

    const { error, value } = await schema.validate(req.body)

    if (error) {
      return res.status(400).json({
        message: error.message,
        status: '0'
      })
    }

    const userId = req.user.id;

    const AssignedProjects = await Project.findAll({
      where: {
        status: '1'
      },
      include: {
        model: TeamMember,
        as: 'team',
        where: where(
          fn('FIND_IN_SET', userId, col('user_ids')),
          { [Op.gt]: 0 }
        )
      },
      attributes: ['id']
    })

    const AssignedProjectIds = AssignedProjects.map(data => data.id)


    const AssignedToTypeKeys = await ProjectCustomFieldTypeKeyModel.findAll({
      where: {
        label_name: 'Assigned To',
        status: '1'
      },
      attributes: ['id']
    })


    const AssignedToTypeKeyIds = AssignedToTypeKeys.map((data) => data.id)


    const AssignedInTasks = await ProjectCustomFieldTypeValueModel.findAll({
      where: {
        type_key_id: AssignedToTypeKeyIds,
        [Op.and]: where(
          fn('FIND_IN_SET', userId, col('person_val')),
          { [Op.gt]: 0 }
        )
      },
      attributes: ['id', 'task_id'],
    })

    const AssignedInTaskIds = AssignedInTasks.map((data) => data.task_id)

    const EstTimes = await Project.findAll({
      where: {
        id: AssignedProjectIds,
        status: '1'
      },
      attributes: ['id', 'project_name'],
      required: false,
      include: {
        model: ProjectTask,
        as: "tasks",
        where: {
          id: AssignedInTaskIds,
          status: '1'
        },
        attributes: ['id', 'task_name', 'parent_id'],
        required: false,
        include: {
          model: TaskEstTimeModel,
          where: {
            status: '1',
            user_id: req.user.id,
            work_date: req.body.work_date
          },
          attributes: ['id', 'user_id', 'task_id', 'est_time'],
          required: false
        }
      }
    })


    if (!EstTimes.length > 0) {
      return res.status(404).json({
        message: 'Recort not found',
        status: '0',
        data: []
      })
    }



    const response = EstTimes.map(project => {
      const tasks = project.tasks.map(task => {
        const estTime = task.pmt_task_est_time;
        return {
          ...task.dataValues,
          pmt_task_est_time: estTime
            ? estTime
            : {
              id: 0,
              user_id: 0,
              task_id: 0,
              est_time: "00.00"
            }
        };
      });

      return {
        ...project.dataValues,
        tasks
      };
    });





    return res.status(200).json({
      message: 'Record found',
      data: response
    })


  } catch (error) {
    console.log(error)

    return res.status(500).json({
      message: 'Something went wrong',
      error: true,
      success: false
    })

  }
}

module.exports = {
  CreateProject,
  ProjectTaskList,
  ProjectTaskAdd,
  taskOrderUpdate,
  ProjectList,
  ProjectTaskUpdate,
  ProjectTaskDelete,
  updateTaskField,
  ProjectCustomFields,
  AddTypeKey,
  updateTypeKey,
  deleteTypeKey,
  updateProject,
  customFieldOptionList,
  addCustomFieldOption,
  updateCustomFieldOptions,
  deleteCustomFieldOptions,
  updateOptionsSerial,
  customFieldList,
  updateAllFields,
  updateTaskSerial,
  updateColumnOnProject,
  deleteProject,
  inProgressProjectList,
  taskTrackTime,
  taskTimeList,
  updateCommentOnTask,
  deleteTaskComment,
  TaskCommentList,
  updateCommentOnProject,
  deleteProjectComment,
  projectCommentList,
  setCustomFieldSerialNo,
  customFieldListByProject,
  createCustomFieldOnProject,
  deleteCustomFieldOnProject,
  deleteAttachmentOnProject,
  projectStatusOptions,
  addProjectAttachments,
  addProjectDescriptionAttachments,
  getNotificationList,
  updateProjectMembers,
  setTaskEstTime,
  getTaskEstTime
}
