const { AccessToken, RoomServiceClient } = require("livekit-server-sdk");
const Chat = require("../../models/ChatModule/chat");
const Meeting = require("../../models/Meeting/Meeting");
const MeetingUsers = require("../../models/Meeting/MeetingUser");
const crypto = require("crypto");
const md5 = require("md5");
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY || "devkey";
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET || "secret";
const LIVEKIT_URL = process.env.LIVEKIT_URL || "http://192.168.11.161:7880";
const roomService = new RoomServiceClient(LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET);




async function generateAccessToken(userId, roomName, participantName) {
  const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
    identity: userId,
    name: participantName,
  });
  at.addGrant({ roomJoin: true, room: roomName, name: participantName });
  // Generate the token
  const token = await at.toJwt();
  return token;
}

// Express route to generate token and return participant details
const GenerateToken = async (req, res) => {
  try {
    const { roomName, participantName, userId } = req.body;

    // Validate required fields
    if (!roomName || !participantName || !userId) {
      return res.status(400).json({
        errorMessage: "roomName, participantName, and userId are required",
      });
    }

    // Generate token with correct parameter order
    const token = await generateAccessToken(userId, roomName, participantName);

    // Return participant details and token
    return res.json({
      token,
    });
  } catch (error) {
    console.error("Error generating token:", error);
    return res.status(500).json({
      errorMessage: "Failed to generate token",
    });
  }
};


function getRoomName(fromUserId, toUserId) {
  const ids = [fromUserId, toUserId].sort();
  return `${ids[0]}-${ids[1]}-room`;
}

function getGroupRoomName(groupId) {
  return `group_${groupId}-room`;
}

async function getOrCreateRoom(fromUserId, toUserId) {
  try {
    const roomName = getRoomName(fromUserId, toUserId);
    const rooms = await roomService.listRooms();
    const existingRoom = rooms.find((room) => room.name === roomName);
    if (existingRoom) {
      console.log(`Existing room found: ${roomName}`);
      return existingRoom;
    }
    const opts = {
      name: roomName,
      emptyTimeout: 10 * 60,
      maxParticipants: 200,
    };
    const room = await roomService.createRoom(opts);
    console.log(`New room created: ${roomName}`);
    return room;
  } catch (error) {
    console.error("Error in getOrCreateRoom:", error);
    throw error;
  }
}

async function createRoomFromUserToUser(fromUserId, toUserId) {
  try {
    const fromUser = fromUserId;
    const toUser = toUserId;
    if (!fromUser || !toUser) {
      console.log("One or both users not found.");
      return;
    }
    const room = await getOrCreateRoom(fromUserId, toUserId);
    const fromUserToken = generateAccessToken(fromUserId, room.name);
    const toUserToken = generateAccessToken(toUserId, room.name);
    return {
      room,
      tokens: {
        fromUserToken,
        toUserToken,
      },
    };
  } catch (error) {
    console.error("Error creating room:", error);
    throw error;
  }
}

const createChatAndRoom = async (req, res) => {
  try {
    const { user1_id, user2_id } = req.body;
    // Validation
    if (!user1_id || !user2_id) {
      return res.status(400).json({
        success: false,
        error: "Both 'user1_id' and 'user2_id' are required",
      });
    }

    // Step 1: Create room first
    const { room, tokens } = await createRoomFromUserToUser(user1_id, user2_id);
    if (!room) {
      return res.status(500).json({
        success: false,
        error: "Failed to create room",
      });
    }

    // Step 2: Room ban gaya, ab chat check aur create karo
    let chat =
      (await Chat.findOne({ where: { user1_id, user2_id } })) ||
      (await Chat.findOne({
        where: { user1_id: user2_id, user2_id: user1_id },
      }));
    if (!chat) {
      chat = await Chat.create({ user1_id, user2_id });
    }
    res.status(201).json({
      success: true,
      status: "1",
      message: "Room and chat generated successfully",
      chat,
      room,
      // tokens,
    });
  } catch (error) {
    console.error("Error in createChatAndRoom:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};



async function getOrCreateGroupRoom(groupId, userIds) {
  try {
    const roomName = getGroupRoomName(groupId);
    const rooms = await roomService.listRooms();
    const existingRoom = rooms.find((room) => room.name === roomName);
    if (existingRoom) {
      console.log(`Existing group room found: ${roomName}`);
      return existingRoom;
    }
    const opts = {
      name: roomName,
      emptyTimeout: 10 * 60,
      maxParticipants: userIds.length, // Set based on group size
    };
    const room = await roomService.createRoom(opts);
    console.log(`New group room created: ${roomName}`);
    return room;
  } catch (error) {
    console.error("Error in getOrCreateGroupRoom:", error);
    throw error;
  }
}



async function createGroupRoom(groupId, userIds) {
  try {
    if (!groupId || !userIds || userIds.length < 2) {
      throw new Error("groupId and at least 2 userIds are required");
    }
    const room = await getOrCreateGroupRoom(groupId, userIds);
    return {
      room,
    };
  } catch (error) {
    console.error("Error creating group room:", error);
    throw error;
  }
}



const GroupRoomCreate = async (req, res) => {
  const { groupId, userIds } = req.body;
  try {
    if (!groupId || !userIds || userIds.length < 2) {
      return res.status(400).json({
        success: false,
        error: "groupId and userIds (array with at least 2 users) are required",
      });
    }
    const { room} = await createGroupRoom(groupId, userIds);
    if (!room) {
      return res.status(500).json({
        success: false,
        error: "Failed to create group room",
      });
    }
    return res.status(200).json({
      success: true,
      status: "1",
      room,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: "Failed to create group room",
    });
  }
};




const MeetingRoomcreate = async ({
  project_id = null,
  is_public = true,
  password = null,
  host_id,
  created_by,
  livekit_room_id = null,
  start_time = new Date(),
  end_time = null,
}) => {
  try {
    // Generate unique livekit_room_id if not provided
    let roomId = livekit_room_id;
    if (!roomId) {
      let attempts = 0;
      do {
        roomId = `room_${crypto.randomBytes(8).toString('hex')}`;
        const existingRoom = await Meeting.findOne({ where: { livekit_room_id: roomId } });
        if (!existingRoom) break;
        attempts++;
      } while (attempts < 5);
      if (attempts >= 5) {
        throw new Error('Failed to generate unique room ID');
      }
    }

    // Generate unique meeting_url
    let meeting_url;
    let urlAttempts = 0;
    do {
      meeting_url = `meet_${crypto.randomBytes(8).toString('hex')}`;
      const existingMeeting = await Meeting.findOne({ where: { meeting_url } });
      if (!existingMeeting) break;
      urlAttempts++;
    } while (urlAttempts < 5);
    if (urlAttempts >= 5) {
      throw new Error('Failed to generate unique meeting URL');
    }

    // Create LiveKit Room
    await roomService.createRoom({
      name: roomId,
      emptyTimeout: 3600,
      maxParticipants: 0, // No participant limit
    });
    console.log(`Room created: ${roomId}`);

    // Hash password for private room
    let hashedPassword = null;
    if (!is_public && password) {
      hashedPassword =  md5(password);
    }

    // Create Meeting
    const meeting = await Meeting.create({
      project_id,
      is_public,
      password: hashedPassword,
      meeting_url,
      livekit_room_id: roomId,
      start_time,
      end_time,
      host_id,
      isactive: true,
      created_by,
      modified_by: created_by,
    });

    // Generate host token
    const hostToken = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity: `user_${host_id}`,
      name: `user_${host_id}`,
    });
    hostToken.addGrant({
      roomJoin: true,
      room: roomId,
      canPublish: true,
      canSubscribe: true,
    });
    const hostTokenString = await hostToken.toJwt();

    // Add host to MeetingUsers
    await MeetingUsers.create({
      meeting_id: meeting.id,
      user_id: host_id,
      role: 'host',
      livekit_token: hostTokenString,
      permissions: {
        canShareScreen: true,
        canUnmute: true,
        canManageParticipants: true,
      },
      isactive: true,
      created_by,
      modified_by: created_by,
    });

    return {
      meeting,
      livekit_room_id: roomId,
      meeting_url,
      host_token: hostTokenString,
    };
  } catch (error) {
    console.error('MeetingRoomcreate Error:', error);
    throw error;
  }
};


module.exports = {
  GenerateToken,
  GroupRoomCreate,
  createChatAndRoom,
  MeetingRoomcreate,
};