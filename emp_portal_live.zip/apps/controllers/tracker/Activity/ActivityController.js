const ActivityLogsModel = require('../../../models/tracker/Activity/ActivityLogs')
const StatusLogModel = require('../../../models/tracker/Activity/StatusLogs')
const WorkLogsModel = require('../../../models/tracker/Activity/WorkLogs')
const AppsDurationModel = require('../../../models/tracker/Activity/AppsDuration')
const mongoose = require('mongoose')
const User = require('../../../models/tracker/user/User')
const { ObjectId } = require('mongodb')
const SessionLogs = require('../../../models/tracker/Activity/SessionLogs')
const MediaLogs = require('../../../models/tracker/Activity/MediaLogs')
const multer = require('multer');
const path = require('path')
const fs = require('fs')
const { Op } = require('sequelize')


const DailyCalculatedSystemStats = require('../../../models/tracker/Activity/DailyCalculatedSystemStats')
const DailySystemStats = require('../../../models/tracker/Activity/DailySystemStats')
const DailyAppActivity = require('../../../models/tracker/Activity/DailyAppActivity')
const DailyAppUsage = require('../../../models/tracker/Activity/DailyAppUsage')




const Joi = require('joi')



const addDailySystemStats = async (req, res) => {
    try {

        const userId = req.user.id;
        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const activityLogDocuments = logs.map(log => {
            const { start_time, end_time, status, duration } = log;

            return {
                userId, start_time, end_time, status, duration
            };
        });

        const savedLogs = await DailySystemStats.bulkCreate(activityLogDocuments);

        return res.status(200).json({
            message: 'Daily System Stats created successfully',
        });
    } catch (error) {
        console.error('Error inserting activity logs:', error.message);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};

const addDailyCalculatedSystemStats = async (req, res) => {
    try {

        const schema = Joi.object({
            idleTime: Joi.number().required(),
            onlineTime: Joi.number().required(),
            offlineTime: Joi.number().required(),
            totalTime: Joi.number().required(),
        })

        const { value, error } = await schema.validate(req.body)

        if (error) {
            return res.status(400).json({
                message: error.message,
                error: true,
                success: false,
                status: '0'
            })
        }

        const insertObject = {
            userId: req.user.id,
            total_idle_time: value.idleTime,
            total_online_time: value.onlineTime,
            total_offline_time: value.offlineTime,
            total_time: value.totalTime,
        }

        const addData = await DailyCalculatedSystemStats.create(insertObject)


        if (addData) {
            return res.status(200).json({
                message: 'Record inserted',
                status: '1',
                error: false,
                success: true
            })
        } else {
            return res.status(500).json({
                message: 'Something went wrong, data not inserted!',
                status: '0'
            })
        }


    } catch (error) {
        console.log(error.message)

        return res.status(500).json({
            message: "Something went wrong",
            error: true,
            success: false,
            status: '0'
        })

    }
}




const addDailyAppActivity = async (req, res) => {
    try {

        const userId = req.user.id;
        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const activityLogDocuments = logs.map(log => {
            const { owner, title, start_time, end_time, duration } = log;

            return {
                userId, owner, title, start_time, end_time, duration
            };
        });

        const savedLogs = await DailyAppActivity.bulkCreate(activityLogDocuments);

        return res.status(200).json({
            message: 'Daily App Activity created successfully',
        });
    } catch (error) {
        console.error('Error inserting activity logs:', error.message);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};


const addDailyAppUsage = async (req, res) => {
    try {

        const userId = req.user.id;
        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const activityLogDocuments = logs.map(log => {
            const { owner, duration } = log;

            return {
                userId, owner, duration
            };
        });

        const savedLogs = await DailyAppUsage.bulkCreate(activityLogDocuments);

        return res.status(200).json({
            message: 'Daily App Usage created successfully',
        });
    } catch (error) {
        console.error('Error inserting activity logs:', error.message);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};











const statusActivityLog = async (req, res) => {
    try {

        const userId = req.user.id;
        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const statusLogDocuments = logs.map(log => {
            const { app, title, url, color, beginDate, endDate, } = log;


            return {

                userId,
                app,
                title,
                url,
                color,
                beginDate,
                endDate,
            };
        });


        const savedLogs = await StatusLogModel.bulkCreate(statusLogDocuments);

        return res.status(201).json({
            message: 'Status logs created successfully',
        });
    } catch (error) {
        console.error('Error inserting status logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};

const workActivityLog = async (req, res) => {
    try {

        const userId = req.user.id;

        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const workLogDocuments = logs.map(log => {
            const { app, title, url, color, beginDate, endDate, } = log;


            return {

                userId,
                app,
                title,
                url,
                color,
                beginDate,
                endDate,
            };
        });

        const savedLogs = await WorkLogsModel.bulkCreate(workLogDocuments);

        return res.status(201).json({
            message: 'Work logs created successfully',
        });
    } catch (error) {
        console.error('Error inserting work logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};

const AppsDurationLog = async (req, res) => {
    try {

        const userId = req.user.id;

        const logs = JSON.parse(req.body.logs);


        if (!userId || !Array.isArray(logs)) {
            return res.status(400).json({ message: 'Missing required fields or logs is not an array' });
        }

        const AppsDurationDocuments = await logs.map(log => {
            const { app, taskName, title, url, color, beginDate, endDate, timeDiffInMs } = log;

            return {

                userId,
                taskName,
                app,
                title,
                url,
                color,
                beginDate,
                endDate,
                duration: timeDiffInMs
            };
        });

        const savedLogs = await AppsDurationModel.bulkCreate(AppsDurationDocuments);

        return res.status(201).json({
            message: 'AppsDuration logs created successfully',
        });
    } catch (error) {
        console.error('Error inserting AppsDuration logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
};


const checkTrackingPermission = async (userId, currentUser) => {
    try {

        const id = currentUser.id;
        const empRole = currentUser.empRole;
        const Admin = empRole == '8' || empRole == '1'
        const userItself = userId == id;

        if (userItself || Admin) {
            return true
        } else {

            const ReportingManager = await User.findOne(
                {
                    _id: new ObjectId(userId),
                    reporting_manager: new ObjectId(id)
                }, {
                _id: 1
            }
            )
            return ReportingManager ? true : false
        }

    } catch (error) {
        console.log(error.message)
        return false
    }
}




const getAppsDuration = async (req, res) => {
    try {
        const { startDate, endDate, userId } = req.body;


        if (!startDate || !endDate || !userId) {

            return res.status(400).json({
                message: 'startDate, endDate and userId are required',
            });
        }

        // const permission = await checkTrackingPermission(req.body.userId, req.user)

        // if (!permission) return res.status(401).json({ message: 'You are not authorized to view this user activity' })

        console.log(startDate, endDate)


        const data = await AppsDurationModel.findAll({
            where: {
                userId: userId,
                beginDate: {
                    [Op.gte]: Number(startDate),
                    [Op.lt]: Number(endDate)
                }
            }
        });

        console.log(data)
        if (!data[0]) {
            return res.status(404).json({ message: 'No record' })
        }

        return res.status(200).json({
            message: 'Record found',
            data: data
        })

    } catch (error) {
        console.error('Error retreiving Apps Duration logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
}


const getActivityLogs = async (req, res) => {
    try {
        const { startDate, endDate, userId } = req.body;


        if (!startDate || !endDate || !userId) {

            return res.status(400).json({
                message: 'startDate, endDate and userId are required',
            });
        }

        // const permission = await checkTrackingPermission(req.body.userId, req.user)

        // if (!permission) return res.status(401).json({ message: 'You are not authorized to view this user activity' })


        const data = await ActivityLogsModel.findAll({
            where: {
                userId: userId,
                beginDate: {
                    [Op.gte]: Number(startDate),
                    [Op.lt]: Number(endDate)
                }
            }
        });

        if (!data[0]) {
            return res.status(404).json({ message: 'No record' })
        }

        return res.status(200).json({
            message: 'Record found',
            data: data
        })

    } catch (error) {
        console.error('Error retreiving Activity logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
}



const getStatusLogs = async (req, res) => {
    try {
        const { startDate, endDate, userId } = req.body;


        if (!startDate || !endDate || !userId) {

            return res.status(400).json({
                message: 'startDate, endDate and userId are required',
            });
        }

        // const permission = await checkTrackingPermission(req.body.userId, req.user)

        // if (!permission) return res.status(401).json({ message: 'You are not authorized to view this user activity' })


        const data = await StatusLogModel.findAll({
            where: {
                userId: userId,
                beginDate: {
                    [Op.gte]: Number(startDate),
                    [Op.lt]: Number(endDate)
                }
            }
        });

        if (!data[0]) {
            return res.status(404).json({ message: 'No record' })
        }

        return res.status(200).json({
            message: 'Record found',
            data: data
        })

    } catch (error) {
        console.error('Error retreiving Status logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
}



const getWorkLogs = async (req, res) => {
    try {
        const { startDate, endDate, userId } = req.body;


        if (!startDate || !endDate || !userId) {

            return res.status(400).json({
                message: 'startDate, endDate and userId are required',
            });
        }

        // const permission = await checkTrackingPermission(req.body.userId, req.user)

        // if (!permission) return res.status(401).json({ message: 'You are not authorized to view this user activity' })


        const data = await WorkLogsModel.findAll({
            where: {
                userId: userId,
                beginDate: {
                    [Op.gte]: Number(startDate),
                    [Op.lt]: Number(endDate)
                }
            }
        });

        if (!data[0]) {
            return res.status(404).json({ message: 'No record' })
        }

        return res.status(200).json({
            message: 'Record found',
            data: data
        })

    } catch (error) {
        console.error('Error retreiving Work logs:', error);
        return res.status(500).json({ message: 'Internal Server Error', error: error.message });
    }
}


const addSession = async (req, res) => {
    try {

        if (!req.body.beginTime) {
            return res.status(400).json({ message: 'Begin time is required' })
        }


        const isValidTimestamp = isNaN(new Date(req.body.beginTime).getTime());
        if (!isValidTimestamp) {
            return res.status(400).json({ message: 'Invalid begin time. It must be a valid timestamp.' });
        }

        const userId = req.user.id;

        const startOfDay = new Date();
        startOfDay.setUTCHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setUTCHours(23, 59, 59, 999);

        const existingSession = await SessionLogs.findOne({
            userId,
            $or: [
                { endTime: { $exists: false } }, // Key does not exist
                { endTime: null },               // Value is null
                { endTime: '' },                 // Value is an empty string
            ],
        });

        if (existingSession) return res.status(400).json({ message: 'Session already exists', data: existingSession })

        const newSession = {
            beginTime: req.body.beginTime,
            userId: req.user.id
        }

        const addSession = await SessionLogs.create(newSession)

        return res.status(200).json({ message: 'Session started successfully.', data: addSession })


    } catch (error) {
        console.log(error.message)
        return res.status(500).json({ message: "Something went wrong", error: error.message })

    }
}

const endSession = async (req, res) => {
    try {

        if (!req.body.endTime || !req.body.id) {
            return res.status(400).json({ message: 'id and endTime is required' })
        }


        const isValidTimestamp = isNaN(new Date(req.body.beginTime).getTime());
        if (!isValidTimestamp) {
            return res.status(400).json({ message: 'Invalid begin time. It must be a valid timestamp.' });
        }

        const valid_id = ObjectId.isValid(req.body.id)

        if (!valid_id) return res.status(400).send({ message: 'id is not valid' })

        const userId = req.user.id;

        const existingSession = await SessionLogs.findOne({
            userId,
            _id: new ObjectId(req.body.id),
        });

        if (existingSession) {
            await existingSession.updateOne({ endTime: req.body.endTime })
            return res.status(200).json({ message: 'Sessiond ended.' })
        } else {
            return res.status(404).json({ message: 'Session not found' })
        }

    } catch (error) {
        console.log(error.message)
        return res.status(500).json({ message: "Something went wrong", error: error.message })

    }
}


const getSession = async (req, res) => {
    try {
        const { from, to } = req.body;

        if (!from || !to) {
            return res.status(400).json({ message: 'Start and end dates (timestamps) are required.' });
        }

        if (isNaN(from) || isNaN(to)) {
            return res.status(400).json({ message: 'Invalid timestamps. Both "from" and "to" must be valid numbers.' });
        }

        const userId = req.user.id;


        const sessions = await SessionLogs.find({
            userId,
            beginTime: { $gte: Number(from), $lte: Number(to) }, // Filter by range
        });

        return res.status(200).json({ message: 'Sessions found.', data: sessions });
    } catch (error) {
        console.error(error.message);
        return res.status(500).json({ message: 'Something went wrong.', error: error.message });
    }
};


function getDayTimestamps(dateString) {
    // Parse the provided date string
    const date = new Date(dateString);

    if (isNaN(date.getTime())) {
        throw new Error("Invalid date format. Use a valid date string, e.g., '01-01-2025' or '2025-01-01'.");
    }

    // Get the start of the day (00:00:00.000)
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const startTimestamp = startOfDay.getTime();

    // Get the end of the day (23:59:59.999)
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    const endTimestamp = endOfDay.getTime();

    return { startTimestamp, endTimestamp };
}

const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir);
}

// Set up multer storage configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);  // The folder where files will be saved
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Use timestamp to avoid name conflicts
    }
});

// Create the multer upload instance with multiple files support
const upload = multer({
    storage: storage,
    limits: { fileSize: 20 * 1024 * 1024 }, // Max file size 10MB
}).array('mediaFiles');  // Max 5 files


const ScreenShot = async (req, res) => {
    // Handle file upload
    upload(req, res, async (err) => {
        if (err) {
            return res.status(400).json({ message: 'File upload error', error: err });
        }

        // Check if files are uploaded
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ message: 'No files uploaded' });
        }

        // Ensure userId is a valid ObjectId
        const userId = mongoose.Types.ObjectId(req.body.userId); // Convert userId to ObjectId

        try {
            // Create a new MediaLog entry for each uploaded file
            const mediaLogs = await Promise.all(req.files.map(file => {
                const newMediaLog = new MediaLog({
                    userId: userId,  // Use the converted userId (ObjectId)
                    type: req.body.type,       // screenshot or cameraShot
                    mediaUrl: `/uploads/${file.filename}`,  // File path relative to the server
                    mediaType: file.mimetype.startsWith('image') ? 'image' : 'video', // Determine if file is image or video
                });

                return newMediaLog.save();  // Save the media log to the database
            }));

            // Respond with success
            res.status(200).json({
                message: 'Files uploaded successfully',
                data: mediaLogs,
            });
        } catch (error) {
            console.error('Error saving media logs:', error);
            res.status(500).json({ message: 'Error saving media logs', error: error.message });
        }
    });
}











module.exports = {
    statusActivityLog, workActivityLog, AppsDurationLog, getAppsDuration, getActivityLogs, getStatusLogs, getWorkLogs, addSession, getSession, endSession, ScreenShot,

    addDailyCalculatedSystemStats, addDailySystemStats, addDailyAppActivity, addDailyAppUsage,
};
