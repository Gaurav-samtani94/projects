const User = require("../../../models/tracker/user/User");
const jwt = require("jsonwebtoken");
// const getDb = require("../../../config/mongoClient");
const { JWT_SECRET } = require("../../../config/config");
const { ObjectId } = require("mongodb");
const Joi = require("joi");
const md5 = require('md5');

const bcrypt = require('bcryptjs')



const userValidationSchema = Joi.object({
  id: Joi.string().optional(),

  user_id: Joi.string().optional(),

  date_of_joining: Joi.date().iso().optional(),

  date_of_leaving: Joi.date().iso().allow("0000-00-00").optional(),

  reporting_manager: Joi.string().optional(),

  reporting_manager_name: Joi.string().optional().allow(null),

  emp_status_id: Joi.string().optional().allow(null),

  emp_status_name: Joi.string().optional().allow(null),

  businessunit_id: Joi.string().optional().allow(null),

  businessunit_name: Joi.string().optional().allow(null),

  department_id: Joi.string().optional().allow(null),

  department_name: Joi.string().optional().allow(null),

  jobtitle_id: Joi.string().optional().allow(null),

  jobtitle_name: Joi.string().optional().allow(null),

  position_id: Joi.string().optional().allow(null),

  position_name: Joi.string().optional().allow(null),

  years_exp: Joi.string().optional().allow(null),

  holiday_group: Joi.string().optional().allow(null),

  holiday_group_name: Joi.string().optional().allow(null),

  prefix_id: Joi.string().optional().allow(null),

  prefix_name: Joi.string().optional().allow(null),

  extension_number: Joi.string().optional().allow(null),

  office_number: Joi.string().optional().allow(null),

  office_faxnumber: Joi.string().optional().allow(null),

  emprole: Joi.number().required().allow(null),

  emprole_name: Joi.string().optional().allow(null),

  firstname: Joi.string().required(),

  lastname: Joi.string().required(),

  userfullname: Joi.string().required(),

  emailaddress: Joi.string().email().required(),

  contactnumber: Joi.string().optional().allow(null),

  backgroundchk_status: Joi.string().optional().allow(null),

  employeeId: Joi.string().optional().allow(null),

  modeofentry: Joi.string().optional().allow(null),

  other_modeofentry: Joi.string().optional().allow(null),

  selecteddate: Joi.date().iso().optional().allow(null),

  candidatereferredby: Joi.string().optional().allow(null),

  referer_name: Joi.string().optional().allow(null),

  profileimg: Joi.string().optional().allow(null),

  branch_id: Joi.string().optional().allow(null),

  createdby: Joi.string().optional().allow(null),

  createdby_name: Joi.string().optional().allow(null),

  modifiedby: Joi.string().optional().allow(null),

  createddate: Joi.date().iso().optional().allow(null),

  modifieddate: Joi.date().iso().optional().allow(null),

  isactive: Joi.string().valid("1", "0").optional(),

  password: Joi.string().optional().allow(null),
});

const updateUserValidationSchema = Joi.object({
  id: Joi.string().optional(),

  user_id: Joi.string().optional(),

  date_of_joining: Joi.date().iso().optional(),

  date_of_leaving: Joi.date().iso().allow("0000-00-00").optional(),

  reporting_manager: Joi.string().optional(),

  reporting_manager_name: Joi.string().optional().allow(null),

  emp_status_id: Joi.string().optional().allow(null),

  emp_status_name: Joi.string().optional().allow(null),

  businessunit_id: Joi.string().optional().allow(null),

  businessunit_name: Joi.string().optional().allow(null),

  department_id: Joi.string().optional().allow(null),

  department_name: Joi.string().optional().allow(null),

  jobtitle_id: Joi.string().optional().allow(null),

  jobtitle_name: Joi.string().optional().allow(null),

  position_id: Joi.string().optional().allow(null),

  position_name: Joi.string().optional().allow(null),

  years_exp: Joi.string().optional().allow(null),

  holiday_group: Joi.string().optional().allow(null),

  holiday_group_name: Joi.string().optional().allow(null),

  prefix_id: Joi.string().optional().allow(null),

  prefix_name: Joi.string().optional().allow(null),

  extension_number: Joi.string().optional().allow(null),

  office_number: Joi.string().optional().allow(null),

  office_faxnumber: Joi.string().optional().allow(null),

  emprole: Joi.number().optional().allow(null),

  emprole_name: Joi.string().optional().allow(null),

  firstname: Joi.string().optional(),

  lastname: Joi.string().optional(),

  userfullname: Joi.string().optional(),

  emailaddress: Joi.string().email().optional(),

  contactnumber: Joi.string().optional().allow(null),

  backgroundchk_status: Joi.string().optional().allow(null),

  employeeId: Joi.string().optional().allow(null),

  modeofentry: Joi.string().optional().allow(null),

  other_modeofentry: Joi.string().optional().allow(null),

  selecteddate: Joi.date().iso().optional().allow(null),

  candidatereferredby: Joi.string().optional().allow(null),

  referer_name: Joi.string().optional().allow(null),

  profileimg: Joi.string().optional().allow(null),

  branch_id: Joi.string().optional().allow(null),

  createdby: Joi.string().optional().allow(null),

  createdby_name: Joi.string().optional().allow(null),

  modifiedby: Joi.string().optional().allow(null),

  createddate: Joi.date().iso().optional().allow(null),

  modifieddate: Joi.date().iso().optional().allow(null),

  isactive: Joi.string().valid("1", "0").optional(),

  password: Joi.string().optional().allow(null),
});

const registerUser = async (req, res) => {
  try {
    const empRole = req.user?.empRole;

    if (empRole != "1")
      return res
        .status(401)
        .json({ message: "You are not authorized to add user" });

    const userData = req.body;
    const { result, error } = await userValidationSchema.validate(userData);

    if (error) return res.status(400).json({ message: error.message });

    const userExists = await User.findOne({
      emailaddress: req.body.emailaddress,
    });

    if (userExists)
      return res.status(400).json({ message: "User already exists" });

    const salt = await bcrypt.genSalt(10);
    const password = await bcrypt.hash(userData.password, salt);

    userData.password = password;

    const user = await User.create(userData);

    if (user) {
      const token = jwt.sign(
        { user: { id: user._id, empRole: user.emprole } },
        JWT_SECRET,
        { expiresIn: "30d" }
      );
      res
        .status(200)
        .json({ message: "Registration successful", token, userData });
    } else {
      res.status(400).json({ message: "Invalid user data" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: error.message });
  }
};

const changePassword = async (req, res) => {
  try {
    const userId = req.user?.id;
    const { oldPassword, newPassword } = req.body;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (!oldPassword || !newPassword) {
      return res.status(400).json({ message: "Both current and new password are required" });
    }

    const user = await User.findOne({ where: { id: userId } });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

     const hashPassword = md5(oldPassword);


    const isMatch = (user.password == hashPassword)

    if (!isMatch) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    const hashedNewPassword = md5(newPassword)

    user.password = hashedNewPassword;
    await user.save();

    res.status(200).json({ message: "Password changed successfully" });
  } catch (error) {
    console.error("Change Password Error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


const loginUser = async (req, res) => {
  const Schema = Joi.object({
    email:Joi.string().email(),
    password: Joi.string()
});

const DataToValidate = {
    email:req.body.email,
    password:req.body.password
};

const result = Schema.validate(DataToValidate);
if(result.error){
    return res.status(401).send({
        message: result.error.details[0].message,
        status:"0",
        success:false,
        error:true
    })
}
try {
    const userRecord = await User.findOne({
        where:{
            emailaddress:req.body.email,
            isactive:"1"
        }
    });

    if (!userRecord) {
        return res.status(401).send({
            message: 'Invalid email or password',
            success: false,
            status: '0',
            error: true,
        });
    }

    // Convert to plain object
    const user = userRecord.get({ plain: true });

    // Check if any other user reports to this user
    const isReportingManager = await User.count({
        where: {
            reporting_manager: user.id,
            isactive: "1"
        }
    });

    // Add the boolean flag
    user.isReportingManager = isReportingManager > 0;

    const hashPassword = md5(DataToValidate?.password);
    if (hashPassword !== user.password) {
        return res.status(401).send({
            message: 'Invalid email or password',
            success: false,
            status: '0',
            error: true,
        });
    }

    const token = jwt.sign(
        {user:user},
        JWT_SECRET,
        {expiresIn:"30d"}
    )
         return res.status(200).send({
            message: 'Login successful',
            success: true,
            status: '1',
            user:user,
            token: token,
        });
} catch (error) {
    return res.status(500).send({
        message:"somthing went wrong",
        success:false,
        status:'0',
        error:error.message
    })
}
};


const getUserHierarchy = async (userId) => {
  // Recursive function to fetch the user and their reporting employees
  const users = await User.find(
    { reporting_manager: userId, isactive: { $ne: "0" } },
    {
      userfullname: 1, // Include only necessary fields
      emailaddress: 1,
      reporting_manager_name: 1,
    }
  );

  const userWithSubordinates = [];
  for (const user of users) {
    const subordinates = await getUserHierarchy(user._id); // Fetch the user's subordinates
    userWithSubordinates.push({ ...user._doc, subordinates });
  }
  return userWithSubordinates;
};

const usersList = async (req, res) => {
  try {
    const userId = req.user.id; 
    const userHierarchy = await getUserHierarchy(userId);
    if (userHierarchy.length) {
      return res
        .status(200)
        .json({ message: "Record Found", data: userHierarchy });
    } else {
      return res.status(404).json({ message: "No record found" });
    }
  } catch (error) {
    console.log(error.message);
    return res
      .status(500)
      .json({ message: "Error fetching users", error: error.message });
  }
};

const allUsersList = async (req, res) => {
  try {
    const users = await User.findAll({
      where: {
          isactive:1
      },
    });

    if (users[0]) {
      return res.status(200).json({ message: "Record Found", data: users });
    } else {
      return res.status(404).json({ message: "No record found" });
    }
  } catch (error) {
    console.log(error.message);
    return res
      .status(500)
      .json({ message: "Error fetching users", error: error.message });
  }
};


const getUserDetails = async (req, res) => {
  try {
    let userId;
    // Check if userId is passed in the body
    if (req.body.userId) {
      userId = req.body.userId;
      // Validate the format of userId (UUID or numeric, depending on your DB schema)
      if (!Number.isInteger(Number(userId))) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
    } else {
      userId = req.user.id;
    }

    // Find the user in the database using Sequelize
    const user = await User.findOne({
      where: { id: userId }
    });

    if (user) {
      // Check if the user making the request has permissions to view the user details
      if (req.body.userId) {
        const isAdmin = req.user.empRole === "8" || req.user.empRole === "1";
        const isReportingManager =
          user.reporting_manager_id && user.reporting_manager_id === req.user.id;

        // If not Admin and not the Reporting Manager, return unauthorized
        if (!isAdmin && !isReportingManager) {
          return res.status(401).json({
            message: "You are not authorized to view this user's details",
          });
        }
      }
      // Return the user details if everything is valid
      return res.status(200).json({ message: "Record found",status:"1", data: user, });
    } else {
      return res.status(404).json({ message: "No record found" });
    }
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({
      message: "Something went wrong",
      error: error.message,
    });
  }
};





const updateUserDetails = async (req, res) => {
  try {
    const empRole = req.user.empRole;

    if (empRole != "1")
      return res
        .status(401)
        .json({ message: "You are not authorized to update user details." });

    const update_id = req.params.update_id;
    const updatedData = req.body;

    const { result, error } = await updateUserValidationSchema.validate(
      updatedData
    );
    if (error) return res.status(400).json({ message: error.message });

    if (!ObjectId.isValid(update_id))
      return res.status(400).json({ message: "update_id is not valid" });

    const user = await User.findOne({ _id: new ObjectId(update_id) });

    if (!user) return res.status(404).send({ message: "User not found" });

    const updateUser = await user.updateOne(updatedData);

    if (updateUser.acknowledged) {
      return res.status(200).json({ message: "Record updated" });
    }
  } catch (error) {
    console.log(error.message);
    return res
      .status(500)
      .json({ message: "Something went wrong", error: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser,
  usersList,
  allUsersList,
  getUserDetails,
  updateUserDetails,
  changePassword
};
