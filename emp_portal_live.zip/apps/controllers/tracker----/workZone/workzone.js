const mongoose = require("mongoose");
const WorkzoneModel = require("../../../models/tracker/workzone/workZone");
const { date } = require("joi");
const { ObjectId } = require("mongodb");
const Joi = require("joi");

const GetWorkZone = async (req, res) => {
  try {
    const assignedBy = req.user.id;
    console.log("Logged-in User ID (assignedBy):", assignedBy); // Log the assignedBy to check its value

    // Validate if assignedBy is a valid ObjectId
    if (!assignedBy || !mongoose.Types.ObjectId.isValid(assignedBy)) {
      return res.status(400).json({
        success: false,
        message: "Invalid AssignedBy ID",
      });
    }

    console.log(assignedBy, "is assigned by id");

    // Cast assignedBy to ObjectId
    // const assignedByObjectId =  new ObjectId(assignedBy);

    // Fetch work zones assigned by the logged-in user
    const workZones = await WorkzoneModel.find({
      assignedBy: new mongoose.Types.ObjectId(assignedBy),
    });

    console.log("Found Work Zones:", workZones); // Log the found work zones to see the result

    // Return response based on result
    return res.status(200).json({
      success: true,
      message: workZones.length ? "Records found" : "No records found",
      data: workZones,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Something went wrong",
      error: error.message,
    });
  }
};

const addWorkZone = async (req, res) => {
  try {
    const assignedBy = req.user.id;

    const schema = Joi.object({
      userId: Joi.string().required(),
      workType: Joi.string().valid("WFH", "WFO").required(),
      startDate: Joi.date().required(),
      endDate: Joi.date().required(),
    });

    const dataToValidate = {
      userId: req.body.userId,
      workType: req.body.workType,
      startDate: req.body.startDate,
      endDate: req.body.endDate,
    }

    const {result, error} = await schema.validate(dataToValidate);
    if(error) return res.status(400).json({message: error.message})

      dataToValidate.assignedBy = assignedBy;

      const insertWorkZone = await WorkzoneModel.create(dataToValidate);

      return res.status(200).json({
        message: 'Record inserted'
      })


  } catch (error) {
    return res.status(500).json({
      message: "Something went wrong",
      error: error.message,
    });
  }
};

module.exports = {
  GetWorkZone, addWorkZone
};
