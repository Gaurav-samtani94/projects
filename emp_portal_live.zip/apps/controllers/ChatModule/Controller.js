const Group = require("../../models/ChatModule/group");
const GroupMember = require("../../models/ChatModule/member");
const Message = require("../../models/ChatModule/message");
const User = require("../../models/tracker/user/User");
const Chat = require("../../models/ChatModule/chat");
const Arrangementsmodel = require('../../models/ChatModule/ChatUserOrder')
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const Joi = require("joi");
const { Op } = require("sequelize");
const getCurrentDateTime = () => new Date();
const timestamp = Date.now();
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const uploadPath = `uploads/public_/chat/${req.user.id}user`;
      // Ensure directory exists, create if not
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    } catch (err) {
      cb(err); // In case of an error, pass it to multer
    }
  },
  filename: (req, file, cb) => {
    try {
      const extension = path.extname(file.originalname);
      // Decode the URL-encoded file name and replace spaces with underscores or remove them
      let filename = decodeURIComponent(file.originalname.trim());
      filename = filename.replace(/\s+/g, "_");
      filename = filename.replace(/[^\w\-_.]/g, "");
      filename = `${"file"}_${filename}`;

      cb(null, filename); // Save with cleaned filename
      req.extension = extension; // Store file extension in request for further use
    } catch (err) {
      cb(err);
    }
  },
});

const upload = multer({ storage: storage });

exports.uploadSingleDocument = async (req, res) => {
  upload.array("file")(req, res, async function (err) {
    if (err) {
      return res.status(400).json({
        message: err.message,
        success: false,
        error: true,
        status: "0",
      });
    }

    try {
      const { chat_id, sender_id, reply_to_id } = req.body;
      const file = req.files[0];
      const timestamp = new Date();

      // Check if file was uploaded
      if (!file) {
        return res.status(400).json({
          message: "No file uploaded",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Validate required fields
      if (!chat_id || !sender_id) {
        return res.status(400).json({
          message: "chat_id and sender_id are required",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Validate chat_id and sender_id are integers
      if (
        !Number.isInteger(Number(chat_id)) ||
        !Number.isInteger(Number(sender_id))
      ) {
        return res.status(400).json({
          message: "chat_id and sender_id must be valid integers",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Sanitize file name
      let filename = decodeURIComponent(file.originalname.trim());
      filename = filename.replace(/\s+/g, "_");
      filename = filename.replace(/[^\w\-_.]/g, "");
      filename = `${"file"}_${filename}`;

      // Sanitize reply_to_id (ensure it's an integer or null)
      const sanitizedReplyToId = Number.isInteger(Number(reply_to_id))
        ? Number(reply_to_id)
        : null;

      const document = await Message.create({
        chat_id: Number(chat_id),
        sender_id: Number(sender_id),
        file_path: file.destination,
        file_name: filename,
        file_type: file.mimetype,
        reply_to_id: sanitizedReplyToId,
        type: sanitizedReplyToId ? "reply" : null,
        created_by: req.user.id,
        delivered_at: timestamp,
      });

      return res.status(201).json({
        message: "Document uploaded successfully",
        success: true,
        error: false,
        status: "1",
        data: document,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Something went wrong",
        success: false,
        error: true,
        status: "0",
        msg: error.message,
      });
    }
  });
};

exports.sendGroupMessage = async (req, res) => {
  try {
    const { group_id, sender_id, text, reply_to_id } = req.body;

    if (!group_id || !sender_id || !text || typeof text !== "string") {
      return res.status(400).send({
        message: "group_id, sender_id, and text (string) are required",
        success: false,
        error: true,
        status: "0",
      });
    }

    if (
      !Number.isInteger(Number(group_id)) ||
      !Number.isInteger(Number(sender_id))
    ) {
      return res.status(400).send({
        message: "group_id and sender_id must be valid integers",
        success: false,
        error: true,
        status: "0",
      });
    }

    const message = await Message.create({
      group_id,
      sender_id,
      text,
      reply_to_id: reply_to_id || null,
      status: "sent",
      delivered_at: new Date(),
    });
    return res.status(201).send({
      message: "message sent to group",
      success: true,
      error: false,
      status: "1",
      data: message,
    });
  } catch (error) {
    res.status(500).json({
      message: "something went wrong",
      success: false,
      status: "0",
      error: error.message,
    });
  }
};

const space = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const uploadPath = `uploads/public_/group/profile`;
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    } catch (err) {
      cb(err);
    }
  },
  filename: (req, file, cb) => {
    try {
      const extension = path.extname(file.originalname);
      let filename = decodeURIComponent(file.originalname.trim());
      filename = filename.replace(/\s+/g, "_").replace(/[^\w\-_.]/g, "");
      req.cleanedFilename = `group_${filename}`;
      cb(null, req.cleanedFilename);
    } catch (err) {
      cb(err);
    }
  },
});


const GroupProfile = multer({ storage: space });

// exports.createGroupChat = async (req, res) => {
//   GroupProfile.single("file")(req, res, async function (err) {
//     if (err) {
//       return res.status(400).json({
//         message: err.message,
//         success: false,
//         error: true,
//         status: "0",
//       });
//     }

//     try {
//       const { group_name, user_ids, description } = req.body;
//       const created_by = req.user.id;
//       const created_at = new Date();
//       const file = req.file; // Corrected: req.file (single file)

//       // Validation checks
//       if (!group_name || !user_ids || !Array.isArray(user_ids)) {
//         return res.status(400).send({
//           message: "group_name (string) and user_ids (array) are required",
//           success: false,
//           error: true,
//           status: "0",
//         });
//       }

//       if (typeof group_name !== "string") {
//         return res.status(400).send({
//           message: "group_name must be a string",
//           success: false,
//           error: true,
//           status: "0",
//         });
//       }

//       if (!user_ids.every((id) => Number.isInteger(Number(id)))) {
//         return res.status(400).send({
//           message: "All user_ids must be valid integers",
//           success: false,
//           error: true,
//           status: "0",
//         });
//       }

//       // Optional: Profile image handling
//       let profile_path = null;
//       if (file) {
//         let filename = decodeURIComponent(file.originalname.trim());
//         filename = filename.replace(/\s+/g, "_").replace(/[^\w\-_.]/g, "");
//         filename = `file_${Date.now()}_${filename}`;
//         profile_path = `/uploads/${filename}`;
//       }

//       // Group creation
//       const group = await Group.create({
//         group_name,
//         description: description || null,
//         profile_name: file ? file.originalname : null,
//         profile_path: profile_path,
//         created_by,
//         created_at,
//       });

//       // Group creator becomes a member
//       await GroupMember.create({ group_id: group.id, user_id: created_by });

//       if (user_ids.length > 0) {
//         const members = user_ids.map((user_id) => ({
//           group_id: group.id,
//           user_id,
//         }));
//         await GroupMember.bulkCreate(members);
//       }

//       return res.status(201).json({
//         message: "Group created successfully",
//         success: true,
//         error: false,
//         status: "1",
//         data: group,
//       });
//     } catch (error) {
//       return res.status(500).json({
//         message: "Something went wrong",
//         success: false,
//         error: true,
//         status: "0",
//         details: error.message,
//       });
//     }
//   });
// };

exports.createGroupChat = async (req, res) => {
  GroupProfile.single("file")(req, res, async function (err) {
    if (err) {
      return res.status(400).json({
        message: err.message,
        success: false,
        error: true,
        status: "0",
      });
    }

    try {
      const { group_name, user_ids, description } = req.body;
      const created_by = req.user.id;
      const created_at = new Date();
      const file = req.file;

      // Validation checks
      if (!group_name || !user_ids || !Array.isArray(user_ids)) {
        return res.status(400).send({
          message: "group_name (string) and user_ids (array) are required",
          success: false,
          error: true,
          status: "0",
        });
      }

      if (typeof group_name !== "string") {
        return res.status(400).send({
          message: "group_name must be a string",
          success: false,
          error: true,
          status: "0",
        });
      }

      if (!user_ids.every((id) => Number.isInteger(Number(id)))) {
        return res.status(400).send({
          message: "All user_ids must be valid integers",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Profile image handling (consistent filename)
      let profile_path = null;
      let profile_name = null;

      if (file) {
        // Using the cleaned filename directly from multer
        profile_name = req.cleanedFilename || file.originalname;
        profile_path = `/uploads/public_/group/profile/${profile_name}`;
      }

      // Group creation
      const group = await Group.create({
        group_name,
        description: description || null,
        profile_name: profile_name,
        profile_path: profile_path,
        created_by,
        created_at,
      });

      // Group creator becomes a member
      await GroupMember.create({ group_id: group.id, user_id: created_by });

      if (user_ids.length > 0) {
        const members = user_ids.map((user_id) => ({
          group_id: group.id,
          user_id,
        }));
        await GroupMember.bulkCreate(members);
      }

      return res.status(201).json({
        message: "Group created successfully",
        success: true,
        error: false,
        status: "1",
        data: group,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Something went wrong",
        success: false,
        error: true,
        status: "0",
        details: error.message,
      });
    }
  });
};


const storagee = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const uploadPath = `uploads/public_/group/${req.user.id}user`;
      // Ensure directory exists, create if not
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    } catch (err) {
      cb(err); // In case of an error, pass it to multer
    }
  },
  filename: (req, file, cb) => {
    try {
      const extension = path.extname(file.originalname);
      // Decode the URL-encoded file name and replace spaces with underscores or remove them
      let filename = decodeURIComponent(file.originalname.trim());
      filename = filename.replace(/\s+/g, "_");
      filename = filename.replace(/[^\w\-_.]/g, "");
      filename = `${"file"}_${filename}`;

      cb(null, filename); // Save with cleaned filename
      req.extension = extension; // Store file extension in request for further use
    } catch (err) {
      cb(err);
    }
  },
});

const Groupupload = multer({ storage: storagee });

exports.uploadGroupDocument = async (req, res) => {
  Groupupload.array("file")(req, res, async function (err) {
    if (err) {
      return res.status(400).json({
        message: err.message,
        success: false,
        error: true,
        status: "0",
      });
    }

    try {
      const { group_id, sender_id, reply_to_id } = req.body;
      const file = req.files[0];
      if (!file) {
        return res.status(400).json({
          message: "No file uploaded",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Validate required fields
      if (!group_id || !sender_id) {
        return res.status(400).json({
          message: "group_id and sender_id are required",
          success: false,
          error: true,
          status: "0",
        });
      }

      if (
        !Number.isInteger(Number(group_id)) ||
        !Number.isInteger(Number(sender_id))
      ) {
        return res.status(400).json({
          message: "chat_id and sender_id must be valid integers",
          success: false,
          error: true,
          status: "0",
        });
      }
      // Sanitize file name
      let filename = decodeURIComponent(file.originalname.trim());
      filename = filename.replace(/\s+/g, "_");
      filename = filename.replace(/[^\w\-_.]/g, "");
      filename = `${"file"}_${filename}`;

      // Sanitize reply_to_id (ensure it's an integer or null)
      const sanitizedReplyToId = Number.isInteger(Number(reply_to_id))
        ? Number(reply_to_id)
        : null;

      const document = await Message.create({
        group_id,
        sender_id,
        reply_to_id: sanitizedReplyToId,
        type: sanitizedReplyToId ? "reply" : null,
        file_path: file.destination,
        file_name: filename,
        file_type: file.mimetype,
        created_by: req.user.id,
        delivered_at: timestamp,
      });
      return res.status(201).json({
        message: "Document uploaded successfully",
        success: true,
        error: false,
        status: "1",
        data: document,
      });
    } catch (error) {
      // Handle unexpected errors
      return res.status(500).json({
        message: "Something went wrong",
        success: false,
        error: true,
        status: "0",
        details: error.message,
      });
    }
  });
};

exports.getGroupChatMessages = async (req, res) => {
  const schema = Joi.object().keys({
    group_id: Joi.number().required(),
    limit: Joi.string().required(),
    page_number: Joi.number().default(0),
  });
  const dataToValidate = {
    group_id: req.body.group_id,
    limit: req.body.limit,
    page_number: req.body.page_number == 0 ? "1" : req.body.page_number,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(400).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      const { group_id } = req.body;
      const page_number = dataToValidate.page_number;
      const parsedLimit = parseInt(dataToValidate.limit) || 10;
      const totalMessages = await Message.count({ where: { group_id } });
      const totalPages = Math.ceil(totalMessages / parsedLimit);
      const offset = (page_number - 1) * parsedLimit;

      const messages = await Message.findAll({
        where: {
          group_id: req.body.group_id,
          is_active: "1",
        },
        offset,
        limit: parsedLimit,
        include: [
          {
            model: User,
            as: "sender",
            attributes: ["id", "emailaddress", "userfullname"],
          },
          {
            model: Message,
            as: "replyTo",
            attributes: ["id", "text", "file_name"],
            required: false,
          },
          {
            model: Message,
            as: "forwardedFrom",
            attributes: ["id", "text", "file_name"],
            required: false,
          },
        ],
        order: [["id", "DESC"]], // latest messages first
      });
      const data = messages.reverse();
      return res.status(200).json({
        message: data.length > 0 ? "record found" : "no messages found",
        success: true,
        error: false,
        status: "1",
        data: Array.isArray(data) ? data : [data],
        pagination: {
          current_page: page_number,
          total_pages: totalPages,
          total_messages: totalMessages,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: "something went wrong",
        success: false,
        error: error.message,
        status: "0",
      });
    }
  }
};

exports.startCall = async (req, res) => {
  try {
    const { chat_id, group_id, caller_id, call_type } = req.body;

    // ✅ Validation: Only one of chat_id or group_id should be provided
    if ((!chat_id && !group_id) || (chat_id && group_id)) {
      return res.status(400).json({
        message: "Either chat_id or group_id is required, but not both.",
        success: false,
        error: true,
        status: "0",
      });
    }

    if (!Number.isInteger(Number(caller_id))) {
      return res.status(400).json({
        message: "caller_id must be a valid integer",
        success: false,
        error: true,
        status: "0",
      });
    }

    if (chat_id && !Number.isInteger(Number(chat_id))) {
      return res.status(400).json({
        message: "chat_id must be a valid integer",
        success: false,
        error: true,
        status: "0",
      });
    }

    if (group_id && !Number.isInteger(Number(group_id))) {
      return res.status(400).json({
        message: "group_id must be a valid integer",
        success: false,
        error: true,
        status: "0",
      });
    }

    // ✅ Check for ongoing call with the same chat_id/group_id that hasn't ended
    const existingCall = await Message.findOne({
      where: {
        [Op.or]: [
          { chat_id: chat_id || null, group_id: null },
          { group_id: group_id || null, chat_id: null },
        ],
        call_type,
        end_time: null, // still ongoing
      },
    });

    if (existingCall) {
      return res.status(200).json({
        message: "Call already in progress",
        success: true,
        status: "1",
        error: false,
        data: existingCall,
      });
    }

    // ✅ No existing call, create a new one
    const call = await Message.create({
      chat_id: chat_id || null,
      group_id: group_id || null,
      caller_id,
      start_time: new Date(),
      sender_id: caller_id,
      chat_type: "call",
      call_type,
      created_by: caller_id,
      delivered_at: new Date(),
    });

    return res.status(201).json({
      message: "Call started successfully",
      success: true,
      status: "1",
      error: false,
      data: call,
    });
  } catch (error) {
    res.status(500).json({
      message: "Something went wrong",
      success: false,
      status: "0",
      error: error.message,
    });
  }
};


exports.endCall = async (req, res) => {
  try {
    const { call_id, group_id } = req.body;

    if (!call_id || !Number.isInteger(Number(call_id))) {
      return res.status(400).json({
        message: "valid call_id (integer) is required",
        success: false,
        error: true,
        status: "0",
      });
    }

    const call = await Message.findOne({
      where: {
        caller_id: call_id,
        group_id: group_id || null,
        end_time: null, // still ongoing
        duration: null,
      },
    });
    if (!call) {
      return res.status(202).json({
        message: "Call not found",
        success: false,
        error: true,
        status: "0",
        data: 404,
      });
    }

    call.end_time = new Date();
    call.duration = Math.floor((call.end_time - call.start_time) / 1000);
    (call.updated_by = call_id), await call.save();

    return res.status(200).json({
      message: "call ended successfully",
      success: true,
      status: "1",
      error: false,
      data: call,
    });
  } catch (error) {
    res.status(200).json({
      message: "something went wrong",
      success: false,
      status: "0",
      error: error.message,
      data: 404,
    });
  }
};

exports.GroupList = async (req, res) => {
  try {
    // Fetch groups where the user is a member
    const memeberID = await GroupMember.findAll({
      where: {
        user_id: req.user.id,
        status: "1",  // Active status
      },
    });

    if (!memeberID || memeberID.length === 0) {
      return res.status(404).send({
        message: "No group found",
        success: false,
        error: true,
        status: "0",
      });
    }
    // Extract the group IDs from the members
    const groupIds = memeberID.map((member) => member.group_id);
    // Fetch group information along with members and creator
    const groups = await Group.findAll({
      where: { id: groupIds },
      attributes: ["id", "group_name", "type", "created_by", "created_at"],
      include: [
        {
          model: User,
          as: "creator",
          attributes: ["id", "userfullname", "emailaddress"], // Creator info
        },
        {
          model: GroupMember,
          as: "members",
          attributes: ["id"],
          include: [
            {
              model: User,
              as: "memberInfo",
              attributes: ["id", "userfullname", "emailaddress"], // Member info
            },
          ],
        },
      ],
    });
    // Adding unread message count and last message for each group
    const groupsWithChatInfo = await Promise.all(
      groups.map(async (group) => {
        // Initialize unread message count and last message as null
        let chat_unread_count = 0;
        let lastmsg = null;

        // Fetch unread messages and last message directly from the Message table using group_id
        const unreadMessages = await Message.count({
          where: {
            group_id: group.id, // Group-specific messages
            // sender_id: { [Op.ne]: req.user.id }, // Messages sent by other users
            read_at: null, // Only unread messages
          },
        });
        // Get the last message in the group
        const last_message = await Message.findOne({
          where: {
            group_id: group.id, // Group-specific messages
          },
          order: [["id", "DESC"]], // Most recent message
        });

        lastmsg = last_message ? last_message.text : null;
        chat_unread_count = unreadMessages;

        return {
          groupId: group.id,
          groupName: group.group_name,
          createdAt: group.created_at,
          groupType: group.type,
          createdBy: group.creator
            ? {
                creatorName: group.creator.userfullname,
              }
            : "Unknown",
          chatUnreadCount: chat_unread_count,
          lastMessage: lastmsg,
          members: group.members.map((member) => ({
            memberId: member.id,
            memberName: member.memberInfo.userfullname,
            userId: member.memberInfo.id,
          })),
        };
      })
    );

    return res.status(200).send({
      message: "Group list found",
      success: true,
      error: false,
      status: "1",
      data: groupsWithChatInfo,
    });
  } catch (error) {
    return res.status(500).send({
      message: "Something went wrong",
      success: false,
      error: true,
      status: "0",
      details: error.message,
    });
  }
};


exports.DeleteChat = async (req, res) => {
  const schema = Joi.object({
    id: Joi.string().required(),
  });

  const dataToValidate = {
    id: req.body.msgId,
  };
  const { result, error } = schema.validate(dataToValidate);
  if (error) {
    return res.status(403).send({
      message: error.details[0].message,
      success: false,
      error: true,
      status: "0",
    });
  }
  try {
    const result = await Message.findOne({
      where: {
        id: dataToValidate.id,
        is_active: "1",
      },
    });
    if (!result) {
      return res.status(404).send({
        message: "record not found",
        success: false,
        error: true,
        status: "0",
      });
    }
    const updated = {
      is_active: "0",
      updated_by: req.user.id,
    };
    const update = await Message.update(updated, {
      where: {
        id: dataToValidate.id,
      },
    });

    return res.status(200).send({
      message: "chat delete successfully",
      error: false,
      success: true,
      status: "1",
    });
  } catch (error) {
    return res.status(500).send({
      message: "somthing went wrong",
      success: false,
      error: true,
      status: "0",
    });
  }
};

exports.sendSingleMessage = async (req, res) => {
  try {
    const { chat_id, sender_id, text, reply_to_id } = req.body;
    const file = req.file;
    const chatExists = await Chat.findOne({ where: { id: chat_id } });
    if (!chatExists) {
      return res.status(400).json({
        success: false,
        status: "0",
        message: "chat_id not match",
      });
    }

    const messageData = {
      chat_id,
      sender_id,
      text: text || null,
      reply_to_id: reply_to_id || null,
      status: "sent",
      created_by: req.user.id,
      delivered_at: new Date(),
      chat_type: "msg",
      type: reply_to_id ? "0" : null,
    };

    if (file) {
      messageData.file_path = file.path;
      messageData.file_name = file.originalname;
      messageData.file_type = file.mimetype;
    }

    const message = await Message.create(messageData);

    res.status(201).json({
      success: true,
      status: "1",
      data: message,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

exports.getSingleChatMessages = async (req, res) => {
  const schema = Joi.object().keys({
    limit: Joi.string().required(),
    page_number: Joi.any().required(), // 'last' for the last page
    chat_id: Joi.number().required(),
  });

  const dataToValidate = {
    chat_id: req.body.chat_id,
    limit: req.body.limit,
    page_number: req.body.page_number,
  };

  const result = schema.validate(dataToValidate);
  if (result.error) {
    return res.status(400).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  }

  try {
    const { chat_id, limit } = dataToValidate;
    let page_number = parseInt(dataToValidate.page_number) || 1;
    const parsedLimit = parseInt(limit) || 9;

    // Total messages count
    const totalMessages = await Message.count({ where: { chat_id } });
    const totalPages = Math.ceil(totalMessages / parsedLimit);

    // Calculate the offset
    const offset = (page_number - 1) * parsedLimit;

    // Fetch messages in descending order (most recent first)
    const messages = await Message.findAll({
      where: { chat_id },
      offset,
      limit: parsedLimit,
      include: [
        {
          model: User,
          as: "sender",
          attributes: ["id", "emailaddress", "userfullname"],
        },
        {
          model: Message,
          as: "replyTo",
          attributes: ["id", "text", "file_name"],
        },
        {
          model: Message,
          as: "forwardedFrom",
          attributes: ["id", "text", "file_name"],
        },
      ],
      order: [["id", "DESC"]], // Most recent messages first
    });

    // If no messages were fetched, it means we're on the last page already
    if (messages.length === 0) {
      return res.status(200).json({
        message: "No more messages to load",
        success: true,
        error: false,
        status: "1",
        data: [],
        pagination: {
          current_page: page_number,
          total_pages: totalPages,
          total_messages: totalMessages,
        },
      });
    }

    res.status(200).json({
      message: "record found",
      success: true,
      error: false,
      status: "1",
      data: messages?.reverse(), // Reverse the order to show oldest first
      pagination: {
        current_page: page_number,
        total_pages: totalPages,
        total_messages: totalMessages,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: "something went wrong",
      error: true,
      success: false,
      msg: error.message,
    });
  }
};

exports.Chatforward = async (req, res) => {
  try {
    const { sender_id, chat_id, group_id, message_id } = req.body;
    if (!chat_id && !group_id) {
      return res.status(400).json({ error: "chat_id or group_id is required" });
    }
    if (!message_id) {
      return res.status(400).json({ error: "message_id is required" });
    }

    const originalMessage = await Message.findByPk(message_id);
    if (!originalMessage) {
      return res
        .status(404)
        .json({ status: "0", error: "Message or document not found" });
    }
    const forwardedMessage = await Message.create({
      chat_id: chat_id || null,
      group_id: group_id || null,
      sender_id,
      text: originalMessage.text,
      file_path: originalMessage.file_path,
      file_name: originalMessage.file_name,
      file_type: originalMessage.file_type,
      forwarded_from_id: message_id,
      status: "sent",
      delivered_at: new Date(),
      type: "1",
    });
    res.status(200).json({
      message: "chat forward successfully",
      success: true,
      error: false,
      status: "1",
      data: forwardedMessage,
    });
  } catch (error) {
    res.status(500).json({
      message: "somthing went wrong",
      error: true,
      success: false,
      msg: error.message,
    });
  }
};

exports.updateGroupDetails = async (req, res) => {
  GroupProfile.single("file")(req, res, async function (err) {
    if (err) {
      return res.status(400).json({
        message: err.message,
        success: false,
        error: true,
        status: "0",
      });
    }
    try {
      const { group_id, group_name, description, user_ids } = req.body;
      const file = req.file;

      if (!group_id) {
        return res.status(400).json({
          message: "group_id is required",
          success: false,
          error: true,
          status: "0",
        });
      }

      const group = await Group.findByPk(group_id);
      if (!group) {
        return res.status(404).json({
          message: "Group not found",
          success: false,
          error: true,
          status: "0",
        });
      }

      // Handling Profile Image
      let profile_path = group.profile_path;
      if (file) {
        // Delete existing file if it exists
        if (group.profile_path) {
          const existingPath = path.join(__dirname, "..", group.profile_path);
          if (fs.existsSync(existingPath)) fs.unlinkSync(existingPath);
        }

        // Use the cleaned filename from multer
        profile_path = `/uploads/public_/group/profile/${req.cleanedFilename}`;
      }

      // Update Group Details
      if (group_name) group.group_name = group_name;
      if (description) group.description = description;
      if (profile_path) group.profile_path = profile_path;
      if (file) group.profile_name = req.cleanedFilename;
      group.updated_by = req.user.id;

      await group.save();

      // Update Group Members (Optional)
      if (user_ids) {
        if (!Array.isArray(user_ids)) {
          return res.status(400).json({
            message: "user_ids must be an array",
            success: false,
            error: true,
            status: "0",
          });
        }

        // Remove existing members
        await GroupMember.destroy({ where: { group_id: group_id } });

        // Add updated members
        const members = user_ids.map((user_id) => ({
          group_id: group_id,
          user_id,
        }));
        await GroupMember.bulkCreate(members);
      }

      return res.status(200).json({
        message: "Group updated successfully",
        success: true,
        error: false,
        status: "1",
        data: group,
      });
    } catch (error) {
      return res.status(500).json({
        message: "Something went wrong",
        success: false,
        error: true,
        status: "0",
        details: error.message,
      });
    }
  });
};



exports.chatuserList = async (req, res) => {
  try {
    const activeUsers = await User.findAll({
      where: {
        isactive: "1",
        id: {
          [Op.ne]: req.user.id,
        },
      },
    });

    // Collecting IDs of users who do not have an arrangement with the current user
    const newArrangements = await Promise.all(
      activeUsers.map(async (user) => {
        const exists = await Arrangementsmodel.count({
          where: {
            from_user_id: req.user.id,
            to_user_id: user.id,
            status: "1",
          },
        });
        return exists < 1 ? user.id : null;
      })
    );
    // Filtering out null values and creating missing arrangements
    const usersToAdd = newArrangements.filter((id) => id !== null);
    if (usersToAdd.length > 0) {
      await Arrangementsmodel.bulkCreate(
        usersToAdd.map((id) => ({
          from_user_id: req.user.id,
          to_user_id: id,
          created_by: req.user.id,
          created_at: getCurrentDateTime(),
        }))
      );
    }

    const UserList = await Arrangementsmodel.findAll({
      where: {
        from_user_id: req.user.id,
        to_user_id: {
          [Op.ne]: req.user.id,
        },
        status: "1",
      },
      attributes: ["id", "to_user_id"],
      group: ["to_user_id"],
      order: [["updated_at", "DESC"]],
      include: [
        {
          model: User,
          where: {
            isactive: "1",
            id: {
              [Op.ne]: req.user.id,
            },
          },
          attributes: [
            "id",
            "userfullname",
            "emailaddress",
            "firstname",
            "lastname",
          ],
          required: false,
        },
      ],
    });

    if (!UserList.length) {
      return res.status(404).send({
        message: "No record found",
        error: true,
        success: false,
        status: "0",
      });
    }
    const tasksWithCount = await Promise.all(
      UserList.map(async (data) => {
        const userId = data.to_user_id;
        // Fetching chat room (either way)
        const chatRoom = await Chat.findOne({
          where: {
            status: "1",
            [Op.or]: [
              { user1_id: req.user.id, user2_id: userId },
              { user1_id: userId, user2_id: req.user.id },
            ],
          },
          attributes: ["id"],
        });
    
        // Fetching unread messages count only for this chat room and user
        let chat_unread_count = 0;
        let lastmsg = null;
    
        if (chatRoom) {
          // Counting unread messages that are sent by the other user and not read
          chat_unread_count = await Message.count({
            where: {
              chat_id: chatRoom.id,
              sender_id: userId,   // Message is sent by the other user
              read_at: null,       // Unread messages only
            },
          });
          // Fetching last message in the chat room
          const last_message = await Message.findOne({
            where: {
              chat_id: chatRoom.id,
              group_id: null,
            },
            order: [["id", "DESC"]],
          });
          lastmsg = last_message ? last_message.text : null;
        }
    
        return {
          tbl_User: data.tbl_User ? {
            ...data.tbl_User.toJSON(),
            chat_unread_count,
            lastmsg,
          } : null
        };
      })
    );
    
    
    return res.status(200).send({
      message: "Record found",
      error: false,
      success: true,
      status: "1",
      data: tasksWithCount,
    });
  } catch (error) {
    console.error("Error in chatuserListBYCompany:", error);
    return res.status(500).send({
      message: "Internal server error",
      error: error.message,
      success: false,
      status: "0",
    });
  }
};


// API: Mark Messages as Read by User ID
exports.markMessagesAsReadByUser = async (req, res) => {
  try {
    const { user_id } = req.body;

    // Ensure user_id is provided
    if (!user_id) {
      return res.status(400).send({
        message: "User ID is required",
        error: true,
        success: false,
        status: "0",
      });
    }

    const loggedInUserId = req.user.id;

    // Fetch the chat room between logged-in user and the specified user
    const chatRoom = await Chat.findOne({
      where: {
        status: "1",
        [Op.or]: [
          { user1_id: loggedInUserId, user2_id: user_id },
          { user1_id: user_id, user2_id: loggedInUserId },
        ],
      },
      attributes: ["id"],
    });

    if (!chatRoom) {
      return res.status(404).send({
        message: "Chat room not found",
        error: true,
        success: false,
        status: "0",
      });
    }

    // Mark messages from the other user as read
    await Message.update(
      { 
        read_at: new Date(),
        updated_at:new Date()
       },
      {
        where: {
          chat_id: chatRoom.id,
          sender_id: user_id,   // Messages sent by the other user
          read_at: null,        // Only unread messages
        },
      }
    );

    return res.status(200).send({
      message: "Messages marked as read",
      error: false,
      success: true,
      status: "1",
    });
  } catch (error) {
    console.error("Error in markMessagesAsReadByUser:", error);
    return res.status(500).send({
      message: "Internal server error",
      error: error.message,
      success: false,
      status: "0",
    });
  }
};






