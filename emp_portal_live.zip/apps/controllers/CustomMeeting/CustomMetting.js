const Joi = require("joi");
const { MeetingRoomcreate } = require("../LiveKit/livekit");
const multer = require("multer");
const path = require("path");
const User = require("../../models/tracker/user/User");
const Meeting = require("../../models/Meeting/Meeting");
const MeetingUsers = require("../../models/Meeting/MeetingUser");
const MeetingAttachments = require("../../models/Meeting/MeetingAttachment");
const md5 = require("md5");
const { AccessToken } = require("livekit-server-sdk");
const LIVEKIT_API_KEY = process.env.LIVEKIT_API_KEY || "your_api_key";
const LIVEKIT_API_SECRET = process.env.LIVEKIT_API_SECRET || "your_secret";
const { Op } = require("sequelize");
const fs = require("fs");

//####################################################################//
// code by tc for custom meeting Apis
//####################################################################//

const CreateCustomMeeting = async (req, res) => {
  try {
    const {
      meeting_name,
      team_member = [],
      description,
      start_time,
      end_time,
    } = req.body;

    // Basic required field validation
    if (!meeting_name) {
      return res.status(400).json({
        status: false,
        error: "meeting_name is required",
      });
    }

    // Parse and validate user IDs from team_member array
    let userIds = [];
    if (Array.isArray(team_member)) {
      if (team_member.length === 1 && typeof team_member[0] === "string") {
        userIds = team_member[0]
          .split(",")
          .map((id) => id.trim())
          .filter((id) => !isNaN(id))
          .map((id) => parseInt(id, 10));
      } else {
        userIds = team_member
          .filter((id) => !isNaN(id))
          .map((id) => parseInt(id, 10));
      }
    }

    if (userIds.length > 0) {
      const users = await User.findAll({
        where: { id: userIds, isactive: true },
      });
      if (users.length !== userIds.length) {
        return res
          .status(400)
          .json({ status: false, error: "Invalid or inactive users" });
      }
    }

    // Validate logged-in user as host
    const host = await User.findOne({
      where: { id: req.user.id, isactive: true },
    });
    if (!host) {
      return res
        .status(400)
        .json({ status: false, error: "Invalid or inactive host" });
    }

    // Validate start_time and end_time
    const startDate = start_time ? new Date(start_time) : null;
    if (isNaN(startDate)) {
      return res
        .status(400)
        .json({ status: false, error: "Invalid start_time" });
    }

    const endDate = end_time ? new Date(end_time) : null;
    if (end_time && isNaN(endDate)) {
      return res.status(400).json({ status: false, error: "Invalid end_time" });
    }

    if (end_time && startDate >= endDate) {
      return res
        .status(400)
        .json({ status: false, error: "end_time must be after start_time" });
    }

    // Create Room
    const { meeting, livekit_room_id, meeting_url, host_token } =
      await MeetingRoomcreate({
        project_id: null,
        is_public: true,
        password: null,
        host_id: req.user.id,
        created_by: req.user.id,
        start_time: startDate,
        end_time: endDate,
      });

    // Update meeting with meeting_name and description
    await meeting.update({
      meeting_name,
      description,
    });

    // Check if host is already added
    const existingHost = await MeetingUsers.findOne({
      where: { meeting_id: meeting.id, user_id: req.user.id },
    });

    if (!existingHost) {
      // Add the logged-in user (host) as a participant with the host role
      const hostToken = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
        identity: `user_${req.user.id}`,
        name: `user_${req.user.id}`,
      });

      hostToken.addGrant({
        roomJoin: true,
        room: livekit_room_id,
        canPublish: true,
        canSubscribe: true,
      });

      const hostTokenString = await hostToken.toJwt();

      await MeetingUsers.create({
        meeting_id: meeting.id,
        user_id: req.user.id,
        role: "host",
        livekit_token: hostTokenString,
        permissions: {
          canShareScreen: true,
          canUnmute: true,
          canManageParticipants: true,
        },
        isactive: true,
        created_by: req.user.id,
        modified_by: req.user.id,
      });
    }

    // Add team members as participants
    for (const user_id of userIds) {
      if (user_id === req.user.id) continue;

      const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
        identity: `user_${user_id}`,
        name: `user_${user_id}`,
      });

      token.addGrant({
        roomJoin: true,
        room: livekit_room_id,
        canPublish: true,
        canSubscribe: true,
      });

      const token_string = await token.toJwt();

      await MeetingUsers.create({
        meeting_id: meeting.id,
        user_id,
        role: "attendee",
        livekit_token: token_string,
        permissions: {
          canShareScreen: true,
          canUnmute: true,
          canManageParticipants: true,
        },
        isactive: true,
        created_by: req.user.id,
        modified_by: req.user.id,
      });
    }

    // Fetch created meeting details with participants
    const createdMeeting = await Meeting.findOne({
      where: { id: meeting.id },
      include: [{ model: MeetingUsers, as: "participants" }],
    });

    // Notify socket listeners
    if (req.io) {
      req.io.to(`meeting_${meeting.id}`).emit("meetingCreated", {
        meeting_id: meeting.id,
        meeting_url,
      });
    }

    // Final Response
    return res.status(201).json({
      status: true,
      data: {
        meeting: createdMeeting.toJSON(),
        meeting_url,
      },
      message: "Custom meeting created successfully",
    });
  } catch (error) {
    console.error("CreateCustomMeeting Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

// Join Meeting via URL
const JoinMeeting = async (req, res) => {
  try {
    const { meeting_url } = req.params;
    const user_id = req.user.id;

    // Find meeting by meeting_url
    const meeting = await Meeting.findOne({
      where: { meeting_url, isactive: true },
    });
    if (!meeting) {
      return res.status(404).json({
        status: false,
        error: "Meeting not found or inactive",
      });
    }

    // Validate user
    const user = await User.findOne({ where: { id: user_id, isactive: true } });
    if (!user) {
      return res
        .status(400)
        .json({ status: false, error: "Invalid or inactive user" });
    }

    // Check if user already in meeting
    let meetingUser = await MeetingUsers.findOne({
      where: { meeting_id: meeting.id, user_id },
    });
    let token;

    let livekit_room_id = meeting.livekit_room_id;
    // Generate token for new participant
    const accessToken = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity: `user_${req.user.id}`,
      name: `${req.user.userfullname}`,
    });
    accessToken.addGrant({
      roomJoin: true,
      room: livekit_room_id,
      canPublish: true,
      canSubscribe: true,
    });
    token = await accessToken.toJwt();
    // Final Response
    return res.status(200).json({
      status: true,
      data: {
        meeting: {
          id: meeting.id,
          meeting_url,
          livekit_room_id: meeting.livekit_room_id,
        },
        livekit_token: token,
      },
      message: "Joined meeting successfully",
    });
  } catch (error) {
    console.error("JoinMeeting Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const ListCustomMeetings = async (req, res) => {
  try {
    const userInMeetings = await MeetingUsers.findAll({
      where: {
        user_id: req.user.id,
      },
    });

    const meetingIds = userInMeetings.map((entry) => entry.meeting_id);

    const uniqueMeetingIds = [...new Set(meetingIds)];

    const meetings = await Meeting.findAll({
      where: {
        id: {
          [Op.in]: uniqueMeetingIds,
        },
        [Op.or]: [
          {
            end_time: {
              [Op.gt]: new Date(), // future dates only
            },
          },
          {
            end_time: null, // allow null end_dates
          },
        ],
      },
      include: [
        {
          model: MeetingUsers,
          as: "participants",
          required: true,
          include: [
            {
              model: User,
              attributes: ["id", "userfullname", "emailaddress"], // add more fields as needed
            },
          ],
        },
      ],
      order: [["start_time", "DESC"]],
    });

    const formattedMeetings = meetings.map((meeting) => {
      const participants = meeting.participants || [];
      return {
        ...meeting.toJSON(),
        participant_count: participants.length,
        participants,
      };
    });

    return res.status(200).json({
      status: true,
      data: formattedMeetings,
      message: "Meetings fetched successfully",
    });
  } catch (error) {
    console.error("GetMeetings Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const MeetingDetails = async (req, res) => {
  const meeting_id = req.body.meeting_id;
  if (!meeting_id) {
    return res.status(401).send({
      message: "meeting_id is required",
      status: "0",
      success: false,
      error: true,
    });
  }
  try {
    const meetings = await Meeting.findAll({
      where: {
        id: meeting_id,
      },
      include: [
        {
          model: MeetingUsers,
          as: "participants",
          include: [
            {
              model: User,
              attributes: ["id", "userfullname", "emailaddress"], // add more fields as needed
            },
          ],
        },
      ],
      order: [["start_time", "DESC"]],
    });

    const formattedMeetings = meetings.map((meeting) => {
      const participants = meeting.participants || [];
      return {
        ...meeting.toJSON(),
        participant_count: participants.length,
        participants,
      };
    });

    return res.status(200).json({
      status: true,
      data: formattedMeetings,
      message: "Meetings fetched successfully",
    });
  } catch (error) {
    console.error("GetMeetings Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const UpdateMeeting = async (req, res) => {
  const id = req.body.meeting_id;
  if (!id) {
    return res.status(401).send({
      message: "meeting_id is required",
      success: false,
      error: true,
      status: "0",
    });
  }
  try {
    const {
      meeting_name,
      description,
      start_time,
      end_time,
      team_member = [],
      is_public,
      password,
    } = req.body;

    const meeting = await Meeting.findOne({
      where: { id, created_by: req.user.id },
      include: [{ model: MeetingUsers, as: "participants" }],
    });

    if (!meeting) {
      return res
        .status(404)
        .json({ status: false, error: "Meeting not found" });
    }

    // Parse team_member IDs
    let userIds = [];
    if (Array.isArray(team_member)) {
      if (team_member.length === 1 && typeof team_member[0] === "string") {
        userIds = team_member[0]
          .split(",")
          .map((id) => id.trim())
          .filter((id) => !isNaN(id))
          .map((id) => parseInt(id, 10));
      } else {
        userIds = team_member
          .filter((id) => !isNaN(id))
          .map((id) => parseInt(id, 10));
      }
    }

    // Validate user IDs
    if (userIds.length > 0) {
      const users = await User.findAll({
        where: { id: userIds, isactive: true },
      });
      if (users.length !== userIds.length) {
        return res
          .status(400)
          .json({ status: false, error: "Invalid or inactive users" });
      }
    }

    // Validate and update time
    const startDate = start_time ? new Date(start_time) : meeting.start_time;
    if (start_time && isNaN(startDate)) {
      return res
        .status(400)
        .json({ status: false, error: "Invalid start_time" });
    }

    const endDate = end_time ? new Date(end_time) : meeting.end_time;
    if (end_time && isNaN(endDate)) {
      return res.status(400).json({ status: false, error: "Invalid end_time" });
    }

    if (end_time && startDate >= endDate) {
      return res
        .status(400)
        .json({ status: false, error: "end_time must be after start_time" });
    }

    // Handle is_public and password
    let updateData = {
      meeting_name: meeting_name || meeting.meeting_name,
      description: description || meeting.description,
      start_time: startDate,
      end_time: endDate,
    };

    if (typeof is_public !== "undefined") {
      if (req.body.is_public === 2) {
        if (!password) {
          return res.status(400).json({
            status: false,
            error: "Password is required for private meetings",
          });
        }
        updateData.is_public = 2;
        updateData.password = password;
      } else {
        updateData.is_public = true;
        updateData.password = null;
      }
    }

    await meeting.update(updateData);

    // Sync team members (add new, remove removed)
    const existingUserIds = meeting.participants.map((p) => p.user_id);
    const hostId = req.user.id;

    // ➕ Add new participants
    for (const user_id of userIds) {
      if (user_id === hostId || existingUserIds.includes(user_id)) continue;

      const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
        identity: `user_${user_id}`,
        name: `user_${user_id}`,
      });

      token.addGrant({
        roomJoin: true,
        room: meeting.livekit_room_id,
        canPublish: false,
        canSubscribe: true,
      });

      const token_string = await token.toJwt();

      await MeetingUsers.create({
        meeting_id: meeting.id,
        user_id,
        role: "attendee",
        livekit_token: token_string,
        permissions: {
          canShareScreen: false,
          canUnmute: true,
          canManageParticipants: false,
        },
        isactive: true,
        created_by: hostId,
        modified_by: hostId,
      });
    }

    // ➖ Remove participants not in new list (except host)
    const toRemove = existingUserIds.filter(
      (uid) => uid !== hostId && !userIds.includes(uid)
    );

    if (toRemove.length > 0) {
      await MeetingUsers.destroy({
        where: {
          meeting_id: meeting.id,
          user_id: toRemove,
        },
      });
    }

    // Fetch updated meeting with participants & users
    const updatedMeeting = await Meeting.findOne({
      where: { id: meeting.id },
      include: [
        {
          model: MeetingUsers,
          as: "participants",
          include: [
            { model: User, attributes: ["id", "userfullname", "emailaddress"] },
          ],
        },
      ],
    });

    return res.status(200).json({
      status: true,
      data: {
        ...updatedMeeting.toJSON(),
        participant_count: updatedMeeting.participants.length,
      },
      message: "Meeting updated successfully",
    });
  } catch (error) {
    console.error("UpdateMeeting Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const DeleteAttachment = async (req, res) => {
  try {
    const user_id = req.user.id;
    const attachment_id = req.body.attachment_id;

    // Validate user
    const user = await User.findOne({ where: { id: user_id, isactive: true } });
    if (!user) {
      return res.status(400).json({
        status: false,
        error: "Invalid or inactive user",
      });
    }

    if (!attachment_id) {
      return res.status(400).json({
        success: false,
        status: "0",
        error: "attachment_id is required",
      });
    }

    // Fetch attachment
    const attachment = await MeetingAttachments.findOne({
      where: { id: attachment_id, isactive: true },
      include: [
        {
          model: Meeting,
          where: { isactive: true, project_id: null },
        },
      ],
    });
    if (!attachment) {
      return res.status(404).json({
        status: false,
        error: "Attachment not found",
      });
    }

    // Check if user is the uploader or meeting host
    const isUploader = attachment.user_id === user_id;
    const isHost = attachment.meet_meeting.host_id === user_id;
    if (!isUploader && !isHost) {
      return res.status(403).json({
        status: false,
        error: "User is not authorized to delete this attachment",
      });
    }

    if (fs.existsSync(attachment.file_path)) {
      fs.unlinkSync(attachment.file_path);
    }

    await attachment.update({ isactive: false, modified_by: user_id });

    return res.status(200).json({
      message: "Attachment deleted successfully",
      status: "1",
      success: true,
      data: { attachment_id },
    });
  } catch (error) {
    console.error("DeleteAttachment Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const GetAttachments = async (req, res) => {
  try {
    const user_id = req.user.id;
    const meeting_id = req.body.meeting_id;
    if (!meeting_id) {
      return res.status(400).json({
        error: "meeting_id is required",
        status: "0",
      });
    }
    // Validate user
    const user = await User.findOne({ where: { id: user_id, isactive: true } });
    if (!user) {
      return res.status(400).json({
        status: false,
        error: "Invalid or inactive user",
      });
    }

    // Validate meeting
    const meeting = await Meeting.findOne({
      where: { id: meeting_id, isactive: true, project_id: null },
    });
    if (!meeting) {
      return res.status(404).json({
        status: false,
        error: "Meeting not found",
      });
    }

    // Check if user is a participant
    const participant = await MeetingUsers.findOne({
      where: { meeting_id, user_id, isactive: true },
    });
    if (!participant) {
      return res.status(403).json({
        status: false,
        error: "User is not a participant in this meeting",
      });
    }

    // Fetch attachments
    const attachments = await MeetingAttachments.findAll({
      where: { meeting_id, isactive: true },
      include: [
        {
          model: User,
          attributes: ["id", "userfullname"],
          where: { isactive: true },
        },
      ],
      order: [["created_at", "ASC"]],
    });

    const formattedAttachments = attachments.map((attachment) => ({
      attachment_id: attachment.id,
      meeting_id: attachment.meeting_id,
      file_name: attachment.file_name,
      file_path: attachment.file_path,
      file_size: attachment.file_size,
      file_type: attachment.file_type,
      description: attachment.description,
      uploaded_by: {
        user_id: attachment.user_id,
        userfullname: attachment.tbl_User.userfullname || "Unknown User",
      },
      created_at: attachment.createdAt,
    }));

    return res.status(200).json({
      message: "Attachments retrieved successfully",
      status: "1",
      success: true,
      data: formattedAttachments,
    });
  } catch (error) {
    console.error("GetAttachments Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};

const AttachmentStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const uploadPath = `uploads/meetings/attachments`;
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    } catch (err) {
      cb(err); // In case of an error, pass it to multer
    }
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const AttachmentUpload = multer({ storage: AttachmentStorage });

const addAttatchment = async (req, res) => {
  AttachmentUpload.array("files")(req, res, async (err) => {
    try {
      if (err) {
        console.error("Multer Error:", err);
        return res.status(500).json({
          message: "File upload error",
          error: true,
          success: false,
          status: "0",
        });
      }

      if (!req.files[0]) {
        return res.status(400).json({
          message: "Please upload a file",
          status: "0",
          error: true,
          success: false,
        });
      }

      // Validation
      const schema = Joi.object({
        meeting_id: Joi.number().required(),
        description: Joi.string().optional(),
      });

      const { error, value } = await schema.validate(req.body);

      if (error) {
        return res.status(400).json({
          message: error.message,
          status: "0",
          error: true,
          success: false,
        });
      }

      let insertArr = [];

      req.files.map((file) => {
        const fileDetails = {
          meeting_id: value.meeting_id,
          user_id: req.user.id,
          file_name: file.originalname,
          file_path: file.path,
          file_size: file.size,
          file_type: path.extname(file.filename),
          description: value.description || "",
          created_by: req.user.id,
          createdAt: Date.now(),
        };
        insertArr.push(fileDetails);
      });

      const add = await MeetingAttachments.bulkCreate(insertArr);

      // Everything is good
      return res.status(200).json({
        message: "Attachment Added.",
        error: false,
        success: true,
        status: "1",
      });
    } catch (error) {
      console.error("Internal Error:", error);
      return res.status(500).json({
        message: "Something went wrong",
        success: false,
        error: error.message,
        status: "0",
      });
    }
  });
};

// Join Meeting via URL
const PublicJoinMeeting = async (req, res) => {
  try {
    const { meeting_url } = req.params;
    const user_id = Math.floor(Math.random() * 10000); // Generate a random user ID for public join
    const user_name = req.body.user_name || `Guest_${user_id}`;

    let token;
    // Find meeting by meeting_url
    const meeting = await Meeting.findOne({
      where: { meeting_url, isactive: true },
    });
    if (!meeting) {
      return res.status(404).json({
        status: false,
        error: "Meeting not found or inactive",
      });
    }

    let livekit_room_id = meeting.livekit_room_id; // ✅ Moved here, after meeting is fetched

    if (meeting.is_public == 2) {
      if (!req.body.Password) {
        return res.status(400).json({
          status: false,
          error: "Password is required for private meetings",
        });
      }
      const pass = req.body.Password;
      if (pass !== meeting.password) {
        return res.status(400).json({
          status: false,
          error: "Invalid password",
        });
      }
    }

    // Generate token for new participant
    const accessToken = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity: `user_${user_id}`,
      name: `${user_name}`,
    });
    accessToken.addGrant({
      roomJoin: true,
      room: livekit_room_id,
      canPublish: true,
      canSubscribe: true,
    });
    token = await accessToken.toJwt();
    if (req.io) {
      req.io.to(`meeting_${meeting.id}`).emit("userJoined", {
        meeting_id: meeting.id,
        user_id,
      });
    }
    // Final Response
    return res.status(200).json({
      status: true,
      data: {
        meeting: {
          id: meeting.id,
          meeting_url,
          livekit_room_id: meeting.livekit_room_id,
        },
        livekit_token: token,
      },
      message: "Joined meeting successfully",
    });
  } catch (error) {
    console.error("JoinMeeting Error:", error);
    return res.status(500).json({ status: false, error: error.message });
  }
};


module.exports = {
  CreateCustomMeeting,
  JoinMeeting,
  ListCustomMeetings,
  MeetingDetails,
  UpdateMeeting,
  DeleteAttachment,
  GetAttachments,
  addAttatchment,
  PublicJoinMeeting,
};
