// Code by Prajwal Date:- 26-03-2025 //

const Joi = require('joi');
require('dotenv').config();

// Load Models //
const Country = require('../../models/Master/CountryModel');
const State = require('../../models/Master/StateModel');
const Cities = require('../../models/Master/CitiesModel');
const Language = require('../../models/Master/LanguageModel');
const BusinessUnit = require('../../models/Master/BusinessUnitModel');
const Department = require('../../models/Master/DepartmentModel');
const Designation = require('../../models/Master/DesignationModel');
const Timezone = require('../../models/Master/TimezoneModel');
const Currency = require('../../models/Master/CurrencyModel');







// Get country list
const GetCountryList = async (req, res) => {
    try {
        const response = await Country.findAll({
            order: [['name', 'ASC']],
            attributes: ['id', 'name']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Country list.',
            error: true,
        });
    }
};

// Get State List
const GetStateList = async (req, res) => {
    try {
        const response = await State.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'name', 'country_id']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the State list.',
            error: true,
        });
    }
};

// Get City List
const GetCitesList = async (req, res) => {
    try {
        const response = await Cities.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'name', 'state_id']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Cities list.',
            error: true,
        });
    }
};


// Get Language List
const GetLanguageList = async (req, res) => {
    try {
        const response = await Language.findAll({
            order: [['name', 'ASC']],
            attributes: ['id', 'name']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Language list.',
            error: true,
        });
    }
};


// Get Business Unit List  
const GetBusinessUnit = async (req, res) => {
    try {
        const response = await BusinessUnit.findAll({
            order: [['id', 'DESC']],
            where: { is_active: 'Active' },
            attributes: ['id', 'name', 'code', 'city_id', 'country_id', 'currency_id', 'timezone_id', 'created_by', 'updated_by', 'is_active', 'created_at', 'updated_at'],
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Business Unit list.',
            error: true,
        })
    }
}


// Get Department List 
const getDepartment = async (req, res) => {
    try {
        const response = await Department.findAll({
            order: [['id', 'DESC']],
            where: { is_active: 'Active' },
            attributes: ['id', 'name', 'code', 'description', 'created_by', 'updated_by', 'is_active', 'created_at', 'updated_at']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Department list.',
            error: true,
        })
    }
}

// Get Designation List 
const GetDesignationList = async (req, res) => {
    try {
        const response = await Designation.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'name', 'created_by', 'updated_by', 'is_active', 'created_at', 'updated_at']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Designation list.',
            error: true,
        });
    }
};

// Get Timezone List
const GetTimezoneList = async (req, res) => {
    try {
        const response = await Timezone.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'name', 'is_active', 'created_at', 'updated_at']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Timezone list.',
            error: true,
        });
    }
};

// Get Currency List
const GetCurrencyList = async (req, res) => {
    try {
        const response = await Currency.findAll({
            order: [['id', 'ASC']],
            attributes: ['id', 'name', 'currency_symbol', 'currency_code', 'is_active', 'created_at', 'updated_at']
        });
        res.status(200).json({
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'An error occurred while fetching the Currency list.',
            error: true,
        });
    }
};

module.exports = { GetCountryList, GetStateList, GetCitesList, GetLanguageList, GetBusinessUnit, getDepartment, GetDesignationList, GetTimezoneList, GetCurrencyList };
