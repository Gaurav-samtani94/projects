// middleware/permissionMiddleware.js
const db = require('../config/database');

const checkPermission = (action) => {
  return async (req, res, next) => {
    try {
      const roleId = req.user.emprole;

      // Extract module name from the first segment of the route
      const pathSegments = req.path.split('/').filter(Boolean);
      const moduleName = pathSegments[0];

      if (!moduleName) {
        return res.status(400).json({ message: 'Invalid module' });
      }

      // Get module_id by module name (slug/route)
      const moduleRows = await db.query(
        `SELECT id FROM mstr_module_routes WHERE action_url = ? and status = ?`,
        {
          replacements: [moduleName, "1"],
          type: db.QueryTypes.SELECT
        }
      );

      let moduleId;

      if (moduleRows.length === 0) {
        const insertResult = await db.query(
          `INSERT INTO mstr_module_routes (module_name, action_url) VALUES (?, ?)`,
          {
            replacements: [moduleName, moduleName],
            type: db.QueryTypes.INSERT
          }
        );
        moduleId = insertResult[0]; // insertResult = [insertId, affectedRows]
        console.log(`Module "${moduleName}" inserted with ID: ${moduleId}`);
      } else {
        moduleId = moduleRows[0].id;
      }

      // Fetch permission for this module + role
      const permRows = await db.query(
        `SELECT add_perm, view_perm, edit_perm, delete_perm
         FROM action_perm_roles
         WHERE role_id = ? AND module_route_id = ?`,
        {
          replacements: [roleId, moduleId],
          type: db.QueryTypes.SELECT
        }
      );

      if (permRows.length === 0) {
        if(roleId == 1){
          const insertResult = await db.query(
            `INSERT INTO action_perm_roles (role_id, module_route_id, view_perm, add_perm, edit_perm, delete_perm, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            {
              replacements: [roleId, moduleId, "1", "1", "1", "1", 1],
              type: db.QueryTypes.INSERT
            }
          );
        }
        return res.status(403).json({ message: 'No permissions defined for this module' });
      }

      console.log(roleId,"====================");
      console.log(moduleId,"moduleId moduleId moduleId moduleId");
      console.log(permRows,"permRowspermRowspermRowspermRowspermRows");
      const perms = permRows[0];
      const isAllowed = {
        'add': perms.add_perm,
        'view': perms.view_perm,
        'edit': perms.edit_perm,
        'delete': perms.delete_perm,
      }[action];
      console.log(isAllowed,"========d=d=d=dd=");
      if (isAllowed == 0) {
        console.log("fldfkdjfkjdkfjdjfk");
        return res.status(403).json({ message: `Access denied for action: ${action}` });
      }

      next();
    } catch (error) {
      console.error('Permission Middleware Error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  };
};


module.exports = checkPermission;
