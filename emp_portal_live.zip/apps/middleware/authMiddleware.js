const jwt = require('jsonwebtoken')
const { JWT_SECRET } = require('../config/config')


const protect = (req, res, next) => {
    let token;
    // Check if authorization header exists
    if (req.headers.authorization) {
        try {
            // Extract the token directly from the Authorization header
            token = req.headers.authorization;
            // Verify the token
            const decoded = jwt.verify(token, JWT_SECRET);
            // Attach the decoded user information to the request object
            req.user = decoded.user;
            
            next(); // Continue to the next middleware or route handler
        } catch (error) {
            console.error(error);
            res.status(401).json({ message: 'Not authorized, token failed' });
        }
    } else {
        // If there's no token, return unauthorized error
        return res.status(401).json({ message: 'Not authorized, no token' });
    }
}



module.exports = { protect }