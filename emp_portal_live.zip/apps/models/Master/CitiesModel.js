// Code by Prajwal Date:- 26-03-2025 //

const DataTypes = require('sequelize');
const sequelize = require('../../config/database');
const Cities = sequelize.define('mstr_cities', {
    id: {
        type: DataTypes.BIGINT(20),
        autoIncrement: true,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    state_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    created_at: {
        type: DataTypes.TIME,
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    updated_at: {
        type: DataTypes.TIME,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    is_active: {
        type: DataTypes.ENUM(
            '0', '1'
        ),
        defaultValue: '1',
    },
});

module.exports = Cities;