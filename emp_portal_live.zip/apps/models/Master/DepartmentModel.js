// Code by Prajwal Date:- 26-03-2025 //

const DataTypes = require('sequelize');
const sequelize = require('../../config/database');

const Department = sequelize.define('mstr_departments', {
  id: {
    type: DataTypes.BIGINT(20),
    autoIncrement: true,
    primaryKey: true,
  },
  description: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  code: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  deptcode: {
    type: DataTypes.STRING(20),
    allowNull: true,
  },
  startdate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  country: {
    type: DataTypes.BIGINT(10).UNSIGNED,
    allowNull: true,
  },
  state: {
    type: DataTypes.BIGINT(10).UNSIGNED,
    allowNull: true,
  },
  city: {
    type: DataTypes.BIGINT(10).UNSIGNED,
    allowNull: true,
  },
  address1: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  address2: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  address3: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  timezone: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  depthead: {
    type: DataTypes.BIGINT(10).UNSIGNED,
    allowNull: true,
  },
  unitid: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  updated_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.ENUM('0', '1'),
    allowNull: false,
    defaultValue: '1',
  }
}, {
  timestamps: false,
  underscored: true,
  freezeTableName: true,
});

module.exports = Department;