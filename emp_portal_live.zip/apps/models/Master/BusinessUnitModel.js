// Code by Prajwal Date:- 26-03-2025 //

const DataTypes = require('sequelize');
const sequelize = require('../../config/database');

const BusinessUnitModel = sequelize.define('mstr_business_units', {
    id: {
        type: DataTypes.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    code: {
        type: DataTypes.STRING,
        allowNull: false
    },
    city_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    state_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    country_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    currency_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    timezone_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false
    },
    created_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    is_active: {
        type: DataTypes.ENUM(
            '0', '1'
        ),
        defaultValue: '1',
    },
    created_at: {
        type: DataTypes.TIME,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.TIME,
        allowNull: true
    }
});

module.exports = BusinessUnitModel;