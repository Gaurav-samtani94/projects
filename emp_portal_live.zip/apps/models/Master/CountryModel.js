// Code by Prajwal Date:- 26-03-2025 //

const DataTypes = require('sequelize');
const sequelize = require('../../config/database');
const Country = sequelize.define('mstr_countries', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    shortname: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phone_code: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false
    },
    created_at: {
        type: DataTypes.TIME,
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    updated_at: {
        type: DataTypes.TIME,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT(20),
        allowNull: true
    },
    is_active: {
        type: DataTypes.ENUM(
            '0', '1'
        ),
        defaultValue: '1',
    },
});

module.exports = Country;