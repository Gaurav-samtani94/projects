const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../tracker/user/User');
const Group = require('./group');

const GroupMember = sequelize.define('chat_group_members', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    group_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull:true
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull:true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull:true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull:true
    },
    status:{
        type: DataTypes.BOOLEAN,
        allowNull: true
    }
},{
    timestamps: false,    // Automatically add created_at and updated_at
});

// Relationships
// GroupMember.belongsTo(Group, { foreignKey: 'group_id' });
// GroupMember.belongsTo(User, { foreignKey: 'user_id' });


// Each GroupMember belongs to a group
Group.hasMany(GroupMember, { foreignKey: 'group_id', as: 'members' });
GroupMember.belongsTo(Group, { foreignKey: 'group_id' });
// Each GroupMember belongs to a user
GroupMember.belongsTo(User, { foreignKey: 'user_id', as: 'memberInfo' });

module.exports = GroupMember;