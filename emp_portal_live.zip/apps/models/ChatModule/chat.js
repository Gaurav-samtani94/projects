const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../../models/tracker/user/User');

const Chat = sequelize.define('chat_chats', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user1_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    user2_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    status: {
        type: DataTypes.BOOLEAN,
        allowNull: true
    }
}, {
    underscored: true,   // Automatically use snake_case in DB
    timestamps: false,    // Automatically add created_at and updated_at
    createdAt: 'created_at',  // Map createdAt to created_at
    updatedAt: 'updated_at'   // Map updatedAt to updated_at
});

// Associations
Chat.belongsTo(User, { as: 'user1', foreignKey: 'user1_id' });
Chat.belongsTo(User, { as: 'user2', foreignKey: 'user2_id' });


module.exports = Chat;
