const { DataTypes, DATEONLY } = require("sequelize");
const sequelize = require("../../config/database");
const User = require("../tracker/user/User");
const Chat = require("./chat");
const Group = require("./group");

const Message = sequelize.define("chat_messages", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  group_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  sender_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  caller_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
    defaultValue: null,
  },
  chat_type:{
    type: DataTypes.TEXT,
    allowNull: true,
  },
  call_type:{
    type: DataTypes.ENUM,
    values: ['0','1'],

  },
  start_time: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: null,
  },
  end_time: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: null,
  },
  duration: {
    type: DataTypes.INTEGER, // Duration in seconds
    allowNull: true,
  },
  reply_to_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  forwarded_from_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  text: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  file_path: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  file_name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  file_type: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  status: {
    type: DataTypes.ENUM("sent", "delivered", "read"),
    defaultValue: "sent",
  },
  delivered_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  read_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  type: {
    type: DataTypes.ENUM("forward", "reply","hide by admin"),
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: true,
    defaultValue: "1",
  },
},{
  timestamps:false,
});

// Relationships
Message.belongsTo(Chat, { foreignKey: "chat_id" });
Chat.hasMany(Message, { foreignKey: 'chat_id', as: 'Messages' });
Message.belongsTo(Group, { foreignKey: "group_id" });
Message.belongsTo(User, { as: "sender", foreignKey: "sender_id" });
Message.belongsTo(Message, { as: "replyTo", foreignKey: "reply_to_id" });
Message.belongsTo(Message, {
  as: "forwardedFrom",
  foreignKey: "forwarded_from_id",
});
module.exports = Message;
