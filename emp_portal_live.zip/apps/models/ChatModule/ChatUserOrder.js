const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../../models/tracker/user/User');
const Chat = require('./chat');

const ChatUserOrder = sequelize.define('chat_user_arrangements', {
    id: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      from_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        index: true,
      },
      to_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        index: true,
      },
      status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        index: true,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
      },
      updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
      },
}, {
    timestamps: false,    // Automatically add created_at and updated_at
});





ChatUserOrder.belongsTo(User, {
  foreignKey: 'to_user_id',
  targetKey: 'id',
  // as: 'fromUser',
});
// ChatUserOrder.belongsTo(User, {
//   foreignKey: 'to_user_id',
//   targetKey: 'id',
//   as: 'toUser',
// });
// ChatUserOrder.belongsTo(Chat, {
//   foreignKey: 'chat_id',
//   targetKey: 'id',
//   as: 'chat',
// });







module.exports = ChatUserOrder;
