const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../tracker/user/User');
const Group = sequelize.define('chat_groups', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    group_name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Description of the group'
    },
    profile_name: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    profile_path: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    type:{
        type: DataTypes.TEXT,
        allowNull: false,
        defaultValue: 'group',
        comment: 'Type of group (group or channel)'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull:true
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull:true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull:true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull:true
    },
    status:{
        type: DataTypes.BOOLEAN,
        allowNull: true
    }
},{
    timestamps: false,    // Automatically add created_at and updated_at
});

// Group created by a user
Group.belongsTo(User, { as: 'creator', foreignKey: 'created_by' });



module.exports = Group;