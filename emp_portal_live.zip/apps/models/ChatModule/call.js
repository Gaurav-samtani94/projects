const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../tracker/user/User');
const Chat = require('./chat');
const Group = require('./group');

const Call = sequelize.define('chat_Call', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    chat_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    group_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    caller_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    start_time: {
        type: DataTypes.DATE,
        allowNull: false
    },
    end_time: {
        type: DataTypes.DATE,
        allowNull: true
    },
    duration: {
        type: DataTypes.INTEGER, // Duration in seconds
        allowNull: true
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    status:{
        type: DataTypes.BOOLEAN,
        allowNull: true
    }
},{
    timestamps: false,    // Automatically add created_at and updated_at
});

// Relationships
Call.belongsTo(Chat, { foreignKey: 'chat_id' });
Call.belongsTo(Group, { foreignKey: 'group_id' });
Call.belongsTo(User, { as: 'caller', foreignKey: 'caller_id' });


module.exports = Call;