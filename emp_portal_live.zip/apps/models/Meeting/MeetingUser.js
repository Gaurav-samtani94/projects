const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../tracker/user/User');
const Meeting = require('./Meeting');

const MeetingUsers = sequelize.define('meet_meeting_users', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false,
  },
  meeting_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  role: {
    type: DataTypes.ENUM('host', 'co-host', 'attendee'),
    allowNull: false,
    defaultValue: 'attendee',
  },
  livekit_token: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  permissions: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: { canShareScreen: false, canUnmute: true, canManageParticipants: false },
  },
  isactive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  modified_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
},{
  timestamps:false
});

// MeetingUsers.sync({ alter: true });

User.hasMany(MeetingUsers, { foreignKey: 'user_id' });
MeetingUsers.belongsTo(User, { foreignKey: 'user_id' });

Meeting.hasMany(MeetingUsers, { foreignKey: 'meeting_id', as: 'participants' });
MeetingUsers.belongsTo(Meeting, { foreignKey: 'meeting_id' });



module.exports = MeetingUsers;