const DataTypes = require("sequelize");
const sequelize = require("../../config/database");
const User = require('../../models/tracker/user/User');
const Meeting = require('../../models/Meeting/Meeting');

    const MeetingAttachments = sequelize.define('meet_Attachments', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,Meeting
      },
      meeting_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      file_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      file_path: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      file_size: {
        type: DataTypes.INTEGER, // Size in bytes
        allowNull: true,
      },
      file_type: {
        type: DataTypes.STRING, // e.g., 'pdf', 'jpg'
        allowNull: true,
      },
      description: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      isactive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
    created_by: {
       type: DataTypes.INTEGER,
       allowNull: false,
     },
     created_at: {
       type: DataTypes.DATE,
       allowNull: false,
       defaultValue: DataTypes.NOW,
     },
     modified_by: {
       type: DataTypes.INTEGER,
       allowNull: true,
     },
     updated_at: {
       type: DataTypes.DATE,
       allowNull: true,
     },
    },{
      timestamps:false
    });
MeetingAttachments.belongsTo(Meeting, { foreignKey: 'meeting_id' });
MeetingAttachments.belongsTo(User, { foreignKey: 'user_id' });


module.exports = MeetingAttachments;