const DataTypes = require("sequelize");
const sequelize = require("../../config/database");

const Meeting = sequelize.define('meet_meetings', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false,
  },
  project_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  is_public: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: "1",
  },
  meeting_name:{
    type: DataTypes.STRING,
    allowNull: true,
  },
  description:{
    type:DataTypes.STRING,
    allowNull:true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  meeting_url: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  livekit_room_id: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  start_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  end_time: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  host_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  isactive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  modified_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
},{
  timestamps:false
});



module.exports = Meeting;