const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const ProjectCustomFieldValues = require('./ProjectCustomFieldTypeValueModel')
const ProjectTaskTImeRecordModel = require("./ProjectTaskTImeRecordModel");
const ProjectsModel = require("./ProjectsModel");
const User = require('../tracker/user/User')


const TaskEstTimeModel = sequelize.define("pmt_task_est_time", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    est_time: {
        type: DataTypes.DECIMAL(5, 2),
        allowNull: true,
    },
    work_date: {
        type: DataTypes.DATEONLY,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW,
    },

}, {
    timestamps: false
});

TaskEstTimeModel.sync({alter: true})



TaskEstTimeModel.associate = (model) => {
    TaskEstTimeModel.belongsTo(model, {
        foreignKey: "task_id",
        as: "task_est_time"
    });
};


module.exports = TaskEstTimeModel;
