const DataTypes = require('sequelize');
const sequelize = require('../../config/database');

const NotificationHistory = sequelize.define('notification_histories', {
    id: {
        type: DataTypes.INTEGER(20),
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    is_read: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        allowNull: false,
        defaultValue: '1',
        comment: '1-active, 0-inactive'
    },
    created_by: {
        type: DataTypes.INTEGER(11),
        allowNull: false
    },
    updated_by: {
        type: DataTypes.INTEGER(11),
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    }
}, {
    timestamps: false
  });

module.exports = NotificationHistory;