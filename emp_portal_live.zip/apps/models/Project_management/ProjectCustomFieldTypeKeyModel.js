const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");
const ProjectCustomFieldsModel = require("./ProjectCustomFieldsModel");
const ProjectCustomFieldTypeOptions = require("./ProjectCustomFieldOptions");

const ProjectCustomFieldTypeKeyModel = sequelize.define("pmt_custom_field_config_type_keys", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    sr_no: {
        type:DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type:DataTypes.INTEGER,
        allowNull: false,
    },
    type_id: {
        type:DataTypes.INTEGER,
        allowNull: false,
    },
    label_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    config_detail: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_default: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '0',
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
}, {
    timestamps: false
  });



ProjectCustomFieldTypeKeyModel.belongsTo(ProjectCustomFieldsModel, {
  foreignKey: "type_id",
  targetKey: "id",
  as: "type" // alias
});


ProjectCustomFieldTypeKeyModel.hasMany(ProjectCustomFieldTypeOptions, {
    foreignKey: "type_key_id",
    as:"key_options"
});

module.exports = ProjectCustomFieldTypeKeyModel;
