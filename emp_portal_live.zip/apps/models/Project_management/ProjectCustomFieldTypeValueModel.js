const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");
const ProjectCustomFieldOptions = require('./ProjectCustomFieldOptions');
const User = require("../tracker/user/User");

const ProjectCustomFieldTypeValueModel = sequelize.define("pmt_custom_field_config_type_values", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    project_id: {
        type:DataTypes.INTEGER,
    },
    task_id: {
        type:DataTypes.INTEGER,
    },
    type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    type_key_id: {
        type:DataTypes.INTEGER
    },
    text_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    estimated_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    select_val: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    number_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    multi_select_val: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    date_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    person_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    attachment_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    url_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    relation_val: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    rich_text: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    checkbox_val: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_by_val: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at_val: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by_val: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at_val: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
}, {
    timestamps: false
  });

  ProjectCustomFieldTypeValueModel.hasMany(ProjectCustomFieldOptions, {
     sourceKey: 'type_key_id', foreignKey: 'type_key_id', as: 'single_select'
  })


  ProjectCustomFieldTypeValueModel.hasMany(ProjectCustomFieldOptions, {
    sourceKey: 'type_key_id', foreignKey: 'type_key_id', as: 'multi_select'
  })

  ProjectCustomFieldTypeValueModel.hasOne(User, {
    sourceKey: 'created_by_val', foreignKey: 'id', as: 'creater'
  })

  ProjectCustomFieldTypeValueModel.hasOne(User, {
    sourceKey: 'updated_by_val', foreignKey: 'id', as: 'updater'
  })



module.exports = ProjectCustomFieldTypeValueModel;
