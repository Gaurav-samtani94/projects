const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');  

const ProjectTaskTImeRecordModel = sequelize.define('pmt_task_time_records', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    user_id: { 
        type: DataTypes.STRING,
        allowNull: true,
    },
    start_time: { 
        type: DataTypes.TIME, 
        allowNull: true,
    },
    end_time: { 
        type: DataTypes.TIME, 
        allowNull: true,
    },
    total_time: { 
        type: DataTypes.TIME, 
        allowNull: true,
    },
    work_date: { 
        type: DataTypes.TIME, 
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
}, {
    timestamps: false
});

module.exports = ProjectTaskTImeRecordModel;
