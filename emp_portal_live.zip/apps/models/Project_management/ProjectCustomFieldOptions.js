const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");
const User = require('../../models/tracker/user/User')

const ProjectCustomFieldTypeOptions = sequelize.define("pmt_project_custom_field_options", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    option_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    sr_no: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    color: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    option_type: {
        type: DataTypes.ENUM('2', '1'),
        allowNull: false,
        values: ['1', '2'],
        defaultValue: '1',
    },
    is_selected: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '0',
    },
    is_disabled: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '0',
    },
    type_key_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
}, {
    timestamps: false
  });

  ProjectCustomFieldTypeOptions.belongsTo(User,{
    foreignKey: 'option_name', targetKey: 'id',
  })

module.exports = ProjectCustomFieldTypeOptions;
