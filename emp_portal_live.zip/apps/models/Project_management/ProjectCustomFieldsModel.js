const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const ProjectCustomFieldsModel = sequelize.define("pmt_mstr_all_custom_fields", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    field_code: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    field_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    // label_name: {
    //     type: DataTypes.STRING,
    //     allowNull: false,
    // },
    field_value_type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
}, {
    timestamps: false
  });

module.exports = ProjectCustomFieldsModel;
