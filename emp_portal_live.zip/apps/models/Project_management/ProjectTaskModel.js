const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const ProjectCustomFieldValues = require('./ProjectCustomFieldTypeValueModel')
const ProjectTaskTImeRecordModel = require("./ProjectTaskTImeRecordModel");
const ProjectsModel = require("./ProjectsModel");
const User = require('../../models/tracker/user/User')

const TaskEstTimeModel = require('../../models/Project_management/TaskEstTimeModel')


const ProjectTaskModel = sequelize.define("pmt_tasks", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    sr_no: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    task_name: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    is_working: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

}, {
    timestamps: false
  });

  ProjectTaskModel.hasMany(ProjectCustomFieldValues, {sourceKey: 'id', foreignKey: 'task_id', as: 'task_fields'})

  ProjectTaskModel.hasMany(ProjectTaskTImeRecordModel, {
    foreignKey:'task_id',
    as:'taskTime'
});

ProjectTaskModel.hasOne(User, {
    foreignKey: 'id', sourceKey: 'updated_by', as: 'updater'
  })

ProjectTaskModel.hasOne(User, {
    foreignKey: 'id', sourceKey: 'created_by', as: 'creater'
})

ProjectTaskModel.belongsTo(TaskEstTimeModel, {
    foreignKey: 'id', targetKey: 'task_id'
})

// ProjectTaskModel.hasMany(ProjectCustomFieldValues, {
//     foreignKey:'task_id',
//     as:'task_field_val'
// });

ProjectTaskModel.associate = (models) => {
    ProjectTaskModel.belongsTo(models.ProjectsModel, {
      foreignKey: "project_id",
      as: "projects"
    });
  };


module.exports = ProjectTaskModel;
