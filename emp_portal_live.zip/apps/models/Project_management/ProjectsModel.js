const DataTypes = require("sequelize");
const sequelize = require("../../config/database");
const Meeting = require("../Meeting/Meeting");
const ProjectCustomFieldTypeKeyModel = require("./ProjectCustomFieldTypeKeyModel");
const TeamMember = require("./projectTeamMember");
const ProjectAttachmentsModel = require("./ProjectAttachmentsModel");
const ProjectTaskModel = require("./ProjectTaskModel");

const ProjectsModel = sequelize.define("pmt_projects", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      project_name: {
        type: DataTypes.TEXT(255),
        allowNull: false
      },
      // project_lead_ids: {
      //   type: DataTypes.STRING,
      //   allowNull: true,
      // },
      icon: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: 'folder'
      },
      team_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      description: {
        type: DataTypes.STRING(255),
        allowNull: true,
        defaultValue: null
      },
      project_full_name: {
        type: DataTypes.STRING(255),
        allowNull: true,
        defaultValue: null
      },
      start_date: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        defaultValue: null
      },
      end_date: {
        type: DataTypes.DATEONLY,
        allowNull: true,
        defaultValue: null
      },
      project_status: {
        type: DataTypes.INTEGER,
        allowNull: true,
         comment: "0=start,1=progress,2=done,3=depend on task"
      },
      estimated_time: {
        type: DataTypes.TIME,
        allowNull: true,
      },
      priority: {
        type: DataTypes.INTEGER,
        allowNull: true,
        comment: "0=low,1=high,2=medium"
      },
      status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: true,
        defaultValue: '1',  // 1 = active, 0 = inactive
        comment: "0=inactive,1=active"
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: false
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: true,
        // defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
      },
      updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      }
}, {
    timestamps: false
});

ProjectsModel.hasMany(ProjectCustomFieldTypeKeyModel, {
  foreignKey: 'project_id',
  sourceKey: 'id',
  as: 'customFieldKeys' // optional alias
});
ProjectsModel.hasOne(TeamMember, {
  foreignKey: 'project_id',
  as: 'team'  // 👈 You'll use this alias in includes
});

ProjectsModel.hasMany(ProjectAttachmentsModel, {
  foreignKey: 'project_id',
  sourceKey: 'id',
  as: 'attachment' // optional alias
});

ProjectsModel.associate = (models) => {
  ProjectsModel.hasMany(models.ProjectTaskModel, {
    foreignKey: "project_id",
    as: "tasks"
  });
};

// ProjectsModel.sync({alter:true})
// ProjectsModel.hasMany(TeamMember, { foreignKey: 'team_id', sourceKey: 'team_id' });
// TeamMember.belongsTo(ProjectsModel, { foreignKey: 'team_id', targetKey: 'team_id' });


ProjectsModel.hasOne(Meeting, { foreignKey: 'project_id' });
Meeting.belongsTo(ProjectsModel, { foreignKey: 'project_id' });

module.exports = ProjectsModel;
