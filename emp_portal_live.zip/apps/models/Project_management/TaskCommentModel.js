const DataTypes = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../tracker/user/User');

const TaskComment = sequelize.define('pmt_task_comments', {
    id: {
        type: DataTypes.INTEGER(20),
        autoIncrement: true,
        primaryKey: true
    },
    parent_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    parent_task_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.STRING,
        allowNull: false
    },
    task_id: {
        type: DataTypes.STRING(11),
        allowNull: true
    },
    comment_text: {
        type: DataTypes.INTEGER(11),
        allowNull: true
    },
    tag_user_ids: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        allowNull: false,
        defaultValue: '1',
        comment: '1-active, 0-inactive'
    },
    created_by: {
        type: DataTypes.INTEGER(11),
        allowNull: false
    },
    updated_by: {
        type: DataTypes.INTEGER(11),
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    }
}, {
    timestamps: false
  });

  TaskComment.belongsTo(User, { foreignKey: 'created_by', as: 'comment_by' });

module.exports = TaskComment;