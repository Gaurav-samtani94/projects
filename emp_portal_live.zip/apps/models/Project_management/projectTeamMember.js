const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');  // Replace with your actual sequelize connection
const ProjectsModel = require('./ProjectsModel');

const TeamMember = sequelize.define('pmt_team_members', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    user_ids: { 
        type: DataTypes.STRING, // Comma-separated user IDs
        allowNull: true,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, {
    timestamps: false
});

// TeamMember.sync({ alter: true });
// TeamMember.belongsTo(ProjectsModel, {
//     foreignKey: 'project_id',
//   });


module.exports = TeamMember;
