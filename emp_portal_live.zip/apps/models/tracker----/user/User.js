const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const EmployeeSummary = require("../../../models/Hrms/user/EmployeeSummary");
const HrmsOtherOfficialData = require("../../../models/Hrms/user/HrmsOtherOfficialData");

const User = sequelize.define('tbl_User', {
  id: {
    type: DataTypes.INTEGER,  // Ensure 'id' is the primary key
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes.STRING(50),
    allowNull: false,
  },
  date_of_joining: {
    type: DataTypes.DATE,
  },
  emailaddress: {
    type: DataTypes.STRING(100),
  },
  date_of_leaving: {
    type: DataTypes.DATE,
  },
  reporting_manager: { // Self-referencing Foreign Key
    type: DataTypes.INTEGER,
    references: {
        model: 'users',
        key: 'id'
    }
  },
  reporting_manager_name: {
    type: DataTypes.STRING(100),
  },
  emp_status_id: {
    type: DataTypes.STRING(50),
  },
  emp_status_name: {
    type: DataTypes.STRING(100),
  },
  businessunit_id: {
    type: DataTypes.STRING(50),
  },
  businessunit_name: {
    type: DataTypes.STRING(100),
  },
  department_id: {
    type: DataTypes.STRING(50),
  },
  department_name: {
    type: DataTypes.STRING(100),
  },
  jobtitle_id: {
    type: DataTypes.STRING(50),
  },
  jobtitle_name: {
    type: DataTypes.STRING(100),
  },
  position_id: {
    type: DataTypes.STRING(50),
  },
  position_name: {
    type: DataTypes.STRING(100),
  },
  years_exp: {
    type: DataTypes.INTEGER,
  },
  holiday_group: {
    type: DataTypes.STRING(50),
  },
  holiday_group_name: {
    type: DataTypes.STRING(100),
  },
  prefix_id: {
    type: DataTypes.STRING(50),
  },
  prefix_name: {
    type: DataTypes.STRING(50),
  },
  extension_number: {
    type: DataTypes.STRING(15),
  },
  office_number: {
    type: DataTypes.STRING(15),
  },
  office_faxnumber: {
    type: DataTypes.STRING(15),
  },
  emprole: {
    type: DataTypes.INTEGER,
  },
  emprole_name: {
    type: DataTypes.STRING(100),
  },
  firstname: {
    type: DataTypes.STRING(50),
  },
  lastname: {
    type: DataTypes.STRING(50),
  },
  userfullname: {
    type: DataTypes.TEXT, // Changed to TEXT for long names
  },
  contactnumber: {
    type: DataTypes.STRING(15),
  },
  backgroundchk_status: {
    type: DataTypes.STRING(50),
  },
  employeeId: {
    type: DataTypes.STRING(50),
  },
  modeofentry: {
    type: DataTypes.STRING(50),
  },
  other_modeofentry: {
    type: DataTypes.STRING(100),
  },
  selecteddate: {
    type: DataTypes.DATE,
  },
  candidatereferredby: {
    type: DataTypes.STRING(50),
  },
  referer_name: {
    type: DataTypes.STRING(100),
  },
  profileimg: {
    type: DataTypes.BLOB('long'), // Changed to BLOB for images
  },
  branch_id: {
    type: DataTypes.STRING(50),
  },
  createdby: {
    type: DataTypes.STRING(50),
  },
  createdby_name: {
    type: DataTypes.STRING(100),
  },
  modifiedby: {
    type: DataTypes.STRING(50),
  },
  createddate: {
    type: DataTypes.DATE,
  },
  modifieddate: {
    type: DataTypes.DATE,
  },
  isactive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
  password: {
    type: DataTypes.STRING(255), // Ensure enough space for hashed password
  },
  updated_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  }
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'tbl_User', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});
User.hasOne(EmployeeSummary, { foreignKey: 'user_id', sourceKey: 'id', as: 'employeeSummary' });
User.hasMany(User, { as: 'childUser', foreignKey: 'reporting_manager' });
User.belongsTo(User, { as: 'manager', foreignKey: 'reporting_manager' });
User.hasOne(HrmsOtherOfficialData, { foreignKey: 'user_id', sourceKey: 'id', as: 'hrmsOtherOfficialData' });



module.exports = User;
