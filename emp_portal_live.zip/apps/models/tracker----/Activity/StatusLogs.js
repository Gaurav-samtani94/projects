const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const StatusLogSchema = sequelize.define('track_statuslogs', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: User,
            key: 'id'
        }
    },
    app: {
        type: DataTypes.STRING,
    },
    title: {
        type: DataTypes.STRING
    },
    url: {
        type: DataTypes.STRING,
    },
    color: {
        type:DataTypes.STRING
    },
    beginDate: {
        type: DataTypes.DATE
    },
    endDate: {
        type: DataTypes.DATE
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
StatusLogSchema.belongsTo(User, { foreignKey: 'userId',});
User.hasMany(StatusLogSchema, { foreignKey: 'userId', });

module.exports = {
    StatusLogSchema,
};
