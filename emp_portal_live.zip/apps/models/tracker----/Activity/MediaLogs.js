const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const MediaLogSchema = sequelize.define('track_MediaLog', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    type: { 
        type: DataTypes.ENUM('screenshot', 'cameraShot'),  // Use ENUM correctly
        allowNull: false  // Corrected from 'required' to 'allowNull'
    },
    mediaUrl: { 
        type: DataTypes.STRING,  // Corrected data type
        allowNull: false  // Corrected from 'required' to 'allowNull'
    },
    mediaType: {
        type: DataTypes.ENUM('image', 'video'),  // ENUM for media types
        allowNull: false
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
MediaLogSchema.belongsTo(User, { foreignKey: 'userId' });
User.hasMany(MediaLogSchema, { foreignKey: 'userId' });


module.exports = {
    MediaLogSchema,
};
