const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const WorkLogSchema = sequelize.define('track_WorkLog', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    taskName:{
        type: DataTypes.STRING,  // Corrected data type
        allowNull:false
    },
    app: {
        type: DataTypes.STRING,
    },
    title: {
        type: DataTypes.STRING
    },
    url: {
        type: DataTypes.STRING,
    },
    color: {
        type:DataTypes.STRING
    },
    beginDate: {
        type: DataTypes.DATE
    },
    endDate: {
        type: DataTypes.DATE
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
WorkLogSchema.belongsTo(User, { foreignKey: 'userId',});
User.hasMany(WorkLogSchema, { foreignKey: 'userId', });


module.exports = {
    WorkLogSchema,
};
