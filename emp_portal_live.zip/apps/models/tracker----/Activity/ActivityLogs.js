const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const ActivityLogSchema = sequelize.define('track_ActivityLog', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: User,
            key: 'id'
        }
    },
    app: {
        type: DataTypes.STRING,
    },
    title: {
        type: DataTypes.STRING
    },
    url: {
        type: DataTypes.STRING,
    },
    beginDate: {
        type: DataTypes.DATE
    },
    endDate: {
        type: DataTypes.DATE
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
ActivityLogSchema.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(ActivityLogSchema, { foreignKey: 'userId', as: 'activities' });


module.exports = {
    ActivityLogSchema,
};
