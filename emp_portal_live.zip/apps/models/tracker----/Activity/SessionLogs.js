const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const SessionLogSchema = sequelize.define('track_sessionLogs', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    beginDate: {
        type: DataTypes.DATE
    },
    endDate: {
        type: DataTypes.DATE
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
SessionLogSchema.belongsTo(User, { foreignKey: 'userId' });
User.hasMany(SessionLogSchema, { foreignKey: 'userId' });

module.exports = {
    SessionLogSchema,
};
