const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const WorkLogSchema = sequelize.define('track_AppsDuration', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: User,
            key: 'id'
        }
    },
    app: {
        type: DataTypes.STRING,
    },
    taskName: {
        type: DataTypes.STRING,  // Corrected type
        allowNull: false
    },
    title: {
        type: DataTypes.STRING
    },
    url: {
        type: DataTypes.STRING,
    },
    color: {
        type: DataTypes.STRING  // Corrected type
    },
    beginDate: {
        type: DataTypes.DATE
    },
    endDate: {
        type: DataTypes.DATE
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

// Define associations
WorkLogSchema.belongsTo(User, { foreignKey: 'userId'});
User.hasMany(WorkLogSchema, { foreignKey: 'userId'});


module.exports = {
    WorkLogSchema,
};
