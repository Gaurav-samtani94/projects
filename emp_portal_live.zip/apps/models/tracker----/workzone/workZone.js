const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../../config/database'); // Adjust the path accordingly
const User = require('../user/User'); // Adjust the path accordingly

const WorkZone = sequelize.define('track__work_zones', {
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    },
    validate: {
      notNull: { msg: "User ID is required" },
      isInt: { msg: "User ID must be an integer" }
    }
  },
  workType: {
    type: DataTypes.ENUM("WFH", "WFO"),
    allowNull: false,
    defaultValue: "WFO",
    validate: {
      notNull: { msg: "Work Type is required" },
      isIn: {
        args: [["WFH", "WFO"]],
        msg: "Work Type must be either 'WFH' or 'WFO'"
      }
    }
  },
  startDate: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      notNull: { msg: "Start date is required" },
      isDate: { msg: "Start date must be a valid date" }
    }
  },
  endDate: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      notNull: { msg: "End date is required" },
      isDate: { msg: "End date must be a valid date" },
      isAfterStart(value) {
        if (this.startDate >= value) {
          throw new Error("End date must be after start date");
        }
      }
    }
  },
  assignedBy: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: 'id'
    },
    validate: {
      notNull: { msg: "Assigned By is required" },
      isInt: { msg: "Assigned By must be an integer" }
    }
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  timestamps: false, // We're manually handling 'createdAt'
  underscored: true, // Converts camelCase to snake_case in DB columns
});

// Associations
WorkZone.belongsTo(User, { foreignKey: 'userId' });
WorkZone.belongsTo(User, {foreignKey: 'assignedBy' });


module.exports = WorkZone;
