// models/taskStats.js

const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const TaskStats = sequelize.define('task_stats', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: {
        type: DataTypes.INTEGER,
       
    },
    project_id: { type: DataTypes.INTEGER },
    project_name: { type: DataTypes.STRING },
    task_id: { type: DataTypes.INTEGER },
    task_name: { type: DataTypes.STRING },
    duration: { type: DataTypes.FLOAT },
    stats_date: { type: DataTypes.BIGINT },
    created_at: {
        type: DataTypes.BIGINT,
        defaultValue: () => Date.now()
    }
}, {
    timestamps: false,
    tableName: 'task_stats'
});

// Associations
TaskStats.belongsTo(User, { foreignKey: 'userId' });
User.hasMany(TaskStats, { foreignKey: 'userId' });

// // Auto-sync
// (async () => {
//     try {
//         await TaskStats.sync({ alter: true });
//         console.log('✅ TaskStats table synced');
//     } catch (error) {
//         console.error('❌ Error syncing TaskStats:', error);
//     }
// })();

module.exports = TaskStats;
