const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const StatusLogSchema = sequelize.define('track_statuslogs', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        // references: {
        //     model: User,
        //     key: 'id'
        // }
    },
    app: {
        type: DataTypes.STRING,
    },
    title: {
        type: DataTypes.JSON
    },
    url: {
        type: DataTypes.TEXT,
    },
    color: {
        type:DataTypes.STRING
    },
    beginDate: {
        type: DataTypes.BIGINT
    },
    endDate: {
        type: DataTypes.BIGINT
    },
    create_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
    update_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW  
    }
});

StatusLogSchema.sync({alter: true})

// // Define associations
// StatusLogSchema.belongsTo(User, { foreignKey: 'userId',});
// User.hasMany(StatusLogSchema, { foreignKey: 'userId', });

module.exports = 
    StatusLogSchema

