// models/systemStats.js

const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const DailyCalculatedSystemStats = sequelize.define('daily_calculated_system_stats', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER },
    total_idle_time: { type: DataTypes.INTEGER },
    total_online_time: { type: DataTypes.INTEGER },
    total_offline_time: { type: DataTypes.INTEGER },
    total_time: { type: DataTypes.INTEGER },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: () => Date.now()
    }
}, {
    timestamps: false,
    tableName: 'daily_calculated_system_stats'
});

// Associations
DailyCalculatedSystemStats.belongsTo(User, { foreignKey: 'userId' });
User.hasMany(DailyCalculatedSystemStats, { foreignKey: 'userId' });

// Auto-sync
(async () => {
    try {
        await DailyCalculatedSystemStats.sync({ alter: true });
    } catch (error) {
    }
})();

module.exports = DailyCalculatedSystemStats;
