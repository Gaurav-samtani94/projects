// models/systemStats.js

const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const DailyAppActivity = sequelize.define('daily_app_activity', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: {type: DataTypes.INTEGER},
    owner: { type: DataTypes.STRING },
    title: { type: DataTypes.STRING },
    end_time: { type: DataTypes.STRING },
    start_time: { type: DataTypes.STRING },
    duration: {type: DataTypes.INTEGER},
    created_at: {
        type: DataTypes.DATE,
        defaultValue: () => Date.now()
    }
}, {
    timestamps: false,
    tableName: 'daily_app_activity'
});

// Associations
DailyAppActivity.belongsTo(User, { foreignKey: 'userId' });

// Auto-sync
(async () => {
    try {
        await DailyAppActivity.sync({ alter: true });
    } catch (error) {
    }
})();

module.exports = DailyAppActivity;
