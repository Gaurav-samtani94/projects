// models/systemStats.js

const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const DailySystemStats = sequelize.define('daily_system_stats', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER },
    start_time: { type: DataTypes.STRING },
    end_time: { type: DataTypes.STRING },
    status: { type: DataTypes.ENUM, values: ['idle', 'online', 'offline'] },
    duration: {type: DataTypes.INTEGER},
    created_at: {
        type: DataTypes.DATE,
        defaultValue: () => Date.now()
    }
}, {
    timestamps: false,
    tableName: 'daily_system_stats'
});

// Associations
DailySystemStats.belongsTo(User, { foreignKey: 'userId' });
User.hasMany(DailySystemStats, { foreignKey: 'userId' });

// Auto-sync
(async () => {
    try {
        await DailySystemStats.sync({ alter: true });
    } catch (error) {
    }
})();

module.exports = DailySystemStats;
