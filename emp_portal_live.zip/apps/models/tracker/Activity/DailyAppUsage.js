// models/systemStats.js

const sequelize = require('../../../config/database');
const { DataTypes } = require('sequelize');
const User = require('../user/User');

const DailyAppUsage = sequelize.define('daily_app_usage', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    userId: { type: DataTypes.INTEGER },
    owner: { type: DataTypes.STRING },
    duration: {type: DataTypes.INTEGER},
    created_at: {
        type: DataTypes.DATE,
        defaultValue: () => Date.now()
    }
}, {
    timestamps: false,
    tableName: 'daily_app_usage'
});

// Associations
DailyAppUsage.belongsTo(User, { foreignKey: 'userId' });

// Auto-sync
(async () => {
    try {
        await DailyAppUsage.sync({ alter: true });
    } catch (error) {
    }
})();

module.exports = DailyAppUsage;
