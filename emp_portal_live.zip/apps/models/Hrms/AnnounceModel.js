const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const Announcement = sequelize.define('Announcement', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    announcement_title: {
        type: DataTypes.STRING(100),
        allowNull: false,
        comment: 'Title of the announcement (e.g., Public Holiday, Company Event)'
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Details about the announcement'
    },
    announcement_type: {
        type: DataTypes.ENUM('Holiday', 'Event', 'Closure', 'Other'),
        allowNull: false,
        defaultValue: 'Holiday',
        comment: 'Type of announcement'
    },
    announcement_date: {
        type: DataTypes.DATE,
        allowNull: false,
        comment: 'Date of the announced event/holiday'
    },
    end_date: {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'End date if the announcement spans multiple days'
    },
    is_full_day: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: '1-full day, 0-half day'
    },
    createdby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
        comment: 'ID of the HR/admin who created the announcement'
    },
    modifiedby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
        comment: 'ID of the HR/admin who modified the announcement'
    },
    createddate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    modifieddate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    isactive: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: '1-active, 0-inactive'
    }
}, {
    tableName: 'hrms_hr_announce',
    timestamps: false
});

module.exports = Announcement;
