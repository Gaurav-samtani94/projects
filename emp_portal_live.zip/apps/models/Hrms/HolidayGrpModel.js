const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const HolidayGroup = sequelize.define('HolidayGroup', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    groupname: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    description: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    createdby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
    },
    modifiedby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
    },
    createddate: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    modifieddate: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    isactive: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: 1,
    }
}, {
    tableName: 'main_holidaygroups',
    timestamps: false,
});

module.exports = HolidayGroup;
