const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const HolidayGroup = require('../../models/Hrms/HolidayGrpModel');

const Holiday = sequelize.define('main_holidaydates', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    holidayname: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    groupid: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    holidaydate: {
        type: DataTypes.DATEONLY,
        allowNull: true,
    },
    holidayyear: {
        type: DataTypes.STRING(4),
        allowNull: true,
    },
    description: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    createdby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
    },
    modifiedby: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true,
    },
    createddate: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modifieddate: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    isactive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
    }
}, {
    tableName: 'main_holidaydates',
    timestamps: false,
});

// ✅ Define association here
Holiday.belongsTo(HolidayGroup, { foreignKey: 'groupid', as: 'group' });

module.exports = Holiday;
