const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const RHLeave = sequelize.define('rh_leave_summery', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },

    RH_name: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    RH_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    Year: {
        type: DataTypes.STRING(4),
        allowNull: true,
    }

}, {
    tableName: 'rh_leave_summery',
    timestamps: false,
});

module.exports = RHLeave;
