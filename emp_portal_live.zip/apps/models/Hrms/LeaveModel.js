const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = require('../../models/tracker/user/User')

const Leave = sequelize.define('hrms_main_leaverequest', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    user_id: {
        type: DataTypes.BIGINT,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    reason: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null
    },
    approver_comments: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null
    },
    leavetypeid: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    leaveday: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: '1-full_day, 2-half_day, 3-sort_leave'
    },
    from_date: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
    },
    to_date: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
    },
    leavestatus: {
        type: DataTypes.ENUM,
        values: ['Pending for approval', 'Approved', 'Rejected'],
        allowNull: true,
        defaultValue: 'Pending for approval'
    },
    rep_mang_id: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    hr_id: {
        type: DataTypes.STRING(10),
        allowNull: true,
        defaultValue: null
    },
    half_day_type: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        allowNull: false,
        defaultValue: '0'
    },
    no_of_days: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    appliedleavescount: {
        type: DataTypes.FLOAT(4, 2),
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    is_sat_holiday: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: null,
        comment: '1-yes, 2-no'
    },
    createdby: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    modifiedby: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null
    },
    createddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
    },

    modifieddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
    },

    isactive: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1
    },

    sort_leave_exptime: {
        type: DataTypes.STRING(20),
        allowNull: true,
        defaultValue: null
    },
    hd_pre_post_lunch: {
        type: DataTypes.ENUM('1', '2', '3'),
        allowNull: true,
        defaultValue: null,
        comment: '1-prel, 2-postl, 3-other'
    }


}, {
    tableName: 'hrms_main_leaverequest',
    timestamps: false,
});


Leave.belongsTo(User, {foreignKey: 'user_id'})

module.exports = Leave;
