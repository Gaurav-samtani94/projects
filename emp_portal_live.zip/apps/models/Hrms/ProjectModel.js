const { DataTypes, STRING } = require('sequelize');
const sequelize = require('../../config/database');
const Project = sequelize.define('Project', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    project_name: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    key: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    description: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    project_type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_lead: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },

}, {
    tableName: 'pmt_prjects',
    timestamps: false,
});
module.exports = Project;