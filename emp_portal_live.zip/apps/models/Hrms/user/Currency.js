const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");

const Currency = sequelize.define('Currency', {
  id: {
    type: DataTypes.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING(191),
    allowNull: false
  },
  currency_symbol: {
    type: DataTypes.STRING(191),
    allowNull: false
  },
  currency_code: {
    type: DataTypes.STRING(191),
    allowNull: false
  },
  status: {
    type: DataTypes.TINYINT,
    allowNull: true,
    defaultValue: 1,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  updated_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,  // Ensure NULL values are allowed
    defaultValue: null
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,  // Ensure NULL values are allowed
    defaultValue: null
  }
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'mstr_currencies', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});

module.exports = Currency;
