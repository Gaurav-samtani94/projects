const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");
const Gender = require("../../../models/Hrms/user/Gender");

const EmpPersonalDetails = sequelize.define('EmpPersonalDetails', {
    id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    genderid: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    mother_nm: {
        type: DataTypes.STRING(247),
        allowNull: false
    },
    father_nm: {
        type: DataTypes.STRING(247),
        allowNull: false
    },
    maritalstatusid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    maritaldate: {
        type: DataTypes.DATE,
        allowNull: true
    },
    nationalityid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    ethniccodeid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    racecodeid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    languageid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    language_known: {
        type: DataTypes.STRING(247),
        allowNull: true
    },
    dob: {
        type: DataTypes.DATE,
        allowNull: true
    },
    celebrated_dob: {
        type: DataTypes.DATE,
        allowNull: true
    },
    bloodgroup: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    religion: {
        type: DataTypes.STRING(123),
        allowNull: true
    },
    identity_documents: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    aadhar_no_enrolment: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    skypee_id: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    spouse_contact_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    height_in_cm: {
        type: DataTypes.STRING(15),
        allowNull: true
    },
    height_cms: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    weight: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    passport_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    pan_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    driving_license_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    driving_liscence: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    ration_card: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    fathers_contact_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    mothers_contact_no: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    marriage_date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    spouse_name: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    spouse_occupation: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_emppersonaldetails', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});
EmpPersonalDetails.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });
EmpPersonalDetails.hasOne(Gender, { foreignKey: 'id', sourceKey: 'genderid', as: 'genderDetails' });

module.exports = EmpPersonalDetails;
