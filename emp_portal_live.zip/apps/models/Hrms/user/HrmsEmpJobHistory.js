const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");
const BusinessUnit = require("../../../models/Hrms/user/BusinessUnit");

const HrmsEmpJobHistory = sequelize.define('HrmsEmpJobHistory', {
    id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    businessunit: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    sub_department: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    positionheld: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    department: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    jobtitleid: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    start_date: {
        type: DataTypes.DATEONLY,
        allowNull: true
    },
    end_date: {
        type: DataTypes.DATEONLY,
        allowNull: true
    },
    active_company: {
        type: DataTypes.TINYINT,
        allowNull: true,
        comment: '1-yes,2-No'
    },
    client_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    vendor: {
        type: DataTypes.STRING(200),
        allowNull: true,
        comment: 'company id'
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    paid_amount: {
        type: DataTypes.DECIMAL(25,2),
        allowNull: true
    },
    received_amount: {
        type: DataTypes.DECIMAL(25,2),
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT.UNSIGNED,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: DataTypes.NOW
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true
    },
    tem_pdf: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    pdf_lock: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '1'
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_empjobhistory', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});
HrmsEmpJobHistory.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });
HrmsEmpJobHistory.hasOne(BusinessUnit, { foreignKey: 'id', sourceKey: 'businessunit', as: 'businessunits' });

module.exports = HrmsEmpJobHistory;
