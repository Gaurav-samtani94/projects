const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");
const Currency = require("../../../models/Hrms/user/Currency");

const EmpSalaryDetails = sequelize.define('EmpSalaryDetails', {
  id: {
    type: DataTypes.BIGINT.UNSIGNED,
    autoIncrement: true,
    primaryKey: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  currencyid: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  salarytype: {
    type: DataTypes.INTEGER,
    allowNull: true,
    comment: '1-Day, 2-Month'
  },
  salary: {
    type: DataTypes.DECIMAL(25,2),
    allowNull: true
  },
  ctcsalary: {
    type: DataTypes.DECIMAL(25,2),
    allowNull: false
  },
  bankname: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  accountholder_name: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  accountholding: {
    type: DataTypes.DATE,
    allowNull: true
  },
  accountclasstypeid: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true
  },
  bankaccountid: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true
  },
  accountnumber: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  branchname: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  ifsc_code: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  micr_code: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  pancard_no: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  created_by: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  appraisalduedate: {
    type: DataTypes.STRING(50),
    allowNull: true
  },
  updated_by: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
    defaultValue: DataTypes.NOW
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true
  },
  status: {
    type: DataTypes.TINYINT.UNSIGNED,
    allowNull: true,
    defaultValue: 1
  },
  flag: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  pan_flag: {
    type: DataTypes.INTEGER,
    allowNull: true
  }
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'hrms_empsalarydetails', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});
EmpSalaryDetails.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });
EmpSalaryDetails.hasOne(Currency, { foreignKey: 'id', sourceKey: 'currencyid', as: 'currencyDetails' });

module.exports = EmpSalaryDetails;
