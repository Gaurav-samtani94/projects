const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");
const Currency = require("../../../models/Hrms/user/Currency");

const MonthlyAttendance = sequelize.define('MonthlyAttendance', {
  id: {
    type: DataTypes.BIGINT,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  month: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  year: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  date: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  in_time: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  out_time: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  late_by: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  early_by: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  working_hour: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  action: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  working_status: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  entry_by: {
    type: DataTypes.INTEGER,
    allowNull: true
  }
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'hrms_mothly_attendances', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});
MonthlyAttendance.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });

module.exports = MonthlyAttendance;
