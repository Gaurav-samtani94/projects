const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");

const Gender = sequelize.define('Gender', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    gendercode: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    gendername: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    description: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    created_by: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    status: {
        type: DataTypes.TINYINT.UNSIGNED,
        defaultValue: 1
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'mstr_gender', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});


Gender.sync({
    alter:true
})

module.exports = Gender;
