const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly

const PayslipFilepath = sequelize.define('PayslipFilepath', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  year: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  month: {
    type: DataTypes.STRING(25),
    allowNull: false
  },
  payrollid: {
    type: DataTypes.STRING(15),
    allowNull: false
  },
  payroll_with_name: {
    type: DataTypes.STRING(177),
    allowNull: true
  },
  fullpath: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  filename: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  status: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: '1'
  },
  entry_date: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {    
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'hrms_payslip_filepath', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});

module.exports = PayslipFilepath;
