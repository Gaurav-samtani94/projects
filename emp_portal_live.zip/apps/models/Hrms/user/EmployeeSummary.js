const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");


const EmployeeSummary = sequelize.define("hrms_employees_summary", {
  id: {
    type: DataTypes.INTEGER.UNSIGNED,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  empipaddress: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  country_mobcode_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  emptemplock: {
    type: DataTypes.TINYINT,
    defaultValue: 0,
  },
  empreasonlocked: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  emplockeddate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  rccandidatename: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  entrycomments: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  company_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  created_by: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  createdby_name: {
    type: DataTypes.STRING(250),
    allowNull: true,
  },
  updated_by: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  status: {
    type: DataTypes.TINYINT.UNSIGNED,
    allowNull: true,
    comment: "0=inactive,1=Active,2=resigned,3=left,4=suspended,5=deleted",
  },
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'hrms_employees_summary', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});

// ✅ CRUD Operations
/*
// Create a new employee record
const createEmployee = async (data) => {
  return await EmployeeSummary.create(data);
};

// Get an employee by ID
const getEmployeeById = async (id) => {
  return await EmployeeSummary.findByPk(id);
};

// Update an employee record
const updateEmployee = async (id, data) => {
  return await EmployeeSummary.update(data, { where: { id } });
};

// Delete an employee record
const deleteEmployee = async (id) => {
  return await EmployeeSummary.destroy({ where: { id } });
};
*/
//module.exports = { EmployeeSummary, createEmployee, getEmployeeById, updateEmployee, deleteEmployee };
module.exports = EmployeeSummary;
