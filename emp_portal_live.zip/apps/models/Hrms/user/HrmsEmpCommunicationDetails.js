const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");

const HrmsEmpCommunicationDetails = sequelize.define('HrmsEmpCommunicationDetails', {
    id: {
        type: DataTypes.BIGINT.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    personalemail: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    perm_hono: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    perm_streetaddress: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    perm_country: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    perm_state: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    perm_city: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    perm_pincode: {
        type: DataTypes.STRING(15),
        allowNull: true
    },
    current_hono: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    current_streetaddress: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    current_country: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    current_state: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    current_city: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    current_pincode: {
        type: DataTypes.STRING(15),
        allowNull: true
    },
    perm_area_locality: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    current_area_locality: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    current_email: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    emergency_address: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    emergency_number: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    emergency_name: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    emergency_namerelation: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    emergency_email: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_empcommunicationdetails', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});
HrmsEmpCommunicationDetails.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });

module.exports = HrmsEmpCommunicationDetails;
