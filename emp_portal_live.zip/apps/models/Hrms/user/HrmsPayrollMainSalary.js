const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");

const PayslipFilepath = require("../../../models/Hrms/user/PayslipFilepath");

const HrmsPayrollMainSalary = sequelize.define('HrmsPayrollMainSalary', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    year: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    fin_year: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    type_id: {
        type: DataTypes.ENUM('1', '2'),
        allowNull: false,
        comment: '1=>ctc, 2=>gross'
    },
    apr_month: DataTypes.DOUBLE,
    may_month: DataTypes.DOUBLE,
    june_month: DataTypes.DOUBLE,
    july_month: DataTypes.DOUBLE,
    aug_month: DataTypes.DOUBLE,
    sep_month: DataTypes.DOUBLE,
    oct_month: DataTypes.DOUBLE,
    nov_month: DataTypes.DOUBLE,
    dec_month: DataTypes.DOUBLE,
    jan_month: DataTypes.DOUBLE,
    feb_month: DataTypes.DOUBLE,
    march_month: DataTypes.DOUBLE,
    status: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
        allowNull: false
    },
    ip_address: {
        type: DataTypes.STRING(25),
        allowNull: false
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_payroll_main_salary', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});
HrmsPayrollMainSalary.hasMany(PayslipFilepath, { 
    foreignKey: 'payrollid', 
    sourceKey: 'id', 
    as: 'payslipdetails' 
  });
  HrmsPayrollMainSalary.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });

module.exports = HrmsPayrollMainSalary;
