const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");


const EmpSkills = sequelize.define('EmpSkills', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        primaryKey: true,
        autoIncrement: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    skillname: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    yearsofexp: {
        type: DataTypes.STRING(20),
        allowNull: true
    },
    competencylevelid: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    year_skill_last_used: {
        type: DataTypes.DATE,
        allowNull: true
    },
    training_type: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    institute_clg_name: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    university: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    marks_obtained: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    tenure_from_to: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    percentage_grade: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    competency_level: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    created_by: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    updated_by: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_empskills', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});
EmpSkills.hasOne(User, { foreignKey: 'id', sourceKey: 'user_id', as: 'userDetails' });

module.exports = EmpSkills;
