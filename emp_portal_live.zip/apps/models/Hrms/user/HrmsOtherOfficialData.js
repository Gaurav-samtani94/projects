const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");
const PayslipFilepath = require("../../../models/Hrms/user/PayslipFilepath");

const HrmsOtherOfficialData = sequelize.define('HrmsOtherOfficialData', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    payroll_with_name: {
        type: DataTypes.STRING(177),
        allowNull: true
    },
    sub_department: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    thumbcode: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    on_project: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    reviewing_officer_ro: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    company_name: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    company_location: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    probation_period_no: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    noticeperiod: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    probation_date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    payrollcode: {
        type: DataTypes.STRING(255),
        allowNull: true
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
    branch_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    atten_punch: {
        type: DataTypes.STRING(10),
        allowNull: true
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1'
    },
    sub_dept_second: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    sub_dept_third: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    join_date_withceg: {
        type: DataTypes.DATE,
        allowNull: true
    },
    floor_number: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    machine_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    shift_in_time: {
        type: DataTypes.STRING(123),
        allowNull: true
    },
    shift_out_time: {
        type: DataTypes.STRING(123),
        allowNull: true
    },
    billable_non_billable: {
        type: DataTypes.ENUM('0', '1', '2', '3'),
        allowNull: false,
        defaultValue: '0'
    },
    related_with: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    payroll_eid: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    payroll_cid: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    payroll_lock: {
        type: DataTypes.INTEGER,
        allowNull: true
    }
}, {    
    timestamps: true, // Adds createdAt and updatedAt automatically
    underscored: true, // Converts camelCase to snake_case in the DB
    tableName: 'hrms_otherofficial_data', // Explicit table name, adjust if needed
    charset: 'utf8mb4', // Support for emojis and special characters
    collate: 'utf8mb4_general_ci'
});


module.exports = HrmsOtherOfficialData;
