const { DataTypes } = require("sequelize");
const sequelize = require('../../../config/database'); // Adjust this path accordingly
const User = require("../../../models/tracker/user/User");

const BusinessUnit = sequelize.define('BusinessUnit', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  unitname: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  unitcode: {
    type: DataTypes.STRING(50),
    allowNull: true,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  startdate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
  },
  country: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  state: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  city: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  address1: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  address2: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  address3: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  timezone: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  unithead: {
    type: DataTypes.STRING(255),
    allowNull: true,
  },
  service_desk_flag: {
    type: DataTypes.TINYINT.UNSIGNED,
    allowNull: true,
    defaultValue: 1,
    comment: '1=buwise, 0=deptwise',
  },
  created_by: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  updated_by: {
    type: DataTypes.INTEGER.UNSIGNED,
    allowNull: true,
  },
  creadted_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  status: {
    type: DataTypes.TINYINT,
    allowNull: true,
    defaultValue: 1,
  },
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  underscored: true, // Converts camelCase to snake_case in the DB
  tableName: 'mstr_businessunits', // Explicit table name, adjust if needed
  charset: 'utf8mb4', // Support for emojis and special characters
  collate: 'utf8mb4_general_ci'
});

module.exports = BusinessUnit;
