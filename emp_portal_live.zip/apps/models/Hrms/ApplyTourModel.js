const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const ApplyTours = sequelize.define('hrms_apply_tour', {
    id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    emp_id: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
        comment: 'Employee ID',
    },
    project_id: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
        comment: 'Project ID',
    },
    week_no: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
        comment: 'Week Number',
    },
    year_week: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
        comment: 'Year and Week',
    },
    month_no: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
        comment: 'Month Number',
    },
    Year: {
        type: DataTypes.DOUBLE,
        allowNull: true,
        defaultValue: null,
        comment: 'Year',
    },
    start_date: {
        type: DataTypes.DATE,
        allowNull: false,
        comment: 'Start Date of the tour',
    },
    end_date: {
        type: DataTypes.DATE,
        allowNull: false,
        comment: 'End Date of the tour',
    },
    tour_location: {
        type: DataTypes.STRING(500),
        allowNull: true,
        defaultValue: null,
        comment: 'Tour Location',
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null,
        comment: 'Description of the tour',
    },
    rejected_notes: {
        type: DataTypes.STRING(500),
        allowNull: true,
        defaultValue: null,
        comment: 'Rejected Notes for the tour',
    },
    approved_bypmanager: {
        type: DataTypes.ENUM('0', '1', '2'),
        allowNull: false,
        defaultValue: '0',
        comment: 'Approval status by Project Manager',
    },
    approved_bylmanager: {
        type: DataTypes.ENUM('0', '1', '2'),
        allowNull: false,
        defaultValue: '0',
        comment: 'Approval status by Line Manager',
    },
    applyed_assets_id: {
        type: DataTypes.STRING(150),
        allowNull: true,
        defaultValue: null,
        comment: 'Applied assets ID for the tour',
    },
    applyed_ticked_id: {
        type: DataTypes.STRING(150),
        allowNull: true,
        defaultValue: null,
        comment: 'Applied ticket ID for the tour',
    },
    is_active: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
        comment: 'Tour status (active or inactive)',
    },
    created_by: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
        comment: 'ID of the user who created the record',
    },
    tour_type: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
        comment: 'Type of the tour (1-general, 2-sort-tour)',
    },
    expected_out_time: {
        type: DataTypes.STRING(55),
        allowNull: true,
        defaultValue: null,
        comment: 'Expected out time of the tour',
    },
    created_date: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
        comment: 'Timestamp of creation',
    },
}, {
    tableName: 'hrms_apply_tour',
    timestamps: false
});

module.exports = ApplyTours;
