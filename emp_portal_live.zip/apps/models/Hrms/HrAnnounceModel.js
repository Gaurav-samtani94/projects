const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const HRAnnounce = sequelize.define('hrms_hr_announce', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    announcement_title: {
        type: DataTypes.STRING(100),
        allowNull: false,
        defaultValue: null,
        comment: 'Title of the announcement (e.g., Public Holiday, Company Event)'
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
        defaultValue: null,
        comment: 'Details about the announcement'
    },
    announcement_type: {
        type: DataTypes.ENUM,
        values: ['Holiday', 'Event', 'Closure', 'Other'],
        allowNull: false,
        defaultValue: 'Holiday',
        comment: 'Type of announcement'
    },
    announcement_date: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: null,
        comment: 'Date of the announced event/holiday'
    },
    end_date: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
        comment: 'End date if the announcement spans multiple days'
    },
    is_full_day: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: '1-full day, 0-half day'
    },
    createdby: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null,
        comment: 'ID of the HR/admin who created the announcement'
    },
    modifiedby: {
        type: DataTypes.INTEGER,
        unsigned: true,
        allowNull: true,
        defaultValue: null,
        comment: 'ID of the HR/admin who modified the announcement'
    },
    createddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
    },
    modifieddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
    },
    isactive: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: '1-active, 0-inactive'
    },
});


module.exports = HRAnnounce;