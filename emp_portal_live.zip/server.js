require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const userRoutes = require("./apps/routes/tracker/userRoutes");
const ActivityRoutes = require("./apps/routes/tracker/ActivityRoutes");
const MasterRoute = require("./apps/routes/Master/MasterRoute");
const HrmsRoute = require("./apps/routes/Hrms/route");
const chatRoutes = require("./apps/routes/ChatModuleRoute/route");
const pmtRoute = require("./apps/routes/Pmt/routes");
const meetingRoute = require("./apps/routes/Meeting/routes");
const LiveKitRoute = require("./apps/routes/Livekit/LivekitRoute");
const { protect } = require("./apps/middleware/authMiddleware");
const logger = require("./apps/utils/logger");
const bodyParser = require("body-parser");
const http = require("http");
const { Op } = require("sequelize");
const socketIo = require("socket.io");
const app = express();
const cors = require("cors");
const path = require("path");
const TaskComment = require("./apps/models/Project_management/TaskCommentModel");
const ProjectsModel = require("./apps/models/Project_management/ProjectsModel");
const ProjectTaskModel = require("./apps/models/Project_management/ProjectTaskModel");
const Arrangementsgroupmodel = require("./apps/models/ChatModule/ChatUserOrder");
const Message = require("./apps/models/ChatModule/message");
const User = require("./apps/models/tracker/user/User");
const Chat = require("./apps/models/ChatModule/chat");
const ProjectComment = require("./apps/models/Project_management/ProjectCommentModel");
const NotificationHistory = require("./apps/models/Project_management/NotificationHistoryModel");
const getCurrentDateTime = () => new Date();
app.use("/uploads", express.static("./uploads"));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(helmet());
app.use(logger);
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(helmet());
app.use(logger);
const server = http.createServer(app);
// local server port
const port = process.env.PORT || 3536;
app.set("views", path.join(__dirname, "./apps/resources/views"));

app.set("view engine", "ejs");

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        formAction: ["'self'", "https://staging-emp.growthgrids.com"],
        connectSrc: ["'self'", "https://staging-emp.growthgrids.com"], // ✅ Allow API calls to backend
      },
    },
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/user", userRoutes);
app.use("/api/user/activity", ActivityRoutes);
app.use("/api/chats", protect, chatRoutes);
app.use("/api/pmt", protect, pmtRoute);
app.use("/api/livekit", LiveKitRoute);
app.use("/api/meeting", meetingRoute);
app.use("/api/master", MasterRoute);
app.use("/api/hrms", HrmsRoute);

const io = socketIo(server, {
  cors: {
    origin: "*",
  },
});

app.get("/", (req, res) => {
  return res.json({ message: "Welcome" });
});

app.use((req, res) => {
  return res.status(400).json({ message: "Invalid url" });
});

const onlineUsers = new Map(); // userId => socketId

io.on("connection", (socket) => {
  console.log(`🔌 Client connected socket: ${socket.id}`);
  // User ID ko handshake query se lo
  const userId = socket.handshake.query.user_id;
  socket.userId = userId; // Socket pe userId set karo
  console.log(`✅ User Connected: ${userId} (Socket ID: ${socket.id})`);

  //============ online/offline check =======================================
  onlineUsers.set(userId, socket.id);
  socket.on("userStatus", (data) => {
    const { userId, chat_status, status } = data;

    if (!userId || !chat_status || !status) {
      console.log("Invalid data in sendMessage:", data);
      return;
    }
    io.emit("online-users", Array.from(onlineUsers.keys()));
  });

  // Sabko user connection ka event bhejo
  io.emit("user-connected", { userId, socketId: socket.id });

  socket.on("sendMessage", async (data) => {
    try {
      const {
        receiverId,
        sender_Id,
        message,
        name,
        isReply,
        isForward,
        chat_id,
        chat_type,
        groupId,
        groupName,
      } = data;

      // Validation check
      if (!receiverId || !message) {
        console.error("Receiver ID and message are required.");
        return;
      }

      // Fetching active users excluding the sender
      const user_details_rec = await User.findAll({
        where: {
          id: {
            [Op.ne]: sender_Id,
          },
          isactive: "1",
        },
        attributes: ["id"],
      });

      if (user_details_rec.length > 0) {
        const userIds = user_details_rec.map((user) => user.id);

        // Preparing bulk create data for Arrangementsgroupmodel
        const arrangements = userIds.flatMap((user_id) => [
          {
            from_user_id: sender_Id,
            to_user_id: receiverId,
            created_by: sender_Id,
            created_at: new Date(),
          },
          {
            from_user_id: receiverId,
            to_user_id: sender_Id,
            created_by: receiverId,
            created_at: new Date(),
          },
        ]);

        // Bulk create missing arrangements (ignore duplicates)
        await Arrangementsgroupmodel.bulkCreate(arrangements, {
          ignoreDuplicates: true,
        });

        // Bulk update for both directions (Sender -> Receiver & Receiver -> Sender)
        await Arrangementsgroupmodel.update(
          {
            updated_at: getCurrentDateTime(),
            updated_by: sender_Id,
          },
          {
            where: {
              [Op.or]: [
                { from_user_id: sender_Id, to_user_id: receiverId },
                { from_user_id: receiverId, to_user_id: sender_Id },
              ],
              status: "1",
            },
          }
        );
        console.log("Arrangements updated successfully.");
      }

      // Emitting the message as a notification to the specific receiver
      io.emit("notification", {
        type: "message",
        message,
        from: sender_Id,
        to: receiverId,
        sender_Id,
        name,
        isReply,
        isForward,
        chat_id,
        chat_type,
        groupId,
        groupName,
      });
      console.log(
        `Sent notification to ${receiverId} from sender ${sender_Id}`
      );
    } catch (error) {
      console.error("Error in sendMessage:", error.message);
    }
  });


  // CallUser event (specific receiver ko)
  socket.on("callUser", (data) => {
    console.log("Received callUser event:", data);
    const {
      receiverId,
      senderId,
      callType,
      name,
      roomname,
      token,
      chat_type,
      groupId,
      memberIds,
    } = data;
    if (!receiverId || !callType) {
      console.log("Invalid data in callUser:", data);
      return;
    }
    io.emit("call-notification", {
      type: callType,
      from: socket.userId,
      senderId: senderId,
      to: receiverId,
      name: name,
      token: token,
      chat_type: chat_type,
      roomname: roomname,
      memberIds: memberIds,
      groupId: groupId,
    });
    console.log(`Sent call notification to ${name}`);
  });

  // Call accept hone pe
  socket.on("callAccepted", (data) => {
    console.log("Received callAccepted event:", data);
    const { senderId, groupId, chat_type } = data;
    if (!senderId) {
      console.log("Invalid data in callAccepted:", data);
      return;
    }
    // Caller ko bataye ki call accept ho gaya
    io.emit("call-accepted", {
      receiverId: socket.userId,
      senderId: senderId,
      groupId: groupId,
      chat_type: chat_type,
    });
    console.log(`Notified ${senderId} that call was accepted`);
  });

  // Call end hone pe
  socket.on("callEnded", (data) => {
    console.log("Received callEnded event:", data);
    const { callerId, chat_type, sendercallId } = data;
    console.log(data, "data");
    if (!callerId) {
      console.log("Invalid data or callId in callEnded:", data);
      return;
    }

    // Caller ko duration bhejo
    io.emit("call-ended", {
      receiverId: socket.userId,
      callerId: callerId,
      chat_type: chat_type,
      sendercallId: sendercallId,
    });
    console.log(`Call ended, notified ${callerId}`);
  });

  socket.on("StartAudioCall", (data) => {
    console.log("Receive audio call id", data);
    const { audioCallerId } = data;
    console.log(audioCallerId, "audioCallerId");
    if (!audioCallerId) {
      console.log("Invalid data or callId in audioCallerId:", data);
      return;
    }

    io.emit("start-audio-Call", {
      id: audioCallerId,
    });
    console.log(`Start Audio call`);
  });

  socket.on("rejoinStart", (data = null) => {
    io.emit("rejoin-start", { data: data });
    console.log(`log the rejion call data ${data}`);
  });

  socket.on("rejoinEnd", (data = null) => {
    io.emit("rejoin-end", { data: data });
    console.log(`Notified ${data} for rejoin end event `);
  });

  //==============================================================================//
  //=============================== TASK COMMENTS ================================//
  //==============================================================================//


  socket.on("task_comment", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;
    const {
      task_id,
      parent_comment_id,
      comment_text,
      ping_users_ids,
      project_id,
      parent_task_id,
      from_user_id,
      isDeleted,
      comment_id,
      isUpdate
    } = parsedData;

    if (!task_id || !comment_text) {
      console.log("Invalid Comment:", data);
      return;
    }

    if (isDeleted == "1") {

      const updateComment = await TaskComment.update(
        {
          status: "0",
        },
        {
          where: {
            id: comment_id,
          },
        }
      );
      if (updateComment) {
        io.emit(task_id, {
          status: 1,
          error: false,
          message: "Comment Deleted Successfully",
          task_id: task_id
        });
        console.log(`Comment Deleted Successfully ${comment_text}`);
      }

    } else if (isUpdate == "1") {

      const updateComment = await TaskComment.update(
        {
          comment_text: comment_text,
        },
        {
          where: {
            id: comment_id,
          },
        }
      );

      if (updateComment) {
        io.emit(task_id, {
          status: 0,
          error: true,
          message: "Comment Updated Successfully",
          task_id: task_id
        });
        console.log(`Comment on Task Updated Successfully ${comment_text}`);
      }
    } else {
      const newObj = {
        parent_task_id: parent_task_id,
        parent_id: parent_comment_id,
        project_id: project_id,
        tag_user_ids: ping_users_ids,
        task_id: task_id,
        comment_text: comment_text,
        created_by: from_user_id,
      };

      const addComment = await TaskComment.create(newObj);
      if (addComment) {
        io.emit(task_id, data);
        console.log(`Sent Comment Successfully ${comment_text}`);
      }

    }
  });

  socket.on("project_comment", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;

    
    const {
      comment_text,
      ping_users_ids,
      project_id,
      parent_proj_cmnt_id,
      from_user_id,
      isDeleted,
      comment_id,
      isUpdate
    } = parsedData;

    if (!project_id || !comment_text) {
      console.log("Invalid Comment:", data);
      return;
    }

    if (isDeleted == "1") {

      const deleteComment = await ProjectComment.update(
        {
          status: "0",
        },
        {
          where: {
            id: comment_id,
          },
        }
      );
      if (deleteComment) {
        io.emit(project_id, {
          status: 1,
          error: false,
          message: "Comment Deleted Successfully",
          project_id: project_id
        });
        console.log(`Comment on Project Deleted Successfully ${comment_text}`);
      }


    } else if (isUpdate == "1") {

      const updateComment = await ProjectComment.update(
        {
          comment_text: comment_text,
        },
        {
          where: {
            id: comment_id,
          },
        }
      );

      if (updateComment) {
        io.emit(project_id, {
          status: 1,
          error: false,
          message: "Comment Updated Successfully",
          project_id: project_id
        });
        console.log(`Comment Updated Successfully ${comment_text}`);
      }
    } else {
      // io.emit(26, data);

      const newObj = {
        parent_id: parent_proj_cmnt_id,
        project_id: project_id,
        tag_user_ids: ping_users_ids,
        comment_text: comment_text,
        created_by: from_user_id,
      };

      const addComment = await ProjectComment.create(newObj);
      if (addComment) {
        // data.comment_type = "project comment";
        io.emit(project_id, data);
        console.log(`Sent Comment Successfully ${comment_text}`);
      }

    }
  });

  //============================ PROJECT COMMEND CODE END HERE ==================================

  //======================= ALL NOTIFICATIONS CODE START===============================

  socket.on("task_assign_notification", (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;

    const { user_ids, task_id } = parsedData;

    if (!task_id || !user_ids) {
      console.log("Invalid data received for Task Assign Notification Event");
      return;
    }

    const userIdArray = user_ids.split(",").map((id) => id.trim());

    userIdArray.forEach(async (userId) => {
      const socketId = onlineUsers.get(userId);
      if (socketId) {
        insertObj = {
          user_id: userId,
          title: "Project Update",
          description: "The project has been updated. Please check the latest changes.",
          created_by: userId,
        };

        const addNotification = await NotificationHistory.create(insertObj);
        if (addNotification) {
          io.to(socketId).emit("task-notification", {
            status: 1,
            error: false,
            notification_data: addNotification,
          });
        } else {
          console.log("Error in adding notification.");
        }

      } else {
        console.log(`User ${userId} is offline. Task notification skipped.`);
      }
    });
  });



  //Comment Reply/ Mention in comment

  socket.on("comment", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;
    const { comment_by_user, mention_ids, reply_to_user_id } = parsedData;

    if (!comment_by_user && !(typeof (comment_by_user) == Number)) {
      console.log('Invalid commentator user id')
      return
    }

    const commentatorDetails = await User.findOne({
      where: {
        id: comment_by_user
      },
      attributes: ['id', 'firstname', 'lastname']
    })

    if (!commentatorDetails) {
      console.log('Invalid commentator')
      return
    }

    const commentatorName = commentatorDetails.firstname + " " + commentatorDetails.lastname


    if (mention_ids) {
      const userIdArray = mention_ids.split(",").map((id) => id.trim());

      const totalMentions = userIdArray.length + (reply_to_user_id ? 1 : 0);

      console.log(totalMentions, userIdArray.length, reply_to_user_id, 'is total mentions')

      const description = totalMentions > 1
        ?
        `${commentatorName} mentioned you and ${totalMentions - 1} others.`
        :
        `${commentatorName} mentioned you in a comment.`

      userIdArray.forEach(async (userId) => {
        const socketId = onlineUsers.get(userId);
        if (socketId) {
          const insertObj = {
            user_id: userId,
            title: "New mention",
            description: description,
            created_by: userId,
          };


          const addNotification = await NotificationHistory.create(insertObj);
          if (addNotification) {
            io.to(socketId).emit("new-comment", {
              status: 1,
              error: false,
              notification_data: addNotification,
            });
          } else {
            console.log("Error in adding notification.");
          }

        } else {
          console.log(`User ${userId} is offline. Task notification skipped.`);
        }
      });
    }
    if (reply_to_user_id && typeof (reply_to_user_id == Number)) {
      const socketId = onlineUsers.get(reply_to_user_id);
      if (socketId) {
        const insertObj = {
          user_id: reply_to_user_id,
          title: "New mention",
          description: `${commentatorName} replied to your comment`,
          created_by: reply_to_user_id,
        };


        const addNotification = await NotificationHistory.create(insertObj);
        if (addNotification) {
          io.to(socketId).emit("new-comment", {
            status: 1,
            error: false,
            notification_data: addNotification,
          });
        } else {
          console.log("Error in adding notification.");
        }

      } else {
        console.log(`User ${reply_to_user_id} is offline. Task notification skipped.`);
      }
    } else {
      console.log(reply_to_user_id, 'is reply to user id received')
    }



  });

  //END comment reply/mention




  //-----Add/Remove Member from Project!

   socket.on("member-update", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;
    const {  added_ids, removed_ids, project_id } = parsedData;

    if (!project_id && !(typeof (project_id) == Number)) {
      console.log('Invalid Project id')
      return
    }

    const ProjectDetails = await ProjectsModel.findOne({
      where: {
        id: project_id
      }
    })

    if(!ProjectDetails){
      console.log('Project Not found')
      return
    }

    const ProjectName = ProjectDetails.project_name



    if (added_ids) {
      const userIdArray = added_ids.split(",").map((id) => id.trim());

      userIdArray.forEach(async (userId) => {
        const socketId = onlineUsers.get(userId);
        if (socketId) {
          const insertObj = {
            user_id: userId,
            title: "Added to Project.",
            description: `You have been added to a project - ${ProjectName}`,
            created_by: userId,
          };


          const addNotification = await NotificationHistory.create(insertObj);
          if (addNotification) {
            io.to(socketId).emit("member-update", {
              status: 1,
              error: false,
              notification_data: addNotification,
            });
          } else {
            console.log("Error in adding notification.");
          }

        } else {
          console.log(`User ${userId} is offline. Task notification skipped.`);
        }
      });
    }

     if (removed_ids) {
      const userIdArray = removed_ids.split(",").map((id) => id.trim());

      userIdArray.forEach(async (userId) => {
        const socketId = onlineUsers.get(userId);
        if (socketId) {
          const insertObj = {
            user_id: userId,
            title: "Removed from Project.",
            description: `You have been Remove from the Project - ${ProjectName} `,
            created_by: userId,
          };


          const addNotification = await NotificationHistory.create(insertObj);
          if (addNotification) {
            io.to(socketId).emit("member-update", {
              status: 1,
              error: false,
              notification_data: addNotification,
            });
          } else {
            console.log("Error in adding notification.");
          }

        } else {
          console.log(`User ${userId} is offline. Task notification skipped.`);
        }
      });
    }
  

  });



  //


  //---------------------------------CREATE PROJECT--------------------------------------------

  socket.on("project", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;

    const { project_id, user_ids, is_project } = parsedData;

    if (!user_ids || !project_id) {
      console.log("Invalid data received for Project Notification Event");
      return;
    }

    if (!is_project) {
      console.log("Notification type (create/update) not specified");
      return;
    }

    const userIdArray = user_ids.split(",").map((id) => id.trim());

    const projectDetails = await ProjectsModel.findOne({
      where: { id: project_id, status: "1" },
    });

    if (!projectDetails) {
      console.log("Project not found or inactive");
      return;
    }

    for (const userId of userIdArray) {
      let insertObj;

      if (is_project === "create") {
        insertObj = {
          user_id: userId,
          title: "You are added to Created Project",
          description: `${projectDetails.project_name} project created! You are added to this project.`,
          created_by: userId,
        };
      } else if (is_project === "update") {
        insertObj = {
          user_id: userId,
          title: "Project Update",
          description: "The project has been updated. Please check the latest changes.",
          created_by: userId,
        };
      }

      const addNotification = await NotificationHistory.create(insertObj);

      const socketId = onlineUsers.get(userId);
      if (socketId && addNotification) {
        io.to(socketId).emit("project-notification", {
          status: 1,
          error: false,
          notification_data: addNotification,
        });
      } else {
        console.log(`User ${userId} is offline or notification failed`);
      }
    }
  });


  // socket.on("project", async(data) => {
  //   const { project_id, user_ids, is_project } = data;
  //   if (!user_ids, !project_id) {
  //     console.log("Invalid data received for Create Project Notification Event");
  //     return;
  //   }

  //   if(!is_project){
  //     console.log("Notification for CREATE OR UPDATE is not defined");
  //     return;
  //   }

  //   const userIdArray = user_ids.split(",").map(id => id.trim());

  //   const projectDetails = await ProjectsModel.findOne({
  //     where:{
  //       id:project_id,
  //       status:"1"
  //     }
  //   });

  //   userIdArray.forEach(async (userId) => {
  //     let insertObj;
  //     if(is_project == "create"){
  //         insertObj = {
  //         user_id: userId,
  //         title: "You are added to Created Project",
  //         description: projectDetails.project_name + " project created! you are added on this project",
  //         created_by: userId,
  //       };
  //     } else if(is_project == "update") {
  //         insertObj = {
  //           user_id: userId,
  //           title: "Project Update",
  //           description: "The project has been updated with new requirements. Check the latest changes.",
  //           created_by: userId,
  //         };
  //     }

  //     const addNotification = await NotificationHistory.create(insertObj);
  //     if(addNotification){
  //       io.emit(userId, {status:1,error:false,notification_data:addNotification});
  //     }
  //   });
  // });


  //------------------------------UPDATE PROJECT LEAD-----------------------------------------------

  socket.on("project_lead_update", async (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;

    const { project_id, project_lead_ids } = parsedData;
    if (!project_lead_ids, !project_id) {
      console.log("Invalid data received for Create Project Notification Event");
      return;
    }

    const userIdArray = project_lead_ids.split(",").map(id => id.trim());

    const projectDetails = await ProjectsModel.findOne({
      where: {
        id: project_id,
        status: "1"
      }
    });

    userIdArray.forEach(async (userId) => {
      const insertObj = {
        user_id: userId,
        title: "Project Lead Assigned",
        description: "You are assigned as PROJECT LEAD in " + projectDetails.project_name + "project",
        created_by: userId,
      };
      const addNotification = await NotificationHistory.create(insertObj);

      const socketId = onlineUsers.get(userId);
      if (socketId && addNotification) {
        io.to(socketId).emit("project-lead-notification", {
          status: 1,
          error: false,
          notification_data: addNotification,
        });
      } else {
        console.log(`User ${userId} is offline or notification failed`);
      }

      // if(addNotification){
      //   io.emit(userId, {status:1,error:false,notification_data:addNotification});
      // }
    });
  });

  socket.on("task_update", (data) => {
    const parsedData = typeof data === "string" ? JSON.parse(data) : data;

    const { user_ids, task_id } = parsedData;

    if (!task_id || !user_ids) {
      console.log("Invalid data received for Task Update Notification Event");
      return;
    }

    const userIdArray = user_ids.split(",").map((id) => id.trim());

    userIdArray.forEach((userId) => {
      const socketId = onlineUsers.get(userId);
      if (socketId) {
        io.to(socketId).emit("task-update-notification", {
          message: `${process.env.TASKUPDATENOTIFY}  #${task_id}`,
        });
      } else {
        console.log(`User ${userId} is offline. Task notification skipped.`);
      }
    });
  });


  //=================== ALL NOTIFICATION CODE END ===============================

  socket.on("messageDelivered", (data) => {
    
    const { msg_id } = data;

    console.log(data, "is data", msg_id, "is msg id");

    if (!msg_id) {
      console.log("Invalid data received for messageDelivered Event");
      return;
    }
    io.emit("message-delivered", msg_id);
  });

  // Server emits when read
  socket.on("messageRead", (data) => {
    const { msg_id } = data;
    if (!msg_id) {
      console.log("Invalid data received for messageRead Event");
      return;
    }
    io.emit("message-read", msg_id);
  });

  socket.on("typing", (data) => {
    if (!data || typeof data !== "object") {
      console.log("Invalid data received for typing event");
      return;
    }
    io.emit("typingStatus", {
      data: data,
    });
  });

  socket.on("stop-typing", (data) => {
    if (!data || typeof data !== "object") {
      console.log("Invalid data received for typingstop event");
      return;
    }
    io.emit("typingStatus", {
      data: data,
    });
  });

  socket.on("disconnect", () => {
    onlineUsers.delete(socket.userId);
    // io.emit("online-users", { userId: socket.userId, chat_status: "offline", status:0 });
    io.emit("online-users", Array.from(onlineUsers.keys()));
    console.log(`❌ Client disconnected: ${(socket.id, "id", socket.userId)}`);
  });
});

//========================================================================================

// Create a models object for reference
const models = {
  ProjectsModel,
  ProjectTaskModel,
};

// Call associate methods manually
if (ProjectsModel.associate) {
  ProjectsModel.associate(models);
}
if (ProjectTaskModel.associate) {
  ProjectTaskModel.associate(models);
}

//=========================================================================================

server.listen(port, () => console.log(`App is running on port ${port}`));
