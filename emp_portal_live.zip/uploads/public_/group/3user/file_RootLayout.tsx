import Footer from './Footer'
// import Header from './Header'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import WindowHeader from './WindowHeader'
import useAuthStore from 'renderer/store/AuthStore'
import { useEffect, useMemo, useState } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ThemeProvider } from './theme-provider'
import { AppSidebar } from './AppSideMenu';
import { Toaster } from 'sonner'
import { useActivityLogStore, useSystemStatusStore } from 'renderer/store/LoggingStore'
import { useChatStore, usePageStore } from 'stores/useChatStore'
import ChatController from 'renderer/Controller/ChatController'
import { createGroupRoom, createRoom, getToken } from 'renderer/service/connectServices'
import { startCall, startCallGroup } from 'renderer/service/authService'


const RootLayout = () => {
  const { App } = window
  const pathname = useLocation().pathname
  const navigate = useNavigate()
  const { selectedUser, chatInfo, selectedToken, selectGroup, callFlag, selectCallerInfo, selectGroupID, group_UserId, setSelectedUser, setChatInfo, setSelectedToken, setSelectGroup, setSelectGroupCallActive, setSelectCallerInfo } = useChatStore();
  const { isAuthenticated } = useAuthStore()
  const { setPageCount } = usePageStore();
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const addLog = useActivityLogStore((state) => state.addActivityLog);
  const replaceLog = useActivityLogStore((state) => state.replaceActivityLog);
  const replaceSytemLog = useSystemStatusStore((state) => state.replaceSystemLog);
  const addSytemLog = useSystemStatusStore((state) => state.setSystemStatus);
  const systemLog = useSystemStatusStore((state) => state.systemStatus);
  const getActivityLog = useActivityLogStore((state) => state.activityLog);
  const getSystemLog = useSystemStatusStore((state) => state.systemStatus);
  const [isAduioCall, setisAduioCall] = useState<any>(null);
  const [incomingCall, setIncomingCall] = useState<any>(null);
  const ResUser = useAuthStore.getState().getUser();

  console.log("getActivityLog from zustand", getActivityLog)
  console.log("systemLog from zustand", systemLog)
  const activityWindow = async () => {
    const activityLog = await App.activityLog()
    const systemLog = await App.systemLog()
    console.log('Activity log:', (activityLog));
    console.log('system log:', (systemLog));
    replaceSytemLog(systemLog);
    replaceLog(activityLog);
  }
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login')
    }
  }, [isAuthenticated, navigate])

  useEffect(() => {
    activityWindow()
    const listener = (_event: any, activity: any, action: any) => {
      if (action === 'new') {
        replaceLog(activity)
      } else {
        addLog(activity)
      }
    };
    const systemListener = (_event: any, status: any) => {
      replaceSytemLog(status);
    };

    App.currentActivity(listener);
    App.currentStatus(systemListener);
    return () => {
      App.clearCurrentListener();
      App.clearSystemListener();
    };
  }, []);

  useEffect(() => {
    SocketHandle()
  }, [])



  const queryClient = useMemo(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            retry: 0,
          },
          mutations: {
            retry: 0,
          },
        },
      }),
    []
  )

  const SocketHandle = async () => {
    let socket: any;

    const handleCallNotification = (data: any) => {
      const latestSelectGroupID = useChatStore.getState().selectGroupID;
      if (data.chat_type === 'Group') {
        if (data.to !== Number(ResUser?.id)) {
          if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) {
            return;
          }
          if (latestSelectGroupID.includes(Number(data.groupId))) {
            setIncomingCall(data);
            setisAduioCall(false)
          }
        }

      } else {
        if (data.to === String(ResUser?.id)) {
          setIncomingCall(data);
          setisAduioCall(false)
        }
      }

    }
    const handleCallEndedNotification = async (data: any) => {
      setIncomingCall(null);
      setSelectCallerInfo(null)
    };

    const handleRejionNotification = async (RejionNotification: any) => {
      if (!selectCallerInfo) {
        setSelectCallerInfo(RejionNotification.data)
      }
    };
    const handleRejionEndNotification = async (RejionNotification: any) => {
      if (selectCallerInfo) {
        setSelectCallerInfo('')
      }
    };

    const setupListeners = () => {
      socket = ChatController.getSocket();
      if (!socket) return;
      socket.on("rejoin-start", handleRejionNotification)
      socket.on("rejoin-end", handleRejionEndNotification)
      socket.on("call-notification", handleCallNotification)
      socket.on("call-ended", handleCallEndedNotification);

    };
    const cleanupListeners = () => {
      if (!socket) return;
      socket.off("rejoin-start", handleRejionNotification)
      socket.off("rejoin-end", handleRejionEndNotification)
      socket.off("call-notification", handleCallNotification)
      socket.off("call-ended", handleCallEndedNotification);


    };

    const waitForSocketReady = () => {
      return new Promise<void>((resolve) => {
        if (ChatController.isSocketConnected === 1) return resolve();

        const interval = setInterval(() => {
          if (ChatController.isSocketConnected === 1) {
            clearInterval(interval);
            resolve();
          }
        }, 300);
      });
    };
    await waitForSocketReady();
    setupListeners();
    return () => {
      cleanupListeners();
    };
  }
  const handleAcceptCall = (callData: any) => {
    if (!callData) return;
    const isVideo = callData?.type === 'video';
    const isUserCall = callData?.chat_type === 'User';
    const isGroupCall = callData?.chat_type === 'Group';
    if (isVideo) {
      if (isUserCall) {
        if (selectedUser && callData.from === String(selectedUser.id)) {
          console.log('callAccepted====>>')
          navigate('/connect/RoomMeeting', { state: { token: selectedToken, selectedUser: callData } });
          handleCall("1", callData);
        } else {
          UserConnectChatVideo(callData);
        }
      } else if (isGroupCall) {
        if (selectGroup && callData.groupId === selectGroup.groupId) {
          navigate('/connect/RoomGroupMeeting', { state: { token: selectedToken, selectedUser: callData } });
          handleCall("1", callData);
        } else {
          GroupConnectChatVideo(callData);
        }
      }
    } else {
      if (isUserCall) {
        if (selectedUser && callData.from === String(selectedUser.id)) {
          setIncomingCall(null);
          const data = {
            senderId: String(callData.from),
          }
          ChatController.callbackSocket('callAccepted', data)
          navigate('/connect/AudioMeeting', {
            state: {
              token: selectedToken,
              selectedUser: callData,
              screenType: 'ChatLayout',
            },
          });
        } else {
          UserConnectChat(callData);
        }
      } else if (isGroupCall) {
        if (selectGroup && callData.groupId === selectGroup.groupId) {
          setIncomingCall(null);
          const data = {
            senderId: String(callData.from),
            groupId: callData.groupId,
            chat_type: 'Group'
          }
          ChatController.callbackSocket('callAccepted', data)
          navigate('/connect/AudioGroupMeeting', { state: { token: selectedToken, selectedUser: callData, screenType: 'ChatLayout' } })
        }
        else {
          UserConnectGroupChat(callData)
        }

        setSelectGroupCallActive(callData);
      }
    }
  };

  const handleDeclineCall = (callData: any) => {
    setIncomingCall(null);
    if (selectGroup === 'User') {
      const data = {
        callerId: String(callData.from),
        chat_type: selectGroup ? 'Group' : 'User'
      }
      ChatController.callbackSocket('callEnded', data)
    }

  };

  const UserConnectChat = async (CallUser: any) => {
    try {

      if (!ResUser?.id || !CallUser?.from) {
        console.warn("User IDs missing, cannot create room");
        return;
      }
      const createRoomPayload = {
        fromUserId: ResUser.id,
        toUserId: CallUser.from,
      };

      const roomResponse = await createRoom(
        createRoomPayload.fromUserId,
        createRoomPayload.toUserId
      );
      setPageCount(1);
      setSelectedUser(CallUser ?? selectedUser);
      setChatInfo(roomResponse.chat);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.userfullname,
          userId: CallUser.senderId || selectedUser.id,
          metadata: JSON.stringify({
            callerId: CallUser.id,
            callerName: ResUser.userfullname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('0', CallUser)
        setIncomingCall(null);
        const data = {
          senderId: String(CallUser.from),
          groupId: '',
          chat_type: 'User'

        }
        ChatController.callbackSocket('callAccepted', data)
        navigate('/connect/AudioMeeting', { state: { token: tokenRes.token, selectedUser: CallUser, screenType: 'ChatLayout' } })

      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }
  };
  const UserConnectChatVideo = async (CallUser: any) => {
    try {
      if (!ResUser?.id || !CallUser?.from) {
        console.warn("User IDs missing, cannot create room");
        return;
      }
      const createRoomPayload = {
        fromUserId: ResUser.id,
        toUserId: CallUser.from,
      };

      const roomResponse = await createRoom(
        createRoomPayload.fromUserId,
        createRoomPayload.toUserId
      );
      setPageCount(1);
      setSelectedUser(selectedUser);
      setChatInfo(roomResponse.chat);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.userfullname,
          userId: ResUser.id,
          metadata: JSON.stringify({
            callerId: CallUser.id,
            callerName: ResUser.userfullname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('1', CallUser)
        setIncomingCall(null);
        const data = {
          senderId: String(CallUser.from),
          groupId: '',
          chat_type: 'User'
        }
        ChatController.callbackSocket('callAccepted', data)
        await navigate('/connect/RoomMeeting', { state: { token: tokenRes.token, selectedUser: CallUser } })
      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }
  }

  const UserConnectGroupChat = async (CallGroup: any) => {
    try {
      if (!ResUser?.id) {
        return;
      }

      const createRoomPayload = {
        userIds: CallGroup.memberIds,
        groupId: CallGroup.groupId,
      };

      const roomResponse = await createGroupRoom(
        createRoomPayload.groupId,
        createRoomPayload.userIds
      );
      setPageCount(1);
      setSelectGroup(CallGroup);

      setChatInfo(CallGroup);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.userfullname,
          userId: ResUser?.id,
          metadata: JSON.stringify({
            callerId: ResUser?.id,
            callerName: ResUser.userfullname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        setIncomingCall(null);
        const data = {
          senderId: String(CallGroup.from),
          groupId: CallGroup.groupId,
          chat_type: 'Group'
        }
        ChatController.callbackSocket('callAccepted', data)
        await navigate('/connect/AudioGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup, screenType: 'ChatLayout' } })
      }
    } catch (err) {
    }

  }
  const GroupConnectChatVideo = async (CallGroup: any) => {
    try {
      if (!ResUser?.id) {
        return;
      }

      const createRoomPayload = {
        userIds: CallGroup.memberIds,
        groupId: CallGroup.groupId,
      };

      const roomResponse = await createGroupRoom(
        createRoomPayload.groupId,
        createRoomPayload.userIds
      );
      setPageCount(1);
      setSelectGroup(CallGroup);

      setChatInfo(CallGroup);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.userfullname,
          userId: ResUser?.id,
          metadata: JSON.stringify({
            callerId: CallGroup.groupId,
            callerName: ResUser.userfullname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('1', CallGroup)
        setIncomingCall(null);
        const data = {
          senderId: String(CallGroup.from),
          groupId: CallGroup.groupId,
          chat_type: 'Group'

        }
        ChatController.callbackSocket('callAccepted', data)
        await navigate('/connect/RoomGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup } })

      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }

  }

  const handleCall = async (call_types: any, callData: any) => {
    if (callData.chat_type === "Group") {
      const response = await startCallGroup({ group_id: callData?.groupId, caller_id: String(callData?.senderId) || "", call_type: call_types });
      if (response?.data) {
        setSelectCallerInfo(response.data)
        ChatController.callbackSocket('StartAudioCall', {
          audioCallerId: response.data.id,
        });
        setIncomingCall(null);
      }
    } else {
      const response = await startCall({ chat_id: chatInfo?.id, caller_id: callData?.senderId || "", call_type: call_types });
      if (response?.data) {
        setSelectCallerInfo(response.data)
        ChatController.callbackSocket('StartAudioCall', {
          audioCallerId: response.data.id,
        });
        setIncomingCall(null);
      }

    }
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <div className="flex flex-col min-h-screen bg-background">
          <WindowHeader />

          <div className="flex items-start w-full">
            <div
              className="sticky top-10 h-[calc(100vh-68px)] inset-y-0 z-20 transform transition duration-200 ease-in-out"
            >
              {pathname !== '/login' && <AppSidebar />}
            </div>

            <main className="flex-grow w-1/2 flex flex-col h-full">
              <Outlet />
            </main>
          </div>
          {pathname !== '/login' && <Footer />}
          <Toaster richColors={true} />
          {incomingCall && (
            <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-40 flex items-center justify-center z-50">
              <div className="bg-white rounded-2xl shadow-xl p-6 w-[300px] text-center">
                <h2 className="text-xl font-semibold mb-4">📞 Incoming Call</h2>
                <p className="mb-6">{incomingCall.name || 'Unknown User'} is calling...</p>
                <div className="flex justify-around">
                  <button
                    onClick={() => handleAcceptCall(incomingCall)}
                    className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-xl"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleDeclineCall(incomingCall)}
                    className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-xl"
                  >
                    Decline
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  )
}

export default RootLayout
