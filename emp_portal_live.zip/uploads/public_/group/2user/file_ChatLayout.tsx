import { useEffect, useMemo, useRef, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import ChatHeader from 'renderer/components/sections/ChatHeader'
import ChatMessageInput from 'renderer/components/sections/ChatMessageInput'
import ChatSidebar from 'renderer/components/sections/ChatSidebar'
import { Chat_history, ChatGroup_history, startCall, startCallGroup } from 'renderer/service/authService';
import { useMutation } from '@tanstack/react-query';
import useAuthStore from 'renderer/store/AuthStore';
import BaseUrl from 'renderer/service/BaseUrl';
import ChatController from 'renderer/Controller/ChatController';
import { useChatStore, usePageStore, useUserStatusStore } from 'stores/useChatStore';
import ChatHeaderGroup from 'renderer/components/sections/ChatHeaderGroup';
import ChatMessageGroup from 'renderer/components/sections/ChatMessageGroup';
import { createGroupRoom, createRoom, getToken } from 'renderer/service/connectServices';
import { useLivekitRoom } from 'renderer/hooks/useLiveKitRoom';
const serverUrl = BaseUrl.LIVEKIT_URL;

const ChatLayout = () => {
    const navigate = useNavigate();
    const pathname = useLocation().pathname
    const { selectedUser, chatInfo, selectedToken, selectGroup, callFlag, selectCallerInfo, selectGroupID, group_UserId, setSelectedUser, setChatInfo, setSelectedToken, setSelectGroup, setSelectGroupCallActive, setSelectCallerInfo } = useChatStore();
    const { setPageCount } = usePageStore();
    const [activeChat, setActiveChat] = useState<any>();
    const [replyMessage, setReplyMessage] = useState<any>(null);
    const { pagecount } = usePageStore();
    const [forwardMessage, setForwardMessage] = useState<any>(null);
    const fileChunksRef = useRef<{ [key: string]: { chunks: string[]; fileName: string } }>({});
    const [messages, setMessages] = useState<{ sender: string; text: string; file: string, sender_id: string, delivered_at: string, msg_id: string, }[]>([]);
    const [incomingCall, setIncomingCall] = useState<any>(null);
    const [activeTab, setActiveTab] = useState<string>(pathname === "/chat/group" ? "groups" : 'users');
    const [isAduioCall, setisAduioCall] = useState<any>(null);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);
    const ResUser = useAuthStore.getState().getUser();
    const selectedUserId = useMemo(() => selectedUser?.id, [selectedUser]);
    const selectGroupId = useMemo(() => selectGroup?.groupId, [selectGroup]);

    const {
        room: livekitRoom,
        sendMessage,
    } = useLivekitRoom({
        token: selectedToken,
        serverUrl,
        callFlag,
        onData: (data: any, participant: any) => {
            try {
                ChatController.callbackSocket('messageDelivered', { msg_id: data.id })
                const isGroup = data.toGroup ? data.toGroup : data.sender_id;
                const isSelect = data.toGroup ? selectGroup?.groupId : selectedUser?.id;

                if (String(isGroup ?? '') === String(isSelect ?? '')) {
                    if (data.isChunk) {
                        const { fileId, fileName, delivered_at, sender_id, chunk, isLast, isReply, replyTo, replyMessage } = data;
                        if (!fileChunksRef.current[fileId]) {
                            fileChunksRef.current[fileId] = { chunks: [], fileName };
                        }
                        fileChunksRef.current[fileId].chunks.push(chunk);
                        if (isLast) {
                            setTimeout(() => {
                                const isGroupChat = !!chatInfo?.groupId;
                                const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;
                                if (chatId) {
                                    if (data.toUser === ResUser?.id && data.chat_type === 'User') getChat_historys(chatId);
                                    if (data.chat_type === 'Group') getChat_historys(chatId);
                                }
                                delete fileChunksRef.current[fileId];
                            }, 300);
                        }
                    } else {
                        if (data.isReply) {
                            const isGroupChat = !!chatInfo?.groupId;
                            const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;
                            if (chatId) {
                                if (data.toUser === ResUser?.id && data.chat_type === 'User') getChat_historys(chatId);
                                if (data.chat_type === 'Group') getChat_historys(chatId);
                            }
                        } else {
                            if (data.toUser === ResUser?.id && data.chat_type === 'User') {
                                setMessages((prev) => [
                                    ...prev,
                                    {
                                        sender: participant?.name ?? "",
                                        sender_id: String(data.sender_id),
                                        text: data.text,
                                        delivered_at: data.delivered_at,
                                        file: data.file || null,
                                        isReply: data.isReply,
                                        replyTo: data.replyTo,
                                        replyMessage: data.replyMessage || null,
                                        msg_id: data.id,
                                        status: 'delivered'
                                    },
                                ]);
                                ChatController.callbackSocket('messageRead', { msg_id: data.id })
                            }
                            if (data.chat_type === 'Group') {
                                setMessages((prev) => [
                                    ...prev,
                                    {
                                        sender: participant?.name ?? "",
                                        sender_id: String(data.sender_id),
                                        text: data.text,
                                        delivered_at: data.delivered_at,
                                        file: data.file || null,
                                        isReply: data.isReply,
                                        replyTo: data.replyTo,
                                        replyMessage: data.replyMessage || null,
                                        msg_id: data.id,
                                        status: ''
                                    },
                                ]);
                            }
                        }
                    }
                }
            } catch (error) {
                console.log('Error parsing data:', error);
            }
        },
    });

    useEffect(() => {
        ConnectUser()
    }, [selectedToken, selectedUserId, selectGroupId]);

    const ConnectUser = async () => {
        await ChatController.connectUser(ResUser?.id || "")
    }

    useEffect(() => {
        setMessages([]);
        const isGroupChat = !!chatInfo?.groupId;
        const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;
        if (chatId) getChat_historys(chatId);
    }, [selectedUser, selectGroup]);

    useEffect(() => {
        if (activeTab === 'users') setSelectGroup(null)
        else if (activeTab === 'groups') setSelectedUser(null)
    }, [activeTab])

    useEffect(() => {
        const handleReceivedNotification = async (data: any) => {
            if (!selectedUser) return;
            if (data.to !== ResUser?.id) return;
            if (data.chat_type !== "User") return;
            if (data.isForward && selectedUser.id === data.sender_id) {
                getForward_historys(data.chat_id, '1', '10')
                ForwardReconnect(data)
            }
        };
        const socket = ChatController.getSocket();
        if (!socket) return;
        socket.on("notification", handleReceivedNotification);
        return () => {
            socket.off("notification", handleReceivedNotification);
        };
    }, [selectedUser])

    useEffect(() => {
        SocketHandle()
    }, [])

    const SocketHandle = async () => {
        let socket: any;
        const handleCallNotification = (data: any) => {
            const latestSelectGroupID = useChatStore.getState().selectGroupID;
            if (data.chat_type === 'Group') {
                if (data.to !== Number(ResUser?.id)) {
                    if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) return;
                    if (latestSelectGroupID.includes(Number(data.groupId))) {
                        setIncomingCall(data);
                        setisAduioCall(false)
                    }
                }
            } else {
                if (data.to === String(ResUser?.id)) {
                    setIncomingCall(data);
                    setisAduioCall(false)
                }
            }
        }
        const handleCallEndedNotification = async () => {
            setIncomingCall(null);
            setSelectCallerInfo(null)
        };
        const handleRejionNotification = async (RejionNotification: any) => {
            if (!selectCallerInfo) setSelectCallerInfo(RejionNotification.data)
        };
        const handleRejionEndNotification = async () => {
            if (selectCallerInfo) setSelectCallerInfo('')
        };

        const setupListeners = () => {
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("rejoin-start", handleRejionNotification)
            socket.on("rejoin-end", handleRejionEndNotification)
            socket.on("call-notification", handleCallNotification)
            socket.on("call-ended", handleCallEndedNotification);
        };
        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("rejoin-start", handleRejionNotification)
            socket.off("rejoin-end", handleRejionEndNotification)
            socket.off("call-notification", handleCallNotification)
            socket.off("call-ended", handleCallEndedNotification);
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();
                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        await waitForSocketReady();
        setupListeners();
        return () => {
            cleanupListeners();
        };
    }

    const handleStatus = (data: any) => {
        if (data?.userId) {
            useUserStatusStore.getState().updateStatus(data);
        }
    };

    const getChat_historys = async (chatInfo: any) => {
        if (!chatInfo) return;
        if (pagecount === 1) {
            if (selectGroup?.groupType === "group") {
                getChatGroup_history.mutate({
                    group_id: chatInfo,
                    page_number: pagecount,
                    limit: '10',
                })
            } else {
                getChat_history.mutate({
                    chat_id: chatInfo,
                    page_number: String(pagecount),
                    limit: '10',
                })
            }
        } else {
            return null;
        }
    }

    const getForward_historys = async (chat_id: any, page_number: any, limit: any) => {
        getChat_history.mutate({
            chat_id: chat_id,
            page_number: page_number,
            limit: limit,
        });
    }

    const getChat_history = useMutation({
        mutationFn: Chat_history,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const formattedMessages = response.data.map((msg: any) => ({
                    sender: msg?.sender?.userfullname ?? "Unknown",
                    sender_id: String(msg?.sender_id ?? ""),
                    text: msg?.text ?? msg?.file_name?.split('_').slice(1).join('_'),
                    delivered_at: msg?.delivered_at ?? msg.createdAt,
                    file: msg.text ? "" : msg?.file_name ? `${BaseUrl.Url_Base}/${msg?.file_path}/${msg?.file_name}` : "",
                    msg_id: String(msg?.id),
                    reply_to_id: msg?.reply_to_id || null,
                    replyTo: msg?.replyTo || null,
                    forwardedFrom: msg?.forwardedFrom || null,
                    start_time: msg?.start_time || null,
                    end_time: msg?.end_time || null,
                    duration: msg?.duration || null,
                    chat_type: msg?.chat_type || null,
                    call_type: msg?.call_type || null,
                    status: ''
                }));
                setMessages(formattedMessages);
                const lastElement = formattedMessages[formattedMessages.length - 1];
                ChatController.callbackSocket('messageRead', { msg_id: lastElement.msg_id })
            }
        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    });

    const getChatGroup_history = useMutation({
        mutationFn: ChatGroup_history,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const formattedMessages = response.data.map((msg: any) => ({
                    sender: msg.sender?.userfullname ?? "Unknown",
                    sender_id: String(msg.sender_id ?? ""),
                    text: msg?.text ?? msg?.file_name?.split('_').slice(1).join('_'),
                    delivered_at: msg?.delivered_at ?? msg.createdAt,
                    file: msg?.text ? "" : msg?.file_name ? `${BaseUrl.Url_Base}/${msg?.file_path}/${msg?.file_name}` : "",
                    msg_id: String(msg?.id),
                    reply_to_id: msg?.reply_to_id || null,
                    replyTo: msg?.replyTo || null,
                    forwardedFrom: msg?.forwardedFrom || null,
                    start_time: msg?.start_time || null,
                    end_time: msg?.end_time || null,
                    duration: msg?.duration || null,
                    chat_type: msg?.chat_type || null,
                    call_type: msg?.call_type || null,
                    status: ''
                }));
                setMessages(formattedMessages);
            }
        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    });

    const handleAcceptCall = (callData: any) => {
        if (!callData) return;
        const isVideo = callData?.type === 'video';
        const isUserCall = callData?.chat_type === 'User';
        const isGroupCall = callData?.chat_type === 'Group';
        if (isVideo) {
            if (isUserCall) {
                if (selectedUser && callData.from === String(selectedUser.id)) {
                    navigate('/connect/RoomMeeting', { state: { token: selectedToken, selectedUser: callData } });
                    handleCall("1", callData);
                } else {
                    UserConnectChatVideo(callData);
                }
            } else if (isGroupCall) {
                if (selectGroup && callData.groupId === selectGroup.groupId) {
                    navigate('/connect/RoomGroupMeeting', { state: { token: selectedToken, selectedUser: callData } });
                    handleCall("1", callData);
                } else {
                    GroupConnectChatVideo(callData);
                }
            }
        } else {
            if (isUserCall) {
                if (selectedUser && callData.from === String(selectedUser.id)) {
                    setIncomingCall(null);
                    const data = {
                        senderId: String(callData.from),
                    }
                    ChatController.callbackSocket('callAccepted', data)
                    navigate('/connect/AudioMeeting', {
                        state: {
                            token: selectedToken,
                            selectedUser: callData,
                            screenType: 'ChatLayout',
                        },
                    });
                } else {
                    UserConnectChat(callData);
                }
            } else if (isGroupCall) {
                if (selectGroup && callData.groupId === selectGroup.groupId) {
                    setIncomingCall(null);
                    const data = {
                        senderId: String(callData.from),
                        groupId: callData.groupId,
                        chat_type: 'Group'
                    }
                    ChatController.callbackSocket('callAccepted', data)
                    navigate('/connect/AudioGroupMeeting', { state: { token: selectedToken, selectedUser: callData, screenType: 'ChatLayout' } })
                }
                else {
                    UserConnectGroupChat(callData)
                }

                setSelectGroupCallActive(callData);
            }
        }
    };


    const UserConnectChat = async (CallUser: any) => {
        try {

            if (!ResUser?.id || !CallUser?.from) {
                console.warn("User IDs missing, cannot create room");
                return;
            }
            const createRoomPayload = {
                fromUserId: ResUser.id,
                toUserId: CallUser.from,
            };

            const roomResponse = await createRoom(
                createRoomPayload.fromUserId,
                createRoomPayload.toUserId
            );
            setPageCount(1);
            setSelectedUser(CallUser ?? selectedUser);
            setChatInfo(roomResponse.chat);
            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.userfullname,
                    userId: CallUser.senderId || selectedUser.id,
                    metadata: JSON.stringify({
                        callerId: CallUser.id,
                        callerName: ResUser.userfullname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );

                setSelectedToken(tokenRes.token);
                handleCall('0', CallUser)
                setIncomingCall(null);
                const data = {
                    senderId: String(CallUser.from),
                    groupId: '',
                    chat_type: 'User'
                }
                ChatController.callbackSocket('callAccepted', data)
                navigate('/connect/AudioMeeting', { state: { token: tokenRes.token, selectedUser: CallUser, screenType: 'ChatLayout' } })

            }
        } catch (err) {
            console.error("❌ Error in initializeChat:", err);
        }
    };
    const UserConnectChatVideo = async (CallUser: any) => {
        try {
            if (!ResUser?.id || !CallUser?.from) {
                console.warn("User IDs missing, cannot create room");
                return;
            }
            const createRoomPayload = {
                fromUserId: ResUser.id,
                toUserId: CallUser.from,
            };

            const roomResponse = await createRoom(
                createRoomPayload.fromUserId,
                createRoomPayload.toUserId
            );
            setPageCount(1);
            setSelectedUser(selectedUser);
            setChatInfo(roomResponse.chat);
            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.userfullname,
                    userId: ResUser.id,
                    metadata: JSON.stringify({
                        callerId: CallUser.id,
                        callerName: ResUser.userfullname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );

                setSelectedToken(tokenRes.token);
                handleCall('1', CallUser)
                setIncomingCall(null);
                const data = {
                    senderId: String(CallUser.from),
                    groupId: '',
                    chat_type: 'User'
                }
                ChatController.callbackSocket('callAccepted', data)
                navigate('/connect/RoomMeeting', { state: { token: tokenRes.token, selectedUser: CallUser } })

            }
        } catch (err) {
            console.error("❌ Error in initializeChat:", err);
        }
    }

    const UserConnectGroupChat = async (CallGroup: any) => {
        try {
            if (!ResUser?.id) {
                return;
            }

            const createRoomPayload = {
                userIds: CallGroup.memberIds,
                groupId: CallGroup.groupId,
            };

            const roomResponse = await createGroupRoom(
                createRoomPayload.groupId,
                createRoomPayload.userIds
            );
            setPageCount(1);
            setSelectGroup(CallGroup);

            setChatInfo(CallGroup);
            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.userfullname,
                    userId: ResUser?.id,
                    metadata: JSON.stringify({
                        callerId: ResUser?.id,
                        callerName: ResUser.userfullname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );

                setSelectedToken(tokenRes.token);
                setIncomingCall(null);
                const data = {
                    senderId: String(CallGroup.from),
                    groupId: CallGroup.groupId,
                    chat_type: 'Group'
                }
                ChatController.callbackSocket('callAccepted', data)
                navigate('/connect/AudioGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup, screenType: 'ChatLayout' } })
            }
        } catch (err) {
        }

    }
    const GroupConnectChatVideo = async (CallGroup: any) => {
        try {
            if (!ResUser?.id) {
                return;
            }

            const createRoomPayload = {
                userIds: CallGroup.memberIds,
                groupId: CallGroup.groupId,
            };

            const roomResponse = await createGroupRoom(
                createRoomPayload.groupId,
                createRoomPayload.userIds
            );
            setPageCount(1);
            setSelectGroup(CallGroup);

            setChatInfo(CallGroup);
            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.userfullname,
                    userId: ResUser?.id,
                    metadata: JSON.stringify({
                        callerId: CallGroup.groupId,
                        callerName: ResUser.userfullname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );

                setSelectedToken(tokenRes.token);
                handleCall('1', CallGroup)
                setIncomingCall(null);
                const data = {
                    senderId: String(CallGroup.from),
                    groupId: CallGroup.groupId,
                    chat_type: 'Group'

                }
                ChatController.callbackSocket('callAccepted', data)
                navigate('/connect/RoomGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup } })

            }
        } catch (err) {
            console.error("❌ Error in initializeChat:", err);
        }

    }

    const handleCall = async (call_types: any, callData: any) => {
        if (callData.chat_type === "Group") {
            const response = await startCallGroup({ group_id: callData?.groupId, caller_id: String(callData?.senderId) || "", call_type: call_types });
            if (response?.data) {
                setSelectCallerInfo(response.data)
                ChatController.callbackSocket('StartAudioCall', {
                    audioCallerId: response.data.id,
                });
            }
        } else {
            const response = await startCall({ chat_id: chatInfo?.id, caller_id: callData?.senderId || "", call_type: call_types });
            if (response?.data) {
                setSelectCallerInfo(response.data)
                ChatController.callbackSocket('StartAudioCall', {
                    audioCallerId: response.data.id,
                });

            }

        }
    }


    const HandleMassage = (data: any) => {
        if (data.type === 'group') {
            if (data.isReply) {
                const chatId = chatInfo?.groupId;
                getChat_historys(chatId);
            } else {
                setMessages((prev) => [
                    ...prev,
                    { msg_id: data.id, sender: data?.sender ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || undefined, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, status: '' },
                ]);
            }
            setForwardMessage(null);
            setReplyMessage(null);
        } else {
            if (data.isReply) {
                const chatId = chatInfo?.id;
                getChat_historys(chatId);
            } else {
                setMessages((prev) => [
                    ...prev,
                    { msg_id: data.id, sender: data?.sender ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || undefined, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, status: 'sent' },
                ]);
            }
            setForwardMessage(null);
            setReplyMessage(null);
        }
    };

    const handleDeclineCall = (callData: any) => {
        setIncomingCall(null);
        if (selectGroup === 'User') {
            const data = {
                callerId: String(callData.from),
                chat_type: selectGroup ? 'Group' : 'User'
            }
            ChatController.callbackSocket('callEnded', data)
        }
    };

    const ForwardReconnect = async (ForwardInfo: any) => {
        const createRoomPayload = {
            fromUserId: ForwardInfo.to,
            toUserId: ForwardInfo?.sender_id,
        };
        const roomResponse = await createRoom(
            createRoomPayload.fromUserId,
            createRoomPayload.toUserId
        );
        setChatInfo(roomResponse.chat);
        setPageCount(1);
        setSelectedUser(selectedUser);
        if (roomResponse.room) {
            const userDetails = {
                roomName: roomResponse.room.name,
                participantName: ResUser?.userfullname ?? 'Unknown',
                userId: ForwardInfo?.sender_id,
                metadata: JSON.stringify({
                    callerId: ForwardInfo?.sender_id,
                    callerName: ResUser?.userfullname ?? 'Unknown',
                }),
            };

            const tokenRes = await getToken(
                userDetails.roomName,
                userDetails.participantName,
                userDetails.userId,
                userDetails.metadata
            );
            setSelectedToken(tokenRes.token);
        }
    }

    return (
        <div className='flex h-full flex-grow'>
            <ChatSidebar room={livekitRoom} forwardedChat={activeChat} activeTab={activeTab} setActiveTab={setActiveTab} setReplyReset={() => setReplyMessage(null)} />
            {selectGroup && livekitRoom && (
                <div className='w-1/2 flex-grow flex flex-col h-[calc(100vh-67px)]'>
                    <ChatHeaderGroup groupInfo={chatInfo} room={livekitRoom} selectGroup={selectGroup} chatInfo={chatInfo} selectedToken={selectedToken ?? undefined} isAudioCall={isAduioCall} selectCallerInfo={selectCallerInfo} />
                    <div className='flex-grow overflow-auto'>
                        <Outlet context={{
                            room: livekitRoom, selectedToken, messages, activeTab, setActiveTab, selectGroup, selectedUser, setReplyMessage, replyMessage, forwardMessage, setForwardMessage, setActiveChat, appendMessages: (newMessages: []) => {
                                setMessages(prev => [...newMessages, ...prev])
                            }, setMessages
                        }} />
                    </div>
                    <ChatMessageGroup
                        room={livekitRoom}
                        groupInfo={chatInfo}
                        messages={messages}
                        selectGroup={selectGroup}
                        setReplyMessage={setReplyMessage}
                        replyMessage={replyMessage}
                        setForwardMessage={setForwardMessage}
                        HandleMassage={HandleMassage}
                    />
                </div>
            )}

            {selectedUser && livekitRoom && (
                <div className='w-1/2 flex-grow flex flex-col h-[calc(100vh-67px)]'>
                    <ChatHeader room={livekitRoom} selectedUser={selectedUser} chatInfo={chatInfo} selectedToken={selectedToken ?? ''} isAudioCall={isAduioCall} />
                    <div className='flex-grow overflow-auto'>
                        <Outlet context={{
                            room: livekitRoom, selectedToken, activeTab, setActiveTab, messages, selectedUser, setReplyMessage, replyMessage, forwardMessage, setForwardMessage, setActiveChat, setMessages, appendMessages: (newMessages: []) => {
                                setMessages(prev => [...newMessages, ...prev])
                            }
                        }} />
                    </div>
                    <ChatMessageInput sendMessage={sendMessage} room={livekitRoom} selectedUser={selectedUser} chatInfo={chatInfo} HandleMassage={HandleMassage} setReplyMessage={setReplyMessage} setForwardMessage={setForwardMessage} replyMessage={replyMessage} />
                </div>
            )}

            {incomingCall && (
                <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-40 flex items-center justify-center z-50">
                    <div className="bg-white rounded-2xl shadow-xl p-6 w-[300px] text-center">
                        <h2 className="text-xl font-semibold mb-4">📞 Incoming Call</h2>
                        <p className="mb-6">{incomingCall.name || 'Unknown User'} is calling...</p>
                        <div className="flex justify-around">
                            <button
                                onClick={() => handleAcceptCall(incomingCall)}
                                className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-xl"
                            >
                                Accept
                            </button>
                            <button
                                onClick={() => handleDeclineCall(incomingCall)}
                                className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-xl"
                            >
                                Decline
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

export default ChatLayout